﻿namespace SmartHostelManagement.Seminar
{
    partial class frmSeminarBookingEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label23 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.label47 = new System.Windows.Forms.Label();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.label44 = new System.Windows.Forms.Label();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnUndo = new System.Windows.Forms.Button();
            this.txtEntryNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnMemo = new System.Windows.Forms.Button();
            this.btnReceipt = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnOpenByEntryNo = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnRefersh = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.dtmTodate = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.dtmFromDate = new System.Windows.Forms.DateTimePicker();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnCancelHostory = new System.Windows.Forms.Button();
            this.btnCancellations = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.chkServiceExmpt = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLogLT = new System.Windows.Forms.TextBox();
            this.grdReservDetails = new System.Windows.Forms.DataGridView();
            this.btnLogNew = new System.Windows.Forms.Button();
            this.btnLogAdd = new System.Windows.Forms.Button();
            this.txtLogAmount = new System.Windows.Forms.TextBox();
            this.btnLogRemove = new System.Windows.Forms.Button();
            this.txtLogHrs = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtLogST = new System.Windows.Forms.TextBox();
            this.cmbLogItem = new System.Windows.Forms.ComboBox();
            this.txtLogQuantity = new System.Windows.Forms.TextBox();
            this.txtLogPrice = new System.Windows.Forms.TextBox();
            this.dtmLogDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbSeminarType = new System.Windows.Forms.ComboBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cmbHallName = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtRent = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTotalReceipt = new System.Windows.Forms.Label();
            this.lblCustStatus = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dtmAddConference = new System.Windows.Forms.DataGridView();
            this.label19 = new System.Windows.Forms.Label();
            this.dtmAddUptoDate = new System.Windows.Forms.DateTimePicker();
            this.txtaddRemarks = new System.Windows.Forms.TextBox();
            this.cmbAddSeminarType = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtAddRent = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnAddCNew = new System.Windows.Forms.Button();
            this.btnAddCAddChange = new System.Windows.Forms.Button();
            this.btnAddCRemove = new System.Windows.Forms.Button();
            this.cmbAddHallName = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtmAddFromDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtOrgans = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtmReservTo = new System.Windows.Forms.DateTimePicker();
            this.btnSelectGuest = new System.Windows.Forms.Button();
            this.btnAddGuest = new System.Windows.Forms.Button();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtDiscountPer = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblRecepDesc7 = new System.Windows.Forms.Label();
            this.lblReceiptNo7 = new System.Windows.Forms.Label();
            this.txtReceipt7 = new System.Windows.Forms.TextBox();
            this.lblRecepDesc6 = new System.Windows.Forms.Label();
            this.lblRecepDesc5 = new System.Windows.Forms.Label();
            this.lblReceiptNo6 = new System.Windows.Forms.Label();
            this.txtReceipt6 = new System.Windows.Forms.TextBox();
            this.lblReceiptNo5 = new System.Windows.Forms.Label();
            this.txtReceipt5 = new System.Windows.Forms.TextBox();
            this.lblRecepDesc4 = new System.Windows.Forms.Label();
            this.lblReceiptNo4 = new System.Windows.Forms.Label();
            this.txtReceipt4 = new System.Windows.Forms.TextBox();
            this.lblRecepDesc3 = new System.Windows.Forms.Label();
            this.lblRecepDesc2 = new System.Windows.Forms.Label();
            this.lblRecepDesc1 = new System.Windows.Forms.Label();
            this.lblRecepDesc0 = new System.Windows.Forms.Label();
            this.lblReceiptNo3 = new System.Windows.Forms.Label();
            this.txtReceipt3 = new System.Windows.Forms.TextBox();
            this.lblReceiptNo2 = new System.Windows.Forms.Label();
            this.txtReceipt2 = new System.Windows.Forms.TextBox();
            this.lblReceiptNo1 = new System.Windows.Forms.Label();
            this.txtReceipt1 = new System.Windows.Forms.TextBox();
            this.lblReceiptAmt0 = new System.Windows.Forms.Label();
            this.txtReceipt0 = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnCatNew = new System.Windows.Forms.Button();
            this.btnCatAddChange = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnCatRemove = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.cmbCatItems = new System.Windows.Forms.ComboBox();
            this.txtCatQuantity = new System.Windows.Forms.TextBox();
            this.txtCatPrice = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdReservDetails)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtmAddConference)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 5);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(98, 14);
            this.label23.TabIndex = 58;
            this.label23.Text = "Entry Number";
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(7, 44);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(963, 463);
            this.dataGridView4.TabIndex = 73;
            this.dataGridView4.TabStop = false;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(204, 20);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(28, 14);
            this.label47.TabIndex = 72;
            this.label47.Text = "To:";
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker7.CustomFormat = "dd/MMM/yyyy";
            this.dateTimePicker7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker7.Location = new System.Drawing.Point(236, 16);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker7.TabIndex = 51;
            this.dateTimePicker7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(12, 20);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(46, 14);
            this.label44.TabIndex = 70;
            this.label44.Text = "From:";
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker6.CustomFormat = "dd/MMM/yyyy";
            this.dateTimePicker6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker6.Location = new System.Drawing.Point(59, 16);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker6.TabIndex = 50;
            this.dateTimePicker6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.dataGridView4);
            this.tabPage3.Controls.Add(this.label47);
            this.tabPage3.Controls.Add(this.dateTimePicker7);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.dateTimePicker6);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(973, 512);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Reservation Chart";
            // 
            // btnUndo
            // 
            this.btnUndo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUndo.Location = new System.Drawing.Point(7, 35);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(89, 26);
            this.btnUndo.TabIndex = 37;
            this.btnUndo.Text = "Undo";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            this.btnUndo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtEntryNo
            // 
            this.txtEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryNo.Location = new System.Drawing.Point(105, 2);
            this.txtEntryNo.MaxLength = 10;
            this.txtEntryNo.Name = "txtEntryNo";
            this.txtEntryNo.Size = new System.Drawing.Size(114, 22);
            this.txtEntryNo.TabIndex = 1;
            this.txtEntryNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEntryNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtEntryNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 14);
            this.label1.TabIndex = 58;
            this.label1.Text = "Title";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(460, 7);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(84, 27);
            this.btnSearch.TabIndex = 44;
            this.btnSearch.Text = "Serach";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            this.btnSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnMemo
            // 
            this.btnMemo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemo.Location = new System.Drawing.Point(333, 6);
            this.btnMemo.Name = "btnMemo";
            this.btnMemo.Size = new System.Drawing.Size(119, 27);
            this.btnMemo.TabIndex = 42;
            this.btnMemo.Text = "Memo";
            this.btnMemo.UseVisualStyleBackColor = true;
            this.btnMemo.Click += new System.EventHandler(this.btnMemo_Click);
            this.btnMemo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnReceipt
            // 
            this.btnReceipt.AutoSize = true;
            this.btnReceipt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReceipt.Location = new System.Drawing.Point(736, 35);
            this.btnReceipt.Name = "btnReceipt";
            this.btnReceipt.Size = new System.Drawing.Size(99, 27);
            this.btnReceipt.TabIndex = 41;
            this.btnReceipt.Text = "Receipts";
            this.btnReceipt.UseVisualStyleBackColor = true;
            this.btnReceipt.Click += new System.EventHandler(this.btnReceipt_Click);
            this.btnReceipt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(460, 34);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(84, 27);
            this.btnDelete.TabIndex = 45;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            this.btnDelete.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnOpenByEntryNo
            // 
            this.btnOpenByEntryNo.AutoSize = true;
            this.btnOpenByEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenByEntryNo.Location = new System.Drawing.Point(570, 35);
            this.btnOpenByEntryNo.Name = "btnOpenByEntryNo";
            this.btnOpenByEntryNo.Size = new System.Drawing.Size(153, 27);
            this.btnOpenByEntryNo.TabIndex = 50;
            this.btnOpenByEntryNo.Text = "Open By Entry No";
            this.btnOpenByEntryNo.UseVisualStyleBackColor = true;
            this.btnOpenByEntryNo.Click += new System.EventHandler(this.btnOpenByEntryNo_Click);
            this.btnOpenByEntryNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnExit
            // 
            this.btnExit.AutoSize = true;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(858, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(92, 39);
            this.btnExit.TabIndex = 51;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            this.btnExit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnFirst
            // 
            this.btnFirst.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(548, 6);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(56, 27);
            this.btnFirst.TabIndex = 46;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            this.btnFirst.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnRefersh
            // 
            this.btnRefersh.AutoSize = true;
            this.btnRefersh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefersh.Location = new System.Drawing.Point(333, 35);
            this.btnRefersh.Name = "btnRefersh";
            this.btnRefersh.Size = new System.Drawing.Size(119, 27);
            this.btnRefersh.TabIndex = 40;
            this.btnRefersh.Text = "Refresh Chart";
            this.btnRefersh.UseVisualStyleBackColor = true;
            this.btnRefersh.Click += new System.EventHandler(this.btnRefersh_Click);
            this.btnRefersh.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnLast
            // 
            this.btnLast.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.Location = new System.Drawing.Point(725, 7);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(54, 27);
            this.btnLast.TabIndex = 49;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            this.btnLast.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(666, 7);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(56, 27);
            this.btnNext.TabIndex = 48;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            this.btnNext.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnPrev
            // 
            this.btnPrev.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrev.Location = new System.Drawing.Point(607, 7);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(56, 27);
            this.btnPrev.TabIndex = 47;
            this.btnPrev.Text = "<";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            this.btnPrev.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(208, 35);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(114, 27);
            this.btnPrint.TabIndex = 43;
            this.btnPrint.Text = "Bill";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            this.btnPrint.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(104, 34);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 27);
            this.btnSave.TabIndex = 39;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            this.btnSave.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(104, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(90, 27);
            this.btnEdit.TabIndex = 38;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            this.btnEdit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNew.Location = new System.Drawing.Point(7, 7);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(89, 27);
            this.btnAddNew.TabIndex = 36;
            this.btnAddNew.Text = "Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            this.btnAddNew.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(260, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 14);
            this.label8.TabIndex = 102;
            this.label8.Text = "Upto";
            // 
            // dtmTodate
            // 
            this.dtmTodate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmTodate.CustomFormat = "dd/MMM/yyyy HH:mm";
            this.dtmTodate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmTodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmTodate.Location = new System.Drawing.Point(299, 3);
            this.dtmTodate.Name = "dtmTodate";
            this.dtmTodate.Size = new System.Drawing.Size(161, 22);
            this.dtmTodate.TabIndex = 14;
            this.dtmTodate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 14);
            this.label7.TabIndex = 100;
            this.label7.Text = "Reserv From";
            // 
            // dtmFromDate
            // 
            this.dtmFromDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFromDate.CustomFormat = "dd/MMM/yyyy HH:mm";
            this.dtmFromDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmFromDate.Location = new System.Drawing.Point(96, 3);
            this.dtmFromDate.Name = "dtmFromDate";
            this.dtmFromDate.Size = new System.Drawing.Size(161, 22);
            this.dtmFromDate.TabIndex = 12;
            this.dtmFromDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(244, 21);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(981, 541);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.btnCancelHostory);
            this.tabPage1.Controls.Add(this.btnCancellations);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.chkServiceExmpt);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.lblTotalReceipt);
            this.tabPage1.Controls.Add(this.lblCustStatus);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.txtDiscountPer);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(973, 512);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Reservation Information";
            // 
            // btnCancelHostory
            // 
            this.btnCancelHostory.AutoSize = true;
            this.btnCancelHostory.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelHostory.Location = new System.Drawing.Point(863, 368);
            this.btnCancelHostory.Name = "btnCancelHostory";
            this.btnCancelHostory.Size = new System.Drawing.Size(105, 38);
            this.btnCancelHostory.TabIndex = 129;
            this.btnCancelHostory.Text = " Cancel \n HIstory";
            this.btnCancelHostory.UseVisualStyleBackColor = true;
            this.btnCancelHostory.Click += new System.EventHandler(this.btnCancelHostory_Click);
            // 
            // btnCancellations
            // 
            this.btnCancellations.AutoSize = true;
            this.btnCancellations.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancellations.Location = new System.Drawing.Point(863, 334);
            this.btnCancellations.Name = "btnCancellations";
            this.btnCancellations.Size = new System.Drawing.Size(105, 27);
            this.btnCancellations.TabIndex = 52;
            this.btnCancellations.Text = "Cancellations";
            this.btnCancellations.UseVisualStyleBackColor = true;
            this.btnCancellations.Click += new System.EventHandler(this.btnCancellations_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 294);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 14);
            this.label4.TabIndex = 113;
            this.label4.Text = "Logical Detail";
            // 
            // chkServiceExmpt
            // 
            this.chkServiceExmpt.BackColor = System.Drawing.Color.Red;
            this.chkServiceExmpt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkServiceExmpt.Location = new System.Drawing.Point(406, 266);
            this.chkServiceExmpt.Name = "chkServiceExmpt";
            this.chkServiceExmpt.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.chkServiceExmpt.Size = new System.Drawing.Size(86, 23);
            this.chkServiceExmpt.TabIndex = 128;
            this.chkServiceExmpt.Text = "ST Exem";
            this.chkServiceExmpt.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkServiceExmpt.UseCompatibleTextRendering = true;
            this.chkServiceExmpt.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtLogLT);
            this.panel2.Controls.Add(this.grdReservDetails);
            this.panel2.Controls.Add(this.btnLogNew);
            this.panel2.Controls.Add(this.btnLogAdd);
            this.panel2.Controls.Add(this.txtLogAmount);
            this.panel2.Controls.Add(this.btnLogRemove);
            this.panel2.Controls.Add(this.txtLogHrs);
            this.panel2.Controls.Add(this.label55);
            this.panel2.Controls.Add(this.label54);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.txtLogST);
            this.panel2.Controls.Add(this.cmbLogItem);
            this.panel2.Controls.Add(this.txtLogQuantity);
            this.panel2.Controls.Add(this.txtLogPrice);
            this.panel2.Controls.Add(this.dtmLogDate);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(3, 303);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(855, 207);
            this.panel2.TabIndex = 127;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(620, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 14);
            this.label6.TabIndex = 130;
            this.label6.Text = "LT";
            // 
            // txtLogLT
            // 
            this.txtLogLT.BackColor = System.Drawing.Color.White;
            this.txtLogLT.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogLT.Location = new System.Drawing.Point(648, 37);
            this.txtLogLT.MaxLength = 40000;
            this.txtLogLT.Name = "txtLogLT";
            this.txtLogLT.Size = new System.Drawing.Size(84, 22);
            this.txtLogLT.TabIndex = 129;
            this.txtLogLT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLogLT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtLogLT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtLogLT.Leave += new System.EventHandler(this.txtLogPrice_Leave);
            // 
            // grdReservDetails
            // 
            this.grdReservDetails.AllowUserToAddRows = false;
            this.grdReservDetails.AllowUserToDeleteRows = false;
            this.grdReservDetails.AllowUserToOrderColumns = true;
            this.grdReservDetails.AllowUserToResizeColumns = false;
            this.grdReservDetails.AllowUserToResizeRows = false;
            this.grdReservDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdReservDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.grdReservDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdReservDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdReservDetails.Location = new System.Drawing.Point(3, 61);
            this.grdReservDetails.MultiSelect = false;
            this.grdReservDetails.Name = "grdReservDetails";
            this.grdReservDetails.ReadOnly = true;
            this.grdReservDetails.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdReservDetails.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.grdReservDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdReservDetails.ShowCellErrors = false;
            this.grdReservDetails.ShowCellToolTips = false;
            this.grdReservDetails.ShowEditingIcon = false;
            this.grdReservDetails.ShowRowErrors = false;
            this.grdReservDetails.Size = new System.Drawing.Size(849, 142);
            this.grdReservDetails.TabIndex = 128;
            this.grdReservDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdReservDetails_CellDoubleClick);
            // 
            // btnLogNew
            // 
            this.btnLogNew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogNew.Location = new System.Drawing.Point(574, 7);
            this.btnLogNew.Name = "btnLogNew";
            this.btnLogNew.Size = new System.Drawing.Size(84, 24);
            this.btnLogNew.TabIndex = 32;
            this.btnLogNew.Text = "&New";
            this.btnLogNew.UseVisualStyleBackColor = true;
            this.btnLogNew.Click += new System.EventHandler(this.btnDetNew_Click);
            this.btnLogNew.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnLogAdd
            // 
            this.btnLogAdd.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogAdd.Location = new System.Drawing.Point(660, 7);
            this.btnLogAdd.Name = "btnLogAdd";
            this.btnLogAdd.Size = new System.Drawing.Size(103, 24);
            this.btnLogAdd.TabIndex = 33;
            this.btnLogAdd.Text = "&Add/Change";
            this.btnLogAdd.UseVisualStyleBackColor = true;
            this.btnLogAdd.Click += new System.EventHandler(this.btnDetAdd_Click);
            this.btnLogAdd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtLogAmount
            // 
            this.txtLogAmount.Enabled = false;
            this.txtLogAmount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogAmount.Location = new System.Drawing.Point(414, 36);
            this.txtLogAmount.MaxLength = 10;
            this.txtLogAmount.Name = "txtLogAmount";
            this.txtLogAmount.Size = new System.Drawing.Size(84, 22);
            this.txtLogAmount.TabIndex = 125;
            this.txtLogAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnLogRemove
            // 
            this.btnLogRemove.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogRemove.Location = new System.Drawing.Point(766, 7);
            this.btnLogRemove.Name = "btnLogRemove";
            this.btnLogRemove.Size = new System.Drawing.Size(84, 24);
            this.btnLogRemove.TabIndex = 34;
            this.btnLogRemove.Text = "Remo&ve";
            this.btnLogRemove.UseVisualStyleBackColor = true;
            this.btnLogRemove.Click += new System.EventHandler(this.btnDetRemove_Click);
            this.btnLogRemove.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtLogHrs
            // 
            this.txtLogHrs.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogHrs.Location = new System.Drawing.Point(293, 36);
            this.txtLogHrs.MaxLength = 10;
            this.txtLogHrs.Name = "txtLogHrs";
            this.txtLogHrs.Size = new System.Drawing.Size(56, 22);
            this.txtLogHrs.TabIndex = 124;
            this.txtLogHrs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLogHrs.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtLogHrs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtLogHrs.Leave += new System.EventHandler(this.txtLogPrice_Leave);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(155, 13);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(38, 14);
            this.label55.TabIndex = 124;
            this.label55.Text = "Item";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(5, 14);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(38, 14);
            this.label54.TabIndex = 123;
            this.label54.Text = "Date";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(502, 40);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(24, 14);
            this.label30.TabIndex = 122;
            this.label30.Text = "ST";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(258, 40);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 14);
            this.label29.TabIndex = 121;
            this.label29.Text = "Hrs";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(123, 40);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(64, 14);
            this.label28.TabIndex = 120;
            this.label28.Text = "Quantity";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(5, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 14);
            this.label10.TabIndex = 119;
            this.label10.Text = "Price";
            // 
            // txtLogST
            // 
            this.txtLogST.BackColor = System.Drawing.Color.White;
            this.txtLogST.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogST.Location = new System.Drawing.Point(530, 36);
            this.txtLogST.MaxLength = 40000;
            this.txtLogST.Name = "txtLogST";
            this.txtLogST.Size = new System.Drawing.Size(84, 22);
            this.txtLogST.TabIndex = 31;
            this.txtLogST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLogST.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtLogST.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtLogST.Leave += new System.EventHandler(this.txtLogPrice_Leave);
            // 
            // cmbLogItem
            // 
            this.cmbLogItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLogItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbLogItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLogItem.FormattingEnabled = true;
            this.cmbLogItem.Location = new System.Drawing.Point(199, 8);
            this.cmbLogItem.Name = "cmbLogItem";
            this.cmbLogItem.Size = new System.Drawing.Size(365, 22);
            this.cmbLogItem.TabIndex = 30;
            this.cmbLogItem.SelectedIndexChanged += new System.EventHandler(this.cmbLogItem_SelectedIndexChanged);
            this.cmbLogItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtLogQuantity
            // 
            this.txtLogQuantity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogQuantity.Location = new System.Drawing.Point(192, 36);
            this.txtLogQuantity.MaxLength = 10;
            this.txtLogQuantity.Name = "txtLogQuantity";
            this.txtLogQuantity.Size = new System.Drawing.Size(60, 22);
            this.txtLogQuantity.TabIndex = 29;
            this.txtLogQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLogQuantity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtLogQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtLogQuantity.Leave += new System.EventHandler(this.txtLogPrice_Leave);
            // 
            // txtLogPrice
            // 
            this.txtLogPrice.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogPrice.Location = new System.Drawing.Point(48, 36);
            this.txtLogPrice.MaxLength = 10;
            this.txtLogPrice.Name = "txtLogPrice";
            this.txtLogPrice.Size = new System.Drawing.Size(72, 22);
            this.txtLogPrice.TabIndex = 28;
            this.txtLogPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLogPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtLogPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtLogPrice.Leave += new System.EventHandler(this.txtLogPrice_Leave);
            // 
            // dtmLogDate
            // 
            this.dtmLogDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmLogDate.CustomFormat = "dd/MMM/yyyy";
            this.dtmLogDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmLogDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmLogDate.Location = new System.Drawing.Point(48, 10);
            this.dtmLogDate.Name = "dtmLogDate";
            this.dtmLogDate.Size = new System.Drawing.Size(103, 22);
            this.dtmLogDate.TabIndex = 26;
            this.dtmLogDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(353, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 14);
            this.label9.TabIndex = 126;
            this.label9.Text = "Amount";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.cmbSeminarType);
            this.panel1.Controls.Add(this.txtRemarks);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.dtmTodate);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.dtmFromDate);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.cmbHallName);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.txtRent);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(3, 152);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(466, 109);
            this.panel1.TabIndex = 126;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(5, 58);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(98, 14);
            this.label21.TabIndex = 134;
            this.label21.Text = "Seminar Type";
            // 
            // cmbSeminarType
            // 
            this.cmbSeminarType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSeminarType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSeminarType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSeminarType.FormattingEnabled = true;
            this.cmbSeminarType.Location = new System.Drawing.Point(104, 55);
            this.cmbSeminarType.Name = "cmbSeminarType";
            this.cmbSeminarType.Size = new System.Drawing.Size(358, 22);
            this.cmbSeminarType.TabIndex = 122;
            this.cmbSeminarType.SelectedIndexChanged += new System.EventHandler(this.cmbSeminarType_SelectedIndexChanged);
            // 
            // txtRemarks
            // 
            this.txtRemarks.BackColor = System.Drawing.Color.White;
            this.txtRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(41, 81);
            this.txtRemarks.MaxLength = 40000;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(420, 22);
            this.txtRemarks.TabIndex = 15;
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtRemarks.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(4, 85);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 14);
            this.label25.TabIndex = 110;
            this.label25.Text = "Rem";
            // 
            // cmbHallName
            // 
            this.cmbHallName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbHallName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbHallName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbHallName.FormattingEnabled = true;
            this.cmbHallName.Location = new System.Drawing.Point(55, 29);
            this.cmbHallName.Name = "cmbHallName";
            this.cmbHallName.Size = new System.Drawing.Size(248, 22);
            this.cmbHallName.TabIndex = 11;
            this.cmbHallName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(4, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 32);
            this.label13.TabIndex = 100;
            this.label13.Text = "Hall Name";
            // 
            // txtRent
            // 
            this.txtRent.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRent.Location = new System.Drawing.Point(345, 29);
            this.txtRent.MaxLength = 10;
            this.txtRent.Name = "txtRent";
            this.txtRent.Size = new System.Drawing.Size(116, 22);
            this.txtRent.TabIndex = 9;
            this.txtRent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRent.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtRent.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(305, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 14);
            this.label3.TabIndex = 101;
            this.label3.Text = "Rent";
            // 
            // lblTotalReceipt
            // 
            this.lblTotalReceipt.BackColor = System.Drawing.Color.LightYellow;
            this.lblTotalReceipt.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalReceipt.Location = new System.Drawing.Point(191, 264);
            this.lblTotalReceipt.Name = "lblTotalReceipt";
            this.lblTotalReceipt.Size = new System.Drawing.Size(210, 26);
            this.lblTotalReceipt.TabIndex = 125;
            this.lblTotalReceipt.Text = "Adv Recpt. : 1234567.00";
            this.lblTotalReceipt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustStatus
            // 
            this.lblCustStatus.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lblCustStatus.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustStatus.Location = new System.Drawing.Point(4, 263);
            this.lblCustStatus.Name = "lblCustStatus";
            this.lblCustStatus.Size = new System.Drawing.Size(183, 27);
            this.lblCustStatus.TabIndex = 113;
            this.lblCustStatus.Text = "Existing-Entry";
            this.lblCustStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dtmAddConference);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.dtmAddUptoDate);
            this.groupBox4.Controls.Add(this.txtaddRemarks);
            this.groupBox4.Controls.Add(this.cmbAddSeminarType);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.txtAddRent);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.btnAddCNew);
            this.groupBox4.Controls.Add(this.btnAddCAddChange);
            this.groupBox4.Controls.Add(this.btnAddCRemove);
            this.groupBox4.Controls.Add(this.cmbAddHallName);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.dtmAddFromDate);
            this.groupBox4.Location = new System.Drawing.Point(474, -1);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(496, 262);
            this.groupBox4.TabIndex = 112;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "ADDITIONAL CONFERENCES";
            // 
            // dtmAddConference
            // 
            this.dtmAddConference.AllowUserToAddRows = false;
            this.dtmAddConference.AllowUserToDeleteRows = false;
            this.dtmAddConference.AllowUserToOrderColumns = true;
            this.dtmAddConference.AllowUserToResizeColumns = false;
            this.dtmAddConference.AllowUserToResizeRows = false;
            this.dtmAddConference.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtmAddConference.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtmAddConference.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtmAddConference.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtmAddConference.Location = new System.Drawing.Point(4, 148);
            this.dtmAddConference.MultiSelect = false;
            this.dtmAddConference.Name = "dtmAddConference";
            this.dtmAddConference.ReadOnly = true;
            this.dtmAddConference.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dtmAddConference.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dtmAddConference.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtmAddConference.ShowCellErrors = false;
            this.dtmAddConference.ShowCellToolTips = false;
            this.dtmAddConference.ShowEditingIcon = false;
            this.dtmAddConference.ShowRowErrors = false;
            this.dtmAddConference.Size = new System.Drawing.Size(490, 109);
            this.dtmAddConference.TabIndex = 137;
            this.dtmAddConference.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtmAddConference_CellDoubleClick);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(1, 105);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 14);
            this.label19.TabIndex = 136;
            this.label19.Text = "Remarks";
            // 
            // dtmAddUptoDate
            // 
            this.dtmAddUptoDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmAddUptoDate.CustomFormat = "dd/MMM/yyyy HH:mm";
            this.dtmAddUptoDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmAddUptoDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmAddUptoDate.Location = new System.Drawing.Point(166, 38);
            this.dtmAddUptoDate.Name = "dtmAddUptoDate";
            this.dtmAddUptoDate.Size = new System.Drawing.Size(161, 22);
            this.dtmAddUptoDate.TabIndex = 125;
            // 
            // txtaddRemarks
            // 
            this.txtaddRemarks.BackColor = System.Drawing.Color.White;
            this.txtaddRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddRemarks.Location = new System.Drawing.Point(4, 122);
            this.txtaddRemarks.MaxLength = 40000;
            this.txtaddRemarks.Name = "txtaddRemarks";
            this.txtaddRemarks.Size = new System.Drawing.Size(251, 22);
            this.txtaddRemarks.TabIndex = 135;
            // 
            // cmbAddSeminarType
            // 
            this.cmbAddSeminarType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddSeminarType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbAddSeminarType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAddSeminarType.FormattingEnabled = true;
            this.cmbAddSeminarType.Location = new System.Drawing.Point(4, 80);
            this.cmbAddSeminarType.Name = "cmbAddSeminarType";
            this.cmbAddSeminarType.Size = new System.Drawing.Size(380, 22);
            this.cmbAddSeminarType.TabIndex = 134;
            this.cmbAddSeminarType.SelectedIndexChanged += new System.EventHandler(this.cmbSeminarType_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(1, 63);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 14);
            this.label18.TabIndex = 133;
            this.label18.Text = "Seminar Type";
            // 
            // txtAddRent
            // 
            this.txtAddRent.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddRent.Location = new System.Drawing.Point(392, 80);
            this.txtAddRent.MaxLength = 10;
            this.txtAddRent.Name = "txtAddRent";
            this.txtAddRent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtAddRent.Size = new System.Drawing.Size(101, 22);
            this.txtAddRent.TabIndex = 132;
            this.txtAddRent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAddRent.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtAddRent.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(392, 64);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 14);
            this.label17.TabIndex = 131;
            this.label17.Text = "Rent";
            // 
            // btnAddCNew
            // 
            this.btnAddCNew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCNew.Location = new System.Drawing.Point(258, 119);
            this.btnAddCNew.Name = "btnAddCNew";
            this.btnAddCNew.Size = new System.Drawing.Size(60, 25);
            this.btnAddCNew.TabIndex = 128;
            this.btnAddCNew.Text = "&New";
            this.btnAddCNew.UseVisualStyleBackColor = true;
            this.btnAddCNew.Click += new System.EventHandler(this.btnAddCNew_Click);
            // 
            // btnAddCAddChange
            // 
            this.btnAddCAddChange.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCAddChange.Location = new System.Drawing.Point(318, 119);
            this.btnAddCAddChange.Name = "btnAddCAddChange";
            this.btnAddCAddChange.Size = new System.Drawing.Size(97, 24);
            this.btnAddCAddChange.TabIndex = 129;
            this.btnAddCAddChange.Text = "&Add/Change";
            this.btnAddCAddChange.UseVisualStyleBackColor = true;
            this.btnAddCAddChange.Click += new System.EventHandler(this.btnAddCAddChange_Click);
            // 
            // btnAddCRemove
            // 
            this.btnAddCRemove.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCRemove.Location = new System.Drawing.Point(416, 119);
            this.btnAddCRemove.Name = "btnAddCRemove";
            this.btnAddCRemove.Size = new System.Drawing.Size(77, 24);
            this.btnAddCRemove.TabIndex = 130;
            this.btnAddCRemove.Text = "Remo&ve";
            this.btnAddCRemove.UseVisualStyleBackColor = true;
            this.btnAddCRemove.Click += new System.EventHandler(this.btnAddCRemove_Click);
            // 
            // cmbAddHallName
            // 
            this.cmbAddHallName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddHallName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbAddHallName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAddHallName.FormattingEnabled = true;
            this.cmbAddHallName.Location = new System.Drawing.Point(330, 38);
            this.cmbAddHallName.Name = "cmbAddHallName";
            this.cmbAddHallName.Size = new System.Drawing.Size(163, 22);
            this.cmbAddHallName.TabIndex = 125;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(326, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 14);
            this.label16.TabIndex = 124;
            this.label16.Text = "Hall Name";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(-1, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 14);
            this.label15.TabIndex = 126;
            this.label15.Text = "Reserv From";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(163, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 14);
            this.label14.TabIndex = 127;
            this.label14.Text = "Reserv Upto";
            // 
            // dtmAddFromDate
            // 
            this.dtmAddFromDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmAddFromDate.CustomFormat = "dd/MMM/yyyy HH:mm";
            this.dtmAddFromDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmAddFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmAddFromDate.Location = new System.Drawing.Point(2, 38);
            this.dtmAddFromDate.Name = "dtmAddFromDate";
            this.dtmAddFromDate.Size = new System.Drawing.Size(161, 22);
            this.dtmAddFromDate.TabIndex = 124;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtOrgans);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.txtAddress2);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dtmReservTo);
            this.groupBox1.Controls.Add(this.btnSelectGuest);
            this.groupBox1.Controls.Add(this.btnAddGuest);
            this.groupBox1.Controls.Add(this.txtCustName);
            this.groupBox1.Controls.Add(this.cmbTitle);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtEntryNo);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(466, 149);
            this.groupBox1.TabIndex = 59;
            this.groupBox1.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 126);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 14);
            this.label20.TabIndex = 71;
            this.label20.Text = "Organ";
            // 
            // txtOrgans
            // 
            this.txtOrgans.BackColor = System.Drawing.Color.White;
            this.txtOrgans.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrgans.Location = new System.Drawing.Point(55, 123);
            this.txtOrgans.MaxLength = 40000;
            this.txtOrgans.Name = "txtOrgans";
            this.txtOrgans.Size = new System.Drawing.Size(407, 22);
            this.txtOrgans.TabIndex = 70;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(71, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(45, 14);
            this.label26.TabIndex = 69;
            this.label26.Text = "Name";
            // 
            // txtAddress2
            // 
            this.txtAddress2.BackColor = System.Drawing.Color.White;
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(8, 98);
            this.txtAddress2.MaxLength = 40000;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(454, 22);
            this.txtAddress2.TabIndex = 8;
            this.txtAddress2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtAddress2.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.White;
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(39, 74);
            this.txtAddress.MaxLength = 40000;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(423, 22);
            this.txtAddress.TabIndex = 7;
            this.txtAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtAddress.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(232, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 14);
            this.label5.TabIndex = 64;
            this.label5.Text = "Date of Reser";
            // 
            // dtmReservTo
            // 
            this.dtmReservTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmReservTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmReservTo.Location = new System.Drawing.Point(335, 2);
            this.dtmReservTo.Name = "dtmReservTo";
            this.dtmReservTo.Size = new System.Drawing.Size(127, 22);
            this.dtmReservTo.TabIndex = 2;
            this.dtmReservTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnSelectGuest
            // 
            this.btnSelectGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectGuest.Location = new System.Drawing.Point(368, 49);
            this.btnSelectGuest.Name = "btnSelectGuest";
            this.btnSelectGuest.Size = new System.Drawing.Size(96, 24);
            this.btnSelectGuest.TabIndex = 6;
            this.btnSelectGuest.Text = "Select Guest";
            this.btnSelectGuest.UseVisualStyleBackColor = true;
            this.btnSelectGuest.Click += new System.EventHandler(this.btnSelectGuest_Click);
            // 
            // btnAddGuest
            // 
            this.btnAddGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddGuest.Location = new System.Drawing.Point(368, 25);
            this.btnAddGuest.Name = "btnAddGuest";
            this.btnAddGuest.Size = new System.Drawing.Size(96, 24);
            this.btnAddGuest.TabIndex = 5;
            this.btnAddGuest.Text = "Add Guest";
            this.btnAddGuest.UseVisualStyleBackColor = true;
            this.btnAddGuest.Click += new System.EventHandler(this.btnAddGuest_Click);
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.Color.White;
            this.txtCustName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.Location = new System.Drawing.Point(71, 46);
            this.txtCustName.MaxLength = 40000;
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(294, 22);
            this.txtCustName.TabIndex = 4;
            this.txtCustName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtCustName.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // cmbTitle
            // 
            this.cmbTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTitle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Location = new System.Drawing.Point(8, 46);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(60, 22);
            this.cmbTitle.TabIndex = 3;
            this.cmbTitle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 14);
            this.label2.TabIndex = 58;
            this.label2.Text = "Add";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(498, 270);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(83, 14);
            this.label27.TabIndex = 103;
            this.label27.Text = "Discount %";
            // 
            // txtDiscountPer
            // 
            this.txtDiscountPer.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscountPer.Location = new System.Drawing.Point(583, 267);
            this.txtDiscountPer.MaxLength = 10;
            this.txtDiscountPer.Name = "txtDiscountPer";
            this.txtDiscountPer.Size = new System.Drawing.Size(76, 22);
            this.txtDiscountPer.TabIndex = 10;
            this.txtDiscountPer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDiscountPer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtDiscountPer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(973, 512);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Additional Details";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblRecepDesc7);
            this.groupBox2.Controls.Add(this.lblReceiptNo7);
            this.groupBox2.Controls.Add(this.txtReceipt7);
            this.groupBox2.Controls.Add(this.lblRecepDesc6);
            this.groupBox2.Controls.Add(this.lblRecepDesc5);
            this.groupBox2.Controls.Add(this.lblReceiptNo6);
            this.groupBox2.Controls.Add(this.txtReceipt6);
            this.groupBox2.Controls.Add(this.lblReceiptNo5);
            this.groupBox2.Controls.Add(this.txtReceipt5);
            this.groupBox2.Controls.Add(this.lblRecepDesc4);
            this.groupBox2.Controls.Add(this.lblReceiptNo4);
            this.groupBox2.Controls.Add(this.txtReceipt4);
            this.groupBox2.Controls.Add(this.lblRecepDesc3);
            this.groupBox2.Controls.Add(this.lblRecepDesc2);
            this.groupBox2.Controls.Add(this.lblRecepDesc1);
            this.groupBox2.Controls.Add(this.lblRecepDesc0);
            this.groupBox2.Controls.Add(this.lblReceiptNo3);
            this.groupBox2.Controls.Add(this.txtReceipt3);
            this.groupBox2.Controls.Add(this.lblReceiptNo2);
            this.groupBox2.Controls.Add(this.txtReceipt2);
            this.groupBox2.Controls.Add(this.lblReceiptNo1);
            this.groupBox2.Controls.Add(this.txtReceipt1);
            this.groupBox2.Controls.Add(this.lblReceiptAmt0);
            this.groupBox2.Controls.Add(this.txtReceipt0);
            this.groupBox2.Location = new System.Drawing.Point(8, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(399, 425);
            this.groupBox2.TabIndex = 113;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Receipt Entry Number";
            // 
            // lblRecepDesc7
            // 
            this.lblRecepDesc7.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc7.Location = new System.Drawing.Point(122, 372);
            this.lblRecepDesc7.Name = "lblRecepDesc7";
            this.lblRecepDesc7.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc7.TabIndex = 134;
            this.lblRecepDesc7.Text = "Amount";
            // 
            // lblReceiptNo7
            // 
            this.lblReceiptNo7.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo7.Location = new System.Drawing.Point(5, 396);
            this.lblReceiptNo7.Name = "lblReceiptNo7";
            this.lblReceiptNo7.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo7.TabIndex = 133;
            this.lblReceiptNo7.Text = "Amount";
            this.lblReceiptNo7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt7
            // 
            this.txtReceipt7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt7.Location = new System.Drawing.Point(5, 372);
            this.txtReceipt7.MaxLength = 10;
            this.txtReceipt7.Name = "txtReceipt7";
            this.txtReceipt7.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt7.TabIndex = 128;
            this.txtReceipt7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt7.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblRecepDesc6
            // 
            this.lblRecepDesc6.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc6.Location = new System.Drawing.Point(122, 322);
            this.lblRecepDesc6.Name = "lblRecepDesc6";
            this.lblRecepDesc6.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc6.TabIndex = 132;
            this.lblRecepDesc6.Text = "Amount";
            // 
            // lblRecepDesc5
            // 
            this.lblRecepDesc5.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc5.Location = new System.Drawing.Point(122, 272);
            this.lblRecepDesc5.Name = "lblRecepDesc5";
            this.lblRecepDesc5.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc5.TabIndex = 131;
            this.lblRecepDesc5.Text = "Amount";
            // 
            // lblReceiptNo6
            // 
            this.lblReceiptNo6.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo6.Location = new System.Drawing.Point(5, 346);
            this.lblReceiptNo6.Name = "lblReceiptNo6";
            this.lblReceiptNo6.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo6.TabIndex = 130;
            this.lblReceiptNo6.Text = "Amount";
            this.lblReceiptNo6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt6
            // 
            this.txtReceipt6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt6.Location = new System.Drawing.Point(5, 322);
            this.txtReceipt6.MaxLength = 10;
            this.txtReceipt6.Name = "txtReceipt6";
            this.txtReceipt6.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt6.TabIndex = 127;
            this.txtReceipt6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt6.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblReceiptNo5
            // 
            this.lblReceiptNo5.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo5.Location = new System.Drawing.Point(5, 296);
            this.lblReceiptNo5.Name = "lblReceiptNo5";
            this.lblReceiptNo5.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo5.TabIndex = 129;
            this.lblReceiptNo5.Text = "Amount";
            this.lblReceiptNo5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt5
            // 
            this.txtReceipt5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt5.Location = new System.Drawing.Point(5, 272);
            this.txtReceipt5.MaxLength = 10;
            this.txtReceipt5.Name = "txtReceipt5";
            this.txtReceipt5.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt5.TabIndex = 126;
            this.txtReceipt5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt5.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblRecepDesc4
            // 
            this.lblRecepDesc4.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc4.Location = new System.Drawing.Point(123, 222);
            this.lblRecepDesc4.Name = "lblRecepDesc4";
            this.lblRecepDesc4.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc4.TabIndex = 125;
            this.lblRecepDesc4.Text = "Amount";
            // 
            // lblReceiptNo4
            // 
            this.lblReceiptNo4.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo4.Location = new System.Drawing.Point(6, 246);
            this.lblReceiptNo4.Name = "lblReceiptNo4";
            this.lblReceiptNo4.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo4.TabIndex = 124;
            this.lblReceiptNo4.Text = "Amount";
            this.lblReceiptNo4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt4
            // 
            this.txtReceipt4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt4.Location = new System.Drawing.Point(6, 222);
            this.txtReceipt4.MaxLength = 10;
            this.txtReceipt4.Name = "txtReceipt4";
            this.txtReceipt4.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt4.TabIndex = 25;
            this.txtReceipt4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt4.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblRecepDesc3
            // 
            this.lblRecepDesc3.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc3.Location = new System.Drawing.Point(123, 172);
            this.lblRecepDesc3.Name = "lblRecepDesc3";
            this.lblRecepDesc3.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc3.TabIndex = 122;
            this.lblRecepDesc3.Text = "Amount";
            // 
            // lblRecepDesc2
            // 
            this.lblRecepDesc2.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc2.Location = new System.Drawing.Point(123, 122);
            this.lblRecepDesc2.Name = "lblRecepDesc2";
            this.lblRecepDesc2.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc2.TabIndex = 121;
            this.lblRecepDesc2.Text = "Amount";
            // 
            // lblRecepDesc1
            // 
            this.lblRecepDesc1.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc1.Location = new System.Drawing.Point(123, 72);
            this.lblRecepDesc1.Name = "lblRecepDesc1";
            this.lblRecepDesc1.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc1.TabIndex = 120;
            this.lblRecepDesc1.Text = "Amount";
            // 
            // lblRecepDesc0
            // 
            this.lblRecepDesc0.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc0.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc0.Location = new System.Drawing.Point(123, 20);
            this.lblRecepDesc0.Name = "lblRecepDesc0";
            this.lblRecepDesc0.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc0.TabIndex = 119;
            this.lblRecepDesc0.Text = "Amount";
            // 
            // lblReceiptNo3
            // 
            this.lblReceiptNo3.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo3.Location = new System.Drawing.Point(6, 196);
            this.lblReceiptNo3.Name = "lblReceiptNo3";
            this.lblReceiptNo3.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo3.TabIndex = 118;
            this.lblReceiptNo3.Text = "Amount";
            this.lblReceiptNo3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt3
            // 
            this.txtReceipt3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt3.Location = new System.Drawing.Point(6, 172);
            this.txtReceipt3.MaxLength = 10;
            this.txtReceipt3.Name = "txtReceipt3";
            this.txtReceipt3.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt3.TabIndex = 24;
            this.txtReceipt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt3.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblReceiptNo2
            // 
            this.lblReceiptNo2.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo2.Location = new System.Drawing.Point(6, 146);
            this.lblReceiptNo2.Name = "lblReceiptNo2";
            this.lblReceiptNo2.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo2.TabIndex = 116;
            this.lblReceiptNo2.Text = "Amount";
            this.lblReceiptNo2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt2
            // 
            this.txtReceipt2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt2.Location = new System.Drawing.Point(6, 122);
            this.txtReceipt2.MaxLength = 10;
            this.txtReceipt2.Name = "txtReceipt2";
            this.txtReceipt2.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt2.TabIndex = 23;
            this.txtReceipt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt2.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblReceiptNo1
            // 
            this.lblReceiptNo1.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo1.Location = new System.Drawing.Point(6, 96);
            this.lblReceiptNo1.Name = "lblReceiptNo1";
            this.lblReceiptNo1.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo1.TabIndex = 114;
            this.lblReceiptNo1.Text = "Amount";
            this.lblReceiptNo1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt1
            // 
            this.txtReceipt1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt1.Location = new System.Drawing.Point(6, 72);
            this.txtReceipt1.MaxLength = 10;
            this.txtReceipt1.Name = "txtReceipt1";
            this.txtReceipt1.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt1.TabIndex = 22;
            this.txtReceipt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt1.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblReceiptAmt0
            // 
            this.lblReceiptAmt0.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptAmt0.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptAmt0.Location = new System.Drawing.Point(6, 44);
            this.lblReceiptAmt0.Name = "lblReceiptAmt0";
            this.lblReceiptAmt0.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptAmt0.TabIndex = 112;
            this.lblReceiptAmt0.Text = "Amount";
            this.lblReceiptAmt0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt0
            // 
            this.txtReceipt0.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt0.Location = new System.Drawing.Point(6, 20);
            this.txtReceipt0.MaxLength = 10;
            this.txtReceipt0.Name = "txtReceipt0";
            this.txtReceipt0.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt0.TabIndex = 21;
            this.txtReceipt0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt0.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(973, 512);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Additional Requirement";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(19, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(113, 14);
            this.label11.TabIndex = 128;
            this.label11.Text = "Catering Details";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Controls.Add(this.btnCatNew);
            this.panel3.Controls.Add(this.btnCatAddChange);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.btnCatRemove);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label32);
            this.panel3.Controls.Add(this.label33);
            this.panel3.Controls.Add(this.label34);
            this.panel3.Controls.Add(this.cmbCatItems);
            this.panel3.Controls.Add(this.txtCatQuantity);
            this.panel3.Controls.Add(this.txtCatPrice);
            this.panel3.Controls.Add(this.label35);
            this.panel3.Location = new System.Drawing.Point(8, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(957, 299);
            this.panel3.TabIndex = 129;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(3, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowCellErrors = false;
            this.dataGridView1.ShowCellToolTips = false;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.ShowRowErrors = false;
            this.dataGridView1.Size = new System.Drawing.Size(950, 231);
            this.dataGridView1.TabIndex = 128;
            this.dataGridView1.TabStop = false;
            // 
            // btnCatNew
            // 
            this.btnCatNew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatNew.Location = new System.Drawing.Point(663, 17);
            this.btnCatNew.Name = "btnCatNew";
            this.btnCatNew.Size = new System.Drawing.Size(84, 24);
            this.btnCatNew.TabIndex = 32;
            this.btnCatNew.Text = "&New";
            this.btnCatNew.UseVisualStyleBackColor = true;
            // 
            // btnCatAddChange
            // 
            this.btnCatAddChange.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatAddChange.Location = new System.Drawing.Point(749, 17);
            this.btnCatAddChange.Name = "btnCatAddChange";
            this.btnCatAddChange.Size = new System.Drawing.Size(103, 24);
            this.btnCatAddChange.TabIndex = 33;
            this.btnCatAddChange.Text = "&Add/Change";
            this.btnCatAddChange.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(499, 36);
            this.textBox2.MaxLength = 10;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(102, 22);
            this.textBox2.TabIndex = 125;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCatRemove
            // 
            this.btnCatRemove.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatRemove.Location = new System.Drawing.Point(855, 17);
            this.btnCatRemove.Name = "btnCatRemove";
            this.btnCatRemove.Size = new System.Drawing.Size(84, 24);
            this.btnCatRemove.TabIndex = 34;
            this.btnCatRemove.Text = "Remo&ve";
            this.btnCatRemove.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(338, 36);
            this.textBox3.MaxLength = 10;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(89, 22);
            this.textBox3.TabIndex = 124;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(5, 13);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(38, 14);
            this.label22.TabIndex = 124;
            this.label22.Text = "Item";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(270, 40);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 14);
            this.label32.TabIndex = 121;
            this.label32.Text = "Persons";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(129, 40);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(64, 14);
            this.label33.TabIndex = 120;
            this.label33.Text = "Quantity";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(5, 40);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 14);
            this.label34.TabIndex = 119;
            this.label34.Text = "Price";
            // 
            // cmbCatItems
            // 
            this.cmbCatItems.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCatItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCatItems.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCatItems.FormattingEnabled = true;
            this.cmbCatItems.Location = new System.Drawing.Point(49, 8);
            this.cmbCatItems.Name = "cmbCatItems";
            this.cmbCatItems.Size = new System.Drawing.Size(601, 22);
            this.cmbCatItems.TabIndex = 30;
            // 
            // txtCatQuantity
            // 
            this.txtCatQuantity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCatQuantity.Location = new System.Drawing.Point(198, 36);
            this.txtCatQuantity.MaxLength = 10;
            this.txtCatQuantity.Name = "txtCatQuantity";
            this.txtCatQuantity.Size = new System.Drawing.Size(60, 22);
            this.txtCatQuantity.TabIndex = 29;
            this.txtCatQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCatPrice
            // 
            this.txtCatPrice.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCatPrice.Location = new System.Drawing.Point(48, 36);
            this.txtCatPrice.MaxLength = 10;
            this.txtCatPrice.Name = "txtCatPrice";
            this.txtCatPrice.Size = new System.Drawing.Size(72, 22);
            this.txtCatPrice.TabIndex = 28;
            this.txtCatPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(438, 40);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(57, 14);
            this.label35.TabIndex = 126;
            this.label35.Text = "Amount";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.button1);
            this.splitContainer1.Panel2.Controls.Add(this.btnSearch);
            this.splitContainer1.Panel2.Controls.Add(this.btnMemo);
            this.splitContainer1.Panel2.Controls.Add(this.btnReceipt);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpenByEntryNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnExit);
            this.splitContainer1.Panel2.Controls.Add(this.btnFirst);
            this.splitContainer1.Panel2.Controls.Add(this.btnRefersh);
            this.splitContainer1.Panel2.Controls.Add(this.btnLast);
            this.splitContainer1.Panel2.Controls.Add(this.btnNext);
            this.splitContainer1.Panel2.Controls.Add(this.btnPrev);
            this.splitContainer1.Panel2.Controls.Add(this.btnPrint);
            this.splitContainer1.Panel2.Controls.Add(this.btnSave);
            this.splitContainer1.Panel2.Controls.Add(this.btnEdit);
            this.splitContainer1.Panel2.Controls.Add(this.btnUndo);
            this.splitContainer1.Panel2.Controls.Add(this.btnAddNew);
            this.splitContainer1.Size = new System.Drawing.Size(981, 616);
            this.splitContainer1.SplitterDistance = 541;
            this.splitContainer1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(208, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 27);
            this.button1.TabIndex = 52;
            this.button1.Text = "Estimate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmSeminarBookingEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 616);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSeminarBookingEntry";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Seminar Booking";
            this.Load += new System.EventHandler(this.frmSeminarBookingEntry_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdReservDetails)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtmAddConference)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.TextBox txtEntryNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnMemo;
        private System.Windows.Forms.Button btnReceipt;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnOpenByEntryNo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnRefersh;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtmTodate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtmFromDate;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblTotalReceipt;
        private System.Windows.Forms.Label lblCustStatus;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtmReservTo;
        private System.Windows.Forms.Button btnSelectGuest;
        private System.Windows.Forms.Button btnAddGuest;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.ComboBox cmbTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtRent;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbHallName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtDiscountPer;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtmLogDate;
        private System.Windows.Forms.TextBox txtLogPrice;
        private System.Windows.Forms.ComboBox cmbLogItem;
        private System.Windows.Forms.TextBox txtLogQuantity;
        private System.Windows.Forms.TextBox txtLogST;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Button btnLogRemove;
        private System.Windows.Forms.Button btnLogNew;
        private System.Windows.Forms.Button btnLogAdd;
        private System.Windows.Forms.DataGridView grdReservDetails;
        private System.Windows.Forms.TextBox txtOrgans;
        private System.Windows.Forms.CheckBox chkServiceExmpt;
        private System.Windows.Forms.ComboBox cmbSeminarType;
        private System.Windows.Forms.TextBox txtLogAmount;
        private System.Windows.Forms.TextBox txtLogHrs;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DateTimePicker dtmAddUptoDate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLogLT;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtaddRemarks;
        private System.Windows.Forms.ComboBox cmbAddSeminarType;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtAddRent;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnAddCNew;
        private System.Windows.Forms.Button btnAddCAddChange;
        private System.Windows.Forms.Button btnAddCRemove;
        private System.Windows.Forms.ComboBox cmbAddHallName;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtmAddFromDate;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnCancelHostory;
        private System.Windows.Forms.Button btnCancellations;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblRecepDesc7;
        private System.Windows.Forms.Label lblReceiptNo7;
        private System.Windows.Forms.TextBox txtReceipt7;
        private System.Windows.Forms.Label lblRecepDesc6;
        private System.Windows.Forms.Label lblRecepDesc5;
        private System.Windows.Forms.Label lblReceiptNo6;
        private System.Windows.Forms.TextBox txtReceipt6;
        private System.Windows.Forms.Label lblReceiptNo5;
        private System.Windows.Forms.TextBox txtReceipt5;
        private System.Windows.Forms.Label lblRecepDesc4;
        private System.Windows.Forms.Label lblReceiptNo4;
        private System.Windows.Forms.TextBox txtReceipt4;
        private System.Windows.Forms.Label lblRecepDesc3;
        private System.Windows.Forms.Label lblRecepDesc2;
        private System.Windows.Forms.Label lblRecepDesc1;
        private System.Windows.Forms.Label lblRecepDesc0;
        private System.Windows.Forms.Label lblReceiptNo3;
        private System.Windows.Forms.TextBox txtReceipt3;
        private System.Windows.Forms.Label lblReceiptNo2;
        private System.Windows.Forms.TextBox txtReceipt2;
        private System.Windows.Forms.Label lblReceiptNo1;
        private System.Windows.Forms.TextBox txtReceipt1;
        private System.Windows.Forms.Label lblReceiptAmt0;
        private System.Windows.Forms.TextBox txtReceipt0;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnCatNew;
        private System.Windows.Forms.Button btnCatAddChange;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnCatRemove;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox cmbCatItems;
        private System.Windows.Forms.TextBox txtCatQuantity;
        private System.Windows.Forms.TextBox txtCatPrice;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dtmAddConference;
    }
}