﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Seminar
{
    public partial class frmSeminarBillpol : Form
    {
        MasterCaller objMasterData = new MasterCaller();
        GuestCaller objMasterGuest = new GuestCaller();
        ReservationCaller objReservBook = new ReservationCaller();
        HostelCaller objHostelData = new HostelCaller();
        AlphaPanel pnlAlpha = new AlphaPanel();

        readonly int roomDorm = Convert.ToInt32(CommonVariables.RoomDormatory.Seminar);
        public int reservationID { get; set; }

        private readonly string tagReservChkin = Convert.ToString((char)(CommonVariables.SpecialTag.Semianr));
        private string adjtypeVal { get { return "SEMINAR"; } }

        #region Local variable
        private EL.HotelBILL objHotelBill { get; set; }
        List<EL.hotelbilldetail> lstHotelbilldetail { get; set; }
        List<EL.HotelBill_MISC_DETAILS> lstMiscDetails { get; set; }

        int rowindex = -1;
        int rowIndexMiscDet = -1;
        decimal recptAmt = 0m;
        double discountper = 0d;
        bool editPage = false;
        #endregion Local variable

        public frmSeminarBillpol()
        {
            InitializeComponent();
        }

        private void frmSeminarBill_Load(object sender, EventArgs e)
        {
            Bind_Title(); Bind_Seminar(); BindItem();
            if (this.reservationID > 0)
            {
                resetPageData();
                FindByReservationId();
            }
            else
                btnLast_Click(null, null);

            btnDelete.Enabled = false;
        }

        private void cmbTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender.GetType() == typeof(CheckBox))
                {
                    if ((CheckBox)sender == chkBillTo) txtBillTo.Focus();
                    if ((CheckBox)sender == chkPrintPrv) btnSave.Focus();                    
                }
                else if (sender.GetType() == typeof(ComboBox))
                {
                    if ((ComboBox)sender == cmbTitle) txtCustName.Focus();
                    if ((ComboBox)sender == cmbSeminar) cmbSeminarType.Focus();
                    if ((ComboBox)sender == cmbSeminarType) txtSemnRent.Focus();
                    if ((ComboBox)sender == cmbMiscItem) txtMiscRate.Focus();
                }
                else if (sender.GetType() == typeof(DateTimePicker))
                {
                    if ((DateTimePicker)sender == dtmDate) txtRemarks.Focus();
                    if ((DateTimePicker)sender == dtmFrom) dtmUpTo.Focus();
                    if ((DateTimePicker)sender == dtmUpTo) txtEntryNo.Focus();
                    if ((DateTimePicker)sender == dtmReservTo) txtExtraHrs.Focus();
                    //if ((DateTimePicker)sender == dtmCatDate) txtCatBillNo.Focus();
                    if ((DateTimePicker)sender == dtmMiscDate) cmbMiscItem.Focus();
                }
                else if (sender.GetType() == typeof(TextBox))
                {
                    if ((TextBox)sender == txtCustName) chkBillTo.Focus();
                    //if ((TextBox)sender == txtBillTo) txtFolio.Focus();
                    //if ((TextBox)sender == txtFolio) dtmDate.Focus();
                    if ((TextBox)sender == txtRemarks) txtAddress.Focus();
                    if ((TextBox)sender == txtAddress) txtAddress2.Focus();
                    if ((TextBox)sender == txtAddress2) txtFinalBill.Focus();
                    if ((TextBox)sender == txtFinalBill) txtOrderFormNo.Focus();
                    if ((TextBox)sender == txtOrderFormNo) cmbSeminar.Focus();
                    if ((TextBox)sender == txtEntryNo) txtOrderFormNo.Focus();
                    //if ((TextBox)sender == txtSemnRent) txtCatering.Focus();
                    //if ((TextBox)sender == txtCatering) txtGstPerc.Focus();
                    if ((TextBox)sender == txtGstPerc) txtSCharge.Focus();
                    if ((TextBox)sender == txtSCharge) txtTotalAmt.Focus();
                    if ((TextBox)sender == txtTotalAmt) txtPax.Focus();
                    if ((TextBox)sender == txtPax) dtmReservTo.Focus();
                    if ((TextBox)sender == txtExtraHrs) btnAddNew.Focus();

                    //if ((TextBox)sender == txtCatAmount) txtMiscAmount.Focus();
                    if ((TextBox)sender == txtMiscAmount) txtTotal.Focus();
                    if ((TextBox)sender == txtTotal) txtNetAdvRece.Focus();
                    if ((TextBox)sender == txtNetAdvRece) txtRoundOff.Focus();
                    if ((TextBox)sender == txtRoundOff) txtAmountDue.Focus();
                    if ((TextBox)sender == txtAmountDue) chkPrintPrv.Focus();

                    //if ((TextBox)sender == txtCatBillNo) txtCatAmount.Focus();
                    //if ((TextBox)sender == txtCatAmount) btnCatAddChange.Focus();
                    if ((TextBox)sender == txtMiscRate) txtMiscQty.Focus();
                    if ((TextBox)sender == txtMiscQty) txtMiscHrs.Focus();
                    if ((TextBox)sender == txtMiscHrs) txtTotalMiscAmt.Focus();
                    if ((TextBox)sender == txtTotalMiscAmt) btnMiscAddChange.Focus();
                }
            }
        }

        private void txtPax_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void Bind_Title()
        {
            try
            {
                List<EL.MasterTitle> lstMtitle = objMasterData.GetTitleMaster().ToList();
                lstMtitle.Insert(0, new EL.MasterTitle { Titleid = 0, Titlename = string.Empty });
                cmbTitle.DataSource = lstMtitle;
                cmbTitle.DisplayMember = "Titlename";
                cmbTitle.ValueMember = "Titleid";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in Bind_Title");
            }
        }

        private void Bind_Seminar()
        {
            try
            {
                List<EL.ROOM_TYPE> lstRoomNum = objMasterData.GetRoomType().Where(c => c.Room_dorm == 3).OrderBy(x => x.RM_TYPE_DESC).ToList();
                List<EL.room_number> lstRoomType = objMasterData.GetRoomNumber().Where(x => x.room_number_ConferenceRoom == 1).OrderBy(x => x.room_number_number).ToList();

                lstRoomNum.Insert(0, new EL.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_CODE = string.Empty, RM_TYPE_DESC = string.Empty });
                lstRoomType.Insert(0, new EL.room_number { room_number_ID = 0, room_number_number = string.Empty });

                cmbSeminar.DataSource = lstRoomType;
                cmbSeminar.DisplayMember = "room_number_number";
                cmbSeminar.ValueMember = "room_number_ID";

                cmbSeminarType.DataSource = lstRoomNum;
                cmbSeminarType.DisplayMember = "RM_TYPE_DESC";
                cmbSeminarType.ValueMember = "RM_TYPE_ID";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindRoomNumber");
            }
        }

        private void BindItem()
        {
            try
            {
                var dbMiscItems = (from c in objMasterData.GetMiscItems() orderby c.Misc_items_Name select c).ToList();
                dbMiscItems.Insert(0, new EL.Misc_items { Misc_items_Id = 0, Misc_items_Name = string.Empty });
                cmbMiscItem.DataSource = dbMiscItems;
                cmbMiscItem.ValueMember = "Misc_items_Id";
                cmbMiscItem.DisplayMember = "Misc_items_Name";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error In Misc Items binding");
            }
        }

        private void resetPageData()
        {
            this.objHotelBill = null;
            this.Text = "Seminar Bill:- ";
            cmbTitle.SelectedIndex = 0;
            txtCustName.Text = string.Empty;
            chkBillTo.Checked = false;
            txtBillTo.Text = string.Empty;
            txtFinalBill.Text = string.Empty;
            //txtFolio.Text = string.Empty;
            dtmDate.Value = DateTime.Now;
            dtmReservTo.Value = DateTime.Now;
            dtmUpTo.Value = DateTime.Now;
            txtEntryNo.Text = string.Empty;
            txtOrderFormNo.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtAddress2.Text = string.Empty;
            txtRemarks.Text = string.Empty;
            
            lblGuestStatus.Text = string.Empty;
            lblGuestStatus.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            lblRoomStatus.Text = string.Empty;
            lblRoomStatus.BackColor = System.Drawing.Color.LightCyan;
            chkStExcempted.Checked = false;

            txtTotalDiningAmt.Text = "0.00";
            txtTotalMiscAmt.Text = "0.00";
            txtTotalCatCanAmt.Text = "0.00";
            txtTotalLogistiesAmt.Text = "0.00";
            txtTotalCancelChargeAmt.Text = "0.00";
            txtTotal.Text = "0.00";
            txtDiscount.Text = "0.00";
            txtNetAdvRece.Text = "0.00";
            txtRoundOff.Text = "0.00";
            txtAmountDue.Text = "0.00";

            MiddlePage();
            this.lstHotelbilldetail = null;
            BindHotelBilldetails();

            BindAdvancePaymentReceipts();

            //catering();
            //this.lstCateringDetails = null;
            //BindCateringDetails();

            miscItems();
            this.lstMiscDetails = null;
            BindMiscellaneousDetails();
        }

        private EL.FilterClass RefreshFilter()
        {
            return new EL.FilterClass
            {
                FinEnd = CommonVariables.dtmFinancialEnd.Year * 100 + CommonVariables.dtmFinancialEnd.Month,
                FinStart = CommonVariables.dtmFinancialStart.Year * 100 + CommonVariables.dtmFinancialStart.Month,
                BillNumber = 0,
                FolioNumber = 0,
                RecordCategory = 0,
                RecordNumber = 0,
                RoomCategory = roomDorm,
                SearchByText = string.Empty,
                tagChar = string.Empty,
                UniqueId = 0,
                GrNo = string.Empty
            };
        }

        private void BindControlsValue()
        {
            try
            {
                if (this.objHotelBill != null)
                {
                    //this.reservationID = this.objHotelBill.reservation_ID.HasValue ? Convert.ToInt32(this.objHotelBill.reservation_ID) : 0;
                    this.Text = "Seminar Bill:- " + this.objHotelBill.Name_guest;

                    DateTime dtDate = objHotelBill.Bdate.HasValue ? Convert.ToDateTime(objHotelBill.Bdate) : DateTime.Now;
                    DateTime dtTime = objHotelBill.Btime.HasValue && objHotelBill.Btime.Value.TimeOfDay.Hours + objHotelBill.Btime.Value.TimeOfDay.Minutes > 0 ?
                        Convert.ToDateTime(objHotelBill.Btime) : Convert.ToDateTime(objHotelBill.Bdate);
                    DateTime billDate = new DateTime(dtDate.Year, dtDate.Month, dtDate.Day, dtTime.Hour, dtTime.Minute, dtTime.Second, dtTime.Kind);
                    cmbTitle.Text = objHotelBill.Title_guest.Trim();
                    txtCustName.Text = objHotelBill.Name_guest;
                    chkBillTo.Checked = objHotelBill.billtochk.HasValue ? (bool)objHotelBill.billtochk : false;
                    txtBillTo.Text = objHotelBill.Name_billto;
                    //txtFolio.Text = objHotelBill.Folio_No.HasValue ? objHotelBill.Folio_No.ToString() : string.Empty;
                    dtmDate.Value = billDate;
                    txtRemarks.Text = objHotelBill.description_b;
                    dtmFrom.Value = objHotelBill.checkintime_date.HasValue ? Convert.ToDateTime(objHotelBill.checkintime_date) : DateTime.Now;
                    dtmFrom.Checked = objHotelBill.checkintime_date.HasValue ? true : false;
                    dtmUpTo.Value = objHotelBill.checkouttime_date.HasValue ? Convert.ToDateTime(objHotelBill.checkouttime_date) : DateTime.Now;
                    dtmUpTo.Checked = objHotelBill.checkouttime_date.HasValue ? true : false;

                    txtAddress.Text = objHotelBill.addr1_guest;
                    txtAddress2.Text = objHotelBill.addr2_guest;
                    txtFinalBill.Text = objHotelBill.Bill_No.HasValue ? Convert.ToString(objHotelBill.Bill_No) : string.Empty;
                    txtEntryNo.Text = objHotelBill.Grno;
                    txtOrderFormNo.Text = objHotelBill.reservation_Number;

                    if (!objHotelBill.date_of_final.HasValue)
                    {
                        lblRoomStatus.Text = "Check-In";
                        lblRoomStatus.BackColor = System.Drawing.Color.Yellow;
                    }
                    else
                    {
                        lblRoomStatus.Text = "Check-Out";
                        lblRoomStatus.BackColor = System.Drawing.Color.Red;
                    }

                    this.lstHotelbilldetail = (objHotelBill.hotelBill_ID > 0) ? objHotelBill.hotelbilldetails.OrderBy(x => x.date_ofdet).ThenBy(x => x.roomno).ToList() : lstHotelbilldetail;
                    //this.lstCateringDetails = objHotelBill.HotelBill_CATERING_DETAILS.ToList();
                    this.lstMiscDetails = (objHotelBill.hotelBill_ID > 0) ? objHotelBill.HotelBill_MISC_DETAILS.ToList() : lstMiscDetails;
                    //this.lstHotelCancelBill = new List<EL.hotelBillCancelAttached>();

                    BindAdvancePaymentReceipts();
                    BindHotelBilldetails();
                    BindCateringDetails();
                    BindMiscellaneousDetails();
                    BindCancelledBillDetails();

                    txtTotalCatCanAmt.Text = objHotelBill.CateringAmountTotal.HasValue ? Convert.ToDouble(objHotelBill.CateringAmountTotal).ToString("0.00") : "0.00";
                    txtTotalMiscAmt.Text = (objHotelBill.MiscAmountTotal.HasValue ? Convert.ToDouble(objHotelBill.MiscAmountTotal).ToString("0.00") : "0.00");
                    txtTotal.Text = objHotelBill.totalamt.HasValue ? Convert.ToDouble(objHotelBill.totalamt).ToString("0.00") : "0.00";
                    txtRoundOff.Text = objHotelBill.roundoff.HasValue ? Convert.ToDouble(objHotelBill.roundoff).ToString("0.00") : "0.00";
                    txtNetAdvRece.Text = recptAmt.ToString("0.00");
                    txtAmountDue.Text = ((objHotelBill.totalamt.HasValue ? Convert.ToDouble(objHotelBill.totalamt) : 0) +
                        (objHotelBill.roundoff.HasValue ? Convert.ToDouble(objHotelBill.roundoff) : 0) - Convert.ToDouble(recptAmt)).ToString("0.00");

                    if (this.objHotelBill.hotelBill_ID > 0 && !editPage)
                    {
                        btnUndo.Enabled = false;
                        btnSave.Enabled = false;
                        btnAddNew.Enabled = true;
                        btnEdit.Enabled = true;
                        btnDelete.Enabled = false;

                        AdditionalTabEnable(false);
                        panel1.Controls.Add(pnlAlpha);
                        pnlAlpha.Dock = DockStyle.Fill;
                        pnlAlpha.BringToFront();
                        tabControl1.BringToFront();
                        dgvSeminarDetails.BringToFront();
                        button1.BringToFront();
                        button2.BringToFront();
                        button3.BringToFront();
                        button4.BringToFront();
                        button5.BringToFront();
                        button6.BringToFront();
                        button7.BringToFront();
                        button8.BringToFront();
                    }
                }
                else
                {
                    panel1.Controls.Remove(pnlAlpha);
                    btnUndo.Enabled = false;
                    btnSave.Enabled = true;
                    btnAddNew.Enabled = true;
                    btnEdit.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in FillRoomBillData");
            }
        }

        private void AdditionalTabEnable(bool flag)
        {
            //dtmCatDate.Enabled = flag;
            //txtCatBillNo.Enabled = flag;
            //txtCatAmount.Enabled = flag;
            //cmbMiscItem.Enabled = flag;
            //dtmMiscDate.Enabled = flag;
            //txtMiscRate.Enabled = flag;
            //txtMiscQty.Enabled = flag;
            //txtMiscHrs.Enabled = flag;
            //txtMiscAmount.Enabled = flag;
            //btnCatNew.Enabled = flag;
            //btnCatAddChange.Enabled = flag;
            //btnCatRemove.Enabled = flag;
            //btnMiscAdd.Enabled = flag;
            //btnMiscAddChange.Enabled = flag;
            //btnMiscRemove.Enabled = flag;
        }

        #region ReceiptDetails
        private void BindAdvancePaymentReceipts()
        {
            try
            {
                IList<EL.HostelReceiptLog> lstReceipt = this.objHotelBill != null && this.objHotelBill.HostelReceiptLogs != null ?
                    this.objHotelBill.HostelReceiptLogs.Where(x => (x.hotelBill_ID == this.objHotelBill.reservation_ID ||
                    x.newreservation_ID == this.objHotelBill.reservation_ID) && x.AdjType.ToUpper() == "S-CATERING"
                    || x.AdjType.ToUpper() == "SEMINAR" || x.AdjType.ToUpper() == "D-CATERING").ToList() : new List<EL.HostelReceiptLog>();

                DataTable dtReceipt = ConversionClass.CreateDataTable<EL.HostelReceiptLog>(lstReceipt);
                dtReceipt.Rows.Add(dtReceipt.NewRow());
                DataRow dr = dtReceipt.NewRow();
                recptAmt = 0;
                int count = 1;
                foreach (DataRow grdRow in dtReceipt.Rows)
                {
                    if (!grdRow.IsNull("recpt_pay_id") && Convert.ToInt32(grdRow["recpt_pay_id"]) > 0)
                        grdRow["SlNo"] = count++;
                    if (!grdRow.IsNull("recpt_pay_char") && Convert.ToString(grdRow["recpt_pay_char"])
                        == Convert.ToString((char)CommonVariables.SpecialTag.Refund))
                        recptAmt -= !grdRow.IsNull("Amount") ? Convert.ToDecimal(grdRow["Amount"]) : 0;
                    else
                        recptAmt += !grdRow.IsNull("Amount") ? Convert.ToDecimal(grdRow["Amount"]) : 0;
                }

                dr["receipt_No"] = "Total.";
                dr["Amount"] = recptAmt;
                dtReceipt.Rows.Add(dr);

                dgvAdvancePayementRece.DataSource = dtReceipt;

                foreach (DataGridViewColumn grdCol in dgvAdvancePayementRece.Columns)
                {
                    grdCol.SortMode = DataGridViewColumnSortMode.NotSortable;
                    if (grdCol.Name == "SlNo" || grdCol.Name == "Rdate" || grdCol.Name == "receipt_No" || grdCol.Name == "Amount" ||
                        grdCol.Name == "mode_of_pay" || grdCol.Name == "ReceiptPaymentType")
                        grdCol.Visible = true;
                    else
                        grdCol.Visible = false;

                    if (grdCol.Name == "Amount")
                    {
                        grdCol.DefaultCellStyle.Format = "0.00";
                        grdCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    }
                    if (grdCol.Name == "SlNo" || grdCol.Name == "receipt_No")
                    {
                        grdCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    }
                }

                foreach (DataGridViewRow grdRow in dgvAdvancePayementRece.Rows)
                {
                    if (grdRow.Cells["recpt_pay_char"] != null && Convert.ToString(grdRow.Cells["recpt_pay_char"].Value)
                        == Convert.ToString((char)CommonVariables.SpecialTag.Refund))
                        grdRow.DefaultCellStyle.BackColor = System.Drawing.Color.Red;
                }

                dgvAdvancePayementRece.Columns["SlNo"].Width = 25;
                dgvAdvancePayementRece.Columns["Rdate"].Width = 40;
                dgvAdvancePayementRece.Columns["receipt_No"].Width = 40;
                dgvAdvancePayementRece.Columns["Amount"].Width = 50;
                dgvAdvancePayementRece.Columns["mode_of_pay"].Width = 50;
                dgvAdvancePayementRece.Columns["ReceiptPaymentType"].Width = 130;

                dgvAdvancePayementRece.Columns["Rdate"].DefaultCellStyle.Format = "dd/MMM/yyyy";

                dgvAdvancePayementRece.Columns["SlNo"].HeaderText = "SNo";
                dgvAdvancePayementRece.Columns["Rdate"].HeaderText = "Date";
                dgvAdvancePayementRece.Columns["receipt_No"].HeaderText = "ReceiptNo";
                dgvAdvancePayementRece.Columns["mode_of_pay"].HeaderText = "M O P";
                dgvAdvancePayementRece.Columns["ReceiptPaymentType"].HeaderText = "Type";                

                DataGridViewRow lastRow = dgvAdvancePayementRece.Rows[dgvAdvancePayementRece.Rows.GetLastRow(0)];
                lastRow.DefaultCellStyle.BackColor = System.Drawing.Color.LightGreen;
                dgvAdvancePayementRece.ClearSelection();
                SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindAdvanceDetails");
            }
        }
        #endregion ReceiptDetails

        private void FindByReservationId()
        {
            try
            {
                resetPageData();
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.tagChar = Convert.ToString((char)CommonVariables.SpecialTag.Semianr);
                objFilter.UniqueId = this.reservationID;
                EL.RESERVATION_CHECKIN_WALKIN objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);

                if (objReservation != null && objReservation.HotelBILLs.Any(x => x.Room_Dormatory == this.roomDorm))
                {
                    this.objHotelBill = objReservation.HotelBILLs.FirstOrDefault(x => x.Room_Dormatory == this.roomDorm);
                }
                else
                {
                    this.lstHotelbilldetail = new List<EL.hotelbilldetail>();

                    #region New Entry
                    this.objHotelBill = new EL.HotelBILL
                    {
                        reservation_ID = objReservation.reservation_ID,
                        Name_guest = objReservation.reservation_PI_frstname,
                        addr1_guest = objReservation.reservation_PI_street,
                        addr2_guest = objReservation.reservation_PI_street1,
                        checkintime_date = objReservation.reservation_CHECKIN,
                        checkouttime_date = objReservation.reservation_CHKOUT,
                        reservation_ID_all = reservationID.ToString() + ",",
                        Grno = (!string.IsNullOrEmpty(objReservation.GRNo) ? objReservation.GRNo + ";" : string.Empty) +
                        (!string.IsNullOrEmpty(objReservation.GRNo1) ? objReservation.GRNo1 + ";" : string.Empty) +
                        (!string.IsNullOrEmpty(objReservation.GRNo2) ? objReservation.GRNo2 + ";" : string.Empty),
                        billroomtype = 5,
                        Room_Dormatory = roomDorm,
                        Title_guest = objReservation.reservation_PI_title,
                        reservation_Number = Convert.ToString(objReservation.reservation_NUMBER),
                        reservation_ADDLGUEST = objReservation.NoofaddlCust,
                        GUEST_NUM = objReservation.GUEST_NUM,
                        HOTELBILLCANCEL = 0,

                        addr3_guest = string.Empty,
                        Name_billto = string.Empty,
                        addr1_billto = string.Empty,
                        addr2_billto = string.Empty,
                        addr3_billto = string.Empty,
                        description_b = string.Empty,
                        activate_delete = false,
                        billtochk = false,

                        schargeamt = 0,
                        schargerate = 0,
                        luxurytaxrate = 0,
                        luxurytaxamt = 0,
                        salestaxrate = 0,
                        salestaxamt = 0,
                        roomserviceamt = 0,
                        discountrate = 0,
                        discountamt = 0,
                        totalkitchen = 0,
                        totalminibar = 0,
                        BillcreationType = 0,
                        sepamtroundoff = 0,
                        transportamt = 0,
                        STExempted = false,

                        totalamt = 0,
                        grandtotalamt = 0,
                        roundoff = 0,
                        totalroomrent = 0,
                        totaltelephone = 0,
                        totalextrabed = 0,
                        totallaundary = 0,
                        totalMiscCharges = 0,
                        advancerecd = 0,
                        netpayable = 0,
                        CateringAmountTotal = 0,
                        MiscAmountTotal = 0
                    };
                    #endregion New Entry

                    #region New Addition Entry
                    if (objReservation.reservation_dormid.HasValue && objReservation.reservation_dormid.Value > 0)
                    {
                        DateTime currentDate = objReservation.reservation_CHECKIN.HasValue ? objReservation.reservation_CHECKIN.Value : DateTime.Today;
                        DateTime pastDate = objReservation.reservation_CHKOUT.HasValue ? objReservation.reservation_CHKOUT.Value : DateTime.Today;

                        var roomdetail = objMasterData.GetRoomNumber().FirstOrDefault(x => x.room_number_ID == objReservation.reservation_dormid);
                        var roomType = objMasterData.GetRoomType().FirstOrDefault(x => x.RM_TYPE_ID == roomdetail.RM_TYPE_ID.Value);

                        while (currentDate.Date <= pastDate.Date)
                        {
                            #region Hotel Bill details
                            EL.hotelbilldetail objAddBill = new EL.hotelbilldetail
                            {
                                hotelBill_ID = this.objHotelBill.hotelBill_ID,
                                roomno = roomdetail != null ? roomdetail.room_number_number : string.Empty,
                                room_number_ID = objReservation.reservation_dormid,
                                date_ofdet = currentDate.Date,
                                //roomserv_kitch_amt = !string.IsNullOrEmpty(txtCatering.Text) ? Convert.ToDouble(txtCatering.Text) : 0,
                                roomrent_amt = roomType != null ? roomType.Room_Type_rate.Value : 0,
                                misc_charges_amt = !string.IsNullOrEmpty(txtGstPerc.Text) ? Convert.ToDouble(txtGstPerc.Text) : 0,
                                xtra_bed = !string.IsNullOrEmpty(txtExtraHrs.Text) ? Convert.ToDouble(txtExtraHrs.Text) : 0,
                                luxurytax = !string.IsNullOrEmpty(txtLuxuryTax.Text) ? Convert.ToDouble(txtLuxuryTax.Text) : 0,
                                males = roomdetail != null && roomdetail.NoPersons.HasValue ? roomdetail.NoPersons.Value : 0,
                                females = 0,
                                child = roomdetail != null && roomdetail.NoPersons.HasValue ? roomdetail.NoPersons.Value : 0,
                                reservation_PI_roomtype = roomType != null ? roomType.RM_TYPE_CODE : string.Empty,
                                ROOM_TYPE_ID = roomType != null ? roomType.RM_TYPE_ID : -1,
                                tele_call_amt = 0,
                                laundary_amt = 0,
                                salestax = 0,
                                misc_ids = string.Empty,
                                kot_ids = string.Empty,
                                comp_roomserv_kitch_amt = 0,
                                comp_roomrent_amt = 0,
                                comp_tele_call_amt = 0,
                                comp_laundary_amt = 0,
                                comp_misc_charges_amt = 0,
                                comp_total_amt_amt = 0,
                                comp_xtra_bed = 0,
                                sep_roomserv_kitch_amt = 0,
                                sep_roomrent_amt = 0,
                                sep_tele_call_amt = 0,
                                sep_laundary_amt = 0,
                                sep_misc_charges_amt = 0,
                                sep_total_amt_amt = 0,
                                sep_xtra_bed = 0,
                                comp_misc_ids = string.Empty,
                                sep_misc_ids = string.Empty,
                                comp_kot_ids = string.Empty,
                                sep_kot_ids = string.Empty,
                                minibar = 0,
                                sep_minibar = 0,
                                comp_minibar = 0,
                                bedno = string.Empty
                            };
                            #endregion Hotel Bill details

                            //objAddBill.Hotelbilldet_id = dbContext.hotelbilldetails.Max(x => x.Hotelbilldet_id) + 1;

                            objAddBill.total_amt_amt = objAddBill.roomrent_amt + objAddBill.roomserv_kitch_amt + objAddBill.misc_charges_amt
                                 + objAddBill.luxurytax + objAddBill.xtra_bed;
                            objAddBill.servtax = (objAddBill.total_amt_amt * (CommonVariables.MiscGST / 100));
                            objAddBill.total_amt_amt = objAddBill.total_amt_amt + objAddBill.servtax;

                            lstHotelbilldetail.Add(objAddBill);

                            currentDate = currentDate.AddDays(1);
                        }
                    }
                    #endregion New Addition Entry

                    IList<EL.RESERVATION_DETAILS_STATUS> lstRESERVATION_DETAILS_STATUS = objReservation.RESERVATION_DETAILS_STATUS.ToList();
                    foreach (EL.RESERVATION_DETAILS_STATUS objAddList in lstRESERVATION_DETAILS_STATUS)
                    {
                        #region New Addition Entry
                        if (objAddList.reservation_dormid.HasValue && objAddList.reservation_dormid.Value > 0)
                        {
                            DateTime currentDate = objAddList.reservation_CHECKIN.HasValue ? objAddList.reservation_CHECKIN.Value : DateTime.Today;
                            DateTime pastDate = objAddList.reservation_CHKOUT.HasValue ? objAddList.reservation_CHKOUT.Value : DateTime.Today;

                            var roomdetail = objMasterData.GetRoomNumber().FirstOrDefault(x => x.room_number_ID == objAddList.reservation_dormid);
                            var roomType = objMasterData.GetRoomType().FirstOrDefault(x => x.RM_TYPE_ID == roomdetail.RM_TYPE_ID.Value);

                            while (currentDate.Date <= pastDate.Date)
                            {
                                #region Hotel Bill details
                                EL.hotelbilldetail objAddBill = new EL.hotelbilldetail
                                {
                                    hotelBill_ID = this.objHotelBill.hotelBill_ID,
                                    roomno = roomdetail != null ? roomdetail.room_number_number : string.Empty,
                                    room_number_ID = objAddList.reservation_dormid,
                                    date_ofdet = currentDate.Date,
                                    //roomserv_kitch_amt = !string.IsNullOrEmpty(txtCatering.Text) ? Convert.ToDouble(txtCatering.Text) : 0,
                                    roomrent_amt = roomType != null ? roomType.Room_Type_rate.Value : 0,
                                    misc_charges_amt = !string.IsNullOrEmpty(txtGstPerc.Text) ? Convert.ToDouble(txtGstPerc.Text) : 0,
                                    xtra_bed = !string.IsNullOrEmpty(txtExtraHrs.Text) ? Convert.ToDouble(txtExtraHrs.Text) : 0,
                                    luxurytax = !string.IsNullOrEmpty(txtLuxuryTax.Text) ? Convert.ToDouble(txtLuxuryTax.Text) : 0,
                                    males = roomdetail != null && roomdetail.NoPersons.HasValue ? roomdetail.NoPersons.Value : 0,
                                    females = 0,
                                    child = roomdetail != null && roomdetail.NoPersons.HasValue ? roomdetail.NoPersons.Value : 0,
                                    reservation_PI_roomtype = roomType != null ? roomType.RM_TYPE_CODE : string.Empty,
                                    ROOM_TYPE_ID = roomType != null ? roomType.RM_TYPE_ID : -1,
                                    tele_call_amt = 0,
                                    laundary_amt = 0,
                                    salestax = 0,
                                    misc_ids = string.Empty,
                                    kot_ids = string.Empty,
                                    comp_roomserv_kitch_amt = 0,
                                    comp_roomrent_amt = 0,
                                    comp_tele_call_amt = 0,
                                    comp_laundary_amt = 0,
                                    comp_misc_charges_amt = 0,
                                    comp_total_amt_amt = 0,
                                    comp_xtra_bed = 0,
                                    sep_roomserv_kitch_amt = 0,
                                    sep_roomrent_amt = 0,
                                    sep_tele_call_amt = 0,
                                    sep_laundary_amt = 0,
                                    sep_misc_charges_amt = 0,
                                    sep_total_amt_amt = 0,
                                    sep_xtra_bed = 0,
                                    comp_misc_ids = string.Empty,
                                    sep_misc_ids = string.Empty,
                                    comp_kot_ids = string.Empty,
                                    sep_kot_ids = string.Empty,
                                    minibar = 0,
                                    sep_minibar = 0,
                                    comp_minibar = 0,
                                    bedno = string.Empty
                                };
                                #endregion Hotel Bill details

                                //objAddBill.Hotelbilldet_id = dbContext.hotelbilldetails.Max(x => x.Hotelbilldet_id) + 1;

                                objAddBill.total_amt_amt = objAddBill.roomrent_amt + objAddBill.roomserv_kitch_amt + objAddBill.misc_charges_amt
                                     + objAddBill.luxurytax + objAddBill.xtra_bed;
                                objAddBill.servtax = (objAddBill.total_amt_amt * (CommonVariables.MiscGST / 100));
                                objAddBill.total_amt_amt = objAddBill.total_amt_amt + objAddBill.servtax;

                                lstHotelbilldetail.Add(objAddBill);

                                currentDate = currentDate.AddDays(1);
                            }
                        }
                        #endregion New Addition Entry
                    }

                    #region New Misc Entry
                    IList<EL.RESERVATION_MISC_DETAILS> lstResrvMisc = objReservation.RESERVATION_MISC_DETAILS.ToList();
                    foreach (EL.RESERVATION_MISC_DETAILS objReervMisc in lstResrvMisc)
                    {
                        EL.HotelBill_MISC_DETAILS objMiscDest = new EL.HotelBill_MISC_DETAILS
                        {
                            Misc_items_Id = objReervMisc.Misc_items_Id,
                            PRICE = objReervMisc.PRICE,
                            QUANTITY = objReervMisc.QUANTITY,
                            HRS = objReervMisc.HRS,
                            AMOUNT = objReervMisc.AMOUNT,
                            EXTRAHRS = objReervMisc.EXTRAHRS,
                            MiscDate = objReervMisc.MiscDate,
                            Servtaxrate = CommonVariables.MiscGST,
                            Serctaxamt = ((objReervMisc.PRICE * objReervMisc.QUANTITY) * CommonVariables.MiscGST) / 100
                        };

                        objMiscDest.AMOUNT = objMiscDest.AMOUNT + objMiscDest.Serctaxamt;

                        this.lstMiscDetails.Add(objMiscDest);
                    }

                    #endregion New Entry
                }
                BindControlsValue();
                SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in FillDataByReservID");
            }
        }

        private bool ValidateFormData()
        {
            if (string.IsNullOrEmpty(txtCustName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please select Customer !!", this.Text);
                txtCustName.Focus();
                return false;
            }
            //else if (this.dgvSeminarDetails.Rows.Count == 0 && this.dgvCateringDetails.Rows.Count == 0 && this.dgvMiscDetails.Rows.Count == 0)
            //{
            //    CustomMessageBox.ShowInformationMessage("Please enter Seminar / Catreing / Misc. details !!", this.Text);
            //    cmbSeminar.Focus();
            //    return false;
            //}
            else
                return true;
        }        

        #region SEMINAR Actions
        private void MiddlePage()
        {
            this.rowindex = -1;
            cmbSeminar.SelectedIndex = 0;
            cmbSeminarType.SelectedIndex = 0;
            txtSemnRent.Text = string.Empty;
            txtLuxuryTax.Text = string.Empty;
            txtSCharge.Text = string.Empty;
            txtTotalAmt.Text = "0.00";
            txtPax.Text = string.Empty;
            txtGstPerc.Text = CommonVariables.MiscGST.ToString();
            dtmReservTo.Value = DateTime.Now;
            txtExtraHrs.Text = string.Empty;
            txtExtraHrscharg.Text = string.Empty;
        }

        private void BindHotelBilldetails()
        {
            try
            {
                if (lstHotelbilldetail == null)
                {
                    lstHotelbilldetail = new List<EL.hotelbilldetail>();
                    //lstHotelbilldetail.Add(new EL.hotelbilldetail());
                }

                var dbData = lstHotelbilldetail.Select(c =>
                    new
                    {
                        Date = (c.date_ofdet.HasValue ? Convert.ToDateTime(c.date_ofdet).ToString("dd/MMM/yyyy") : string.Empty),
                        c.Hotelbilldet_id,
                        Seminar_Hall = c.roomno,
                        Seminar_Type = c.reservation_PI_roomtype,
                        Seminar_Rent = (c.roomrent_amt.HasValue ? Convert.ToDouble(c.roomrent_amt).ToString("0.00") : "0.00"),
                        Luxury_Tax = (c.servtax.HasValue ? Convert.ToDouble(c.servtax).ToString("0.00") : "0.00"),
                        GST = (c.GSTAmt.HasValue ? Convert.ToDouble(c.GSTAmt).ToString("0.00") : "0.00"),
                        ExtraHrsAM = (c.ExtraHrsBeforeAmt.HasValue ? Convert.ToDouble(c.ExtraHrsBeforeAmt).ToString("0.00") : "0.00"),
                        ExtraHrsPM = (c.ExtraHrsAfterAmt.HasValue ? Convert.ToDouble(c.ExtraHrsAfterAmt).ToString("0.00") : "0.00"),
                        FromTo = c.Datefromto,
                        DiscPer = (c.roomdiscperc.HasValue ? Convert.ToDouble(c.roomdiscperc.Value).ToString("0.00") : "0.00"),
                        DiscAmt = (c.roomdiscamt.HasValue ? Convert.ToDouble(c.roomdiscamt.Value).ToString("0.00") : "0.00"),
                        Total_Amt = (c.total_amt_amt.HasValue ? Convert.ToDouble(c.total_amt_amt).ToString("0.00") : "0.00"),
                        PAX = (c.males.HasValue ? Convert.ToInt32(c.males) : 0)
                    });

                dgvSeminarDetails.DataSource = dbData.ToList();
                dgvSeminarDetails.Columns["Date"].HeaderCell.Style.BackColor = System.Drawing.Color.LightGray;
                dgvSeminarDetails.Columns["Hotelbilldet_id"].Visible = false;
                dgvSeminarDetails.Columns["Date"].Frozen = true;
                dgvSeminarDetails.Columns["Date"].DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                dgvSeminarDetails.Columns["Seminar_Rent"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["Luxury_Tax"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["GST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["ExtraHrsAM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["ExtraHrsPM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["DiscPer"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["DiscAmt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["Total_Amt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSeminarDetails.Columns["PAX"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in BindSeminarBillDetails");
            }
        }

        private void btnSNew_Click(object sender, EventArgs e)
        {
            MiddlePage();
        }

        private void btnSAddChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbSeminar.SelectedIndex < 1 || cmbSeminarType.SelectedIndex < 1)
                {
                    CustomMessageBox.ShowInformationMessage("Please select Seminar type or Seminar category !!", this.Text);
                    return;
                }

                decimal roomrent = 0;
                decimal.TryParse(txtTotalAmt.Text, out roomrent);

                if (rowindex > -1)
                {
                    #region Edit
                    lstHotelbilldetail[rowindex].roomno = (cmbSeminar.SelectedIndex > 0 ? cmbSeminar.Text : lstHotelbilldetail[rowindex].roomno);
                    lstHotelbilldetail[rowindex].room_number_ID = (cmbSeminar.SelectedIndex > 0 ? Convert.ToInt32(cmbSeminar.SelectedValue) : lstHotelbilldetail[rowindex].room_number_ID);
                    lstHotelbilldetail[rowindex].date_ofdet = dtmReservTo.Value.Date;
                    lstHotelbilldetail[rowindex].roomrent_amt = !string.IsNullOrEmpty(txtSemnRent.Text) ? Convert.ToDouble(txtSemnRent.Text) : 0;
                    lstHotelbilldetail[rowindex].total_amt_amt = !string.IsNullOrEmpty(txtTotalAmt.Text) ? Convert.ToDouble(txtTotalAmt.Text) : 0;
                    lstHotelbilldetail[rowindex].luxurytax = !string.IsNullOrEmpty(txtSCharge.Text) ? Convert.ToDouble(txtSCharge.Text) : 0;
                    lstHotelbilldetail[rowindex].males = !string.IsNullOrEmpty(txtPax.Text) ? Convert.ToInt32(txtPax.Text) : 0;
                    lstHotelbilldetail[rowindex].females = 0;
                    lstHotelbilldetail[rowindex].child = !string.IsNullOrEmpty(txtPax.Text) ? Convert.ToInt32(txtPax.Text) : 0;
                    lstHotelbilldetail[rowindex].reservation_PI_roomtype = cmbSeminarType.SelectedIndex > 0 ? cmbSeminarType.Text : lstHotelbilldetail[rowindex].reservation_PI_roomtype;
                    lstHotelbilldetail[rowindex].ROOM_TYPE_ID = (cmbSeminarType.SelectedIndex > 0 ? Convert.ToInt32(cmbSeminarType.SelectedValue) : lstHotelbilldetail[rowindex].ROOM_TYPE_ID);
                    lstHotelbilldetail[rowindex].ExtraHrsBeforeAmt = !string.IsNullOrEmpty(txtExtraHrs.Text) ? Convert.ToDouble(txtExtraHrs.Text) : 0;
                    lstHotelbilldetail[rowindex].ExtraHrsAfterAmt = !string.IsNullOrEmpty(txtExtraHrscharg.Text) ? Convert.ToDouble(txtExtraHrscharg.Text) : 0;
                    lstHotelbilldetail[rowindex].Datefromto = dtmReservTo.Value.Date.ToString("dd/MMM/yyyy") + " 9:00 -- " + dtmReservTo.Value.Date.ToString("dd/MMM/yyyy") + " 17:00";
                    lstHotelbilldetail[rowindex].GSTRate = !string.IsNullOrEmpty(txtGstPerc.Text) ? Convert.ToDouble(txtGstPerc.Text) : 0;
                    lstHotelbilldetail[rowindex].GSTAmt = !string.IsNullOrEmpty(txtSCharge.Text) ? Convert.ToDouble(txtSCharge.Text) : 0;
                    
                    lstHotelbilldetail[rowindex].roomactualamt = lstHotelbilldetail[rowindex].roomactualamt + lstHotelbilldetail[rowindex].ExtraHrsBeforeAmt + lstHotelbilldetail[rowindex].ExtraHrsAfterAmt;
                    lstHotelbilldetail[rowindex].roomdiscperc = discountper;
                    lstHotelbilldetail[rowindex].roomdiscamt = (lstHotelbilldetail[rowindex].roomrent_amt * (discountper / 100));
                    lstHotelbilldetail[rowindex].roomrent_amt = lstHotelbilldetail[rowindex].roomactualamt - lstHotelbilldetail[rowindex].roomdiscamt;
                    lstHotelbilldetail[rowindex].GSTAmt = lstHotelbilldetail[rowindex].roomrent_amt * (lstHotelbilldetail[rowindex].GSTRate / 100);
                    lstHotelbilldetail[rowindex].luxurytax = lstHotelbilldetail[rowindex].roomrent_amt * (lstHotelbilldetail[rowindex].GSTRate / 100);

                    lstHotelbilldetail[rowindex].total_amt_amt = lstHotelbilldetail[rowindex].roomrent_amt + lstHotelbilldetail[rowindex].GSTAmt;
                    #endregion Edit
                }
                else
                {
                    #region add
                    EL.hotelbilldetail objAddBill = new EL.hotelbilldetail
                    {
                        hotelBill_ID = this.objHotelBill.hotelBill_ID,
                        roomno = cmbSeminar.Text,
                        room_number_ID = (cmbSeminar.SelectedIndex > 0 ? Convert.ToInt32(cmbSeminar.SelectedValue) : -1),
                        date_ofdet = dtmReservTo.Value.Date,
                        roomrent_amt = !string.IsNullOrEmpty(txtSemnRent.Text) ? Convert.ToDouble(txtSemnRent.Text) : 0,
                        luxurytax = !string.IsNullOrEmpty(txtSCharge.Text) ? Convert.ToDouble(txtSCharge.Text) : 0,
                        males = !string.IsNullOrEmpty(txtPax.Text) ? Convert.ToInt32(txtPax.Text) : 0,
                        females = 0,
                        child = !string.IsNullOrEmpty(txtPax.Text) ? Convert.ToInt32(txtPax.Text) : 0,
                        reservation_PI_roomtype = cmbSeminarType.Text,
                        ROOM_TYPE_ID = (cmbSeminarType.SelectedIndex > 0 ? Convert.ToInt32(cmbSeminarType.SelectedValue) : -1),
                        ExtraHrsBeforeAmt = !string.IsNullOrEmpty(txtExtraHrs.Text) ? Convert.ToDouble(txtExtraHrs.Text) : 0,
                        ExtraHrsAfterAmt = !string.IsNullOrEmpty(txtExtraHrscharg.Text) ? Convert.ToDouble(txtExtraHrscharg.Text) : 0,
                        Datefromto = dtmReservTo.Value.Date.ToString("dd/MMM/yyyy") + " 9:00 -- " + dtmReservTo.Value.Date.ToString("dd/MMM/yyyy") + " 17:00",
                        GSTRate = !string.IsNullOrEmpty(txtGstPerc.Text) ? Convert.ToDouble(txtGstPerc.Text) : 0,
                        GSTAmt = !string.IsNullOrEmpty(txtSCharge.Text) ? Convert.ToDouble(txtSCharge.Text) : 0,
                        
                        xtra_bed = 0,
                        roomserv_kitch_amt = 0,
                        tele_call_amt = 0,
                        laundary_amt = 0,
                        salestax = 0,
                        misc_charges_amt = 0,
                        misc_ids = string.Empty,
                        kot_ids = string.Empty,
                        servtax = 0,
                        comp_roomserv_kitch_amt = 0,
                        comp_roomrent_amt = 0,
                        comp_tele_call_amt = 0,
                        comp_laundary_amt = 0,
                        comp_misc_charges_amt = 0,
                        comp_total_amt_amt = 0,
                        comp_xtra_bed = 0,
                        sep_roomserv_kitch_amt = 0,
                        sep_roomrent_amt = 0,
                        sep_tele_call_amt = 0,
                        sep_laundary_amt = 0,
                        sep_misc_charges_amt = 0,
                        sep_total_amt_amt = 0,
                        sep_xtra_bed = 0,
                        comp_misc_ids = string.Empty,
                        sep_misc_ids = string.Empty,
                        comp_kot_ids = string.Empty,
                        sep_kot_ids = string.Empty,
                        minibar = 0,
                        sep_minibar = 0,
                        comp_minibar = 0,
                        
                    };
                    objAddBill.roomactualamt = objAddBill.ExtraHrsBeforeAmt + objAddBill.ExtraHrsAfterAmt;
                    objAddBill.roomdiscperc = discountper;
                    objAddBill.roomdiscamt = (objAddBill.roomrent_amt * (discountper / 100));
                    objAddBill.roomrent_amt = objAddBill.roomactualamt - objAddBill.roomdiscamt;
                    objAddBill.GSTAmt = objAddBill.roomrent_amt * (objAddBill.GSTRate / 100);
                    objAddBill.luxurytax = objAddBill.roomrent_amt * (objAddBill.GSTRate / 100);
                    objAddBill.total_amt_amt = objAddBill.roomrent_amt + objAddBill.GSTAmt;
                    //objAddBill.Hotelbilldet_id = dbContext.hotelbilldetails.Max(x => x.Hotelbilldet_id) + 1;
                    lstHotelbilldetail.Add(objAddBill);
                    #endregion Add
                }

                MiddlePage();
                BindHotelBilldetails();
                SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Add/Change Seminar Details");
            }
        }

        private void btnSRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (rowindex > -1 && this.lstHotelbilldetail.Count > 0)
                {
                    this.lstHotelbilldetail.RemoveAt(rowindex);
                    MiddlePage();
                    BindHotelBilldetails();
                    SeminarCalculations();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Remove Seminar Details");
            }
        }

        private void cmbSeminarType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                txtSemnRent.Text = string.Empty;
                txtGstPerc.Text = CommonVariables.MiscGST.ToString();
                txtSCharge.Text = string.Empty;
                txtTotalAmt.Text = string.Empty;
                txtPax.Text = string.Empty;
                txtLuxuryTax.Text = string.Empty;
                txtExtraHrs.Text = string.Empty;
                txtExtraHrscharg.Text = string.Empty;

                if (cmbSeminarType.SelectedIndex > 0)
                {
                    int roomno = Convert.ToInt32(cmbSeminarType.SelectedValue);
                    var rmType = objMasterData.GetRoomType().FirstOrDefault(x => x.RM_TYPE_ID == roomno);
                    if (rmType != null)
                    {
                        txtSemnRent.Text = (rmType.Room_Type_rate.HasValue ? rmType.Room_Type_rate.Value.ToString() : "0");
                        txtPax.Text = (rmType.NoPersons.HasValue ? rmType.NoPersons.Value.ToString() : "0");
                        txtSCharge.Text = (Convert.ToDouble(txtSemnRent.Text) * (CommonVariables.MiscGST / 100)).ToString("0.00");
                        txtTotalAmt.Text = (Convert.ToDouble(txtSemnRent.Text) + Convert.ToDouble(txtSCharge.Text)).ToString("0.00");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In cmbSeminarType_SelectedIndexChanged");
            }
        }

        private void dgvSeminarDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvSeminarDetails.SelectedRows.Count > 0 && !panel1.Controls.Contains(pnlAlpha))
            {
                this.rowindex = dgvSeminarDetails.SelectedRows[0].Index;
                cmbSeminar.SelectedValue = Convert.ToInt32(this.lstHotelbilldetail[rowindex].room_number_ID);
                cmbSeminarType.SelectedValue = Convert.ToInt32(this.lstHotelbilldetail[rowindex].ROOM_TYPE_ID);
                txtPax.Text = Convert.ToString(this.lstHotelbilldetail[rowindex].males);
                txtSemnRent.Text = Convert.ToString(this.lstHotelbilldetail[rowindex].roomrent_amt);
                txtGstPerc.Text = Convert.ToString(this.lstHotelbilldetail[rowindex].GSTRate);
                txtSCharge.Text = Convert.ToString(this.lstHotelbilldetail[rowindex].GSTAmt);
                txtTotalAmt.Text = Convert.ToString(this.lstHotelbilldetail[rowindex].total_amt_amt);
                txtExtraHrs.Text = Convert.ToString(this.lstHotelbilldetail[rowindex].xtra_bed);
                dtmReservTo.Value = this.lstHotelbilldetail[rowindex].date_ofdet.HasValue ? this.lstHotelbilldetail[rowindex].date_ofdet.Value : DateTime.Now;
            }
        }
        #endregion SEMINAR Actions

        private void SeminarCalculations()
        {
            try
            {
                if (lstHotelbilldetail.Count > 0)
                {
                    this.objHotelBill.totalroomrent = this.lstHotelbilldetail.Sum(x => x.roomrent_amt);
                    this.objHotelBill.luxurytaxamt = this.lstHotelbilldetail.Sum(x => x.luxurytax);
                    this.objHotelBill.salestaxrate = CommonVariables.MiscGST;
                    this.objHotelBill.salestaxamt = this.lstHotelbilldetail.Sum(x => x.servtax);
                    this.objHotelBill.totaltelephone = this.lstHotelbilldetail.Sum(x => x.tele_call_amt);
                    this.objHotelBill.totallaundary = this.lstHotelbilldetail.Sum(x => x.laundary_amt);
                    this.objHotelBill.totalMiscCharges = this.lstHotelbilldetail.Sum(x => x.misc_charges_amt);
                    this.objHotelBill.totalextrabed = this.lstHotelbilldetail.Sum(x => x.xtra_bed);
                    this.objHotelBill.totalamt = (this.objHotelBill.totalroomrent + this.objHotelBill.luxurytaxamt + this.objHotelBill.totalextrabed +
                        this.objHotelBill.salestaxamt + this.objHotelBill.totaltelephone + this.objHotelBill.totallaundary + this.objHotelBill.totalMiscCharges);
                }
                else
                {
                    this.objHotelBill.totalroomrent = 0;
                    this.objHotelBill.luxurytaxamt = 0;
                    this.objHotelBill.salestaxrate = CommonVariables.MiscGST;
                    this.objHotelBill.salestaxamt = 0;
                    this.objHotelBill.totaltelephone = 0;
                    this.objHotelBill.totallaundary = 0;
                    this.objHotelBill.totalMiscCharges = 0;
                    this.objHotelBill.totalextrabed = 0;
                    this.objHotelBill.totalamt = (this.objHotelBill.totalroomrent + this.objHotelBill.luxurytaxamt + this.objHotelBill.totalextrabed +
                        this.objHotelBill.salestaxamt + this.objHotelBill.totaltelephone + this.objHotelBill.totallaundary + this.objHotelBill.totalMiscCharges);
                }

                if (lstMiscDetails.Count > 0) objHotelBill.MiscAmountTotal = lstMiscDetails.Sum(x => x.AMOUNT);

                //if (lstCateringDetails.Count > 0) objHotelBill.CateringAmountTotal = lstCateringDetails.Sum(x => x.CateringAMOUNT);

                objHotelBill.totalamt += objHotelBill.CateringAmountTotal + objHotelBill.MiscAmountTotal;

                objHotelBill.advancerecd = Convert.ToDouble(recptAmt);

                this.objHotelBill.grandtotalamt = this.objHotelBill.totalamt - this.objHotelBill.advancerecd;
                this.objHotelBill.netpayable = this.objHotelBill.grandtotalamt.HasValue ? Convert.ToDouble(Convert.ToInt32(this.objHotelBill.grandtotalamt.Value)) : 0;
                this.objHotelBill.roundoff = this.objHotelBill.netpayable - this.objHotelBill.grandtotalamt;

                txtTotalCatCanAmt.Text = objHotelBill.CateringAmountTotal.HasValue ? Convert.ToDouble(objHotelBill.CateringAmountTotal).ToString("0.00") : "0.00";
                txtTotalMiscAmt.Text = (objHotelBill.MiscAmountTotal.HasValue ? Convert.ToDouble(objHotelBill.MiscAmountTotal).ToString("0.00") : "0.00");
                txtTotal.Text = objHotelBill.totalamt.HasValue ? Convert.ToDouble(objHotelBill.totalamt).ToString("0.00") : "0.00";
                txtRoundOff.Text = objHotelBill.roundoff.HasValue ? Convert.ToDouble(objHotelBill.roundoff).ToString("0.00") : "0.00";
                txtNetAdvRece.Text = recptAmt.ToString("0.00");
                txtAmountDue.Text = ((objHotelBill.totalamt.HasValue ? Convert.ToDouble(objHotelBill.totalamt) : 0) +
                    (objHotelBill.roundoff.HasValue ? Convert.ToDouble(objHotelBill.roundoff) : 0) - Convert.ToDouble(recptAmt)).ToString("0.00");
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Bill Calculation");
            }
        }

        #region CATERING Actions
        private void catering()
        {
            //this.rowIndexCatDet = -1;
            ////dtmCatDate.Value = DateTime.Now;
            //txtCatBillNo.Text = "0";
            //txtCatAmount.Text = "0.00";
        }

        private void BindCateringDetails()
        {
            try
            {
                //if (lstCateringDetails == null) lstCateringDetails = new List<EL.HotelBill_CATERING_DETAILS>();
                ////if (dgvCateringDetails.RowCount > 0) dgvSeminarDetails.Rows.Clear();
                //var dbCData = lstCateringDetails.Select((x, index) =>
                //    new
                //    {
                //        SlNo = index + 1,
                //        x.HotelBill_CATER_id,
                //        Date = (x.CateringBillDate.HasValue ? Convert.ToDateTime(x.CateringBillDate).ToString("dd/MMM/yyyy") : string.Empty),
                //        Bill_No = x.CateringBillNo,
                //        Amount = (x.CateringAMOUNT.HasValue ? Convert.ToDouble(x.CateringAMOUNT).ToString("0.00") : "0.00")
                //    });

                //dgvCateringDetails.DataSource = dbCData.ToList();
                //dgvCateringDetails.Columns["HotelBill_CATER_id"].Visible = false;
                //dgvCateringDetails.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Eror in BindCateringDetails");
            }
        }

        private void btnCatNew_Click(object sender, EventArgs e)
        {
            catering();
        }

        private void btnCatAddChange_Click(object sender, EventArgs e)
        {
            try
            {
                //if (string.IsNullOrEmpty(txtCatAmount.Text) && Convert.ToDecimal(txtCatAmount.Text) <= 0)
                //    return;

                //if (this.rowIndexCatDet > -1)
                //{
                //    lstCateringDetails[rowIndexCatDet].CateringBillDate = dtmCatDate.Value.Date;
                //    lstCateringDetails[rowIndexCatDet].CateringBillNo = !string.IsNullOrEmpty(txtCatBillNo.Text) ? txtCatBillNo.Text : "0";
                //    lstCateringDetails[rowIndexCatDet].CateringAMOUNT = !string.IsNullOrEmpty(txtCatAmount.Text) ? Convert.ToDouble(txtCatAmount.Text) : 0;
                //}
                //else
                //{
                //    lstCateringDetails.Add(new EL.HotelBill_CATERING_DETAILS
                //    {
                //        CateringBillDate = dtmCatDate.Value.Date,
                //        CateringBillNo = !string.IsNullOrEmpty(txtCatBillNo.Text) ? txtCatBillNo.Text : "0",
                //        CateringAMOUNT = !string.IsNullOrEmpty(txtCatAmount.Text) ? Convert.ToDouble(txtCatAmount.Text) : 0
                //    });
                //}
                //catering();
                BindCateringDetails();
                SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Add/Change Catering Details");
            }
        }

        private void btnCatRemove_Click(object sender, EventArgs e)
        {
            try
            {
                //if (rowIndexCatDet > -1)
                //    lstCateringDetails.RemoveAt(rowIndexCatDet);
                //catering();
                //BindCateringDetails();
                //SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Remove Catering Details");
            }
        }

        private void dgvCateringDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (dgvCateringDetails.SelectedRows.Count > 0 && !panel1.Controls.Contains(pnlAlpha))
            //{
            //    this.rowIndexCatDet = dgvCateringDetails.SelectedRows[0].Index;
            //    dtmCatDate.Value = lstCateringDetails[rowIndexCatDet].CateringBillDate.HasValue ? lstCateringDetails[rowIndexCatDet].CateringBillDate.Value : DateTime.Now;
            //    txtCatBillNo.Text = lstCateringDetails[rowIndexCatDet].CateringBillNo;
            //    txtCatAmount.Text = lstCateringDetails[rowIndexCatDet].CateringAMOUNT.HasValue ? Convert.ToString(lstCateringDetails[rowIndexCatDet].CateringAMOUNT.Value) : string.Empty;
            //}
        }
        #endregion CATERING Actions

        #region MISC Actions
        private void miscItems()
        {
            this.rowIndexMiscDet = -1;
            //dtmMiscDate.Value = DateTime.Now;
            txtMiscAmount.Text = "0.00";
            cmbMiscItem.SelectedIndex = 0;
            txtMiscRate.Text = "0.00";
            txtMiscQty.Text = "0";
            txtMiscHrs.Text = "0";
        }

        private void BindMiscellaneousDetails()
        {
            try
            {
                int index = 1;
                if (this.lstMiscDetails == null) this.lstMiscDetails = new List<EL.HotelBill_MISC_DETAILS>();
                if (dgvMiscDetails.RowCount > 0) dgvMiscDetails.DataSource = null;
                var dbMData = (from w in lstMiscDetails
                               join d in objMasterData.GetMiscItems() on w.Misc_items_Id equals d.Misc_items_Id
                               select
                                   new
                                   {
                                       SlNo = index++,
                                       w.HotelBill_MISC_id,
                                       Date = (w.MiscDate.HasValue ? Convert.ToDateTime(w.MiscDate.Value).ToString("dd/MMM/yyyy") : string.Empty),
                                       Item = d.Misc_items_Name,
                                       Price = (w.PRICE.HasValue ? Convert.ToDouble(w.PRICE.Value).ToString("0.00") : "0.00"),
                                       Quantity = (w.QUANTITY.HasValue ? w.QUANTITY.ToString() : string.Empty),
                                       Hrs = (w.HRS.HasValue ? w.HRS.ToString() : string.Empty),
                                       GST = (w.Serctaxamt.HasValue ? Convert.ToDouble(w.Serctaxamt.Value).ToString("0.00") : "0.00"),
                                       Amount = (w.AMOUNT.HasValue ? Convert.ToDouble(w.AMOUNT.Value).ToString("0.00") : "0.00")
                                   }).ToList();


                dgvMiscDetails.DataSource = dbMData.ToList();
                //dgvMiscDetails.Rows[dgvMiscDetails.Rows.Count - 1].DefaultCellStyle.BackColor = System.Drawing.Color.LightGreen;

                dgvMiscDetails.Columns["HotelBill_MISC_id"].Visible = false;

                dgvMiscDetails.Columns["SlNo"].Width = 25;
                dgvMiscDetails.Columns["Date"].Width = 60;
                dgvMiscDetails.Columns["Item"].Width = 100;
                dgvMiscDetails.Columns["Price"].Width = 40;
                dgvMiscDetails.Columns["Quantity"].Width = 20;
                dgvMiscDetails.Columns["Hrs"].Width = 25;
                dgvMiscDetails.Columns["GST"].Width = 40;
                dgvMiscDetails.Columns["Amount"].Width = 80;

                dgvMiscDetails.Columns["Quantity"].DefaultCellStyle.Format = "0";
                dgvMiscDetails.Columns["Quantity"].HeaderText = "Qty";
                dgvMiscDetails.Columns["Date"].DefaultCellStyle.Format = "dd/MMM/yyyy";

                dgvMiscDetails.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvMiscDetails.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvMiscDetails.Columns["Hrs"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvMiscDetails.Columns["GST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvMiscDetails.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Eror in Bind Miscellaneous Details");
            }
        }

        private void btnMiscAdd_Click(object sender, EventArgs e)
        {
            miscItems();
        }

        private void btnMiscAddChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtMiscAmount.Text) && Convert.ToDecimal(txtMiscAmount.Text) <= 0) return;

                if (this.rowIndexMiscDet > -1)
                {
                    txtMiscQty_Leave(null, null);
                    lstMiscDetails[rowIndexMiscDet].Misc_items_Id = cmbMiscItem.SelectedIndex > 0 ? Convert.ToInt32(cmbMiscItem.SelectedValue) : 0;
                    lstMiscDetails[rowIndexMiscDet].PRICE = !string.IsNullOrEmpty(txtMiscRate.Text) ? Convert.ToDouble(txtMiscRate.Text) : 0;
                    lstMiscDetails[rowIndexMiscDet].QUANTITY = !string.IsNullOrEmpty(txtMiscQty.Text) ? Convert.ToInt32(txtMiscQty.Text) : 0;
                    lstMiscDetails[rowIndexMiscDet].HRS = !string.IsNullOrEmpty(txtMiscHrs.Text) ? Convert.ToInt32(txtMiscHrs.Text) : 0;
                    lstMiscDetails[rowIndexMiscDet].Servtaxrate = CommonVariables.MiscGST;
                    lstMiscDetails[rowIndexMiscDet].Serctaxamt = !string.IsNullOrEmpty(txtMiscAmount.Text) ? Convert.ToDouble(txtMiscAmount.Text) * CommonVariables.MiscGST / 100 : 0;
                    lstMiscDetails[rowIndexMiscDet].AMOUNT = !string.IsNullOrEmpty(txtMiscAmount.Text) ? Convert.ToDouble(txtMiscAmount.Text) : 0;
                    lstMiscDetails[rowIndexMiscDet].MiscDate = dtmMiscDate.Value.Date;
                    lstMiscDetails[rowIndexMiscDet].AMOUNT = lstMiscDetails[rowIndexMiscDet].AMOUNT.Value + lstMiscDetails[rowIndexMiscDet].Serctaxamt.Value;
                }
                else
                {
                    EL.HotelBill_MISC_DETAILS objMiscDest = new EL.HotelBill_MISC_DETAILS
                    {
                        Misc_items_Id = cmbMiscItem.SelectedIndex > 0 ? Convert.ToInt32(cmbMiscItem.SelectedValue) : 0,
                        PRICE = !string.IsNullOrEmpty(txtMiscRate.Text) ? Convert.ToDouble(txtMiscRate.Text) : 0,
                        QUANTITY = !string.IsNullOrEmpty(txtMiscQty.Text) ? Convert.ToInt32(txtMiscQty.Text) : 0,
                        HRS = !string.IsNullOrEmpty(txtMiscHrs.Text) ? Convert.ToInt32(txtMiscHrs.Text) : 0,
                        Servtaxrate = CommonVariables.MiscGST,
                        Serctaxamt = !string.IsNullOrEmpty(txtMiscAmount.Text) ? Convert.ToDouble(txtMiscAmount.Text) * CommonVariables.MiscGST / 100 : 0,
                        AMOUNT = !string.IsNullOrEmpty(txtMiscAmount.Text) ? Convert.ToDouble(txtMiscAmount.Text) : 0,
                        MiscDate = dtmMiscDate.Value.Date
                    };
                    objMiscDest.AMOUNT = objMiscDest.AMOUNT.Value + objMiscDest.Serctaxamt.Value;

                    lstMiscDetails.Add(objMiscDest);

                }
                miscItems();
                BindMiscellaneousDetails();
                SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Eror in Add/Change Misc Details");
            }
        }

        private void btnMiscRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.rowIndexMiscDet > -1)
                    lstMiscDetails.RemoveAt(rowIndexMiscDet);
                miscItems();
                BindMiscellaneousDetails();
                SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Eror in Remove Misc Details");
            }
        }

        private void dgvMiscDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvMiscDetails.SelectedRows.Count > 0 && !panel1.Controls.Contains(pnlAlpha))
            {
                this.rowIndexMiscDet = dgvMiscDetails.SelectedRows[0].Index;
                dtmMiscDate.Value = lstMiscDetails[rowIndexMiscDet].MiscDate.HasValue ? lstMiscDetails[rowIndexMiscDet].MiscDate.Value : DateTime.Now;
                cmbMiscItem.SelectedValue = lstMiscDetails[rowIndexMiscDet].Misc_items_Id;
                txtMiscRate.Text = lstMiscDetails[rowIndexMiscDet].PRICE.HasValue ? Convert.ToString(lstMiscDetails[rowIndexMiscDet].PRICE.Value) : string.Empty;
                txtMiscQty.Text = lstMiscDetails[rowIndexMiscDet].QUANTITY.HasValue ? Convert.ToString(lstMiscDetails[rowIndexMiscDet].QUANTITY.Value) : string.Empty;
                txtMiscHrs.Text = lstMiscDetails[rowIndexMiscDet].HRS.HasValue ? Convert.ToString(lstMiscDetails[rowIndexMiscDet].HRS.Value) : string.Empty;
                txtMiscAmount.Text = lstMiscDetails[rowIndexMiscDet].AMOUNT.HasValue ? Convert.ToString(lstMiscDetails[rowIndexMiscDet].AMOUNT.Value) : string.Empty;
            }
        }

        private void txtMiscQty_Leave(object sender, EventArgs e)
        {
            try
            {
                decimal vPrice = 0m, vQty = 0m, vHrs = 0m;
                vPrice = !string.IsNullOrEmpty(txtMiscRate.Text) ? Convert.ToDecimal(txtMiscRate.Text) : 0;
                vQty = !string.IsNullOrEmpty(txtMiscQty.Text) ? Convert.ToDecimal(txtMiscQty.Text) : 0;
                vHrs = !string.IsNullOrEmpty(txtMiscHrs.Text) ? Convert.ToDecimal(txtMiscHrs.Text) : 0;

                txtMiscAmount.Text = ((vPrice * vQty) + vHrs).ToString("0.00");
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in txtMiscqty");
            }
            
        }

        private void cmbMiscItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMiscItem.SelectedIndex > 0)
            {
                int miscId = Convert.ToInt32(cmbMiscItem.SelectedValue);
                EL.Misc_items objMisc = objMasterData.GetMiscItems().FirstOrDefault(x => x.Misc_items_Id == miscId);
                if (objMisc != null)
                {
                    txtMiscRate.Text = objMisc.Price.HasValue ? objMisc.Price.Value.ToString("0.00") : "0.00";
                    txtMiscQty.Text = objMisc.Unit.HasValue ? objMisc.Unit.Value.ToString() : "0";
                    txtMiscAmount.Text = (Convert.ToDecimal(txtMiscRate.Text) * Convert.ToDecimal(txtMiscQty.Text)).ToString("0.00");
                }
                else
                {
                    txtMiscRate.Text = string.Empty;
                    txtMiscQty.Text = string.Empty;
                    txtMiscAmount.Text = string.Empty;
                }
            }
        }
        #endregion MISC Actions

        private void BindCancelledBillDetails()
        {
            try
            {
                //if (this.lstHotelCancelBill == null) this.lstHotelCancelBill = new List<EL.hotelBillCancelAttached>();
                //var dbData = lstHotelCancelBill.Select((w, index) =>
                //    new
                //    {
                //        SlNo = index + 1,
                //        w.CancelhotelBillid,
                //        Date = (w.HotelBILL.Bdate.HasValue ? Convert.ToDateTime(w.HotelBILL.Bdate).ToString("dd/MMM/yyyy") : string.Empty),
                //        BillNo = w.HotelBILL.Bill_No
                //    });

                //dgvMiscDetails.DataSource = dbData.ToList();
                //dgvMiscDetails.Columns["HotelBill_MISC_id"].Visible = false;
                //dgvMiscDetails.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                //dgvMiscDetails.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Eror in Bind Cancelled bill Details");
            }
        }

        private void dgvAdvancePayementRece_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvAdvancePayementRece.SelectedRows.Count > 0 && !DBNull.Value.Equals(dgvAdvancePayementRece.SelectedRows[0].Cells["recpt_pay_id"].Value))
                {
                    int recepid = Convert.ToInt32(dgvAdvancePayementRece.SelectedRows[0].Cells["recpt_pay_id"].Value);
                    string recepchar = Convert.ToString(dgvAdvancePayementRece.SelectedRows[0].Cells["recpt_pay_char"].Value);

                    if (!string.IsNullOrEmpty(recepchar) && recepchar == Convert.ToString((char)CommonVariables.SpecialTag.Refund))
                    {
                        using (Transaction.frmPayRefund frmRefund = new Transaction.frmPayRefund())
                        {
                            frmRefund.recieptID = recepid;
                            frmRefund.ShowDialog();
                        }
                    }
                    else
                    {
                        using (Transaction.frmVoucher frmRecep = new Transaction.frmVoucher())
                        {
                            frmRecep.recieptID = recepid;
                            frmRecep.ShowDialog();
                        }
                    }

                    editPage = false;
                    EL.FilterClass objFilter = RefreshFilter();
                    objFilter.UniqueId = objHotelBill.hotelBill_ID;
                    resetPageData();
                    objHotelBill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.None);
                    BindControlsValue();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Eror in dgvReceiptDet_CellDoubleClick");
            }  
        }

        #region Select Guest Actions
        private void btnAddGuest_Click(object sender, EventArgs e)
        {
            using (Master.frmGuestMaster guestMaster = new Master.frmGuestMaster())
            {
                guestMaster.ShowDialog();
                GetGuestDetails(guestMaster.guestnum);
            }
        }

        private void GetGuestDetails(int guestnumber)
        {
            EL.Mast_guest objGuest = objMasterGuest.GuestDetailByID(new EL.Mast_guest { GUEST_NUM = guestnumber });
            if (objGuest != null)
            {
                if (this.objHotelBill != null && this.objHotelBill.hotelBill_ID > 0)
                {
                    this.objHotelBill.GUEST_NUM = objGuest.GUEST_NUM;
                    this.objHotelBill.Name_guest = objGuest.G_FNAME + " " + objGuest.G_LNAME;
                    this.objHotelBill.addr1_guest = objGuest.G_Street;
                    this.objHotelBill.addr2_guest = objGuest.G_PHONE1 + " " + objGuest.G_PHONE2 + " " + objGuest.G_EMAIL;
                    this.objHotelBill.Title_guest = objGuest.G_TITLE;
                }
                else
                {
                    resetPageData();
                    #region New Entry
                    this.objHotelBill = new EL.HotelBILL
                    {
                        GUEST_NUM = objGuest.GUEST_NUM,
                        Name_guest = objGuest.G_FNAME + " " + objGuest.G_LNAME,
                        addr1_guest = objGuest.G_Street,
                        addr2_guest = objGuest.G_PHONE1 + " " + objGuest.G_PHONE2 + " " + objGuest.G_EMAIL,
                        Title_guest = objGuest.G_TITLE,
                        billroomtype = 5,
                        Room_Dormatory = this.roomDorm,

                        addr3_guest = string.Empty,
                        addr1_billto = string.Empty,
                        addr2_billto = string.Empty,
                        addr3_billto = string.Empty,
                        Name_billto = string.Empty,
                        description_b = string.Empty,
                        Advance_ids = string.Empty,
                        billtochk = false,
                        activate_delete = false,
                        Grno = string.Empty,
                        reservation_Number = string.Empty,
                        HOTELBILLCANCEL = 0,

                        schargerate = 0,
                        schargeamt = 0,
                        luxurytaxamt = 0,
                        luxurytaxrate = 0,
                        salestaxamt = 0,
                        salestaxrate = 0,
                        roomserviceamt = 0,
                        discountrate = 0,
                        discountamt = 0,
                        totalkitchen = 0,
                        totalminibar = 0,
                        BillcreationType = 0,
                        sepamtroundoff = 0,
                        transportamt = 0,

                        totalamt = 0,
                        grandtotalamt = 0,
                        roundoff = 0,
                        totalroomrent = 0,
                        totaltelephone = 0,
                        totalextrabed = 0,
                        totallaundary = 0,
                        totalMiscCharges = 0,
                        advancerecd = 0,
                        netpayable = 0,
                        CateringAmountTotal = 0,
                        MiscAmountTotal = 0
                    };
                    #endregion New Entry
                }
                BindControlsValue();
            }
        }

        private void btnSelectGuest_Click(object sender, EventArgs e)
        {
            using (Search.frmGuestSearch guestSearch = new Search.frmGuestSearch())
            {
                guestSearch.guestName = txtCustName.Text;
                guestSearch.ShowDialog();
                GetGuestDetails(guestSearch.GuestNum);
            }
        }
        #endregion Select Guest Actions

        #region Bottom Actions
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            resetPageData();
            panel1.Controls.Remove(this.pnlAlpha);
            btnUndo.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            editPage = true;
            AdditionalTabEnable(true);
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            editPage = false;
            var hotelDet = this.objHotelBill;
            resetPageData();
            if (hotelDet != null && hotelDet.hotelBill_ID > 0)
            {
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = hotelDet.hotelBill_ID;
                this.objHotelBill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.None);
                BindControlsValue();
            }
            else
                btnLast_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)  
        {
            panel1.Controls.Remove(this.pnlAlpha);
            btnUndo.Enabled = true;
            btnSave.Enabled = true;
            btnAddNew.Enabled = false;
            btnEdit.Enabled = false;
            editPage = true;
            AdditionalTabEnable(true);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateFormData() && this.objHotelBill != null)
                {
                    bool isNew = false;

                    this.objHotelBill.Bdate = dtmDate.Value.Date;
                    this.objHotelBill.Btime = dtmDate.MinDate.Add(new TimeSpan(dtmDate.Value.Hour, dtmDate.Value.Minute, dtmDate.Value.Second));
                    if (dtmFrom.Checked) 
                        this.objHotelBill.checkintime_date = dtmFrom.Value;
                    else
                        this.objHotelBill.checkintime_date = null;
                    if (dtmUpTo.Checked) 
                        this.objHotelBill.checkouttime_date = dtmUpTo.Value;
                    else
                        this.objHotelBill.checkouttime_date = null;
                    this.objHotelBill.description_b = txtRemarks.Text;
                    this.objHotelBill.billtochk = chkBillTo.Checked;
                    this.objHotelBill.Name_billto = txtBillTo.Text;
                    //if (!string.IsNullOrEmpty(txtFolio.Text)) this.objHotelBill.Folio_No = Convert.ToInt32(txtFolio.Text);
                    objHotelBill.MachineName = Environment.MachineName;
                    
                    if (objHotelBill.hotelBill_ID > 0)
                    {
                        #region Edit
                        objHotelBill.id1 = Frm_Login.UserLogin.log_id;
                        objHotelBill.date_of_mod = DateTime.Now;
                        objHotelBill.modifiedby = Frm_Login.UserLogin.loginID;
                        #endregion Edit
                    }
                    else
                    {
                        isNew = true;

                        #region Add
                        objHotelBill.Bill_No = objHostelData.GetHostelBillNumber(RefreshFilter());
                        objHotelBill.Finalby = Frm_Login.UserLogin.loginID;
                        objHotelBill.id3 = Frm_Login.UserLogin.log_id;
                        objHotelBill.date_of_final = DateTime.Now;
                        objHotelBill.id = Frm_Login.UserLogin.log_id;
                        objHotelBill.date_of_add = DateTime.Now;
                        objHotelBill.createdby = Frm_Login.UserLogin.loginID;
                        #endregion Add
                    }

                    objHotelBill.hotelbilldetails = lstHotelbilldetail;
                    //objHotelBill.HotelBill_CATERING_DETAILS = lstCateringDetails;
                    objHotelBill.HotelBill_MISC_DETAILS = lstMiscDetails;

                    EL.HotelBILL objNewHotelbill = objHostelData.SaveAndUpdateHotelBill(isNew, this.objHotelBill);

                    resetPageData();
                    this.objHotelBill = objNewHotelbill;
                    if (this.objHotelBill != null)
                        CustomMessageBox.ShowInformationMessage("Record Saved !!!", this.Text);
                    else if (this.objHotelBill == null && (Button)sender == btnDelete)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Saved !!!", this.Text);
                        btnAddNew_Click(sender, e);
                    }
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!!", this.Text);
                    
                    editPage = false;
                    BindControlsValue();
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Unable to save data", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in Save data");
            }
        }

        private void btnSearchByBillNo_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                using (Search.frmHotelSearch frmHSearch = new Search.frmHotelSearch())
                {
                    frmHSearch.roomDorm = this.roomDorm;
                    frmHSearch.ShowDialog();
                    if (frmHSearch.hotelbillid > 0)
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        objFilter.UniqueId = frmHSearch.hotelbillid;
                        resetPageData();
                        this.objHotelBill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.None);
                        BindControlsValue();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnSearchByBillNo_Click");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Hostel Booking ?") == System.Windows.Forms.DialogResult.OK)
                {
                    this.objHotelBill.HOTELBILLCANCEL = 0;
                    this.objHotelBill.activate_delete = true;
                    btnSave_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.objHotelBill != null)
                {
                    EL.RESERVATION_CHECKIN_WALKIN objReservation = objHotelBill.reservation_ID.HasValue ?
                        objReservBook.GetReservationByID(objHotelBill.reservation_ID.Value) : null;

                    EL.Mast_guest objGuest = this.objHotelBill.GUEST_NUM.HasValue ?
                        objMasterGuest.GuestDetailByID(new EL.Mast_guest { GUEST_NUM = this.objHotelBill.GUEST_NUM.Value }) : null;
                    
                    #region Commented Code
                    // dbContext.Database.ExecuteSqlCommand(@" DECLARE @HOTELBILL INT = " + this.objHotelBill.hotelBill_ID +
// @"  delete from tempc
//     delete from tempc1
//     delete from tempc3
//     delete from tempc4
//     delete from tempc11
//
//     insert into tempc(sno,tempC_22,tempC_13,tempF_15,tempF_16,tempF_1,tempC_1,tempC_2,tempF_5,tempC_4,tempF_14,tempC_32,tempC_35,tempC_9,tempC_10,tempC_11,tempC_6,tempC_12,tempC_25)
//     select ROW_NUMBER() over(order by H.hotelbill_id),H.Title_guest,H.Name_guest,H.MiscAmountTotal,H.CateringAmountTotal,H.totalamt,H.Bill_No,
//     CONVERT(varchar(11),H.Bdate,106),H.netpayable,H.reservation_Number,
//     (select SUM(total_amt_amt) from hotelbilldetail  where hotelbilldetail.hotelBill_ID=H.hotelBill_ID),
//     stuff((select distinct ';'+roomno from hotelbilldetail where hotelbilldetail.hotelBill_ID=H.hotelBill_ID for xml path('')),1,1,''),
//     H.Finalby +' / '+convert(varchar(11),H.date_of_final,106)+' / '+convert(varchar(5),H.date_of_final,108)+'      '+'P/ON : '+convert(varchar(11),
//     getdate(),106)+' / '+ convert(varchar(5),getdate(),108) as Createdby,M.GUEST_CODE,M.G_LICENSE,M.G_Followup,H.addr1_guest,H.description_b,
//     (CASE WHEN H.billtochk=1 THEN H.Name_billto END)
//     from hotelbill H JOIN Mast_guest M ON H.GUEST_NUM=M.GUEST_NUM where hotelBill_ID = @HOTELBILL 
//
//     insert into tempc1(sno1,sno,tempC_1,tempC_2,tempF_3,tempF_9,tempF_5,tempF_6,tempF_8,tempF_7,tempD_1)
//     select  ROW_NUMBER() over(order by Hotelbilldet_id),1,CONVERT(varchar(11),date_ofdet,106),roomno+' (9963)',roomrent_amt,xtra_bed,
//     misc_charges_amt,(servtax)/2,(servtax)/2,total_amt_amt,Cast(date_ofdet as date)
//     from hotelbilldetail where hotelBill_ID = @HOTELBILL
//
//     insert into tempc4(sno4,sno,tempC_1,tempC_2,tempF_1,tempF_2,tempF_3,tempF_4,tempF_5,tempF_6)
//     select ROW_NUMBER() over(order by HotelBill_MISC_id),1,CONVERT(varchar(11),MiscDate,103),
//     (select Misc_items_Name from Misc_items where Misc_items_id=HotelBill_MISC_DETAILS.Misc_items_id),
//     PRICE,QUANTITY,(ISNULL(PRICE,0)*ISNULL(QUANTITY,0)),AMOUNT,(Serctaxamt/2),(Serctaxamt/2) 
//     from HotelBill_MISC_DETAILS where hotelBill_ID = @HOTELBILL
//
//     insert into tempC3(sno3,sno,tempC_1,tempC_2,tempF_1)
//     select ROW_NUMBER() over(order by HotelBill_CATER_id),1,CONVERT(varchar(11),CateringBillDate,106),CateringBillNo,CateringAMOUNT
//     from HotelBill_CATERING_DETAILS where hotelBill_ID = @HOTELBILL
//
//     insert into tempc11 (sno11,sno,tempC_1,tempC_2,tempF_1) 
//	                        select row_number() over(order by b.receipt_No),1, b.receipt_No,convert(varchar, b.Rdate, 103),a.amount_Adj
//	                        from receipt_payment_Adjust_details a join receipt_payment b on a.recpt_pay_id=b.recpt_pay_id 
//     where a.AdjType IN ('SEMINAR','S-Catering') and a.hotelBill_ID =" + (objHotelBill.reservation_ID.HasValue ? objHotelBill.reservation_ID.Value.ToString() : "0"));
                    //                }
                    #endregion

                    if (objHostelData.PrintHotelBill(this.objHotelBill, objReservation, objGuest))
                    {
                        Report.frmbillreportview freport = new Report.frmbillreportview();
                        freport.reportCaption = "CONFERENCE BILL";
                        freport.reportName = "rpt_ravi_ConferenceBill.rpt";
                        freport.amttowaords = "Rupees " + CommonBaseFN.NumberToWords(Convert.ToInt32(objHotelBill.totalamt.Value)) + " Only ";
                        freport.Createdby = objHotelBill.Finalby + " / " +
                            (objHotelBill.date_of_final.HasValue ? objHotelBill.date_of_final.Value.ToString("dd-MMM-yyyy / HH:mm") : string.Empty) +
                            "   P/ON : " + DateTime.Now.ToString("dd-MMM-yyyy / HH:mm");
                        freport.Show();
                    }
                    else
                        CustomMessageBox.ShowInformationMessage("Unable to print report", this.Text);
                }
                else
                    CustomMessageBox.ShowInformationMessage("Please select bill for print", this.Text);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in btnPrint_Click");
            }
        }

        private void btnOpenByEntryNo_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                string dfValue = string.Empty;
                if (CustomFormFunction.InputBox("Search By entry No", "Please enter Entry number", ref dfValue) ==
                    System.Windows.Forms.DialogResult.OK)
                {
                    EL.FilterClass objFilter = RefreshFilter();
                    objFilter.SearchByText = dfValue;

                    EL.HotelBILL objSHotelbill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.None);
                    if (objSHotelbill == null)
                        CustomMessageBox.ShowInformationMessage("No Record found!", this.Text);
                    else
                    {
                        resetPageData();
                        this.objHotelBill = objSHotelbill;
                        BindControlsValue();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnOpenByReservNo_Click");
            }
        }

        private void btnOpnByBillNo_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                string dfValue = string.Empty;
                int billno = 0;
                if (CustomFormFunction.InputBox("Search By Bill No", "Please enter bill number", ref dfValue) == System.Windows.Forms.DialogResult.OK)
                {
                    if (Int32.TryParse(dfValue, out billno))
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        objFilter.BillNumber = billno;

                        EL.HotelBILL objBill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.None);
                        if (objBill != null)
                        {
                            resetPageData();
                            this.objHotelBill = objBill;
                            BindControlsValue();
                        }
                        else
                            CustomMessageBox.ShowInformationMessage("Record not found", this.Text);
                    }
                    else
                        CustomMessageBox.ShowInformationMessage("Record not found", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnOpByBillNo_Click");
            }
        }

        private void btnOpenByReservNo_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                string dfValue = string.Empty;
                if (CustomFormFunction.InputBox("Search By Reservation No", "Please enter Reservation number", ref dfValue) ==
                    System.Windows.Forms.DialogResult.OK)
                {
                    EL.FilterClass objFilter = RefreshFilter();
                    objFilter.SearchByText = dfValue;

                    EL.HotelBILL objSHotelbill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.None);
                    if (objSHotelbill == null)
                        CustomMessageBox.ShowInformationMessage("No Record found!", this.Text);
                    else
                    {
                        resetPageData();
                        this.objHotelBill = objSHotelbill;
                        BindControlsValue();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnOpenByReservNo_Click");
            }
        }

        private void btnReceipt_Click(object sender, EventArgs e)
        {
            try
            {
                using (Transaction.frmVoucher frmreceipt = new Transaction.frmVoucher())
                {
                    frmreceipt.hotelBill_Id = (this.objHotelBill != null) ? this.objHotelBill.hotelBill_ID : 0;
                    frmreceipt.ShowDialog();
                    editPage = false;
                    EL.FilterClass objFilter = RefreshFilter();
                    objFilter.UniqueId = objHotelBill.hotelBill_ID;
                    resetPageData();
                    this.objHotelBill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.None);
                    BindControlsValue();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Receipt Records");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion Bottom Actions

        #region First Last Next Previous
        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.HotelBILL objSHotelbill = objHostelData.GetHotelDataByID(RefreshFilter(), CommonVariables.RecordCatergory.First);

                if (objSHotelbill != null && objHotelBill != null && objSHotelbill.hotelBill_ID == this.objHotelBill.hotelBill_ID)
                    CustomMessageBox.ShowInformationMessage("This is first record", this.Text);

                resetPageData();
                this.objHotelBill = objSHotelbill;
                BindControlsValue();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In First Records");
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.objHotelBill != null ? this.objHotelBill.hotelBill_ID : 0;
                EL.HotelBILL objSHotelbill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.Previous);

                if (objSHotelbill != null && objHotelBill != null && objSHotelbill.hotelBill_ID == this.objHotelBill.hotelBill_ID)
                    CustomMessageBox.ShowInformationMessage("This is first record", this.Text);

                resetPageData();
                this.objHotelBill = objSHotelbill;
                BindControlsValue();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Previous Records");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.objHotelBill != null ? this.objHotelBill.hotelBill_ID : 0;
                EL.HotelBILL objSHotelbill = objHostelData.GetHotelDataByID(objFilter, CommonVariables.RecordCatergory.Next);

                if (objSHotelbill != null && objHotelBill != null && objSHotelbill.hotelBill_ID == this.objHotelBill.hotelBill_ID)
                    CustomMessageBox.ShowInformationMessage("This is last record", this.Text);

                resetPageData();
                this.objHotelBill = objSHotelbill;
                BindControlsValue();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Next Records");
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.HotelBILL objSHotelbill = objHostelData.GetHotelDataByID(RefreshFilter(), CommonVariables.RecordCatergory.Last);

                if (objSHotelbill != null && objHotelBill != null && objSHotelbill.hotelBill_ID == this.objHotelBill.hotelBill_ID)
                    CustomMessageBox.ShowInformationMessage("This is last record", this.Text);

                resetPageData();
                this.objHotelBill = objSHotelbill;
                BindControlsValue();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Last Records");
            }
        }
        #endregion First Last Next Previous

        private void btnPrintTax_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.objHotelBill != null)
                {
//                    frmbillreportview freport = new frmbillreportview();
//                    dbContext.Database.ExecuteSqlCommand(@"BEGIN
//	                        DECLARE @HOTELBILL INT = " + this.objHotelBill.hotelBill_ID +
//         @"TRUNCATE TABLE tempc11s
//	                        INSERT INTO tempc11s(sno11,tempC_1,tempC_2,tempC_3,tempF_1,tempF_2,tempF_3,tempF_4,tempF_5,tempF_6,tempF_7,tempI_1,tempD_1)
//	                        select ROW_NUMBER() over (order by Name_guest) ,Name_guest,'','',totalroomrent,(salestaxrate/2) CGST,(salestaxrate/2) SGST,
//	                        (Serctaxamt/2) CGSTA,(Serctaxamt/2) SGSTA, totalamt,salestaxamt,Bill_No,Bdate 
//	                        from HotelBILL where hotelBill_ID = @HOTELBILL
// END");
//                    freport.reportName = "BilledRoom.rpt";
//                    freport.Show();
                }
                else
                    CustomMessageBox.ShowInformationMessage("Please select bill for print", string.Empty);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Print Tax");
            }
        }

        private void txtSemnRent_Leave(object sender, EventArgs e)
        {
            try
            {
                Double roomrent = (string.IsNullOrEmpty(txtSemnRent.Text) ? 0 : Convert.ToDouble(txtSemnRent.Text));
                txtSCharge.Text = (Convert.ToDouble(roomrent) * (CommonVariables.MiscGST / 100)).ToString("0.00");
                txtTotalAmt.Text = (Convert.ToDouble(roomrent) + Convert.ToDouble(txtSCharge.Text)).ToString("0.00");
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in txtSemnRent_Leave");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button objButton = (Button)sender;

            button1.BackColor = System.Drawing.Color.Transparent;
            button2.BackColor = System.Drawing.Color.Transparent;
            button3.BackColor = System.Drawing.Color.Transparent;
            button4.BackColor = System.Drawing.Color.Transparent;
            button5.BackColor = System.Drawing.Color.Transparent;
            button6.BackColor = System.Drawing.Color.Transparent;
            button7.BackColor = System.Drawing.Color.Transparent;
            button8.BackColor = System.Drawing.Color.Transparent;

            if(objButton == button1)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage1);
            }
            else if (objButton == button2)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage2);
            }
            else if (objButton == button3)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage3);
            }
            else if (objButton == button4)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage4);
            }
            else if (objButton == button5)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage5);
            }
            else if (objButton == button6)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage6);
            }
            else if (objButton == button7)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage7);
            }
            else if (objButton == button8)
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage8);
            }
            else
            {
                objButton.BackColor = System.Drawing.Color.White;
                tabControl1.SelectTab(tabPage1);
            }
        }

        private void txtDiscount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double amtDisc = !string.IsNullOrEmpty(txtDiscount.Text) ? Convert.ToDouble(txtDiscount.Text) : 0;
                if(objHotelBill != null)
                {
                    objHotelBill.discountamt = amtDisc;
                    objHotelBill.grandtotalamt = objHotelBill.totalamt - amtDisc;
                    objHotelBill.netpayable = objHotelBill.advancerecd - objHotelBill.grandtotalamt;
                }
                SeminarCalculations();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "discount text");
            }
        }        
    }
}
