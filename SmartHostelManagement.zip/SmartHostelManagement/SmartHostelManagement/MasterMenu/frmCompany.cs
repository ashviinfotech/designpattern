﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Master
{
    public partial class frmCompany : Form
    {
        MasterCaller objMaster = new MasterCaller();
        EL.CompanyDetail objCompanyDetail = null;

        public frmCompany()
        {
            InitializeComponent();
        }

        private void frmRoomType_Load(object sender, EventArgs e)
        {
            try
            {
                BindComboBox(); BindControlValue();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, this.Text);
            }
        }

        void BindComboBox()
        {
            try
            {
                IList<EL.GSTState> lstGstState = objMaster.GetGstState().OrderBy(x => x.StateName).ToList();
                lstGstState.Insert(0, new EL.GSTState { GSTSTATE_id = 0, StateName = string.Empty });
                cmbGSTState.DataSource = lstGstState;
                cmbGSTState.ValueMember = "GSTSTATE_id";
                cmbGSTState.DisplayMember = "StateName";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "BindComboBox");
            }
        }

        void BindControlValue()
        {
            objCompanyDetail = objMaster.GetCompanyDetails();
            if(objCompanyDetail != null)
            {
                txtCompanyCode.Text = objCompanyDetail.comp_id;
                txtCompName.Text = objCompanyDetail.comp_name;
                txtCompPrintName.Text = objCompanyDetail.c_prtname;
                txtCompAddress.Text = objCompanyDetail.addr1;
                txtCompLocality.Text = objCompanyDetail.addr2;
                txtCity.Text = objCompanyDetail.addr3;
                txtPincode.Text = objCompanyDetail.pin_code;
                txtVatNo.Text = objCompanyDetail.st_no;
                txtCstNo.Text = objCompanyDetail.cst_no;
                txtTinNo.Text = objCompanyDetail.tin_no;
                txtPanNo.Text = objCompanyDetail.pan_no;
                txtEmail.Text = objCompanyDetail.email;
                txtPhone.Text = objCompanyDetail.phone;
                txtFax.Text = objCompanyDetail.fax;
                dtmVatDate.Value = objCompanyDetail.s_tax_date.HasValue ? objCompanyDetail.s_tax_date.Value : DateTime.Now;
                dtmCstDate.Value = objCompanyDetail.cs_tax_date.HasValue ? objCompanyDetail.cs_tax_date.Value : DateTime.Now;
                dtmTinDate.Value = objCompanyDetail.TIN_date.HasValue ? objCompanyDetail.TIN_date.Value : DateTime.Now;
                dtmPanNoDate.Value = objCompanyDetail.pan_date.HasValue ? objCompanyDetail.pan_date.Value : DateTime.Now;
                cmbGSTState.SelectedValue = objCompanyDetail.GSTSTATE_id.HasValue ? (int)objCompanyDetail.GSTSTATE_id.Value : 0;
                txtGstCode.Text = objCompanyDetail.GSTCODE;
                dtmVatDate.Checked = objCompanyDetail.s_tax_date.HasValue ? true : false;
                dtmCstDate.Checked = objCompanyDetail.cs_tax_date.HasValue ? true : false;
                dtmTinDate.Checked = objCompanyDetail.TIN_date.HasValue ? true : false;
                dtmPanNoDate.Checked = objCompanyDetail.pan_date.HasValue ? true : false;
            }
            else
            {
                txtCompanyCode.Text = string.Empty;
                txtCompName.Text = string.Empty;
                txtCompPrintName.Text = string.Empty;
                txtCompAddress.Text = string.Empty;
                txtCompLocality.Text = string.Empty;
                txtCity.Text = string.Empty;
                txtPincode.Text = string.Empty;
                txtVatNo.Text = string.Empty;
                txtCstNo.Text = string.Empty;
                txtTinNo.Text = string.Empty;
                txtPanNo.Text = string.Empty;
                txtEmail.Text = string.Empty;
                txtPhone.Text = string.Empty;
                txtFax.Text = string.Empty;
                dtmVatDate.Value = DateTime.Now;
                dtmCstDate.Value = DateTime.Now;
                dtmTinDate.Value = DateTime.Now;
                dtmPanNoDate.Value = DateTime.Now;
                cmbGSTState.SelectedIndex = 0;
                txtGstCode.Text = string.Empty;
                dtmVatDate.Checked = false;
                dtmCstDate.Checked = false;
                dtmTinDate.Checked = false;
                dtmPanNoDate.Checked = false;
            }
        }

        private void cmbGSTState_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int gstId = (int)cmbGSTState.SelectedValue;
                EL.GSTState objGstState = objMaster.GetGstState().FirstOrDefault(x => x.GSTSTATE_id == gstId);

                if (objGstState != null && objGstState.GSTSTATE_id > 0)
                {
                    txtGstCode.Text = objGstState.StateCode;
                }
                else
                {
                    txtGstCode.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "BindComboBox");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                bool result = false;
                if (objCompanyDetail != null)
                {
                    objCompanyDetail.comp_name = txtCompName.Text;
                    objCompanyDetail.c_prtname = txtCompPrintName.Text;
                    objCompanyDetail.addr1 = txtCompAddress.Text;
                    objCompanyDetail.addr2 = txtCompLocality.Text;
                    objCompanyDetail.addr3 = txtCity.Text;
                    objCompanyDetail.pin_code = txtPincode.Text;
                    objCompanyDetail.st_no = txtVatNo.Text;
                    objCompanyDetail.cst_no = txtCstNo.Text;
                    objCompanyDetail.tin_no = txtTinNo.Text;
                    objCompanyDetail.pan_no = txtPanNo.Text;
                    objCompanyDetail.email = txtEmail.Text;
                    objCompanyDetail.phone = txtPhone.Text;
                    objCompanyDetail.fax = txtFax.Text;
                    if (dtmVatDate.Checked) objCompanyDetail.s_tax_date = dtmVatDate.Value.Date;
                    if (dtmCstDate.Checked) objCompanyDetail.cs_tax_date = dtmCstDate.Value.Date;
                    if (dtmTinDate.Checked) objCompanyDetail.TIN_date = dtmTinDate.Value.Date;
                    if (dtmPanNoDate.Checked) objCompanyDetail.pan_date = dtmPanNoDate.Value.Date;
                    if (cmbGSTState.SelectedIndex > 0) objCompanyDetail.GSTSTATE_id = (int)cmbGSTState.SelectedValue;
                    objCompanyDetail.GSTCODE = txtGstCode.Text;

                    result = objMaster.SaveUpdateCompanyDetails(objCompanyDetail);
                }

                if (result)
                    CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                else
                    CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                BindControlValue();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
