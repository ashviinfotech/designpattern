﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Master
{
    public partial class frmRoomType : Form
    {
        MasterCaller objMaster = new MasterCaller();
        EL.ROOM_TYPE objRoomType { get; set; }

        public frmRoomType()
        {
            InitializeComponent();
        }

        private void frmRoomType_Load(object sender, EventArgs e)
        {
            try
            {
                Dictionary<int, string> dataApplies = new Dictionary<int, string>();
                dataApplies.Add(0, "");
                dataApplies.Add(1, "Dormatory");
                dataApplies.Add(2, "Rooms");
                dataApplies.Add(3, "Seminar");

                Dictionary<int, string> dataChargeType = new Dictionary<int, string>();
                dataChargeType.Add(0, "");
                dataChargeType.Add(1, "Billed");
                dataChargeType.Add(2, "UnBilled");

                cmbApplies.DataSource = dataApplies.ToList();
                cmbApplies.ValueMember = "Key";
                cmbApplies.DisplayMember = "Value";

                cmbChargeType.DataSource = dataChargeType.ToList();
                cmbChargeType.ValueMember = "key";
                cmbChargeType.DisplayMember = "value";

                btnNew_Click(null, null);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, this.Text);
            }
        }

        void BindGridViewDetails()
        {
            if (objRoomType == null) objRoomType = new EL.ROOM_TYPE();
            var dbData = objRoomType.room_type_rates.Select((x, index) => 
                new { 
                    x.RM_TYPE_rate_ID,
                    SLNo = index + 1,
                    x.ApplicableFrom,
                    x.ApplicableUpto,
                    x.Room_Type_rate,
                    Xtrabedrate = x.Room_Type_Xtrabedrate,
                    NOP = x.NoPersons,
                    Rate_Type_Rate = x.Room_Type_rate,
                    Rate_Full_Hrs = x.RateFullHrs
                });
            dgvRoomType.DataSource = dbData.ToList();
            dgvRoomType.Columns[0].Visible = false;
            dgvRoomType.Columns[2].DefaultCellStyle.Format = "dd-MMM-yyyy";
            dgvRoomType.Columns[3].DefaultCellStyle.Format = "dd-MMM-yyyy";
        }


        private void txtLoginid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender.GetType() == typeof(TextBox))
                {
                    if ((TextBox)sender == txtRoomTypeCode) txtDescription.Focus();
                    if ((TextBox)sender == txtDescription) txtRoomTypeRate.Focus();
                    if ((TextBox)sender == txtRoomTypeRate) txtExtraBedRate.Focus();
                    if ((TextBox)sender == txtExtraBedRate) cmbApplies.Focus();
                }
                if (sender.GetType() == typeof(ComboBox))
                {
                    if ((ComboBox)sender == cmbApplies) cmbChargeType.Focus();
                    if ((ComboBox)sender == cmbChargeType) txtNoPerson.Focus();
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            objRoomType = null;
            txtRoomTypeCode.Text = string.Empty;
            txtDescription.Text = string.Empty;
            cmbChargeType.SelectedIndex = 0;
            cmbApplies.SelectedIndex = 0;
            btnNew_Click(sender, e);
        }
        
        private void txtItemCode_Leave(object sender, EventArgs e)
        {
            try
            {
                if(!string.IsNullOrEmpty(txtRoomTypeCode.Text.Trim()))
                {
                    IList<EL.ROOM_TYPE> lstRoomType = objMaster.GetRoomType().ToList();
                    if (lstRoomType.Any(x => x.RM_TYPE_CODE.ToUpper().Equals(txtRoomTypeCode.Text.Trim().ToUpper())))
                    {
                        CustomMessageBox.ShowInformationMessage("Item Code alredy exists !!!", this.Text);
                        txtRoomTypeCode.Text = string.Empty;
                        txtRoomTypeCode.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "txtItemCode_Leave");
            }
        }

        bool validatePageData()
        {
            if (string.IsNullOrEmpty(txtRoomTypeCode.Text))
            {
                CustomMessageBox.ShowStopMessage("Please Enter Item Code.", this.Text);
                txtDescription.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtDescription.Text))
            {
                CustomMessageBox.ShowStopMessage("Please Enter Room Description.", this.Text);
                txtRoomTypeRate.Focus();
                return false;
            }
            //else if (string.IsNullOrEmpty(txtRoomTypeRate.Text))
            //{
            //    CustomMessageBox.ShowStopMessage("Please Enter Room Rate.", this.Text);
            //    txtRoomTypeRate.Focus();
            //    return false;
            //}
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (validatePageData())
                {
                    bool isNew = false;

                    if (objRoomType != null && objRoomType.RM_TYPE_ID > 0)
                    {
                        objRoomType.id1 = Frm_Login.UserLogin.log_id;
                        objRoomType.date_of_mod = DateTime.Now;
                    }
                    else
                    {
                        isNew = true;
                        if (objRoomType == null) objRoomType = new EL.ROOM_TYPE();

                        objRoomType.id = Frm_Login.UserLogin.log_id;
                        objRoomType.date_of_add = DateTime.Now;
                        objRoomType.RM_TYPE_CONF_DESC = string.Empty;
                        objRoomType.RM_TYPE_DET_DESC = string.Empty;
                        objRoomType.RM_TYPE_IMG_PATH = string.Empty;
                    }

                    objRoomType.RM_TYPE_CODE = txtRoomTypeCode.Text.Trim();
                    objRoomType.RM_TYPE_DESC = txtDescription.Text.Trim();
                    //objRoomType.Room_Type_rate = !string.IsNullOrEmpty(txtRoomTypeRate.Text) ? Convert.ToDouble(txtRoomTypeRate.Text.Trim()) : 0;
                    //objRoomType.Room_Type_Xtrabedrate = !string.IsNullOrEmpty(txtExtraBedRate.Text) ? Convert.ToDouble(txtExtraBedRate.Text.Trim()) : 0;
                    //if (cmbApplies.SelectedIndex > 0)
                    //    objRoomType.Room_dorm = cmbApplies.Text == "Room" ? 1 : 0;
                    //else
                    //    objRoomType.Room_dorm = null;
                    //if (cmbChargeType.SelectedIndex > 0)
                    //    objRoomType.Type_unbilled = cmbChargeType.Text == "Billed" ? 1 : cmbChargeType.Text == "UnBilled" ? 2 : 3;
                    //else
                    //    objRoomType.Type_unbilled = null;

                    //objRoomType.NoPersons = !string.IsNullOrEmpty(txtNoPerson.Text) ? Convert.ToInt32(txtNoPerson.Text) : 0;

                    if (objMaster.SaveUpdateDeleteRoomType(objRoomType, isNew, false))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmGuestSearch objfrmSearch = new frmGuestSearch())
                {
                    objfrmSearch.searchTypeObject = typeof(EL.ROOM_TYPE);
                    objfrmSearch.ShowDialog();
                    objRoomType = objMaster.GetRoomTypeById(new EL.ROOM_TYPE { RM_TYPE_ID = objfrmSearch.GuestNum });

                    if (objRoomType != null)
                    {
                        this.objRoomType = objRoomType;
                        txtRoomTypeCode.Text = objRoomType.RM_TYPE_CODE;
                        txtDescription.Text = objRoomType.RM_TYPE_DESC;
                        cmbApplies.SelectedValue = objRoomType.Room_dorm.HasValue ? objRoomType.Room_dorm.Value : 0;
                        cmbChargeType.SelectedValue = objRoomType.Room_dorm.HasValue ? objRoomType.Type_unbilled.Value : 0;
                    }
                    btnNew_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in search");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Room Type ?") == System.Windows.Forms.DialogResult.Yes)
                {
                    if (objMaster.SaveUpdateDeleteRoomType(objRoomType, false, true))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dgvRoomType_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            rowrateindex = e.RowIndex;
            EL.ROOM_TYPE_rates objRoomRate = objRoomType.room_type_rates.ElementAt(rowrateindex);
            //cmbApplies.SelectedIndex = objRoomRate.Room_dorm.HasValue ? (int)objRoomRate.Room_dorm.Value : 0;
            //cmbChargeType.SelectedIndex = objRoomRate.Type_unbilled.HasValue ? (int)objRoomRate.Type_unbilled.Value : 0;
            dtmApplicable.Value = objRoomRate.ApplicableFrom.HasValue ? objRoomRate.ApplicableFrom.Value : DateTime.Now;
            dtmUpto.Value = objRoomRate.ApplicableUpto.HasValue ? objRoomRate.ApplicableUpto.Value : DateTime.Now;
            txtRoomRateFull.Text = objRoomRate.RateFullAmt.HasValue ? objRoomRate.RateFullAmt.Value.ToString() : "0";
            txtRoomRateHrs.Text = objRoomRate.RateFullHrs.HasValue ? objRoomRate.RateFullHrs.Value.ToString() : "0";
            txtRoomTypeRate.Text = objRoomRate.Room_Type_rate.HasValue ? objRoomRate.Room_Type_rate.Value.ToString() : "0";
            txtExtraBedRate.Text = objRoomRate.Room_Type_Xtrabedrate.HasValue ? objRoomRate.Room_Type_Xtrabedrate.Value.ToString() : "0";
            txtNoPerson.Text = objRoomRate.NoPersons.HasValue ? objRoomRate.NoPersons.Value.ToString() : "";
        }

        int rowrateindex = -1;
        private void btnNew_Click(object sender, EventArgs e)
        {
            try
            {
                rowrateindex = -1;
                //cmbApplies.SelectedIndex = 0;
                //cmbChargeType.SelectedIndex = 0;
                dtmApplicable.Value = DateTime.Now;
                dtmUpto.Value = DateTime.Now;
                txtRoomRateFull.Text = string.Empty;
                txtRoomRateHrs.Text = string.Empty;
                txtRoomTypeRate.Text = string.Empty;
                txtExtraBedRate.Text = string.Empty;
                txtNoPerson.Text = string.Empty;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Room Type");
            }
            BindGridViewDetails();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (objRoomType == null) objRoomType = new EL.ROOM_TYPE();
                List<EL.ROOM_TYPE_rates> roomtyperatelist = objRoomType.room_type_rates.ToList();
                EL.ROOM_TYPE_rates newAddRoomRate = new EL.ROOM_TYPE_rates();

                newAddRoomRate.RM_TYPE_ID = objRoomType.RM_TYPE_ID;
                newAddRoomRate.ApplicableFrom = dtmApplicable.Value.Date;
                newAddRoomRate.ApplicableUpto = dtmUpto.Value.Date;
                newAddRoomRate.Room_Type_rate = !string.IsNullOrEmpty(txtRoomTypeRate.Text) ? Convert.ToDouble(txtRoomTypeRate.Text) : 0;
                newAddRoomRate.Room_Type_Xtrabedrate = !string.IsNullOrEmpty(txtExtraBedRate.Text) ? Convert.ToDouble(txtExtraBedRate.Text) : 0;
                //newAddRoomRate.Room_dorm = cmbApplies.SelectedIndex > 0 ? (int)cmbApplies.SelectedValue : 0;
                //newAddRoomRate.Type_unbilled = cmbChargeType.SelectedIndex > 0 ? (int)cmbChargeType.SelectedValue : 0;
                newAddRoomRate.NoPersons = !string.IsNullOrEmpty(txtNoPerson.Text) ? Convert.ToInt32(txtNoPerson.Text) : 0;
                newAddRoomRate.RateFullAmt = !string.IsNullOrEmpty(txtRoomRateFull.Text) ? Convert.ToDouble(txtRoomRateFull.Text) : 0;
                newAddRoomRate.RateFullHrs = !string.IsNullOrEmpty(txtRoomRateHrs.Text) ? Convert.ToDouble(txtRoomRateHrs.Text) : 0;


                if (rowrateindex > -1)
                {
                    roomtyperatelist.RemoveAt(rowrateindex);
                    roomtyperatelist.Insert(rowrateindex, newAddRoomRate);
                }
                else
                {
                    roomtyperatelist.Add(newAddRoomRate);
                }

                objRoomType.room_type_rates = roomtyperatelist;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Room rate Add Gridview");
            }
            btnNew_Click(sender, e);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if(rowrateindex > -1 && objRoomType != null)
            {
                EL.ROOM_TYPE_rates rmvRoomTypeRate = objRoomType.room_type_rates.ElementAt(rowrateindex);
                objRoomType.room_type_rates.Remove(rmvRoomTypeRate);
            }
            btnNew_Click(sender, e);
        }
    }
}
