﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Master
{
    public partial class frmRoomNumber : Form
    {
        MasterCaller objMaster = new MasterCaller();
        EL.room_number objRoomNumb { get; set; }

        public frmRoomNumber()
        {
            InitializeComponent();
        }

        private void frmRoomNumber_Load(object sender, EventArgs e)
        {
            Bindroomtype();
            BindRoomCategory();
        }

        private void Bindroomtype()
        {
            try
            {
                IList<EL.ROOM_TYPE> lstRoomType = objMaster.GetRoomType().OrderBy(x => x.RM_TYPE_DESC).ToList();
                lstRoomType.Insert(0, new EL.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_DESC = "--Select--" });
                cmbRoomType.DataSource = lstRoomType;
                cmbRoomType.ValueMember = "RM_TYPE_ID";
                cmbRoomType.DisplayMember = "RM_TYPE_DESC";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Bindroomtype-->");
            }
        }

        private void txtLoginid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender.GetType() == typeof(NumericUpDown))
                {
                    if ((NumericUpDown)sender == drpMaxAdult) txtDescrption.Focus();
                }
                else if (sender.GetType() == typeof(ComboBox))
                {
                    if ((ComboBox)sender == cmbRoomType) drpMaxAdult.Focus();
                }
                else if (sender.GetType() == typeof(MaskedTextBox))
                {
                    if ((MaskedTextBox)sender == txtRoomIp) btnReferesh.Focus();
                }
                else if (sender.GetType() == typeof(TextBox))
                {
                    if ((TextBox)sender == txtRNumber) cmbRoomType.Focus();
                    if ((TextBox)sender == txtDescrption) txtAttributes.Focus();
                    if ((TextBox)sender == txtAttributes) txtPhoneNumber.Focus();
                    if ((TextBox)sender == txtPhoneNumber) txtData.Focus();
                    if ((TextBox)sender == txtData) txtRoomIp.Focus();
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void BindRoomCategory()
        {
            lstCategory.Items.Clear();
            lstCategory.Items.Add("Room");
            lstCategory.Items.Add("Conference");
            lstCategory.Items.Add("Banquet");
            lstCategory.Items.Add("Lawns");
            lstCategory.Items.Add("Hall");
            lstCategory.Items.Add("Dormatory");
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            objRoomNumb = null;
            txtRNumber.Text = string.Empty;
            cmbRoomType.SelectedIndex = 0;
            drpMaxAdult.Text = "0";
            chkRoomDorm.Checked = false;
            txtDescrption.Text = string.Empty;
            txtAttributes.Text = string.Empty;
            txtPhoneNumber.Text = string.Empty;
            txtData.Text = string.Empty;
            txtRoomIp.Text = string.Empty;
        }
        
        private void txtItemCode_Leave(object sender, EventArgs e)
        {
            try
            {
                if(!string.IsNullOrEmpty(txtRNumber.Text.Trim()))
                {
                    IList<EL.room_number> lstMiscItems = objMaster.GetRoomNumber().ToList();
                    if (lstMiscItems.Any(x => x.room_number_number.ToUpper().Equals(txtRNumber.Text.Trim().ToUpper())))
                    {
                        CustomMessageBox.ShowInformationMessage("Room Code alredy exists !!!", this.Text);
                        txtRNumber.Text = string.Empty;
                        txtRNumber.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "txtItemCode_Leave");
            }
        }

        bool validatePageData()
        {
            if (string.IsNullOrEmpty(txtRNumber.Text))
            {
                CustomMessageBox.ShowStopMessage("Please Enter Room Number.", this.Text);
                txtRNumber.Focus();
                return false;
            }
            else if (cmbRoomType.SelectedIndex <= 0)
            {
                CustomMessageBox.ShowStopMessage("Please select Room type.", this.Text);
                cmbRoomType.Focus();
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (validatePageData())
                {
                    bool isNew = false;

                    if (objRoomNumb != null)
                    {
                        objRoomNumb.id1 = Frm_Login.UserLogin.log_id;
                        objRoomNumb.date_of_mod = DateTime.Now;
                    }
                    else
                    {
                        isNew = true;
                        objRoomNumb = new EL.room_number 
                        { 
                            id = Frm_Login.UserLogin.log_id,
                            date_of_add = DateTime.Now,
                            room_number_sheetchngdays = 0,
                            room_number_stayovercleanminr = 0,
                            room_number_checkoutcleanminr = 0,
                            room_number_ignREPwhenstayover = false,
                            room_number_ignREPwhencheckout = false,
                            room_number_owner_name = string.Empty,
                            room_number_owner_street = string.Empty,
                            room_number_owner_city = string.Empty,
                            room_number_owner_state = string.Empty,
                            room_number_owner_pincode = string.Empty,
                            room_number_owner_country = string.Empty,
                            room_number_owner_phone = string.Empty,
                            room_number_owner_instruction = string.Empty,
                            room_number_owner_connector = string.Empty,
                            room_number_commn_amt = 0,
                            room_number_ignindayendcls = false,
                            NoPersons = 0
                        };
                    }

                    objRoomNumb.room_number_number = txtRNumber.Text;
                    objRoomNumb.RM_TYPE_ID = cmbRoomType.SelectedIndex > 0 ? Convert.ToInt32(cmbRoomType.SelectedValue) : 0;
                    objRoomNumb.room_number_maxadults = Convert.ToInt32(drpMaxAdult.Text);
                    objRoomNumb.Dormatory = chkRoomDorm.Checked ? 1 : 0;
                    objRoomNumb.room_number_desc = txtDescrption.Text;
                    objRoomNumb.room_number_attrib = txtAttributes.Text;
                    objRoomNumb.room_number_phno = txtPhoneNumber.Text;
                    objRoomNumb.room_number_dataextn = txtData.Text;
                    //objRoomNumb.room_number_ConferenceRoom =
                    objRoomNumb.room_number_IP = !string.IsNullOrEmpty(txtRoomIp.Text) ? txtRoomIp.Text : "000.000.000.000";

                    if (objMaster.SaveUpdateDeleteRoomNumber(objRoomNumb, isNew, false))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmRoomTypeSearch objfrmSRoomtype = new frmRoomTypeSearch())
                {
                    objfrmSRoomtype.ShowDialog();
                    btnReferesh_Click(null, null);
                    if (objfrmSRoomtype.objSRoomNumb != null)
                    {
                        this.objRoomNumb = objfrmSRoomtype.objSRoomNumb;
                        txtRNumber.Text = objfrmSRoomtype.objSRoomNumb.room_number_number;
                        cmbRoomType.SelectedValue = objfrmSRoomtype.objSRoomNumb.RM_TYPE_ID;
                        drpMaxAdult.Text = objfrmSRoomtype.objSRoomNumb.room_number_maxadults.HasValue ?
                            objfrmSRoomtype.objSRoomNumb.room_number_maxadults.Value.ToString("0") : "0";
                        chkRoomDorm.Checked = objfrmSRoomtype.objSRoomNumb.Dormatory.HasValue ?
                            (objfrmSRoomtype.objSRoomNumb.Dormatory.Value > 0 ? true : false) : false;
                        txtDescrption.Text = objfrmSRoomtype.objSRoomNumb.room_number_desc;
                        txtAttributes.Text = objfrmSRoomtype.objSRoomNumb.room_number_attrib;
                        txtPhoneNumber.Text = objfrmSRoomtype.objSRoomNumb.room_number_phno;
                        txtData.Text = objfrmSRoomtype.objSRoomNumb.room_number_dataextn;
                        txtRoomIp.Text = objfrmSRoomtype.objSRoomNumb.room_number_IP;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in search");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Room Entry ?") == System.Windows.Forms.DialogResult.Yes)
                {
                    if (objMaster.SaveUpdateDeleteRoomNumber(objRoomNumb, false, true))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
