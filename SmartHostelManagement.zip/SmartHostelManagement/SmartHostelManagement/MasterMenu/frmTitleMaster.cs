﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Master
{
    public partial class frmTitleMaster : Form
    {
        MasterCaller objMaster = new MasterCaller();
        EL.MasterTitle objMasterTitle { get; set; }

        public frmTitleMaster()
        {
            InitializeComponent();
        }

        private void frmTitleMaster_Load(object sender, EventArgs e)
        {
            BindGridview();
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (datagrdiview.SelectedRows.Count > 0)
                {
                    DataGridViewRow dr = datagrdiview.SelectedRows[0];
                    int miscid = Convert.ToInt32(dr.Cells["Titleid"].Value);
                    this.objMasterTitle = objMaster.GetTitleMaster().FirstOrDefault(x => x.Titleid == miscid);
                    txtTitle.Text = objMasterTitle.Titlename;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in select data");
            }
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            objMasterTitle = null;
            txtTitle.Text = string.Empty;
            BindGridview();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtTitle.Text.Trim()))
                {
                    bool isNew = false;

                    if (objMasterTitle != null)
                        isNew = false;
                    else
                    {
                        isNew = true;
                        objMasterTitle = new EL.MasterTitle();
                    }


                    objMasterTitle.Titlename = txtTitle.Text.Trim();

                    if (objMaster.SaveUpdateDeleteTitleMaster(objMasterTitle, isNew, false))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please enter title name.", this.Text);
                    txtTitle.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        void BindGridview()
        {
            try
            {
                IList<EL.MasterTitle> lstTitle = !string.IsNullOrEmpty(txtTitle.Text) ? objMaster.GetTitleMaster()
                    .Where(x => x.Titlename.ToUpper().Contains(txtTitle.Text.ToUpper())).ToList() : 
                    objMaster.GetTitleMaster().ToList();

                var dbdata = lstTitle.Select((c, index) =>
                new
                {
                    c.Titleid,
                    SlNo = index + 1,
                    c.Titlename,
                    Description = ""
                });

                datagrdiview.DataSource = dbdata.ToList();
                datagrdiview.Columns["Titleid"].Visible = false;
                datagrdiview.Columns["SlNo"].Width = 100;
                datagrdiview.Columns["Titlename"].Width = 150;
                datagrdiview.Columns["Description"].Width = 250;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "BindGridview");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            BindGridview();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Title ?") == System.Windows.Forms.DialogResult.Yes)
                {
                    if (objMaster.SaveUpdateDeleteTitleMaster(objMasterTitle, false, true))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }        
    }
}
