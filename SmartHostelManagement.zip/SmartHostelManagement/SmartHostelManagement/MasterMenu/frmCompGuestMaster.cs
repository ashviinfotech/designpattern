﻿using System;
using System.Linq;
using System.Windows.Forms;
using SmartHostelManagement.Search;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Master
{
    public partial class frmCompanyGuestMaster : Form
    {
        GuestCaller objGuestData = new GuestCaller();
        MasterCaller objMasterData = new MasterCaller();

        public int guestnum { get; set; }

        public frmCompanyGuestMaster()
        {
            InitializeComponent();
        }

        private void frmGuestMaster_Load(object sender, EventArgs e)
        {
            BindComboBox();
            cmbFollowUp.DataSource = new BindingSource(CommonVariables.FollowUp, null);
            cmbFollowUp.DisplayMember = "value";
            cmbFollowUp.ValueMember = "key";
        }

        private void BindComboBox()
        {
            var gstStateList = objMasterData.GetGstState().ToList();
            gstStateList.Insert(0, new EL.GSTState { GSTSTATE_id = 0, StateCode = "0", StateName = string.Empty });
            cmbGstState.DataSource = gstStateList;
            cmbGstState.DisplayMember = "StateName";
            cmbGstState.ValueMember = "GSTSTATE_id";
        }

        private void SetControlsValue(EL.CompanyGuest mastguest)
        {
            try
            {
                txtCompanyName.Text = mastguest.CGUEST_CODE;
                txtPrintName.Text = mastguest.CG_FNAME;
                txtAddress1.Text = mastguest.CG_Street;
                txtAddress2.Text = mastguest.Addr2;
                txtAddress3.Text = mastguest.Addr3;
                txtCity.Text = mastguest.CG_CITY;
                txtState.Text = mastguest.CG_STATE;
                txtZipCode.Text = mastguest.CG_ZIP;
                txtCountry.Text = mastguest.CG_COUNTRY;
                txtPhone.Text = mastguest.CG_PHONE1;
                txtPhone2.Text = mastguest.CG_PHONE2;
                txtGSTNo.Text = mastguest.GST_NO;
                cmbGstState.SelectedValue = (mastguest.GSTSTATE_id.HasValue ? mastguest.GSTSTATE_id.Value : 0);
                txtPANNo.Text = mastguest.UID_NO;
                txtContactPerson.Text = mastguest.ContactPerson;
                txtPhone3.Text = mastguest.CPPhone;
                txtEmail.Text = mastguest.CG_EMAIL;
                cmbFollowUp.Text = (!string.IsNullOrEmpty(mastguest.CG_Followup) ? mastguest.CG_Followup : "");
                chkDoNotSendMail.Checked = (mastguest.CG_send_mail.HasValue ? mastguest.CG_send_mail.Value : false);
                chkUnwelcomedList.Checked = (mastguest.CG_place_unwel_list.HasValue ? mastguest.CG_place_unwel_list.Value : false);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, this.Text);
            }
            
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtCompanyName.Text = string.Empty;
            txtPrintName.Text = string.Empty;
            txtAddress1.Text = string.Empty;
            txtAddress2.Text = string.Empty;
            txtAddress3.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtState.Text = string.Empty;
            txtZipCode.Text = string.Empty;
            txtCountry.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtPhone2.Text = string.Empty;
            txtGSTNo.Text = string.Empty;
            cmbGstState.SelectedIndex = 0;
            txtPANNo.Text = string.Empty;
            txtContactPerson.Text = string.Empty;
            txtPhone3.Text = string.Empty;
            txtEmail.Text = string.Empty;
            cmbFollowUp.SelectedIndex = 0;
            chkDoNotSendMail.Checked = false;
            chkUnwelcomedList.Checked = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidatePageData())
                {
                    EL.CompanyGuest objmasguest = objGuestData.CompanyGuestDetailByID(new EL.CompanyGuest { CGuest_num = this.guestnum });
                    #region Edit Company Guest Data
                    if (objmasguest != null)
                    {
                        objmasguest.CGUEST_CODE = txtCompanyName.Text;
                        objmasguest.CG_FNAME = txtPrintName.Text;
                        objmasguest.CG_Street = txtAddress1.Text;
                        objmasguest.Addr2 = txtAddress2.Text;
                        objmasguest.Addr3 = txtAddress3.Text;
                        objmasguest.CG_CITY = txtCity.Text;
                        objmasguest.CG_STATE = txtState.Text;
                        objmasguest.CG_ZIP = txtZipCode.Text;
                        objmasguest.CG_COUNTRY = txtCountry.Text;
                        objmasguest.CG_PHONE1 = txtPhone.Text;
                        objmasguest.CG_PHONE2 = txtPhone2.Text;
                        objmasguest.GST_NO = txtGSTNo.Text;
                        objmasguest.GSTSTATE_id = cmbGstState.SelectedIndex > 0 ? (int)cmbGstState.SelectedValue : 0;
                        objmasguest.UID_NO = txtPANNo.Text;
                        objmasguest.ContactPerson = txtContactPerson.Text;
                        objmasguest.CPPhone = txtPhone3.Text;
                        objmasguest.CG_EMAIL = txtEmail.Text;
                        objmasguest.CG_Followup = cmbFollowUp.SelectedIndex > 0 ? cmbFollowUp.Text : string.Empty;
                        objmasguest.CG_send_mail = chkDoNotSendMail.Checked;
                        objmasguest.CG_place_unwel_list = chkUnwelcomedList.Checked;
                        objmasguest.id1 = Frm_Login.UserLogin.log_id;
                        objmasguest.date_of_mod = DateTime.Now;
                    }
                    #endregion Edit Company Guest Data

                    #region Add Company Guest Data
                    else
                    {
                        objmasguest = new EL.CompanyGuest
                        {
                            CGUEST_CODE = txtCompanyName.Text,
                            CG_FNAME = txtPrintName.Text,
                            CG_Street = txtAddress1.Text,
                            Addr2 = txtAddress2.Text,
                            Addr3 = txtAddress3.Text,
                            CG_CITY = txtCity.Text,
                            CG_STATE = txtState.Text,
                            CG_ZIP = txtZipCode.Text,
                            CG_COUNTRY = txtCountry.Text,
                            CG_PHONE1 = txtPhone.Text,
                            CG_PHONE2 = txtPhone2.Text,
                            GST_NO = txtGSTNo.Text,
                            GSTSTATE_id = cmbGstState.SelectedIndex > 0 ? (int)cmbGstState.SelectedValue : 0,
                            UID_NO = txtPANNo.Text,
                            ContactPerson = txtContactPerson.Text,
                            CPPhone = txtPhone3.Text,
                            CG_EMAIL = txtEmail.Text,
                            CG_Followup = cmbFollowUp.SelectedText,
                            CG_send_mail = chkDoNotSendMail.Checked,
                            CG_place_unwel_list = chkUnwelcomedList.Checked,
                            id = Frm_Login.UserLogin.log_id,
                            date_of_add = DateTime.Now
                        };
                    }
                    #endregion Add Company Guest Data

                    this.guestnum = objGuestData.SaveUpdateGuestDetails(objmasguest);

                    if (this.guestnum > 0)
                        CustomMessageBox.ShowInformationMessage("Record Saved", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record not Saved", this.Text);

                    btnRefresh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        private bool ValidatePageData()
        {
            if (string.IsNullOrEmpty(txtCompanyName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please Enter name of Guest.", this.Text);
                return false;
            }
            else if (cmbGstState.SelectedIndex < 1)
            {
                CustomMessageBox.ShowInformationMessage("Please Select GST State.", this.Text);
                return false;
            }
            else
                return true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (frmGuestSearch guestsearch = new frmGuestSearch())
            {
                guestsearch.guestName = txtCompanyName.Text;
                guestsearch.searchTypeObject = typeof(EL.CompanyGuest);
                guestsearch.ShowDialog();
                this.guestnum = guestsearch.GuestNum;
                SetControlsValue(objGuestData.CompanyGuestDetailByID(new EL.CompanyGuest { CGuest_num = this.guestnum }));
            } 
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void cmbTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender.GetType() == typeof(ComboBox))
                {
                    if (((ComboBox)sender) == cmbGstState)
                        txtPANNo.Focus();
                    else if (((ComboBox)sender) == cmbFollowUp)
                        chkDoNotSendMail.Focus();
                }
                else if (sender.GetType() == typeof(TextBox))
                {
                    if (((TextBox)sender) == txtCompanyName)
                        txtPrintName.Focus();
                    else if (((TextBox)sender) == txtPrintName)
                        txtAddress1.Focus();
                    else if (((TextBox)sender) == txtAddress1)
                        txtAddress2.Focus();
                    else if (((TextBox)sender) == txtAddress2)
                        txtAddress3.Focus();
                    else if (((TextBox)sender) == txtAddress3)
                        txtCity.Focus();
                    else if (((TextBox)sender) == txtCity)
                        txtState.Focus();
                    else if (((TextBox)sender) == txtState)
                        txtZipCode.Focus();
                    else if (((TextBox)sender) == txtZipCode)
                        txtCountry.Focus();
                    else if (((TextBox)sender) == txtCountry)
                        txtPhone.Focus();
                    else if (((TextBox)sender) == txtPhone)
                        txtPhone2.Focus();
                    else if (((TextBox)sender) == txtPhone2)
                        txtGSTNo.Focus();
                    else if (((TextBox)sender) == txtGSTNo)
                        cmbGstState.Focus();
                    else if (((TextBox)sender) == txtPANNo)
                        txtContactPerson.Focus();
                    else if (((TextBox)sender) == txtContactPerson)
                        txtPhone3.Focus();
                    else if (((TextBox)sender) == txtPhone3)
                        txtEmail.Focus();
                    else if (((TextBox)sender) == txtEmail)
                        cmbFollowUp.Focus();
                }
                else if (sender.GetType() == typeof(CheckBox))
                {
                    if (((CheckBox)sender) == chkDoNotSendMail)
                        chkUnwelcomedList.Focus();
                    else if (((CheckBox)sender) == chkUnwelcomedList)
                        btnSave.Focus();
                }
            }
        }

        private void txtFirstName_Leave(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(TextBox))
            {
                TextBox txtText = (TextBox)sender;
                txtText.Text = CommonBaseFN.ConvertFirstLetterToCapital(txtText.Text);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                EL.CompanyGuest objmasguest = objGuestData.CompanyGuestDetailByID(new EL.CompanyGuest { CGuest_num = this.guestnum });
                if (objmasguest != null && CustomMessageBox.ShowDialogBoxMessage("Delete this Company Detail ?") == System.Windows.Forms.DialogResult.Yes)
                {
                    if (objGuestData.DeleteCompanyGuest(objmasguest))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnRefresh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }
    }
}