﻿namespace SmartHostelManagement.Order
{
    partial class frmAccountWiseSales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dtmFrom = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dtmTo = new System.Windows.Forms.DateTimePicker();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.chkAllPending = new System.Windows.Forms.CheckBox();
            this.chkDetails = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstGLAccounts = new System.Windows.Forms.ListBox();
            this.chkStaffAcount = new System.Windows.Forms.CheckBox();
            this.chkCreditAccount = new System.Windows.Forms.CheckBox();
            this.btnSelectAll = new System.Windows.Forms.Button();
            this.btnPrepareBill = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabDetail = new System.Windows.Forms.TabPage();
            this.dgvDetailed = new System.Windows.Forms.DataGridView();
            this.tabSummarized = new System.Windows.Forms.TabPage();
            this.dgvSummarized = new System.Windows.Forms.DataGridView();
            this.tabBilling = new System.Windows.Forms.TabPage();
            this.dgvBlling = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailed)).BeginInit();
            this.tabSummarized.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummarized)).BeginInit();
            this.tabBilling.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBlling)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 14);
            this.label1.TabIndex = 8;
            this.label1.Text = "Date From";
            // 
            // dtmFrom
            // 
            this.dtmFrom.CustomFormat = "dd/MMM/yyyy";
            this.dtmFrom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmFrom.Location = new System.Drawing.Point(91, 11);
            this.dtmFrom.Name = "dtmFrom";
            this.dtmFrom.Size = new System.Drawing.Size(122, 22);
            this.dtmFrom.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 14);
            this.label2.TabIndex = 8;
            this.label2.Text = "Date To";
            // 
            // dtmTo
            // 
            this.dtmTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmTo.Location = new System.Drawing.Point(91, 39);
            this.dtmTo.Name = "dtmTo";
            this.dtmTo.Size = new System.Drawing.Size(122, 22);
            this.dtmTo.TabIndex = 25;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(219, 15);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(84, 41);
            this.btnRefresh.TabIndex = 26;
            this.btnRefresh.Text = "&Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // chkAllPending
            // 
            this.chkAllPending.AutoSize = true;
            this.chkAllPending.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAllPending.Location = new System.Drawing.Point(17, 70);
            this.chkAllPending.Name = "chkAllPending";
            this.chkAllPending.Size = new System.Drawing.Size(150, 21);
            this.chkAllPending.TabIndex = 28;
            this.chkAllPending.Text = "All Pending Bills";
            this.chkAllPending.UseVisualStyleBackColor = true;
            this.chkAllPending.CheckedChanged += new System.EventHandler(this.chkAllPending_CheckedChanged);
            // 
            // chkDetails
            // 
            this.chkDetails.AutoSize = true;
            this.chkDetails.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDetails.Location = new System.Drawing.Point(201, 70);
            this.chkDetails.Name = "chkDetails";
            this.chkDetails.Size = new System.Drawing.Size(89, 21);
            this.chkDetails.TabIndex = 28;
            this.chkDetails.Text = "Detailed";
            this.chkDetails.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(15, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(265, 78);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Legends";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Yellow;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(128, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 23);
            this.label6.TabIndex = 8;
            this.label6.Text = "General";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(128, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 23);
            this.label4.TabIndex = 8;
            this.label4.Text = "Compl && Splitted";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Lime;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Splitted";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Complementary";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lstGLAccounts);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(318, 15);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(362, 160);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "For G/L Accounts";
            // 
            // lstGLAccounts
            // 
            this.lstGLAccounts.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstGLAccounts.FormattingEnabled = true;
            this.lstGLAccounts.ItemHeight = 14;
            this.lstGLAccounts.Location = new System.Drawing.Point(6, 21);
            this.lstGLAccounts.Name = "lstGLAccounts";
            this.lstGLAccounts.ScrollAlwaysVisible = true;
            this.lstGLAccounts.Size = new System.Drawing.Size(350, 130);
            this.lstGLAccounts.TabIndex = 0;
            // 
            // chkStaffAcount
            // 
            this.chkStaffAcount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkStaffAcount.Location = new System.Drawing.Point(700, 60);
            this.chkStaffAcount.Name = "chkStaffAcount";
            this.chkStaffAcount.Size = new System.Drawing.Size(116, 40);
            this.chkStaffAcount.TabIndex = 30;
            this.chkStaffAcount.Text = "Staff Accounts";
            this.chkStaffAcount.UseVisualStyleBackColor = true;
            this.chkStaffAcount.CheckedChanged += new System.EventHandler(this.chkStaffAcount_CheckedChanged);
            // 
            // chkCreditAccount
            // 
            this.chkCreditAccount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCreditAccount.Location = new System.Drawing.Point(700, 106);
            this.chkCreditAccount.Name = "chkCreditAccount";
            this.chkCreditAccount.Size = new System.Drawing.Size(116, 40);
            this.chkCreditAccount.TabIndex = 30;
            this.chkCreditAccount.Text = "Credit Accounts";
            this.chkCreditAccount.UseVisualStyleBackColor = true;
            this.chkCreditAccount.CheckedChanged += new System.EventHandler(this.chkStaffAcount_CheckedChanged);
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectAll.Location = new System.Drawing.Point(834, 73);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(102, 30);
            this.btnSelectAll.TabIndex = 31;
            this.btnSelectAll.Text = "&Select All";
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            // 
            // btnPrepareBill
            // 
            this.btnPrepareBill.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrepareBill.Location = new System.Drawing.Point(834, 128);
            this.btnPrepareBill.Name = "btnPrepareBill";
            this.btnPrepareBill.Size = new System.Drawing.Size(102, 30);
            this.btnPrepareBill.TabIndex = 31;
            this.btnPrepareBill.Text = "Prepare Bill";
            this.btnPrepareBill.UseVisualStyleBackColor = true;
            this.btnPrepareBill.Click += new System.EventHandler(this.btnPrepareBill_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(942, 73);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 30);
            this.button2.TabIndex = 31;
            this.button2.Text = "&Un-Select";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(942, 128);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(86, 30);
            this.btnClose.TabIndex = 31;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabDetail);
            this.tabControl1.Controls.Add(this.tabSummarized);
            this.tabControl1.Controls.Add(this.tabBilling);
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.HotTrack = true;
            this.tabControl1.ItemSize = new System.Drawing.Size(405, 20);
            this.tabControl1.Location = new System.Drawing.Point(12, 181);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1218, 295);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 32;
            this.tabControl1.TabStop = false;
            // 
            // tabDetail
            // 
            this.tabDetail.AutoScroll = true;
            this.tabDetail.Controls.Add(this.dgvDetailed);
            this.tabDetail.Location = new System.Drawing.Point(4, 24);
            this.tabDetail.Name = "tabDetail";
            this.tabDetail.Padding = new System.Windows.Forms.Padding(3);
            this.tabDetail.Size = new System.Drawing.Size(1210, 267);
            this.tabDetail.TabIndex = 0;
            this.tabDetail.Text = "Detailed";
            this.tabDetail.UseVisualStyleBackColor = true;
            // 
            // dgvDetailed
            // 
            this.dgvDetailed.AllowUserToAddRows = false;
            this.dgvDetailed.AllowUserToDeleteRows = false;
            this.dgvDetailed.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDetailed.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvDetailed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetailed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDetailed.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvDetailed.Location = new System.Drawing.Point(3, 3);
            this.dgvDetailed.MultiSelect = false;
            this.dgvDetailed.Name = "dgvDetailed";
            this.dgvDetailed.RowHeadersVisible = false;
            this.dgvDetailed.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetailed.ShowCellErrors = false;
            this.dgvDetailed.ShowCellToolTips = false;
            this.dgvDetailed.ShowEditingIcon = false;
            this.dgvDetailed.ShowRowErrors = false;
            this.dgvDetailed.Size = new System.Drawing.Size(1204, 261);
            this.dgvDetailed.TabIndex = 0;
            // 
            // tabSummarized
            // 
            this.tabSummarized.Controls.Add(this.dgvSummarized);
            this.tabSummarized.Location = new System.Drawing.Point(4, 24);
            this.tabSummarized.Name = "tabSummarized";
            this.tabSummarized.Padding = new System.Windows.Forms.Padding(3);
            this.tabSummarized.Size = new System.Drawing.Size(1210, 267);
            this.tabSummarized.TabIndex = 1;
            this.tabSummarized.Text = "Summarized";
            this.tabSummarized.UseVisualStyleBackColor = true;
            // 
            // dgvSummarized
            // 
            this.dgvSummarized.AllowUserToAddRows = false;
            this.dgvSummarized.AllowUserToDeleteRows = false;
            this.dgvSummarized.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSummarized.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSummarized.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSummarized.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSummarized.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvSummarized.Location = new System.Drawing.Point(3, 3);
            this.dgvSummarized.MultiSelect = false;
            this.dgvSummarized.Name = "dgvSummarized";
            this.dgvSummarized.RowHeadersVisible = false;
            this.dgvSummarized.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSummarized.ShowCellErrors = false;
            this.dgvSummarized.ShowCellToolTips = false;
            this.dgvSummarized.ShowEditingIcon = false;
            this.dgvSummarized.ShowRowErrors = false;
            this.dgvSummarized.Size = new System.Drawing.Size(1204, 261);
            this.dgvSummarized.TabIndex = 0;
            // 
            // tabBilling
            // 
            this.tabBilling.Controls.Add(this.dgvBlling);
            this.tabBilling.Location = new System.Drawing.Point(4, 24);
            this.tabBilling.Name = "tabBilling";
            this.tabBilling.Padding = new System.Windows.Forms.Padding(3);
            this.tabBilling.Size = new System.Drawing.Size(1210, 267);
            this.tabBilling.TabIndex = 2;
            this.tabBilling.Text = "Select Voucher for Billing";
            this.tabBilling.UseVisualStyleBackColor = true;
            // 
            // dgvBlling
            // 
            this.dgvBlling.AllowUserToAddRows = false;
            this.dgvBlling.AllowUserToDeleteRows = false;
            this.dgvBlling.AllowUserToResizeRows = false;
            this.dgvBlling.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvBlling.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvBlling.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBlling.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBlling.Location = new System.Drawing.Point(3, 3);
            this.dgvBlling.MultiSelect = false;
            this.dgvBlling.Name = "dgvBlling";
            this.dgvBlling.RowHeadersVisible = false;
            this.dgvBlling.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvBlling.ShowCellErrors = false;
            this.dgvBlling.ShowCellToolTips = false;
            this.dgvBlling.ShowEditingIcon = false;
            this.dgvBlling.ShowRowErrors = false;
            this.dgvBlling.Size = new System.Drawing.Size(1204, 261);
            this.dgvBlling.TabIndex = 0;
            // 
            // frmAccountWiseSales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1242, 488);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnPrepareBill);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnSelectAll);
            this.Controls.Add(this.chkCreditAccount);
            this.Controls.Add(this.chkStaffAcount);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chkDetails);
            this.Controls.Add(this.chkAllPending);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dtmTo);
            this.Controls.Add(this.dtmFrom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.Name = "frmAccountWiseSales";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Account Wise Sale";
            this.Load += new System.EventHandler(this.frmChannelBill_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabDetail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailed)).EndInit();
            this.tabSummarized.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummarized)).EndInit();
            this.tabBilling.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBlling)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtmFrom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtmTo;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.CheckBox chkAllPending;
        private System.Windows.Forms.CheckBox chkDetails;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstGLAccounts;
        private System.Windows.Forms.CheckBox chkStaffAcount;
        private System.Windows.Forms.CheckBox chkCreditAccount;
        private System.Windows.Forms.Button btnSelectAll;
        private System.Windows.Forms.Button btnPrepareBill;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabDetail;
        private System.Windows.Forms.TabPage tabSummarized;
        private System.Windows.Forms.TabPage tabBilling;
        private System.Windows.Forms.DataGridView dgvDetailed;
        private System.Windows.Forms.DataGridView dgvSummarized;
        private System.Windows.Forms.DataGridView dgvBlling;
    }
}