﻿namespace SmartHostelManagement.Order
{
    partial class frmCancelCatOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTotalamt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dtmReservTo = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEntryNo = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtmCancelledDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtItemList = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCancelQty = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBuffetTYpe = new System.Windows.Forms.TextBox();
            this.txtMenuName = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDetRemarks = new System.Windows.Forms.TextBox();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.txtOrderQty = new System.Windows.Forms.TextBox();
            this.dtmDetUptoReserv = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnExist = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvReservationDet = new System.Windows.Forms.DataGridView();
            this.btnAddChange = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservationDet)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtTotalamt);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.dtmReservTo);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtEntryNo);
            this.groupBox1.Controls.Add(this.txtAddress2);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtCustName);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.dtmCancelledDate);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtItemList);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCancelQty);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtBuffetTYpe);
            this.groupBox1.Controls.Add(this.txtMenuName);
            this.groupBox1.Controls.Add(this.label55);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtDetRemarks);
            this.groupBox1.Controls.Add(this.txtRate);
            this.groupBox1.Controls.Add(this.txtOrderQty);
            this.groupBox1.Controls.Add(this.dtmDetUptoReserv);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.btnUndo);
            this.groupBox1.Controls.Add(this.btnExist);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.dgvReservationDet);
            this.groupBox1.Controls.Add(this.btnAddChange);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(911, 509);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Display";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 225);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 14);
            this.label12.TabIndex = 165;
            this.label12.Text = "Total Amt";
            // 
            // txtTotalamt
            // 
            this.txtTotalamt.BackColor = System.Drawing.Color.White;
            this.txtTotalamt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalamt.Location = new System.Drawing.Point(85, 221);
            this.txtTotalamt.MaxLength = 40000;
            this.txtTotalamt.Name = "txtTotalamt";
            this.txtTotalamt.ReadOnly = true;
            this.txtTotalamt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtTotalamt.Size = new System.Drawing.Size(168, 22);
            this.txtTotalamt.TabIndex = 164;
            this.txtTotalamt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalamt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(190, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 14);
            this.label8.TabIndex = 163;
            this.label8.Text = "Date Of Order";
            // 
            // dtmReservTo
            // 
            this.dtmReservTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.CalendarMonthBackground = System.Drawing.SystemColors.HighlightText;
            this.dtmReservTo.CalendarTrailingForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtmReservTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmReservTo.Enabled = false;
            this.dtmReservTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmReservTo.Location = new System.Drawing.Point(295, 19);
            this.dtmReservTo.Name = "dtmReservTo";
            this.dtmReservTo.Size = new System.Drawing.Size(127, 22);
            this.dtmReservTo.TabIndex = 162;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 14);
            this.label7.TabIndex = 161;
            this.label7.Text = "Name";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Viner Hand ITC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(900, 12);
            this.label2.TabIndex = 159;
            this.label2.Text = "---------------------------------------------------------------------------------" +
    "--------------------------------------------------------------------------------" +
    "----";
            // 
            // txtEntryNo
            // 
            this.txtEntryNo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtEntryNo.Enabled = false;
            this.txtEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryNo.Location = new System.Drawing.Point(86, 19);
            this.txtEntryNo.MaxLength = 10;
            this.txtEntryNo.Name = "txtEntryNo";
            this.txtEntryNo.Size = new System.Drawing.Size(101, 22);
            this.txtEntryNo.TabIndex = 158;
            this.txtEntryNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAddress2
            // 
            this.txtAddress2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAddress2.Enabled = false;
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(17, 95);
            this.txtAddress2.MaxLength = 40000;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(428, 22);
            this.txtAddress2.TabIndex = 157;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(14, 75);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 14);
            this.label16.TabIndex = 156;
            this.label16.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAddress.Enabled = false;
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(76, 71);
            this.txtAddress.MaxLength = 40000;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(368, 22);
            this.txtAddress.TabIndex = 155;
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCustName.Enabled = false;
            this.txtCustName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.Location = new System.Drawing.Point(76, 46);
            this.txtCustName.MaxLength = 40000;
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(368, 22);
            this.txtCustName.TabIndex = 154;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(14, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 14);
            this.label11.TabIndex = 152;
            this.label11.Text = "Order No.";
            // 
            // dtmCancelledDate
            // 
            this.dtmCancelledDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmCancelledDate.CustomFormat = "dd/MMM/yyyy HH:mm tt";
            this.dtmCancelledDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmCancelledDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmCancelledDate.Location = new System.Drawing.Point(567, 95);
            this.dtmCancelledDate.Name = "dtmCancelledDate";
            this.dtmCancelledDate.Size = new System.Drawing.Size(199, 22);
            this.dtmCancelledDate.TabIndex = 151;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(461, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 14);
            this.label1.TabIndex = 150;
            this.label1.Text = "Date Of Cancel";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(490, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 14);
            this.label4.TabIndex = 149;
            this.label4.Text = "Item List";
            // 
            // txtItemList
            // 
            this.txtItemList.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemList.Location = new System.Drawing.Point(493, 152);
            this.txtItemList.MaxLength = 10;
            this.txtItemList.Multiline = true;
            this.txtItemList.Name = "txtItemList";
            this.txtItemList.ReadOnly = true;
            this.txtItemList.Size = new System.Drawing.Size(243, 89);
            this.txtItemList.TabIndex = 148;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(288, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 14);
            this.label3.TabIndex = 147;
            this.label3.Text = "Cancel Qty";
            // 
            // txtCancelQty
            // 
            this.txtCancelQty.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCancelQty.Location = new System.Drawing.Point(291, 151);
            this.txtCancelQty.MaxLength = 10;
            this.txtCancelQty.Name = "txtCancelQty";
            this.txtCancelQty.Size = new System.Drawing.Size(98, 22);
            this.txtCancelQty.TabIndex = 146;
            this.txtCancelQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCancelQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 14);
            this.label6.TabIndex = 143;
            this.label6.Text = "Menu Name";
            // 
            // txtBuffetTYpe
            // 
            this.txtBuffetTYpe.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBuffetTYpe.Location = new System.Drawing.Point(256, 194);
            this.txtBuffetTYpe.MaxLength = 10;
            this.txtBuffetTYpe.Name = "txtBuffetTYpe";
            this.txtBuffetTYpe.ReadOnly = true;
            this.txtBuffetTYpe.Size = new System.Drawing.Size(234, 22);
            this.txtBuffetTYpe.TabIndex = 141;
            // 
            // txtMenuName
            // 
            this.txtMenuName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMenuName.Location = new System.Drawing.Point(17, 194);
            this.txtMenuName.MaxLength = 10;
            this.txtMenuName.Name = "txtMenuName";
            this.txtMenuName.ReadOnly = true;
            this.txtMenuName.Size = new System.Drawing.Size(234, 22);
            this.txtMenuName.TabIndex = 139;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(14, 136);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(121, 14);
            this.label55.TabIndex = 140;
            this.label55.Text = "Serve Date/Time";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(14, 250);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 14);
            this.label30.TabIndex = 138;
            this.label30.Text = "Remarks";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(389, 136);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(37, 14);
            this.label28.TabIndex = 136;
            this.label28.Text = "Rate";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(187, 136);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 14);
            this.label10.TabIndex = 135;
            this.label10.Text = "Order Qty";
            // 
            // txtDetRemarks
            // 
            this.txtDetRemarks.BackColor = System.Drawing.Color.White;
            this.txtDetRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDetRemarks.Location = new System.Drawing.Point(85, 246);
            this.txtDetRemarks.MaxLength = 40000;
            this.txtDetRemarks.Name = "txtDetRemarks";
            this.txtDetRemarks.Size = new System.Drawing.Size(633, 22);
            this.txtDetRemarks.TabIndex = 134;
            // 
            // txtRate
            // 
            this.txtRate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRate.Location = new System.Drawing.Point(392, 151);
            this.txtRate.MaxLength = 10;
            this.txtRate.Name = "txtRate";
            this.txtRate.ReadOnly = true;
            this.txtRate.Size = new System.Drawing.Size(98, 22);
            this.txtRate.TabIndex = 132;
            this.txtRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // txtOrderQty
            // 
            this.txtOrderQty.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderQty.Location = new System.Drawing.Point(190, 151);
            this.txtOrderQty.MaxLength = 10;
            this.txtOrderQty.Name = "txtOrderQty";
            this.txtOrderQty.ReadOnly = true;
            this.txtOrderQty.Size = new System.Drawing.Size(98, 22);
            this.txtOrderQty.TabIndex = 131;
            this.txtOrderQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrderQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // dtmDetUptoReserv
            // 
            this.dtmDetUptoReserv.CalendarFont = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetUptoReserv.CustomFormat = "dd/MMM/yyyy HH:mm";
            this.dtmDetUptoReserv.Enabled = false;
            this.dtmDetUptoReserv.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetUptoReserv.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmDetUptoReserv.Location = new System.Drawing.Point(17, 151);
            this.dtmDetUptoReserv.Name = "dtmDetUptoReserv";
            this.dtmDetUptoReserv.Size = new System.Drawing.Size(170, 22);
            this.dtmDetUptoReserv.TabIndex = 130;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(254, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 14);
            this.label9.TabIndex = 142;
            this.label9.Text = "Buffet Type";
            // 
            // btnUndo
            // 
            this.btnUndo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUndo.Location = new System.Drawing.Point(10, 474);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(96, 27);
            this.btnUndo.TabIndex = 62;
            this.btnUndo.Text = "&Undo";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnExist
            // 
            this.btnExist.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExist.Location = new System.Drawing.Point(112, 474);
            this.btnExist.Name = "btnExist";
            this.btnExist.Size = new System.Drawing.Size(96, 27);
            this.btnExist.TabIndex = 61;
            this.btnExist.Text = "&Edit";
            this.btnExist.UseVisualStyleBackColor = true;
            this.btnExist.Click += new System.EventHandler(this.btnExist_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(707, 474);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 27);
            this.button1.TabIndex = 60;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvReservationDet
            // 
            this.dgvReservationDet.AllowUserToAddRows = false;
            this.dgvReservationDet.AllowUserToDeleteRows = false;
            this.dgvReservationDet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvReservationDet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvReservationDet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvReservationDet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReservationDet.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvReservationDet.Location = new System.Drawing.Point(6, 273);
            this.dgvReservationDet.MultiSelect = false;
            this.dgvReservationDet.Name = "dgvReservationDet";
            this.dgvReservationDet.ReadOnly = true;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReservationDet.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvReservationDet.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            this.dgvReservationDet.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvReservationDet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvReservationDet.ShowCellErrors = false;
            this.dgvReservationDet.ShowCellToolTips = false;
            this.dgvReservationDet.ShowEditingIcon = false;
            this.dgvReservationDet.ShowRowErrors = false;
            this.dgvReservationDet.Size = new System.Drawing.Size(901, 192);
            this.dgvReservationDet.TabIndex = 59;
            this.dgvReservationDet.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReservationDet_CellDoubleClick);
            // 
            // btnAddChange
            // 
            this.btnAddChange.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddChange.Location = new System.Drawing.Point(751, 241);
            this.btnAddChange.Name = "btnAddChange";
            this.btnAddChange.Size = new System.Drawing.Size(118, 27);
            this.btnAddChange.TabIndex = 58;
            this.btnAddChange.Text = "&Add/Change";
            this.btnAddChange.UseVisualStyleBackColor = true;
            this.btnAddChange.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // frmCancelCatOrder
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(911, 509);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCancelCatOrder";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Cancel Order";
            this.Load += new System.EventHandler(this.frmReservation_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservationDet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAddChange;
        private System.Windows.Forms.DataGridView dgvReservationDet;
        private System.Windows.Forms.Button btnExist;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBuffetTYpe;
        private System.Windows.Forms.TextBox txtMenuName;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDetRemarks;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.TextBox txtOrderQty;
        private System.Windows.Forms.DateTimePicker dtmDetUptoReserv;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCancelQty;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtItemList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEntryNo;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtmCancelledDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtmReservTo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtTotalamt;
    }
}