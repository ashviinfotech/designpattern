﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Order
{
    public partial class frmChannelBill : Form
    {
        ISIPMEntities dbContext { get; set; }
        MasterCaller masterCaller = new MasterCaller();
        string sqlConnectString { get; set; }

        public ChannelBILL objChannelBill { get; set; }
        public List<ChannelBillDetail> lstChannelBillDetail { get; set; }

        public frmChannelBill()
        {
            using (dbContext = new ISIPMEntities())
                sqlConnectString = dbContext.Database.Connection.ConnectionString;
            InitializeComponent();
        }

        private void frmChannelBill_Load(object sender, EventArgs e)
        {
            dbContext = new ISIPMEntities();
            chkPreview.Checked = true;

            if (objChannelBill != null)
            {
                FillPageData();
            }
        }

        private void ResetPageData()
        {
            this.objChannelBill = null;

            dtmDate.Value = DateTime.Now;
            chkBillTo.Checked = false;
            chkPreview.Checked = true;
            txtGuestName.Text = string.Empty;
            txtBillto.Text = string.Empty;
            txtBillNo.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtAddress2.Text = string.Empty;
            txtTelephone.Text = string.Empty;
            txtBilltoAdd.Text = string.Empty;
            txtBillToAddress2.Text = string.Empty;
            txtBilltoTelephone.Text = string.Empty;
            txtOrderNo.Text = string.Empty;

            txtDescription.Text = string.Empty;
            txtBillDetails.Text = string.Empty;
            txtQuantity.Text = string.Empty;
            txtSCharge.Text = string.Empty;
            txtTotal.Text = string.Empty;
            txtGCST.Text = string.Empty;
            txtSGST.Text = string.Empty;
            txtDiscount.Text = string.Empty;
            txtRoudOff.Text = string.Empty;
            txtNetAmount.Text = string.Empty;

            lstChannelBillDetail = null;
            BindChannelBillDetails();
        }

        private void FillPageData()
        {
            try
            {
                if (objChannelBill != null)
                {
                    dtmDate.Value = CommonBaseFN.MergeDatetime(objChannelBill.Bdate, objChannelBill.Btime);
                    chkBillTo.Checked = objChannelBill.billtochk.HasValue ? objChannelBill.billtochk.Value : false;

                    txtGuestName.Text = objChannelBill.Name_guest;
                    txtBillto.Text = objChannelBill.Name_billto;
                    txtBillNo.Text = objChannelBill.Bill_No.HasValue ? objChannelBill.Bill_No.Value.ToString() : string.Empty;
                    txtAddress.Text = objChannelBill.addr1_guest;
                    txtAddress2.Text = objChannelBill.addr2_guest;
                    txtTelephone.Text = objChannelBill.addr3_guest;
                    txtBilltoAdd.Text = objChannelBill.addr1_billto;
                    txtBillToAddress2.Text = objChannelBill.addr2_billto;
                    txtBilltoTelephone.Text = objChannelBill.addr3_billto;
                    txtOrderNo.Text = objChannelBill.orderformno;

                    txtDescription.Text = objChannelBill.description_b;
                    txtBillDetails.Text = objChannelBill.BILLDETAILS;
                    txtQuantity.Text = objChannelBill.totalroomrent.HasValue ? objChannelBill.totalroomrent.Value.ToString() : string.Empty;
                    txtSCharge.Text = objChannelBill.schargeamt.HasValue ? objChannelBill.schargeamt.Value.ToString("0.00") : "0.00";
                    txtTotal.Text = objChannelBill.totalamt.HasValue ? objChannelBill.totalamt.Value.ToString("0.00") : "0.00";
                    txtGCST.Text = objChannelBill.billroomtype.HasValue && objChannelBill.billroomtype.Value == 1 ?
                        objChannelBill.VATamt.HasValue ? objChannelBill.VATamt.Value.ToString("0.00") : "0.00" : "0.00";
                    txtSGST.Text = objChannelBill.billroomtype.HasValue && objChannelBill.billroomtype.Value == 1 ?
                        objChannelBill.VATamt1.HasValue ? objChannelBill.VATamt1.Value.ToString("0.00") : "0.00" : "0.00";
                    txtDiscount.Text = objChannelBill.discountamt.HasValue ? objChannelBill.discountamt.Value.ToString("0.00") : "0.00";
                    txtRoudOff.Text = objChannelBill.roundoff.HasValue ? objChannelBill.roundoff.Value.ToString("0.00") : "0.00";
                    txtNetAmount.Text = objChannelBill.netpayable.HasValue ? objChannelBill.netpayable.Value.ToString("0.00") : "0.00";

                    if (objChannelBill.ChannelBillDetails != null && objChannelBill.ChannelBillDetails.Count > 0) lstChannelBillDetail = objChannelBill.ChannelBillDetails.ToList();                    
                    BindChannelBillDetails();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void BindChannelBillDetails()
        {
            try
            {
                if (this.lstChannelBillDetail == null) lstChannelBillDetail = new List<ChannelBillDetail>();
                var billData = lstChannelBillDetail.Select((c,index) => new 
                {
                    Slno = index + 1,
                    c.Channelbilldet_id,
                    Particulars = c.roomno,
                    Qty = c.roomrent_amt,
                    Rate = c.roomserv_kitch_amt,
                    ServChrg = c.laundary_amt,
                    CGST = c.minibar,
                    SGST = 0,
                    TotalAmt = c.total_amt_amt
                }).ToList();

                dgvChannellBilldetails.DataSource = billData;

                dgvChannellBilldetails.Columns["Slno"].Frozen = true;
                dgvChannellBilldetails.Columns["Channelbilldet_id"].Visible = false;
                dgvChannellBilldetails.Columns["Qty"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["Qty"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["Rate"].DefaultCellStyle.Format = "0.00";
                dgvChannellBilldetails.Columns["Rate"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["Rate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["ServChrg"].DefaultCellStyle.Format = "0.00";
                dgvChannellBilldetails.Columns["ServChrg"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["ServChrg"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["CGST"].DefaultCellStyle.Format = "0.00";
                dgvChannellBilldetails.Columns["CGST"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["CGST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["SGST"].DefaultCellStyle.Format = "0.00";
                dgvChannellBilldetails.Columns["SGST"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["SGST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["TotalAmt"].DefaultCellStyle.Format = "0.00";
                dgvChannellBilldetails.Columns["TotalAmt"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvChannellBilldetails.Columns["TotalAmt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvChannellBilldetails.ClearSelection();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (objChannelBill != null)
                {
                    if (string.IsNullOrEmpty(objChannelBill.GAccountCode))
                    {
                        CustomMessageBox.ShowExclamationMessage("Please select GL to create bill", this.Text);
                        return;
                    }

                    using (TransactionScope objTrans = new TransactionScope(TransactionScopeOption.Required,
                        new TransactionOptions { IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted },
                        EnterpriseServicesInteropOption.Automatic))
                    {
                        #region Object Properties value
                        //objChannelBill.GAccountname=;
                        //objChannelBill.GAccountCode=;
                        //objChannelBill.schargerate=;
                        //objChannelBill.schargeamt=;
                        //objChannelBill.totalamt=;
                        //objChannelBill.luxurytaxrate=;
                        //objChannelBill.luxurytaxamt=;
                        //objChannelBill.salestaxrate=;
                        //objChannelBill.salestaxamt=;
                        //objChannelBill.grandtotalamt=;
                        //objChannelBill.roomserviceamt=;
                        //objChannelBill.discountrate=;
                        //objChannelBill.discountamt=;
                        //objChannelBill.advancerecd=;
                        //objChannelBill.netpayable=;
                        //objChannelBill.roundoff=;
                        //objChannelBill.totalroomrent=;
                        //objChannelBill.totalkitchen=;
                        //objChannelBill.totaltelephone=;
                        //objChannelBill.totalextrabed=;
                        //objChannelBill.totallaundary=;
                        //objChannelBill.totalMiscCharges=;
                        //objChannelBill.duebalance=;
                        //objChannelBill.totalminibar=;
                        //objChannelBill.VATamt=;
                        //objChannelBill.VATamt1=;
                        //objChannelBill.KOTIDS=;
                        //objChannelBill.BILLDETAILS=;
                        //objChannelBill.servicetaxamt=;

                        objChannelBill.Bdate = dtmDate.Value.Date;
                        objChannelBill.Btime = dtmDate.Value;
                        objChannelBill.Name_guest = txtGuestName.Text;
                        objChannelBill.addr1_guest = txtAddress.Text;
                        objChannelBill.addr2_guest = txtAddress2.Text;
                        objChannelBill.addr3_guest = txtTelephone.Text;
                        objChannelBill.Name_billto = txtBillto.Text;
                        objChannelBill.addr1_billto = txtBilltoAdd.Text;
                        objChannelBill.addr2_billto = txtBillToAddress2.Text;
                        objChannelBill.addr3_billto = txtBilltoTelephone.Text;
                        objChannelBill.description_b = txtDescription.Text;
                        objChannelBill.billtochk = chkBillTo.Checked;
                        objChannelBill.MachineName = Environment.MachineName;
                        objChannelBill.orderformno = txtOrderNo.Text;
                        #endregion Object Properties value

                        if (objChannelBill.ChannelBill_Id > 0)
                        {
                            objChannelBill.id1 = Frm_Login.UserLogin.log_id;
                            objChannelBill.date_of_mod = DateTime.Now;
                            objChannelBill.modifiedby = Frm_Login.UserLogin.loginID;
                        }
                        else
                        {
                            #region Add New Bill
                            objChannelBill.ChannelBill_Id = dbContext.ChannelBILLs.Max(x => x.ChannelBill_Id) + 1;
                            dbContext.Configuration.LazyLoadingEnabled = false;
                            if ((dtmDate.Value.Year * 100 + dtmDate.Value.Month) > (DateTime.Today.Year * 100 + 3))
                            {
                                objChannelBill.Bill_No = dbContext.ChannelBILLs.Where(x => (x.Bdate.Value.Year * 100 + x.Bdate.Value.Month) > (DateTime.Today.Year * 100 + 3)
                                    && (x.Bdate.Value.Year * 100 + x.Bdate.Value.Month) < ((DateTime.Today.Year + 1) * 100 + 04)).Max(t => t.Bill_No);
                            }
                            else
                            {
                                objChannelBill.Bill_No = dbContext.ChannelBILLs.Where(x => (x.Bdate.Value.Year * 100 + x.Bdate.Value.Month) > ((DateTime.Today.Year - 1) * 100 + 3)
                                    && (x.Bdate.Value.Year * 100 + x.Bdate.Value.Month) < (DateTime.Today.Year * 100 + 04)).Max(t => t.Bill_No);
                            }
                            dbContext.Configuration.LazyLoadingEnabled = true;
                            objChannelBill.Bill_No = objChannelBill.Bill_No.HasValue ? objChannelBill.Bill_No.Value + 1 : 1;

                            objChannelBill.billroomtype = 1;
                            objChannelBill.id = Frm_Login.UserLogin.log_id;
                            objChannelBill.date_of_add = DateTime.Now;
                            objChannelBill.createdby = Frm_Login.UserLogin.loginID;
                            objChannelBill.BillcreationType = 0;
                            objChannelBill.transportamt = 0;
                            objChannelBill.MISCIDS = string.Empty;
                            #endregion Add New Bill

                            dbContext.ChannelBILLs.Add(objChannelBill);
                        }

                        if (dbContext.SaveChanges() > 0)
                        {
                            string[] KOTID = objChannelBill.KOTIDS.Split(',');
                            int kot_id = 0;
                            foreach (string strKot in KOTID)
                            {
                                if (int.TryParse(strKot, out kot_id))
                                {
                                    KOT objKot = dbContext.KOTs.FirstOrDefault(x => x.KOT_ID == kot_id);
                                    //if(objChannelBill.activate_delete.HasValue && objChannelBill.activate_delete.Value == true)
                                    //    objKot.cHANNELbILLNO =  null;
                                    //else
                                    //    objKot.cHANNELbILLNO = objChannelBill.ChannelBill_Id;
                                }
                            }

                            int Channelbilldet_id = dbContext.ChannelBillDetails.Max(x => x.Channelbilldet_id);

                            foreach (ChannelBillDetail objChanelDet in lstChannelBillDetail)
                            {
                                
                                if (objChanelDet.Channelbilldet_id < 1)
                                {
                                    Channelbilldet_id = Channelbilldet_id + 1;
                                    objChanelDet.Channelbilldet_id = Channelbilldet_id;    
                                    objChanelDet.ChannelBill_Id = objChannelBill.ChannelBill_Id;
                                    dbContext.ChannelBillDetails.Add(objChanelDet);
                                }
                            }

                            #region ChannelBillLog
                            dbContext.ChannelBILL_log.Add(new ChannelBILL_log
                            {
                                ChannelBill_ID_log = dbContext.ChannelBILL_log.Max(x => x.ChannelBill_ID_log) + 1,
                                ChannelBill_ID = objChannelBill.ChannelBill_Id,
                                Bill_No = objChannelBill.Bill_No,
                                Bdate = objChannelBill.Bdate,
                                Btime = objChannelBill.Btime,
                                reservation_ID = objChannelBill.reservation_ID,
                                Name_guest = objChannelBill.Name_guest,
                                addr1_guest = objChannelBill.addr1_guest,
                                addr2_guest = objChannelBill.addr2_guest,
                                addr3_guest = objChannelBill.addr3_guest,
                                Name_billto = objChannelBill.Name_billto,
                                addr1_billto = objChannelBill.addr1_billto,
                                addr2_billto = objChannelBill.addr2_billto,
                                addr3_billto = objChannelBill.addr3_billto,
                                roomNo = objChannelBill.roomNo,
                                checkintime_date = objChannelBill.checkintime_date,
                                checkouttime_date = objChannelBill.checkouttime_date,
                                schargerate = objChannelBill.schargerate,
                                schargeamt = objChannelBill.schargeamt,
                                totalamt = objChannelBill.totalamt,
                                luxurytaxrate = objChannelBill.luxurytaxrate,
                                luxurytaxamt = objChannelBill.luxurytaxamt,
                                salestaxrate = objChannelBill.salestaxrate,
                                salestaxamt = objChannelBill.salestaxamt,
                                grandtotalamt = objChannelBill.grandtotalamt,
                                roomserviceamt = objChannelBill.roomserviceamt,
                                discountrate = objChannelBill.discountrate,
                                discountamt = objChannelBill.discountamt,
                                advancerecd = objChannelBill.advancerecd,
                                netpayable = objChannelBill.netpayable,
                                description_b = objChannelBill.description_b,
                                Advance_ids = objChannelBill.Advance_ids,
                                id = objChannelBill.id,
                                date_of_add = objChannelBill.date_of_add,
                                id1 = objChannelBill.id1,
                                date_of_mod = objChannelBill.date_of_mod,
                                activate_delete = objChannelBill.activate_delete,
                                reservation_ID_all = objChannelBill.reservation_ID_all,
                                roundoff = objChannelBill.roundoff,
                                Grno = objChannelBill.Grno,
                                totalroomrent = objChannelBill.totalroomrent,
                                totalkitchen = objChannelBill.totalkitchen,
                                totaltelephone = objChannelBill.totaltelephone,
                                totalextrabed = objChannelBill.totalextrabed,
                                totallaundary = objChannelBill.totallaundary,
                                totalMiscCharges = objChannelBill.totalMiscCharges,
                                duebalance = objChannelBill.duebalance,
                                totalminibar = objChannelBill.totalminibar,
                                billtochk = objChannelBill.billtochk,
                                billroomtype = objChannelBill.billroomtype,
                                MachineName = objChannelBill.MachineName,
                                BillcreationType = objChannelBill.BillcreationType,
                                sepamtroundoff = objChannelBill.sepamtroundoff,
                                transportamt = objChannelBill.transportamt,
                                createdby = objChannelBill.createdby,
                                modifiedby = objChannelBill.modifiedby,
                                GAccountCode = objChannelBill.GAccountCode,
                                GAccountname = objChannelBill.GAccountname,
                                VATamt = objChannelBill.VATamt,
                                KOTIDS = objChannelBill.KOTIDS,
                                MISCIDS = objChannelBill.MISCIDS,
                                BILLDETAILS = objChannelBill.BILLDETAILS,
                                orderformno = objChannelBill.orderformno
                            });
                            #endregion ChannelBillLog

                            dbContext.SaveChanges();
                        }

                        objTrans.Complete();
                        objTrans.Dispose();
                    }

                    CustomMessageBox.ShowExclamationMessage("Record Save", this.Text);
                    dbContext = new ISIPMEntities();
                    int channleid = objChannelBill.ChannelBill_Id;
                    ResetPageData();
                    objChannelBill = dbContext.ChannelBILLs.FirstOrDefault(x => x.ChannelBill_Id == channleid);
                    FillPageData();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.objChannelBill != null)
                {
                    if (CustomMessageBox.ShowDialogBoxMessage("Delete this bill ?") == DialogResult.Yes)
                    {
                        this.objChannelBill.activate_delete = true;
                        btnSave_Click(sender, e);
                        btnLast_Click(sender, e);
                    }
                }
                else
                    CustomMessageBox.ShowExclamationMessage("Please select the bill.", this.Text);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.objChannelBill != null && this.objChannelBill.ChannelBill_Id > 1)
                {
                    string sqlQuery = @"BEGIN
	                        DECLARE @ChannelBill_Id INT = " + objChannelBill.ChannelBill_Id + @"

	                        DELETE FROM tempc;
	                        DELETE FROM tempc1;

	                        INSERT INTO tempc (sno,tempC_1,tempD_1,tempC_3,tempC_4,tempC_5,tempC_6,tempC_12,tempC_13,tempC_14,tempF_2,tempF_4,tempF_5,tempF_6,tempF_9,tempF_10,tempF_11,tempC_7,tempC_8)
                            SELECT  ROW_NUMBER() OVER(ORDER BY A.ChannelBill_Id),A.Bill_No,A.Bdate,A.Name_guest,A.addr1_guest,A.addr2_guest,A.addr3_guest,A.description_b,A.orderformno,
                            A.BILLDETAILS,A.discountamt,A.roundoff,A.netpayable,A.schargeamt,(CASE WHEN A.billroomtype = 1 THEN A.VATamt ELSE 0 END) CGST,
                            (CASE WHEN A.billroomtype = 1 THEN A.VATamt1 ELSE 0 END) SGST,A.totalextrabed,B.CSTNO [GST],B.PARPIN [PAN]
                            FROM ChannelBILL A LEFT JOIN [ORDER] B on A.GAccountCode=B.ORDNO WHERE A.ChannelBill_Id = @ChannelBill_Id;

	                        INSERT INTO tempc1 (sno1,sno,tempC_2,tempF_1,tempF_2,tempF_3,tempI_1)
                            SELECT ROW_NUMBER() OVER(ORDER BY Channelbilldet_id),1,roomno,roomrent_amt,roomserv_kitch_amt,total_amt_amt,ROW_NUMBER() OVER(ORDER BY Channelbilldet_id)
                            FROM channelbilldetail WHERE ChannelBill_Id = @ChannelBill_Id;
                        END";

                    dbContext.Database.ExecuteSqlCommand(sqlQuery);

                    //frmReportview freport = new frmReportview();
                    //freport.reportName = "rpt_ravi_channelbill.rpt";
                    ////freport.captionName = "ROOMS BILL";
                    //freport.Show();
                }
                else
                {
                    CustomMessageBox.ShowExclamationMessage("Please select bill to print.", this.Text);
                }
            }
            catch(Exception ex) 
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnOpenByBill_Click(object sender, EventArgs e)
        {
            try
            {
                string strVal = string.Empty;
                if (CustomFormFunction.InputBox("Search by Order Bill No.", "Please Enter BILL Number", ref strVal) ==
                    System.Windows.Forms.DialogResult.OK)
                {
                    int billNo = 0;
                    int.TryParse(strVal, out billNo);

                    var searchR = dbContext.ChannelBILLs.Where(x => x.Bill_No == billNo && x.activate_delete == false).ToList();
                    if (searchR != null)
                    {
                        if (searchR.Count == 1)
                        {
                            ResetPageData();
                            this.objChannelBill = searchR.FirstOrDefault();
                            FillPageData();
                        }
                        else
                        {
                            //using (frmSearchChnlBill frmOrderSearch = new frmSearchChnlBill())
                            //{
                            //    frmOrderSearch.billNo = strVal;
                            //    frmOrderSearch.ShowDialog();
                            //    if (frmOrderSearch.ChannelBill_Id > 0)
                            //    {
                            //        ResetPageData();
                            //        objChannelBill = dbContext.ChannelBILLs.FirstOrDefault(x => x.ChannelBill_Id == frmOrderSearch.ChannelBill_Id);
                            //        FillPageData();
                            //    }
                            //}
                        }
                    }
                    else
                        CustomMessageBox.ShowExclamationMessage("Record not found", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //using (frmSearchChnlBill frmOrderSearch = new frmSearchChnlBill())
            //{
            //    frmOrderSearch.ShowDialog();
            //    if (frmOrderSearch.ChannelBill_Id > 0)
            //    {
            //        ResetPageData();
            //        objChannelBill = dbContext.ChannelBILLs.FirstOrDefault(x => x.ChannelBill_Id == frmOrderSearch.ChannelBill_Id);
            //        FillPageData();
            //    }
            //}
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ResetPageData();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelBill_Id from ChannelBILL WHERE ISNULL(activate_delete,0) = 0 order by ChannelBill_Id asc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);

                if (this.objChannelBill != null && this.objChannelBill.ChannelBill_Id == hotelID)
                    CustomMessageBox.ShowExclamationMessage("This is first record", this.Text);
                else
                {
                    ResetPageData();
                    this.objChannelBill = dbContext.ChannelBILLs.FirstOrDefault(x => x.ChannelBill_Id == hotelID);
                    FillPageData();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in First Selection Data");
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelBill_Id from ChannelBILL WHERE ISNULL(activate_delete,0) = 0" +
                    (this.objChannelBill != null && this.objChannelBill.ChannelBill_Id > 0 ? " and ChannelBill_Id < " + this.objChannelBill.ChannelBill_Id : string.Empty) +
                    " order by ChannelBill_Id desc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);

                if (this.objChannelBill != null && this.objChannelBill.ChannelBill_Id == hotelID)
                    CustomMessageBox.ShowExclamationMessage("This is first record", this.Text);
                else
                {
                    ResetPageData();
                    this.objChannelBill = dbContext.ChannelBILLs.FirstOrDefault(x => x.ChannelBill_Id == hotelID);
                    FillPageData();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Pervious Selection Data");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelBill_Id from ChannelBILL WHERE ISNULL(activate_delete,0) = 0" +
                    (this.objChannelBill != null && this.objChannelBill.ChannelBill_Id > 0 ? " and ChannelBill_Id > " + this.objChannelBill.ChannelBill_Id : string.Empty) +
                    " order by ChannelBill_Id asc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);

                if (this.objChannelBill != null && this.objChannelBill.ChannelBill_Id == hotelID)
                    CustomMessageBox.ShowExclamationMessage("This is Last record", this.Text);
                else
                {
                    ResetPageData();
                    this.objChannelBill = dbContext.ChannelBILLs.FirstOrDefault(x => x.ChannelBill_Id == hotelID);
                    FillPageData();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Pervious Selection Data");
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelBill_Id from ChannelBILL WHERE ISNULL(activate_delete,0) = 0 order by ChannelBill_Id desc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);

                if (this.objChannelBill != null && this.objChannelBill.ChannelBill_Id == hotelID)
                    CustomMessageBox.ShowExclamationMessage("This is Last record", this.Text);
                else
                {
                    ResetPageData();
                    this.objChannelBill = dbContext.ChannelBILLs.FirstOrDefault(x => x.ChannelBill_Id == hotelID);
                    FillPageData();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in First Selection Data");
            }
        }
    }
}
