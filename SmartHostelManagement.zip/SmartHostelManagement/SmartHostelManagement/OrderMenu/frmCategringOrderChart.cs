﻿using System;
using System.Data;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Order
{
    public partial class frmCategringOrderChart : Form
    {
        DataTable dtChannelOrder = null;
        public frmCategringOrderChart()
        {
            InitializeComponent();
        }

        private void frmCategringOrderChart_Load(object sender, EventArgs e)
        {
            dtmToDate.Value = DateTime.Now.AddDays(14);
            GetDataForGrid();
        }

        private void GetDataForGrid()
        {
            try 
	        {	        
		        MasterCaller objMaster = new MasterCaller();
                DateTime dtFromDate = dtmFromDate.Value;
                DateTime dtToDate = dtmToDate.Value;

                dtChannelOrder = new DataTable();
                dtChannelOrder.Columns.Add(new DataColumn(" ", typeof(string)));
                dtChannelOrder.Rows.Add(new object[] { "7 AM-10 AM B/F" });
                dtChannelOrder.Rows.Add(new object[] { "11 AM-12 PM Morn Tea" });
                dtChannelOrder.Rows.Add(new object[] { "1-3 PM Lunch" });
                dtChannelOrder.Rows.Add(new object[] { "3-5 PM Eve Tea" });
                dtChannelOrder.Rows.Add(new object[] { "7-10 PM Dinner" });
                dtChannelOrder.Rows.Add(new object[] { string.Empty });
                dtChannelOrder.Rows.Add(new object[] { string.Empty });

                string sqlQuery = @";WITH ABC AS 
                (	
	                SELECT ChannelOrder_Id, date_ofdet, Qtymax, qty, rate  
	                FROM ChannelOrderDet WHERE CAST(date_ofdet AS DATE) BETWEEN CAST('"+dtFromDate.Date+"' AS DATE) AND CAST('"+dtToDate.Date+@"' AS DATE)	
                ),
                DEF AS
                (
	                SELECT cast(1 as int) Meal,* FROM ABC WHERE CAST(date_ofdet AS TIME) BETWEEN CAST('07:00:00' AS TIME) AND CAST('10:00:00' AS TIME)
	                UNION
	                SELECT cast(2 as int) Meal,* FROM ABC WHERE CAST(date_ofdet AS TIME) BETWEEN CAST('11:00:00' AS TIME) AND CAST('12:00:00' AS TIME)
	                UNION
	                SELECT cast(3 as int) Meal,* FROM ABC WHERE CAST(date_ofdet AS TIME) BETWEEN CAST('13:00:00' AS TIME) AND CAST('15:00:00' AS TIME)
	                UNION
	                SELECT cast(4 as int) Meal,* FROM ABC WHERE CAST(date_ofdet AS TIME) BETWEEN CAST('16:00:00' AS TIME) AND CAST('17:00:00' AS TIME)
	                UNION
	                SELECT cast(5 as int) Meal,* FROM ABC WHERE CAST(date_ofdet AS TIME) BETWEEN CAST('19:00:00' AS TIME) AND CAST('22:00:00' AS TIME)
                )
                SELECT A.ChannelOrder_Id, A.Bill_No,A.Name_guest,B.Meal,B.date_ofdet,B.Qtymax,B.qty,B.rate, 
                (REPLACE(CONVERT(VARCHAR(20),B.date_ofdet,106),' ','-') + ' - ' + A.Name_guest) COL,
                (REPLACE(CONVERT(VARCHAR(20),A.Bdate,106),' ','-')) BDate
                FROM ChannelOrder A JOIN DEF B ON A.ChannelOrder_Id = B.ChannelOrder_Id
                ORDER BY B.date_ofdet;";

                DataTable dtSqlData = objMaster.GetDataTableData(sqlQuery, "ChannelOrderChart");
                if (dtSqlData != null)
                {
                    for (int i = 0; i < dtSqlData.Rows.Count; i++)
                    {
                        string columnName = dtSqlData.Rows[i]["COL"].ToString();
                        System.Text.StringBuilder columnValue = new System.Text.StringBuilder();
                            
                        if(!DBNull.Value.Equals(dtSqlData.Rows[i]["Bill_No"])) 
                        {
                            columnValue.Append("Order No: ");
                            columnValue.Append(dtSqlData.Rows[i]["Bill_No"].ToString());
                            columnValue.Append("\t");
                        }
                        if(!DBNull.Value.Equals(dtSqlData.Rows[i]["BDate"])) 
                        {
                            columnValue.Append("Dated ");
                            columnValue.Append(dtSqlData.Rows[i]["BDate"].ToString());
                        }
                        if(!DBNull.Value.Equals(dtSqlData.Rows[i]["Qtymax"])) 
                        {
                            columnValue.Append("\nMaximum: ");
                            columnValue.Append(dtSqlData.Rows[i]["Qtymax"].ToString());
                        }
                        if(!DBNull.Value.Equals(dtSqlData.Rows[i]["qty"])) 
                        {
                            columnValue.Append("\nMinimum: ");
                            columnValue.Append(dtSqlData.Rows[i]["qty"].ToString());
                        }
                        if(!DBNull.Value.Equals(dtSqlData.Rows[i]["rate"])) 
                        {
                            columnValue.Append(System.Environment.NewLine);
                            columnValue.Append("Rate: ");
                            columnValue.Append(dtSqlData.Rows[i]["rate"].ToString());
                        }
                        
                        if (!dtChannelOrder.Columns.Contains(columnName))
                            dtChannelOrder.Columns.Add(columnName);

                        if (Convert.ToInt32(dtSqlData.Rows[i]["Meal"]) == 1)
                        {
                            dtChannelOrder.Rows[0][columnName] = columnValue.ToString();
                        }
                        else if (Convert.ToInt32(dtSqlData.Rows[i]["Meal"]) == 2)
                        {
                            dtChannelOrder.Rows[1][columnName] = columnValue.ToString();
                        }
                        else if (Convert.ToInt32(dtSqlData.Rows[i]["Meal"]) == 3)
                        {
                            dtChannelOrder.Rows[2][columnName] = columnValue.ToString();
                        }
                        else if (Convert.ToInt32(dtSqlData.Rows[i]["Meal"]) == 4)
                        {
                            dtChannelOrder.Rows[3][columnName] = columnValue.ToString();
                        }
                        else if (Convert.ToInt32(dtSqlData.Rows[i]["Meal"]) == 5)
                        {
                            dtChannelOrder.Rows[4][columnName] = columnValue.ToString();
                        }
                        dtChannelOrder.Rows[5][columnName] = !DBNull.Value.Equals(dtSqlData.Rows[i]["Bill_No"]) ? (dtSqlData.Rows[i]["Bill_No"]).ToString() : string.Empty;
                        dtChannelOrder.Rows[6][columnName] = Convert.ToInt32(dtSqlData.Rows[i]["ChannelOrder_Id"]);
                    }
                }

                foreach (DataGridViewColumn dtCol in dataGridView1.Columns)
                {
                    dtCol.HeaderCell.Style.BackColor = System.Drawing.Color.Gray;
                    dtCol.SortMode = DataGridViewColumnSortMode.NotSortable;
                }   

                dataGridView1.DataSource = dtChannelOrder;
                dataGridView1.Columns[0].Frozen = true;
                dataGridView1.Rows[6].Visible = false;
	        }
	        catch (Exception ex)
	        {
		        ExceptionLogging.SendErrorToText(ex, "GetDataForGrid");
	        }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GetDataForGrid();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > 0 && e.RowIndex > -1)
            {
                string currCell = Convert.ToString(dtChannelOrder.Rows[e.RowIndex][e.ColumnIndex]);
                if (!string.IsNullOrEmpty(currCell))
                {
                    int chanlorderid = Convert.ToInt32(dtChannelOrder.Rows[6][e.ColumnIndex]);
                    using (frmCateringOrder frmcatorder = new frmCateringOrder())
                    {
                        frmcatorder.channelorderchartId = chanlorderid;
                        frmcatorder.ShowDialog();
                    }
                }
            }
        }
    }
}
