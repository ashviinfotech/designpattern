﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Order
{
    public partial class frmAccountWiseSales : Form
    {
        MasterCaller masterCaller = new MasterCaller();
        ISIPMEntities dbContext { get; set; }
        string constring { get; set; }

        public frmAccountWiseSales()
        {
            using (dbContext = new ISIPMEntities())
                constring = dbContext.Database.Connection.ConnectionString;
            InitializeComponent();
        }

        private void frmChannelBill_Load(object sender, EventArgs e)
        {
            dbContext = new ISIPMEntities();
            BindAccount();
            tabControl1.SelectedTab = tabSummarized;
        }

        private void BindAccount()
        {
            IList<ORDER> lstAccount = null;
            if ((chkCreditAccount.Checked && chkStaffAcount.Checked) || (!chkCreditAccount.Checked && !chkStaffAcount.Checked))
                lstAccount = dbContext.ORDERs.OrderBy(x => x.PARNAM).ToList();
            else if (chkCreditAccount.Checked && !chkStaffAcount.Checked)
                lstAccount = dbContext.ORDERs.OrderBy(x => x.PARNAM).ToList();
            else if (!chkCreditAccount.Checked && chkStaffAcount.Checked)
                lstAccount = dbContext.ORDERs.OrderBy(x => x.PARNAM).ToList();
            
            lstGLAccounts.DataSource = lstAccount;
            lstGLAccounts.ValueMember = "ORDID";
            lstGLAccounts.DisplayMember = "PARNAM";
        }

        private void chkStaffAcount_CheckedChanged(object sender, EventArgs e)
        {
            BindAccount();
        }

        private void chkAllPending_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAllPending.Checked)
            {
                dtmFrom.Enabled = false;
                dtmTo.Enabled = false;
            }
            else
            {
                dtmFrom.Enabled = true;
                dtmTo.Enabled = true;
            }
        }   

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();
                string str1, str2;

                if (chkAllPending.Checked)
                {
                    str1 = @"Select KOT_ID,KOT_No,KotBookNo,Kdate,Ktime,(Amount-taxed_Amount) Amount,taxed_Amount [SrvChrg],
                        (CASE WHEN delivery_status=1 THEN ServTaxAmt ELSE 0 END) GST,Disc_amt DiscAmt,NetTotal,createdby,mod_of_bill_desc
                        from Kot where OrdNo='#" + lstGLAccounts.SelectedValue + "' and ISNULL(KOT.cHANNELbILLNO,0) = 0 AND ISNULL(activate_delete,0) = 0 AND ISNULL(KOTCANCEL,0) = 0";

                    str2 = @"SELECT M.Food_Id,M.Food_code,M.Food_Name,T.Quantity,T.Amount,T.tax_amt [SrvChrg],T.vatamount GST,T.NetAmount
                        FROM (select B.Food_Id,SUM(B.Quantity) Quantity,SUM(B.Quantity * B.Price) Amount,SUM(tax_amt) tax_amt, 
                        SUM(CASE WHEN B.comp_itm = 1 THEN B.vatamount ELSE 0 END) vatamount, SUM((CASE WHEN B.comp_itm = 1 THEN B.vatamount ELSE 0 END) + B.Amount) NetAmount
                        FROM KOT A JOIN KOT_details B ON A.KOT_ID=B.KOT_ID WHERE A.OrdNo='#" + lstGLAccounts.SelectedValue.ToString() + @"' 
                        AND ISNULL(A.cHANNELbILLNO,0) = 0 AND ISNULL(activate_delete,0) = 0 AND ISNULL(KOTCANCEL,0) = 0  GROUP BY B.Food_Id) T
                        JOIN MENU M ON T.Food_Id=M.Food_Id ORDER BY OrderBased DESC,Food_Name";
                }
                else
                {
                    DateTime dtFrom = dtmFrom.Value;
                    DateTime dtTo = dtmTo.Value;

                    str1 = @"Select KOT_ID,KOT_No,KotBookNo,Kdate,Ktime,(Amount-taxed_Amount) Amount,taxed_Amount [SrvChrg],
                        (CASE WHEN delivery_status=1 THEN ServTaxAmt ELSE 0 END) GST,Disc_amt [DiscAmt],NetTotal,createdby,mod_of_bill_desc
                        FROM KOT WHERE CAST(Kdate AS DATE) BETWEEN CAST('" + dtFrom.Date.ToString("MM/dd/yyyy") + "' AS DATE) AND CAST('" + dtTo.Date.ToString("MM/dd/yyyy") + @"' AS DATE) 
                        AND OrdNo='#" + lstGLAccounts.SelectedValue + "' AND ISNULL(cHANNELbILLNO,0) = 0 AND ISNULL(activate_delete,0) = 0 AND ISNULL(KOTCANCEL,0) = 0";

                    str2 = @"SELECT M.Food_Id,M.Food_code,M.Food_Name,T.Quantity,T.Amount,T.tax_amt [SrvChrg],T.vatamount GST,T.NetAmount
                        FROM (select B.Food_Id,SUM(B.Quantity) Quantity,SUM(B.Quantity * B.Price) Amount,SUM(tax_amt) tax_amt, 
                        SUM(CASE WHEN B.comp_itm = 1 THEN B.vatamount ELSE 0 END) vatamount, SUM((CASE WHEN B.comp_itm = 1 THEN B.vatamount ELSE 0 END) + B.Amount) NetAmount
                        FROM KOT A JOIN KOT_details B ON A.KOT_ID=B.KOT_ID WHERE A.OrdNo='#" + lstGLAccounts.SelectedValue.ToString() + @"'
                        AND CAST(Kdate AS DATE) BETWEEN CAST('" + dtFrom.Date.ToString("MM/dd/yyyy") + "' AS DATE) AND CAST('" + dtTo.Date.ToString("MM/dd/yyyy") + @"' AS DATE) 
                        AND ISNULL(A.cHANNELbILLNO,0) = 0 AND ISNULL(activate_delete,0) = 0 AND ISNULL(KOTCANCEL,0) = 0  GROUP BY B.Food_Id) T
                        JOIN MENU M ON T.Food_Id=M.Food_Id ORDER BY OrderBased DESC,Food_Name";
                }

                ds.Tables.Add(masterCaller.GetDataTableData(str1, "KotDetails"));
                ds.Tables.Add(masterCaller.GetDataTableData(str2, "KotSummarized"));

                filltabOne(ds.Tables["KotDetails"]);
                filltabTwo(ds.Tables["KotSummarized"]);
                fillTabThree(ds.Tables["KotDetails"].Copy());
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void filltabOne(DataTable dt)
        {
            try
            {
                dt.Rows.Add(dt.NewRow());
                DataRow drOne = dt.NewRow();

                decimal amount = 0, srvchrg = 0, gst = 0, discamt = 0, netamt = 0;
                
                foreach (DataRow dr in dt.Rows)
                {
                    amount += (!DBNull.Value.Equals(dr["Amount"]) ? Convert.ToDecimal(dr["Amount"]) : 0);
                    srvchrg += (!DBNull.Value.Equals(dr["SrvChrg"]) ? Convert.ToDecimal(dr["SrvChrg"]) : 0);
                    gst += (!DBNull.Value.Equals(dr["GST"]) ? Convert.ToDecimal(dr["GST"]) : 0);
                    discamt += (!DBNull.Value.Equals(dr["DiscAmt"]) ? Convert.ToDecimal(dr["DiscAmt"]) : 0);
                    netamt += (!DBNull.Value.Equals(dr["NetTotal"]) ? Convert.ToDecimal(dr["NetTotal"]) : 0);
                }

                drOne["Amount"] = amount;
                drOne["SrvChrg"] = srvchrg;
                drOne["GST"] = gst;
                drOne["DiscAmt"] = discamt;
                drOne["NetTotal"] = netamt;
                dt.Rows.Add(drOne);

                dgvDetailed.DataSource = dt;

                dgvDetailed.Columns["KOT_ID"].Visible = false;
                dgvDetailed.Columns["Kdate"].DefaultCellStyle.Format = "dd/MMM/yyyy";
                dgvDetailed.Columns["Ktime"].DefaultCellStyle.Format = "HH:mm:ss";
                dgvDetailed.Columns["Amount"].DefaultCellStyle.Format = "0.00";
                dgvDetailed.Columns["SrvChrg"].DefaultCellStyle.Format = "0.00";
                dgvDetailed.Columns["GST"].DefaultCellStyle.Format = "0.00";
                dgvDetailed.Columns["DiscAmt"].DefaultCellStyle.Format = "0.00";
                dgvDetailed.Columns["NetTotal"].DefaultCellStyle.Format = "0.00";

                dgvDetailed.Columns["Amount"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["SrvChrg"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["GST"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["DiscAmt"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["NetTotal"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvDetailed.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["SrvChrg"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["GST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["DiscAmt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDetailed.Columns["NetTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvDetailed.Rows[dgvDetailed.Rows.Count - 1].DefaultCellStyle.BackColor = System.Drawing.Color.LimeGreen;

                dgvDetailed.ClearSelection();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void filltabTwo(DataTable dt)
        {
            try
            {
                dt.Rows.Add(dt.NewRow());
                DataRow drOne = dt.NewRow();

                decimal amount = 0, srvchrg = 0, gst = 0, qty = 0, netamt = 0;

                foreach (DataRow dr in dt.Rows)
                {
                    amount += (!DBNull.Value.Equals(dr["Amount"]) ? Convert.ToDecimal(dr["Amount"]) : 0);
                    srvchrg += (!DBNull.Value.Equals(dr["SrvChrg"]) ? Convert.ToDecimal(dr["SrvChrg"]) : 0);
                    gst += (!DBNull.Value.Equals(dr["GST"]) ? Convert.ToDecimal(dr["GST"]) : 0);
                    qty += (!DBNull.Value.Equals(dr["Quantity"]) ? Convert.ToDecimal(dr["Quantity"]) : 0);
                    netamt += (!DBNull.Value.Equals(dr["NetAmount"]) ? Convert.ToDecimal(dr["NetAmount"]) : 0);
                }

                drOne["Amount"] = amount;
                drOne["SrvChrg"] = srvchrg;
                drOne["GST"] = gst;
                drOne["Quantity"] = qty;
                drOne["NetAmount"] = netamt;
                dt.Rows.Add(drOne);

                dgvSummarized.DataSource = dt;

                dgvSummarized.Columns["Food_Id"].Visible = false;
                dgvSummarized.Columns["Amount"].DefaultCellStyle.Format = "0.00";
                dgvSummarized.Columns["SrvChrg"].DefaultCellStyle.Format = "0.00";
                dgvSummarized.Columns["GST"].DefaultCellStyle.Format = "0.00";
                dgvSummarized.Columns["NetAmount"].DefaultCellStyle.Format = "0.00";

                dgvSummarized.Columns["Amount"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["SrvChrg"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["GST"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["Quantity"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["NetAmount"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvSummarized.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["SrvChrg"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["GST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvSummarized.Columns["NetAmount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvSummarized.Rows[dgvSummarized.RowCount - 1].DefaultCellStyle.BackColor = System.Drawing.Color.LimeGreen;
                dgvSummarized.ClearSelection();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void fillTabThree(DataTable dt)
        {
            try
            {
                if (dt.Rows.Count >= 2)
                {
                    dt.Rows.RemoveAt(dt.Rows.Count - 1);
                    dt.Rows.RemoveAt(dt.Rows.Count - 1);
                    dt.AcceptChanges();
                }

                if (dgvBlling.Columns.Count > 0) dgvBlling.Columns.Clear();

                dgvBlling.Columns.Insert(0, new DataGridViewCheckBoxColumn { Name="Select", HeaderText = "Select", ReadOnly = false });
                dgvBlling.DataSource = dt;

                foreach (DataGridViewColumn col in dgvBlling.Columns)
                    if (col.Name != "Select") col.ReadOnly = true;

                dgvBlling.Columns["KOT_ID"].Visible = false;
                dgvBlling.Columns["Kdate"].DefaultCellStyle.Format = "dd/MMM/yyyy";
                dgvBlling.Columns["Ktime"].DefaultCellStyle.Format = "HH:mm:ss";
                dgvBlling.Columns["Amount"].DefaultCellStyle.Format = "0.00";
                dgvBlling.Columns["SrvChrg"].DefaultCellStyle.Format = "0.00";
                dgvBlling.Columns["GST"].DefaultCellStyle.Format = "0.00";
                dgvBlling.Columns["DiscAmt"].DefaultCellStyle.Format = "0.00";
                dgvBlling.Columns["NetTotal"].DefaultCellStyle.Format = "0.00";

                dgvBlling.Columns["Amount"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["SrvChrg"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["GST"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["DiscAmt"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["NetTotal"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvBlling.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["SrvChrg"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["GST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["DiscAmt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.Columns["NetTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvBlling.ClearSelection();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabBilling;
            foreach (DataGridViewRow grd in dgvBlling.Rows)
            {
                DataGridViewCheckBoxCell chk_Slno = (DataGridViewCheckBoxCell)grd.Cells[0];
                chk_Slno.Value = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow grd in dgvBlling.Rows)
            {
                DataGridViewCheckBoxCell chk_Slno = (DataGridViewCheckBoxCell)grd.Cells[0];
                chk_Slno.Value = false;
            }
        }

        private void btnPrepareBill_Click(object sender, EventArgs e)
        {
            try
            {
                string strKotIDS = string.Empty;

                foreach (DataGridViewRow grd in dgvBlling.Rows)
                {
                    DataGridViewCheckBoxCell chk_Slno = (DataGridViewCheckBoxCell)grd.Cells[0];
                    if (Convert.ToBoolean(chk_Slno.Value) == true) strKotIDS = strKotIDS + Convert.ToString(grd.Cells["KOT_ID"].Value) + ",";
                }

                if (strKotIDS.Length > 0)
                {
                    strKotIDS = strKotIDS.Substring(0,strKotIDS.Length - 1);
                    ChannelBILL objChannelBill = new ChannelBILL();
                    List<ChannelBillDetail> lstChannelBillDetail = new List<ChannelBillDetail>();
                    string str1 = string.Empty,str2=string.Empty;
                    DataTable dtKOt = new DataTable();
                    DataTable dtDetails = new DataTable();

                    str1 = @"Select KOT_ID,KOT_No,KotBookNo,Kdate,Ktime,(Amount-taxed_Amount) Amount,taxed_Amount [SrvChrg],
                    (CASE WHEN delivery_status=1 THEN ServTaxAmt ELSE 0 END) GST,Disc_amt DiscAmt,NetTotal,createdby,mod_of_bill_desc
                    from Kot where KOT_ID IN (" + strKotIDS+")";

                    str2 = @"SELECT M.Food_Id,M.Food_code,M.Food_Name,T.Quantity,T.Amount,T.tax_amt [SrvChrg],T.vatamount GST,T.NetAmount,m.Price
                    FROM (select B.Food_Id,SUM(B.Quantity) Quantity,SUM(B.Quantity * B.Price) Amount,SUM(tax_amt) tax_amt, 
                    SUM(CASE WHEN B.comp_itm = 1 THEN B.vatamount ELSE 0 END) vatamount, SUM((CASE WHEN B.comp_itm = 1 THEN B.vatamount ELSE 0 END) + B.Amount) NetAmount
                    FROM KOT A JOIN KOT_details B ON A.KOT_ID=B.KOT_ID WHERE A.KOT_ID IN (" + strKotIDS + @") GROUP BY B.Food_Id) T
                    JOIN MENU M ON T.Food_Id=M.Food_Id ORDER BY OrderBased DESC,Food_Name";

                    dtKOt = masterCaller.GetDataTableData(str1, "KOT");
                    dtDetails = masterCaller.GetDataTableData(str2, "KOTDetails");

                    //using(SqlHelperClass objSql = new SqlHelperClass(constring))
                    //{
                    //    dtKOt = objSql.GetDatatableFormQuery(str1,"KOT");
                    //    dtDetails = objSql.GetDatatableFormQuery(str2,"KOTDetails");
                    //}

                    int ordno = Convert.ToInt32(lstGLAccounts.SelectedValue);

                    ORDER objCust = dbContext.ORDERs.FirstOrDefault(x => x.ORDID == ordno);

                    string add3guest = string.Empty;
                    if (!string.IsNullOrEmpty(objCust.CSTNO)) add3guest += "GST No. : " + objCust.CSTNO + " ";
                    if (!string.IsNullOrEmpty(objCust.PARPIN)) add3guest += "PAN No. : " + objCust.PARPIN + " ";
                    if (!string.IsNullOrEmpty(objCust.PARADD2)) add3guest += objCust.PARADD2;

                    objChannelBill.ChannelBill_Id = 0;
                    objChannelBill.Name_guest = objCust.PARNAM;
                    objChannelBill.addr1_guest = objCust.PARADD;
                    objChannelBill.addr2_guest = objCust.PARADD1;
                    objChannelBill.addr3_guest = add3guest;
                    objChannelBill.Name_billto = string.Empty;
                    objChannelBill.addr1_billto = string.Empty;
                    objChannelBill.addr2_billto = string.Empty;
                    objChannelBill.addr3_billto = string.Empty;
                    objChannelBill.GAccountCode = objCust.ORDNO;
                    objChannelBill.GAccountname = objCust.PARNAM;

                    objChannelBill.schargeamt = 0;
                    objChannelBill.totalamt = 0;
                    objChannelBill.grandtotalamt = 0;
                    objChannelBill.discountamt = 0;
                    objChannelBill.totallaundary =0;
                    objChannelBill.VATamt = 0;
                    objChannelBill.VATamt1 = 0;
                    objChannelBill.totalroomrent = 0;

                    foreach (DataRow dr in dtKOt.Rows)
                    {
                        objChannelBill.schargeamt += (!DBNull.Value.Equals(dr["SrvChrg"]) ? Convert.ToDouble(dr["SrvChrg"]) : 0);
                        objChannelBill.totalamt += (!DBNull.Value.Equals(dr["Amount"]) ? Convert.ToDouble(dr["Amount"]) : 0);
                        objChannelBill.grandtotalamt += (!DBNull.Value.Equals(dr["NetTotal"]) ? Convert.ToDouble(dr["NetTotal"]) : 0);
                        objChannelBill.discountamt += (!DBNull.Value.Equals(dr["DiscAmt"]) ? Convert.ToDouble(dr["DiscAmt"]) : 0);
                        objChannelBill.totallaundary += (!DBNull.Value.Equals(dr["GST"]) ? Convert.ToDouble(dr["GST"]) / 2 : 0);
                        objChannelBill.VATamt += (!DBNull.Value.Equals(dr["GST"]) ? Convert.ToDouble(dr["GST"]) / 2 : 0);
                        objChannelBill.VATamt1 += (!DBNull.Value.Equals(dr["GST"]) ? Convert.ToDouble(dr["GST"]) / 2 : 0);
                        objChannelBill.KOTIDS += (!DBNull.Value.Equals(dr["KOT_ID"]) ? Convert.ToString(dr["KOT_ID"]) + "," : string.Empty);
                        objChannelBill.BILLDETAILS += (!DBNull.Value.Equals(dr["KOT_No"]) ? Convert.ToString(dr["KOT_No"]) + " " : string.Empty);
                        objChannelBill.BILLDETAILS += (!DBNull.Value.Equals(dr["Kdate"]) ? "(" + Convert.ToDateTime(dr["Kdate"]).ToString("dd/MMM/yyyy") + ")/ " : string.Empty);
                    }

                    if (objChannelBill.BILLDETAILS.Length > 1) objChannelBill.BILLDETAILS = objChannelBill.BILLDETAILS.Trim().Substring(0,objChannelBill.BILLDETAILS.Trim().Length - 1);
                    if (objChannelBill.KOTIDS.Length > 1) objChannelBill.KOTIDS = objChannelBill.KOTIDS.Trim().Substring(0,objChannelBill.KOTIDS.Trim().Length - 1);

                    objChannelBill.netpayable = Convert.ToDouble(Convert.ToInt32(objChannelBill.grandtotalamt));
                    objChannelBill.roundoff = Convert.ToDouble(objChannelBill.netpayable - objChannelBill.grandtotalamt);
                    objChannelBill.totaltelephone = objChannelBill.totalamt;
                    objChannelBill.totalminibar = objChannelBill.schargeamt;
                    objChannelBill.billroomtype = 1;

                    objChannelBill.schargerate=0;
                    objChannelBill.luxurytaxrate =0;
                    objChannelBill.luxurytaxamt=0;
                    objChannelBill.salestaxrate=0;
                    objChannelBill.salestaxamt=0;
                    objChannelBill.roomserviceamt=0;
                    objChannelBill.discountrate=0;
                    objChannelBill.advancerecd=0;                    
                    objChannelBill.description_b = string.Empty;
                    objChannelBill.activate_delete = false;                    
                    //---objChannelBill.totalroomrent 
                    objChannelBill.totalkitchen=0;                    
                    objChannelBill.totalextrabed=0;
                    objChannelBill.totalMiscCharges=0;                    
                    objChannelBill.billtochk = false;
                    objChannelBill.BillcreationType=0;
                    objChannelBill.transportamt=0;
                    objChannelBill.MISCIDS = string.Empty;
                    objChannelBill.orderformno = string.Empty;
                    //objChannelBill.servicetaxamt = 0;

                    foreach (DataRow dr in dtDetails.Rows)
                    {
                        ChannelBillDetail objChannelBillDetail = new ChannelBillDetail
                        {
                            roomno = (!DBNull.Value.Equals(dr["Food_Name"]) ? Convert.ToString(dr["Food_Name"]) : string.Empty),
                            KOT_misc = 1,
                            Kot_Misc_expID = (!DBNull.Value.Equals(dr["Food_Id"]) ? Convert.ToInt32(dr["Food_Id"]) : 0),
                            date_ofdet = DateTime.Now.Date,
                            roomserv_kitch_amt = (!DBNull.Value.Equals(dr["Price"]) ? Convert.ToDouble(dr["Price"]) : 0),
                            roomrent_amt = (!DBNull.Value.Equals(dr["Quantity"]) ? Convert.ToDouble(dr["Quantity"]) : 0),
                            laundary_amt = (!DBNull.Value.Equals(dr["SrvChrg"]) ? Convert.ToDouble(dr["SrvChrg"]) : 0),
                            total_amt_amt = (!DBNull.Value.Equals(dr["Amount"]) ? Convert.ToDouble(dr["Amount"]) : 0),
                            males = 1,
                            minibar = (!DBNull.Value.Equals(dr["GST"]) ? Convert.ToDouble(dr["GST"]) / 2 : 0),
                            //minibar1 = (!DBNull.Value.Equals(dr["GST"]) ? Convert.ToDouble(dr["GST"]) / 2 : 0)
                        };
                        lstChannelBillDetail.Add(objChannelBillDetail);
                        objChannelBill.totalroomrent = objChannelBill.totalroomrent + objChannelBillDetail.roomrent_amt;
                    }

                    if (objChannelBill != null && lstChannelBillDetail.Count > 0)
                    {
                        this.Hide();
                        //using (frmChannelBill objChannel = new frmChannelBill())
                        //{
                        //    objChannel.objChannelBill = objChannelBill;
                        //    //objChannel.objChannelBill.ChannelBillDetails = lstChannelBillDetail;
                        //    objChannel.lstChannelBillDetail = lstChannelBillDetail;
                        //    objChannel.ShowDialog();
                        //}
                        //this.Close();
                    }
                }
                else
                    CustomMessageBox.ShowExclamationMessage("Please prepare a bill of selected GL Account", ""); 
                               
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
