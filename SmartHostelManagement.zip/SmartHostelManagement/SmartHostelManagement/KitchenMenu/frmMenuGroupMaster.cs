﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmMenuGroupMaster : Form
    {
        ISIPMEntities dbContext = new ISIPMEntities();
        int menugroupid { get; set; }

        IList<DBData.Menu> lstMenu { get; set; }
        List<DBData.Menu> lstNewMenu { get; set; }
        MENUGROUPMASTER objMenuGroupMaster { get; set; }

        public frmMenuGroupMaster()
        {
            InitializeComponent();
        }

        private void frmMenuGroupMaster_Load(object sender, EventArgs e)
        {
            BindFirstChecklist();
        }

        private void BindFirstChecklist()
        {
            try
            {
                lstMenu = dbContext.Menus.Where(m => m.channelid == 5 && m.DisplayinKOT == 1 ).OrderBy(x=>x.Food_Name).ToList();
                string menuItem = string.Empty;
                foreach (DBData.Menu objMenu in lstMenu)
                {
                    menuItem = objMenu.Food_code + objMenu.Food_Name; 
                    checkedListBox1.Items.Add(objMenu.Food_Name);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnForward_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstNewMenu == null) lstNewMenu = new List<DBData.Menu>();
                checkedListBox2.Items.Clear();

                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {
                    if (checkedListBox1.GetItemChecked(i))
                    {   
                        lstNewMenu.Add(lstMenu[i]);
                        checkedListBox1.SetItemChecked(i, false);
                    }
                }

                foreach (DBData.Menu objMenu in lstNewMenu)
                    checkedListBox2.Items.Add(objMenu.Food_code + objMenu.Food_Name);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnForward_Click");
            }
        }

        private void btnBackward_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < checkedListBox2.Items.Count; i++)
                {
                    if (checkedListBox2.GetItemChecked(i))
                    {
                        lstNewMenu.RemoveAt(i);
                    }
                }
                checkedListBox2.Items.Clear();

                foreach (DBData.Menu objMenu in lstNewMenu)
                    checkedListBox2.Items.Add(objMenu.Food_code + objMenu.Food_Name);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnBackward_Click");
            }
        }

        private void txtGroupCode_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtGroupCode.Text.Trim()))
            {
                if (dbContext.MENUGROUPMASTERs.Any(x => x.MENUGROUPno.ToUpper() == txtGroupCode.Text.Trim()))
                {
                    CustomMessageBox.ShowInformationMessage("Code Already exists !!", "");
                    txtGroupCode.Text = string.Empty;
                    txtGroupCode.Focus();
                }
            }
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                checkedListBox1.SetItemChecked(i, false);
            this.menugroupid = 0;
            objMenuGroupMaster = null;
            txtGroupCode.Text = string.Empty;
            txtGroupName.Text = string.Empty;
            lstNewMenu = new List<DBData.Menu>();
            checkedListBox2.Items.Clear();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidatePageData())
                {
                    if (objMenuGroupMaster != null)
                    {
                        objMenuGroupMaster.MENUGROUPno = txtGroupCode.Text;
                        objMenuGroupMaster.MENUGROUPname = txtGroupName.Text;
                        objMenuGroupMaster.id1 = Frm_Login.UserLogin.log_id;
                        objMenuGroupMaster.date_of_mod = DateTime.Now;
                    }
                    else
                    {
                        menugroupid = dbContext.MENUGROUPMASTERs.Any() ? dbContext.MENUGROUPMASTERs.Max(x => x.MENUGROUP_id) + 1 : 1;

                        objMenuGroupMaster = new MENUGROUPMASTER
                        {
                            MENUGROUP_id = menugroupid,
                            MENUGROUPno = txtGroupCode.Text,
                            MENUGROUPname = txtGroupName.Text,
                            id = Frm_Login.UserLogin.log_id,
                            date_of_add = DateTime.Now
                        };
                        dbContext.MENUGROUPMASTERs.Add(objMenuGroupMaster);
                    }
                    if (lstNewMenu == null) lstNewMenu = new List<DBData.Menu>();
                    List<MENUGROUPMASTERDETAIL> lstMenuDet = objMenuGroupMaster.MENUGROUPMASTERDETAILs.ToList();
                    foreach (MENUGROUPMASTERDETAIL objMenuDet in lstMenuDet)
                    {
                        if (!lstNewMenu.Any(x => x.Food_Id == objMenuDet.Food_Id))
                            dbContext.MENUGROUPMASTERDETAILs.Remove(objMenuDet);
                    }

                    int menudroupdetid = dbContext.MENUGROUPMASTERDETAILs.Any() ? dbContext.MENUGROUPMASTERDETAILs.Max(x => x.MENUGROUPDET_ID) : 0;

                    foreach(DBData.Menu objMenu in lstNewMenu)
                    {
                        if (!this.objMenuGroupMaster.MENUGROUPMASTERDETAILs.Any(x => x.Food_Id == objMenu.Food_Id))
                        {
                            menudroupdetid++;
                            dbContext.MENUGROUPMASTERDETAILs.Add(new MENUGROUPMASTERDETAIL 
                            {
                                MENUGROUPDET_ID = menudroupdetid,
                                MENUGROUP_id = menugroupid,
                                Food_Id = objMenu.Food_Id
                            });
                        }
                    }

                    if (dbContext.SaveChanges() > 0)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Saved", "");
                    }
                    else
                        CustomMessageBox.ShowInformationMessage("Record not Saved", "");

                    btnReferesh_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private bool ValidatePageData()
        {
            if (string.IsNullOrEmpty(txtGroupCode.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please enter Menu group code", "");
                txtGroupCode.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtGroupName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please enter Menu group code", "");
                txtGroupName.Focus();
                return false;
            }
            //else if (lstNewMenu == null || lstNewMenu.Count == 0)
            //{
            //    CustomMessageBox.ShowInformationMessage("Please Add items in menu items.", "");
            //    return false;
            //}
            else
                return true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (frmSearchMenuGroup objMenuS = new frmSearchMenuGroup())
            {
                objMenuS.menumaster = true;
                objMenuS.ShowDialog();
                if (objMenuS.menugroupid > 0)
                {
                    btnReferesh_Click(sender, e);
                    this.menugroupid = objMenuS.menugroupid;
                    objMenuGroupMaster = dbContext.MENUGROUPMASTERs.FirstOrDefault(x => x.MENUGROUP_id == this.menugroupid);
                    populatePageData();
                }
            }
        }

        private void populatePageData()
        {
            try
            {
                if (this.objMenuGroupMaster != null)
                {
                    txtGroupCode.Text = objMenuGroupMaster.MENUGROUPno;
                    txtGroupName.Text = objMenuGroupMaster.MENUGROUPname;

                    IList<MENUGROUPMASTERDETAIL> lstMenuGrpDetail = objMenuGroupMaster.MENUGROUPMASTERDETAILs.ToList();
                    foreach (MENUGROUPMASTERDETAIL objMgd in lstMenuGrpDetail)
                    {
                        if (lstMenu.Any(x => x.Food_Id == objMgd.Food_Id))
                        {
                            var localMen = lstMenu.FirstOrDefault(x => x.Food_Id == objMgd.Food_Id);

                            lstNewMenu.Add(localMen);
                            checkedListBox2.Items.Add(localMen.Food_Name);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (menugroupid > 0 && CustomMessageBox.ShowDialogBoxMessage("Delete this Menu Group item ?") 
                    == System.Windows.Forms.DialogResult.Yes)
                { 
                    foreach(MENUGROUPMASTERDETAIL objMenDet in dbContext.MENUGROUPMASTERDETAILs.Where(x=>x.MENUGROUP_id == menugroupid))
                        dbContext.MENUGROUPMASTERDETAILs.Remove(objMenDet);

                    dbContext.MENUGROUPMASTERs.Remove(dbContext.MENUGROUPMASTERs.FirstOrDefault(x => x.MENUGROUP_id == menugroupid));

                    if (dbContext.SaveChanges() > 0)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Deleted !!!", "");
                        dbContext = new ISIPMEntities();
                        btnReferesh_Click(null, null);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
