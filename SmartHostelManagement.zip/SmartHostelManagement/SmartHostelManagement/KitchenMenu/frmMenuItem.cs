﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmMenuItem : Form
    {
        ISIPMEntities dbContext = new ISIPMEntities();
        public int channelid = 0;
        public string channelname = string.Empty;
        int foodid { get; set; }

        public frmMenuItem()
        {
            InitializeComponent();
        }

        private void frmMenuItem_Load(object sender, EventArgs e)
        {
            Dictionary<int, string> dicData = new Dictionary<int,string>();
            dicData.Add(channelid, channelname);
            cmbChannel.DataSource = dicData.ToList();
            cmbChannel.ValueMember = "key";
            cmbChannel.DisplayMember = "value";
            cmbChannel.SelectedIndex = 0;
            ResetPageData();
        }

        private void ResetPageData()
        {
            this.foodid = 0;
            txtFoodCode.Text = string.Empty;
            txtFoodName.Text = string.Empty;
            txtPrice.Text = "0.00";
            txtServiceChrg.Text = "0.00";
            txtVATGst.Text = "0.00";
            txtUnit.Text = "1";
            chkBasedConsump.Checked = false;
            chkDeativate.Checked = false;
            chkNotInKot.Checked = false;
        }

        private void populatePageData(DBData.Menu objMenu)
        {
            if (objMenu != null)
            {
                this.foodid = objMenu.Food_Id;
                txtFoodCode.Text = objMenu.Food_code;
                txtFoodName.Text = objMenu.Food_Name;
                txtPrice.Text = objMenu.Price.HasValue ? objMenu.Price.Value.ToString("0.00") : "0.00";
                txtServiceChrg.Text = objMenu.Tax.HasValue ? objMenu.Tax.Value.ToString("0.00") : "0.00";
                txtVATGst.Text = objMenu.vatpercent.HasValue ? objMenu.vatpercent.Value.ToString("0.00") : "0.00";
                txtUnit.Text = objMenu.Unit.HasValue ? objMenu.Unit.Value.ToString("0") : "0";
                chkBasedConsump.Checked = objMenu.OrderBased.HasValue ? (objMenu.OrderBased.Value == 1 ? true : false) : false;
                chkNotInKot.Checked = objMenu.DisplayinKOT.HasValue ? (objMenu.DisplayinKOT.Value == 1 ? true : false) : false;
                chkDeativate.Checked = objMenu.Deactivate.HasValue ? (objMenu.Deactivate.Value == 1 ? true : false) : false;
            }
        }

        private void cmbChannel_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 2);
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            ResetPageData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtFoodCode.Text.Trim()))
                {
                    if (!string.IsNullOrEmpty(txtFoodName.Text.Trim()))
                    {
                        DBData.Menu objMenu = dbContext.Menus.FirstOrDefault(x => x.Food_Id == this.foodid);
                        bool newEntry = false;

                        if (objMenu != null)
                        {
                            objMenu.id1 = Frm_Login.UserLogin.log_id;
                            objMenu.date_of_mod = DateTime.Now;
                        }
                        else
                        {
                            objMenu = new DBData.Menu();
                            newEntry = true;
                            objMenu.channelid = channelid;
                            objMenu.id = Frm_Login.UserLogin.log_id;
                            objMenu.date_of_add = DateTime.Now;
                        }

                        objMenu.Food_code = txtFoodCode.Text;
                        objMenu.Food_Name = txtFoodName.Text;
                        objMenu.Price = !string.IsNullOrEmpty(txtPrice.Text) ? Convert.ToDecimal(txtPrice.Text) : 0;
                        objMenu.Tax = !string.IsNullOrEmpty(txtServiceChrg.Text) ? Convert.ToDouble(txtServiceChrg.Text) : 0;
                        objMenu.Unit = !string.IsNullOrEmpty(txtUnit.Text) ? Convert.ToDouble(txtUnit.Text) : 0;                        
                        objMenu.vatpercent = !string.IsNullOrEmpty(txtVATGst.Text) ? Convert.ToDouble(txtVATGst.Text) : 0;
                        objMenu.Deactivate = chkDeativate.Checked ? 1 : 0;
                        if (chkDeativate.Checked)
                            objMenu.DateDeactivate = DateTime.Now;
                        else
                            objMenu.DateDeactivate = null;
                        objMenu.OrderBased = chkBasedConsump.Checked ? 1 : 0;
                        objMenu.DisplayinKOT = chkNotInKot.Checked ? 1 : 0;

                        if (newEntry) dbContext.Menus.Add(objMenu);

                        dbContext.SaveChanges();

                        CustomMessageBox.ShowInformationMessage("Recorded Save !!!", "");
                        btnReferesh_Click(null, null);
                    }
                    else
                    {
                        CustomMessageBox.ShowInformationMessage("Please Enter Food Name", "");
                        txtFoodName.Focus();
                    }
                }
                else
                {
                    CustomMessageBox.ShowHandMessage("Please Enter Food Code", "");
                    txtFoodCode.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnSave_Click");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (frmMenuSearch objMenuS = new frmMenuSearch())
            {
                objMenuS.channelId = channelid;
                objMenuS.ShowDialog();
                if (objMenuS.foodid > 0)
                {
                    this.foodid = objMenuS.foodid;
                    populatePageData(dbContext.Menus.FirstOrDefault(x => x.Food_Id == this.foodid));
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DBData.Menu objMenu = dbContext.Menus.FirstOrDefault(x => x.Food_Id == foodid);
                if (objMenu != null)
                {
                    dbContext.Menus.Remove(objMenu);
                    dbContext.SaveChanges();
                    dbContext = new ISIPMEntities();
                    CustomMessageBox.ShowInformationMessage("Recorded Delete !!","");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
            btnReferesh_Click(null, null);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void txtFoodCode_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFoodCode.Text.Trim()))
            {
                if (dbContext.Menus.Any(x => x.Food_code.ToUpper() == txtFoodCode.Text.ToUpper()))
                {
                    CustomMessageBox.ShowHandMessage("Food Code Exist", "");
                    txtFoodCode.Text = string.Empty;
                    txtFoodCode.Focus();
                }
            }
        }
    }
}
