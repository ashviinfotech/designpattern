﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmGLCreateAcc : Form
    {
        ISIPMEntities dbContext = new ISIPMEntities();
        SMH.Entities.Layer.login objLogin = Frm_Login.UserLogin;

        ORDER objOrder { get; set; }
        public int orderNo { get; set; }

        public frmGLCreateAcc()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textBox1.Text))
                {
                    if (objOrder != null)
                    {
                        objOrder.PARNAM = textBox1.Text;
                        objOrder.AccStaff = chkStaffAcc.Checked;
                        objOrder.CHRGST = chkSCFreeAcc.Checked;
                        objOrder.PARADD = txtAddress.Text;
                        objOrder.PARADD1 = txtPerson.Text;
                        objOrder.PARADD2 = txtTelephone.Text;
                        objOrder.PARPIN = txtPanNo.Text;
                        objOrder.CSTNO = txtGstNo.Text;
                    }
                    else
                    {
                        objOrder = new ORDER();
                        int maxordrid = dbContext.ORDERs.Max(x => x.ORDID);
                        objOrder.ORDID = maxordrid + 1;
                        objOrder.ORDNO = "#" + objOrder.ORDID;
                        objOrder.GCODE = "C6";
                        objOrder.PARNAM = textBox1.Text;
                        objOrder.AccStaff = chkStaffAcc.Checked;
                        objOrder.CHRGST = chkSCFreeAcc.Checked;
                        objOrder.PARADD = txtAddress.Text;
                        objOrder.PARADD1 = txtPerson.Text;
                        objOrder.PARADD2 = txtTelephone.Text;
                        objOrder.PARPIN = txtPanNo.Text;
                        objOrder.CSTNO = txtGstNo.Text;
                        dbContext.ORDERs.Add(objOrder);
                    }

                    if (dbContext.SaveChanges() > 0)
                    {
                        CustomMessageBox.ShowInformationMessage("Record save", "");
                        textBox1.Text = string.Empty;
                        chkStaffAcc.Checked = false;
                        chkSCFreeAcc.Checked = false;
                    }
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please enter name","");
                    textBox1.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmGLCreateAcc_Load(object sender, EventArgs e)
        {
            if (this.orderNo > 0)
            {
                objOrder = dbContext.ORDERs.FirstOrDefault(x => x.ORDID == this.orderNo);
                if (objOrder != null)
                {
                    textBox1.Text = objOrder.PARNAM;
                    txtAddress.Text = objOrder.PARADD;
                    txtPerson.Text = objOrder.PARADD1;
                    txtTelephone.Text = objOrder.PARADD2;
                    txtGstNo.Text = objOrder.CSTNO;
                    txtPanNo.Text = objOrder.PARPIN;
                    chkSCFreeAcc.Checked = objOrder.CHRGST.HasValue ? objOrder.CHRGST.Value : false;
                    chkStaffAcc.Checked = objOrder.CHRGST.HasValue ? objOrder.CHRGST.Value : false;
                }
            }
        }
    }
}
