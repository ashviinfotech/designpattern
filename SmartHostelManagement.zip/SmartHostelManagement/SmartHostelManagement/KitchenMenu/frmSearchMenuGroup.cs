﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using DB = SmartHostelManagement.DBData;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmSearchMenuGroup : Form
    {
        public int menugroupid = 0;

        public bool menumaster { get; set; }

        public frmSearchMenuGroup()
        {
            InitializeComponent();
        }

        private void frmSearchMenuGroup_Load(object sender, EventArgs e)
        {
            loadPageData();
        }

        private void txtFoodCode_KeyUp(object sender, KeyEventArgs e)
        {
            loadPageData();
        }

        private void loadPageData()
        {
            try
            {
                SMH.BusinessLogic.Layer.MasterCaller objMaster = new SMH.BusinessLogic.Layer.MasterCaller();
                string sqlQuery = string.Empty;
                if (menumaster)
                {
                    sqlQuery = @"SELECT ROW_NUMBER() OVER (ORDER BY MENUGROUPno) SLNo,MENUGROUP_id,
                            MENUGROUPno as [Menu Code],MENUGROUPname [Menu Name] FROM MENUGROUPMASTER ";
                }
                else
                {
                    sqlQuery = @"SELECT ROW_NUMBER() OVER (ORDER BY Buffetno) SLNo,Buffet_id,
                            Buffetno as [Buffet Code],Buffetname [Buffet Name] FROM BuffetMaster ";
                }

                if (!string.IsNullOrEmpty(txtMenuCode.Text.Trim()))
                    if (menumaster)
                        sqlQuery += " WHERE MENUGROUPno like '%" + txtMenuCode.Text.Trim() + "%'";
                    else
                        sqlQuery += " WHERE Buffetno like '%" + txtMenuCode.Text.Trim() + "%'";

                DataTable dt = objMaster.GetDataTableData(sqlQuery, "Menus");

                DataView dv = dt.AsDataView();
                dv.Sort = menumaster ? "[Menu Code] asc" : "[Buffet Code] asc";

                dgSearch.DataSource = dv.ToTable();
                if (menumaster)
                {
                    dgSearch.Columns["MENUGROUP_id"].Visible = false;

                    dgSearch.Columns["SLNo"].Width = 50;
                    dgSearch.Columns["Menu Code"].Width = 250;
                    dgSearch.Columns["Menu Name"].Width = 250;
                }
                else
                {
                    dgSearch.Columns["Buffet_id"].Visible = false;

                    dgSearch.Columns["SLNo"].Width = 50;
                    dgSearch.Columns["Buffet Code"].Width = 250;
                    dgSearch.Columns["Buffet Name"].Width = 250;
                }
                dgSearch.Columns["SLNo"].HeaderText = "Sl.No.";
                dgSearch.ClearSelection();                
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in loadPageData");
            }
        }

        private void dgSearch_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (menumaster && int.TryParse(dgSearch.Rows[e.RowIndex].Cells["MENUGROUP_id"].Value.ToString(), out menugroupid))
                {
                    this.Close();
                }
                else if (!menumaster && int.TryParse(dgSearch.Rows[e.RowIndex].Cells["Buffet_id"].Value.ToString(), out menugroupid))
                    this.Close();

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in dgSearch_CellDoubleClick");
            }
        }
    }
}
