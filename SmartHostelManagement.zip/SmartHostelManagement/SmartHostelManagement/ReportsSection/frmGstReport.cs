﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;
using SMH.DataAccess.Layer;
using System.Drawing;

namespace SmartHostelManagement.Reports
{
    public partial class frmGstReport : Form
    {
        MasterCaller objMstCaller = new MasterCaller();
        ExportHelper exportCaller = new ExportHelper();
        CommonVariables.ReportSection _reportName;
        string strQuery = string.Empty;
        int[] columnValue;
        DataTable dtReport = null;
        DataTable dtReport2 = null;

        public frmGstReport()
        {
            InitializeComponent();
            this.Text = "GST Report";
        }

        private void txtBillTo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void loadReportData()
        {
            try
            {
                System.Text.StringBuilder dbQuery = new System.Text.StringBuilder();
                _reportName = CommonVariables.ReportSection.ReceiptSummary;
                dbQuery.Append("DECLARE @startdate Date = CAST('" + dtmReportFrom.Value.ToString("yyyy-MM-dd") + @"' AS DATE);
                        DECLARE @enddate Date = CAST('" + dtmReportTo.Value.ToString("yyyy-MM-dd") + "' AS DATE);");
                dbQuery.Append(reportQuery());
                dtReport = objMstCaller.GetDataTableData(dbQuery.ToString(), "B2CL");
                LoadReportData(dtReport, dgvReportData);

                dbQuery.Clear();
                _reportName = CommonVariables.ReportSection.HotelCollection;
                dbQuery.Append("DECLARE @startdate Date = CAST('" + dtmReportFrom.Value.ToString("yyyy-MM-dd") + @"' AS DATE);
                        DECLARE @enddate Date = CAST('" + dtmReportTo.Value.ToString("yyyy-MM-dd") + "' AS DATE);");
                dbQuery.Append(reportQuery());
                dtReport2 = objMstCaller.GetDataTableData(dbQuery.ToString(), "HSHN");
                LoadReportData(dtReport2, dgvReport2);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Bill Statement");
            }
        }

        private void LoadReportData(DataTable dtData, DataGridView dgv)
        {
            if (columnValue != null) GetTotalCalFooter(columnValue, dtData);
            dgv.DataSource = dtData;
            foreach (DataGridViewColumn grdCol in dgv.Columns)
            {
                grdCol.SortMode = DataGridViewColumnSortMode.NotSortable;
                if (columnValue[0] != grdCol.Index && columnValue.Any(x => x == grdCol.Index))
                {
                    grdCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    grdCol.DefaultCellStyle.Format = "0.00";
                }
            }

            if (dgv.Rows.Count >= 2)
            {
                dgv.Rows[dgv.Rows.Count - 1].DefaultCellStyle.BackColor = System.Drawing.Color.Yellow;
                dgv.Rows[dgv.Rows.Count - 1].DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8, FontStyle.Bold);
            }
        }

        private string reportQuery()
        {
            if (_reportName.Equals(CommonVariables.ReportSection.ReceiptSummary))
            {
                columnValue = new int[] {0,2,5,8,9};
                return @";WITH ABC AS
                (
	                SELECT (CASE WHEN A.Room_Dormatory = 1 THEN 'R-'+CONVERT(VARCHAR, A.Bill_No) ELSE 'C-'+CONVERT(VARCHAR, A.Bill_No) END) [Invoice Number],
	                REPLACE(CONVERT(VARCHAR,A.date_of_final, 106),' ','-') [Invoice Date], CONVERT(DECIMAL(10,2),CAST((ISNULL(A.luxurytaxamt,0)+ISNULL(A.totalroomrent,0)
	                +ISNULL(A.CateringAmountTotal,0)+ISNULL(A.MiscAmountTotal,0)+ISNULL(A.CancelChargesAmountTotal,0)+ISNULL(A.DiningAmountTotal,0)+ISNULL(A.totalroomrentAM,0)
	                +ISNULL(A.totalroomrentPM,0)+ISNULL(A.CatCancelChargesAmountTotal,0)) AS INT)) [Invoice Value],(SELECT TOP 1 B.StateCode + '-' + B.StateName FROM 
	                Company_guest C LEFT JOIN GSTState B ON C.GSTSTATE_id=B.GSTSTATE_id WHERE C.GST_NO=LTRIM(RTRIM(A.RecGST_NO))) [Place Of Supply],A.hotelBill_ID, 
	                A.RecGST_NO,A.date_of_final, A.Room_Dormatory, A.Bill_No
	                FROM HotelBILL A with (nolock) WHERE Room_Dormatory IN (1,5) and a.activate_delete=0 AND CAST(A.date_of_final AS DATE) BETWEEN @startdate AND @enddate
                ), DEF AS
                (
	                SELECT A.hotelBill_ID, ISNULL(A.GSTRate,0) Rate,(ISNULL(A.roomrent_amt,0)+ISNULL(A.ExtraHrsBeforeAmt,0)+ISNULL(a.ExtraHrsAfterAmt,0)) RENT,
                    (A.GSTAmt) GSTAmt, (0) DiscAmt 
	                FROM hotelbilldetail A with (nolock) JOIN ABC ON A.hotelBill_ID=ABC.hotelBill_ID
	                UNION ALL
	                SELECT A.hotelBill_ID, 5 Rate, (A.CateringAMOUNT) RENT, (A.GSTAmt) GSTAmt, (0) DiscAmt
	                FROM HotelBill_CATERING_DETAILS A with (nolock) JOIN ABC ON A.hotelBill_ID=ABC.hotelBill_ID
	                UNION ALL
	                SELECT A.hotelBill_ID,ISNULL(A.ServTaxPerc,0) Rate, (A.AMOUNT-A.ServTaxAmt) RENT, (A.ServTaxAmt) GSTAmt, (0) DiscAmt
	                FROM Hotel_DININGRoom_details A with (nolock) JOIN ABC ON A.hotelBill_ID=ABC.hotelBill_ID   JOIN
                    KOT K ON A.KOT_Id = K.KOT_ID WHERE K.activate_delete=0 AND K.KOTCANCEL = 0
	                UNION ALL
	                SELECT A.hotelBill_ID,ISNULL(A.Servtaxrate,0) Rate, (A.AMOUNT) RENT, (A.Serctaxamt) GSTAmt, (0) DiscAmt
	                FROM HotelBill_MISC_DETAILS A with (nolock) JOIN ABC ON A.hotelBill_ID=ABC.hotelBill_ID
	                UNION ALL
	                SELECT A.hotelBill_ID,ISNULL(A.servrate,0) Rate, (A.Cancel_charges_ttl) RENT, (A.servtax) GSTAmt, (0) DiscAmt
	                FROM HotelBillCancelCharges A with (nolock) JOIN ABC ON A.hotelBill_ID=ABC.hotelBill_ID
	                UNION ALL
	                SELECT A.hotelBill_ID,ISNULL(A.servrate,0) Rate, (A.Cancel_charges_ttl) RENT, (A.servtax) GSTAmt, (0) DiscAmt
	                FROM HotelBillCatCancelDetail A with (nolock) JOIN ABC ON A.hotelBill_ID=ABC.hotelBill_ID
                ),
                FGH AS
                (
	                SELECT DEF.hotelBill_ID,(DEF.Rate) Rate, SUM(DEF.RENT) RENT, SUM(DEF.GSTAmt) GSTAmt, SUM(DEF.DiscAmt) DiscAmt 
	                FROM DEF GROUP BY DEF.hotelBill_ID, DEF.Rate
                ),
                IJK AS
                (
	                SELECT ABC.[Invoice Number],ABC.[Invoice Date],ABC.[Invoice Value],ABC.[Place Of Supply],CONVERT(DECIMAL(10,2),T.Rate) Rate,
	                CONVERT(DECIMAL(10,2),T.RENT) [Taxable Value],'' [Cess Amount], ABC.RecGST_NO [E-COMMERCE GSTIN],CONVERT(DECIMAL(10,2),T.DiscAmt) [Discount], 
	                CONVERT(DECIMAL(10,2),T.GSTAmt) [GST Amt],1 [FSR],CAST(ABC.date_of_final AS DATE) [FDATE], ABC.Bill_No [FBILL] 
	                FROM ABC JOIN FGH T ON ABC.hotelBill_ID=T.hotelBill_ID
	                UNION ALL
	                SELECT 'RK-'+CONVERT(VARCHAR, A.Kot_No) [Invoice Number], REPLACE(CONVERT(VARCHAR,A.Kdate, 106),' ','-') [Invoice Date], 
	                CAST(A.NetTotal AS DEC(10,2)) [Invoice Value], NULL [Place Of Supply], CAST(A.ServTaxPerc AS DEC(10,2)) [Rate], 
	                CAST(A.Amount AS DEC(10,2)) [Taxable Value], '' [Cess Amount],'' [E-COMMERCE GSTIN], '0.00' [Discount], 
	                CAST(A.ServTaxAmt AS DEC(10,2)) [GST Amt],2 [FSR],CAST(A.Kdate AS DATE) [FDATE], A.Kot_No [FBILL] 
	                FROM KOT A WHERE mod_of_bill = 0 and a.activate_delete=0 AND CAST(KDATE AS DATE) BETWEEN @startdate AND @enddate	
                )
                SELECT IJK.[Invoice Number],IJK.[Invoice Date],IJK.[Invoice Value],IJK.[Place Of Supply],IJK.Rate,IJK.[Taxable Value],
                IJK.[Cess Amount],IJK.[E-COMMERCE GSTIN],IJK.Discount,IJK.[GST Amt] 
                FROM IJK ORDER BY IJK.FSR,IJK.FDATE,IJK.FBILL";
            }
            else 
            {
                columnValue = new int[] { 1, 2, 3, 4, 5, 6 };

                return @";WITH HOS AS
                (
	                SELECT hotelBill_ID,Room_Dormatory from HotelBILL with (nolock) where Room_Dormatory IN (1, 5) AND HOTELBILLCANCEL=0 and activate_delete=0 AND  
	                CAST(date_of_final as date) between @startdate and @enddate
                ), 
                GHI AS
                (
	                SELECT KOT.KOT_ID, KOT.Amount, KOT.NetTotal, KOT.ServTaxAmt 
	                FROM KOT WHERE mod_of_bill=0 AND activate_delete=0 AND CAST(KDATE AS DATE) BETWEEN CAST(@startdate AS DATE) AND CAST(@enddate AS DATE)
	                UNION ALL
	                SELECT A.KOT_Id, (A.AMOUNT - A.ServTaxAmt) [Amount], A.AMOUNT [NetTotal],A.ServTaxAmt 
	                FROM Hotel_DININGRoom_details A JOIN HOS ON A.hotelBill_ID=HOS.hotelBill_ID JOIN KOT K ON A.KOT_Id=K.KOT_ID
	                WHERE K.activate_delete=0 AND K.KOTCANCEL = 0
                ),
                DEF AS
                (
	                SELECT '996311' [HSN Code],'ROOM' [Description], COUNT(1) [Total Quantity], SUM(CONVERT(Decimal(10,2),total_amt_amt)) [Total Val], 
                    SUM(CONVERT(Decimal(10,2),roomrent_amt)) [Taxable Value],SUM(CONVERT(DECIMAL(10,2),GSTAmt/2)) [Central Tax Amount], 
                    SUM(CONVERT(DECIMAL(10,2),GSTAmt/2)) [State/UT Tax Amount], '' [Cess Amount]
                    from hotelbilldetail A with (nolock) JOIN HOS on A.hotelBill_ID = HOS.hotelBill_ID AND HOS.Room_Dormatory=1
                    UNION ALL
                    SELECT '996338' [HSN Code],'ROOM DINING' [Description], COUNT(1) [Total Quantity], SUM(CONVERT(Decimal(10,2),AMOUNT)) [Total Val], 
                    SUM(CONVERT(Decimal(10,2),AMOUNT)) [Taxable Value],SUM(CONVERT(DECIMAL(10,2),ServTaxAmt/2)) [Central Tax Amount], 
                    SUM(CONVERT(DECIMAL(10,2),ServTaxAmt/2)) [State/UT Tax Amount], '' [Cess Amount]
                    from GHI A with (nolock)
                    UNION ALL
                    SELECT '997212' [HSN Code],'CONFERENCE' [Description], COUNT(1) [Total Quantity], SUM(CONVERT(Decimal(10,2),total_amt_amt)) [Total Val], 
                    SUM(CONVERT(Decimal(10,2),ISNULL(roomrent_amt,0)+ISNULL(ExtraHrsBeforeAmt,0)+ISNULL(ExtraHrsAfterAmt,0))) [Taxable Value],
                    SUM(CONVERT(DECIMAL(10,2),GSTAmt/2)) [Central Tax Amount], SUM(CONVERT(DECIMAL(10,2),GSTAmt/2)) [State/UT Tax Amount], '' [Cess Amount]
                    from hotelbilldetail A with (nolock) JOIN HOS on A.hotelBill_ID = HOS.hotelBill_ID AND HOS.Room_Dormatory=5
                    UNION ALL
                    SELECT '996334' [HSN Code],'CONF-MISC' [Description], COUNT(1) [Total Quantity], SUM(CONVERT(Decimal(10,2),AMOUNT+Serctaxamt)) [Total Val], 
                    SUM(CONVERT(Decimal(10,2),AMOUNT)) [Taxable Value],SUM(CONVERT(DECIMAL(10,2),Serctaxamt/2)) [Central Tax Amount], 
                    SUM(CONVERT(DECIMAL(10,2),Serctaxamt/2)) [State/UT Tax Amount], '' [Cess Amount]
                    FROM HotelBill_MISC_DETAILS A with (nolock) JOIN HOS on A.hotelBill_ID = HOS.hotelBill_ID AND HOS.Room_Dormatory=5
                )
                SELECT * FROM DEF;";
            }
        }        

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadReportData();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {        }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Bill Statement");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (dtReport != null) 
            {
                string filePath = Application.StartupPath+"\\"+this.Text;
                //if (exportCaller.WriteDataTableToExcel(dtReport, this.Text, filePath, string.Empty))
                if (exportCaller.WriteDataGridViewToExcel(new DataGridView[] { dgvReport2, dgvReportData }, new string[] { "HSN", "B2CL" }, filePath, string.Empty))
                {
                    CustomMessageBox.ShowInformationMessage("Export Successfull !", "Export");
                    System.Diagnostics.Process.Start(filePath + ".xlsx");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadReportData();
        }

        private void GetTotalCalFooter(int[] column, DataTable reportData)
        {
            try
            {
                if (reportData != null)
                {
                    double[] totValue = new double[column.Length];
                    foreach (DataRow dr in reportData.Rows)
                    {
                        for (int i = 1; i < column.Length; i++)
                        {
                            totValue[i] += (!DBNull.Value.Equals(dr[column[i]]) ? Convert.ToDouble(dr[column[i]]) : 0);
                        }
                    }

                    totValue = totValue.Select(d => Math.Round(d * 16) / 16).ToArray();


                    reportData.Rows.Add(reportData.NewRow());
                    DataRow drNew = reportData.NewRow();
                    for (int i = 0; i < column.Length; i++)
                    {
                        if (i == 0)
                        {
                            if (reportData.Columns[column[i]].DataType == typeof(string)) drNew[column[i]] = "Total";
                        }
                        else
                        {
                            drNew[column[i]] = totValue[i];
                        }
                    }

                    reportData.Rows.Add(drNew);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Total Cal Footer Error !");
            }
        }
    }
}
