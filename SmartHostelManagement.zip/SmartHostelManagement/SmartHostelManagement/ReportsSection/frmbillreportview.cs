﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using SmartHostelManagement.Properties;
using SMH.CommonLogic.Layer;
using SMH.BusinessLogic.Layer;

namespace SmartHostelManagement.Report
{
    public partial class frmbillreportview : Form
    {
        public string reportName { get; set; }
        public string reportCaption { get; set; }
        public string amttowaords { get; set; }
        public string Createdby { get; set; }
        public string AdvanceDetails { get; set; }

        string costr { get; set; }
        string _servername { get; set; }
        string _dbname { get; set; }
        string _userid { get; set; }
        string _pass { get; set; }

        public frmbillreportview()
        {
            InitializeComponent();
        }

        private void frmbillreportview_Load(object sender, EventArgs e)
        {
            _servername = SMHResources.ServerName;
            _dbname = SMHResources.DatabaseName;
            _userid = SMHResources.UserID;
            _pass = SMHResources.Password;

            printCrystalReport();

            #region Commented Code
            //return;
            //DataSet ds = new DataSet();
            //using (SqlHelperClass sqlHelp = new SqlHelperClass(costr))
            //{
            //    DataTable dt = sqlHelp.GetDatatableFormQuery("select * FROM tempc11s", "tempc11s");
            //    ds.Tables.Add(dt);
            //}

            //string test = Application.ExecutablePath;

            //ReportDocument rprt = new ReportDocument();
            //rprt.Load("E:\\Current Work\\Yuva Kendra\\SmartHotel\\SmartHotel\\Reports\\BilledRoom.rpt");
            //rprt.SetDataSource(ds);
            //crystalReportViewer1.ReportSource = rprt;
            #endregion Commented Code
        }



        private void printCrystalReport()
        {
            ReportDocument rptDoc = new ReportDocument();
            TableLogOnInfo crtableLogoninfo = new TableLogOnInfo();
            ConnectionInfo crConnectionInfo = new ConnectionInfo();
            Tables CrTables;

            //MasterCaller objMaster = new MasterCaller();
            //DataSet ds = new DataSet();
            //ds.Tables.Add(objMaster.GetDataTableData("select * from tempc;", "tempc"));
            //ds.Tables.Add(objMaster.GetDataTableData("select * from tempc3;", "tempc1"));
                        

            string rportPath = Application.StartupPath + "\\Reports\\" + reportName;
            rptDoc.Load(rportPath);

            crConnectionInfo.ServerName = _servername;
            crConnectionInfo.DatabaseName = _dbname;
            //crConnectionInfo.IntegratedSecurity = true;
            crConnectionInfo.UserID = _userid;
            crConnectionInfo.Password = _pass;

            //rptDoc.SetDataSource(ds.Tables[0]);
            //for (int i = 0; i < rptDoc.Subreports.Count; i++)
            //{
            //    rptDoc.Subreports[i].SetDataSource(ds.Tables[1]);
            //}


            CrTables = rptDoc.Database.Tables;
            foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
            {
                crtableLogoninfo = CrTable.LogOnInfo;
                crtableLogoninfo.ConnectionInfo = crConnectionInfo;
                CrTable.ApplyLogOnInfo(crtableLogoninfo);
            }

            foreach (FormulaFieldDefinition fieldResult in rptDoc.DataDefinition.FormulaFields)
            {
                if (fieldResult.Name.ToUpper() == "BILLTYPE")
                    fieldResult.Text = "\"" + reportCaption + "\"";

                if (fieldResult.Name.ToUpper() == "DRTYPE")
                {
                    if (reportCaption == "ROOMS BILL" || reportCaption == "PERFORMA ROOMS BILL" || reportCaption == "UN-BILLED ROOM" || reportCaption == "PERFORMA UN-BILLED ROOM")
                        fieldResult.Text = "\" Room \"";
                    else if (reportCaption == "CONFERENCE BILL" || reportCaption == "PERFORMA CONFERENCE BILL")
                        fieldResult.Text = "\" LOCATION \"";
                    else
                        fieldResult.Text = "\" Dorm \"";
                }

                if (fieldResult.Name.ToUpper() == "ADVANCEDETAIL")
                    fieldResult.Text = "\"" + AdvanceDetails + "\"";

                if (fieldResult.Name.ToUpper() == "REPORT CAPTION")
                    fieldResult.Text = "\"" + reportCaption + "\"";

                if (fieldResult.Name.ToUpper() == "AMTTOWORDS")
                    fieldResult.Text = "\"" + amttowaords + "\"";

                if (fieldResult.Name.ToUpper() == "CREATEDBY")
                    fieldResult.Text = "\"" + Createdby + "\"";
            }

            crystalReportViewer1.ReportSource = rptDoc;
            rptDoc.Refresh();
            crystalReportViewer1.Refresh();

        }
    }
}
