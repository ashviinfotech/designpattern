﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;
using SMH.DataAccess.Layer;
using System.Drawing;

namespace SmartHostelManagement.Reports
{
    public partial class frmCollectionReport : Form
    {
        MasterCaller objMstCaller = new MasterCaller();
        ExportHelper exportCaller = new ExportHelper();
        public int ReceiptRightId;
        //string strQuery = string.Empty;
        int[] columnValue;
        DataSet dsReport = null;

        public frmCollectionReport()
        {
            InitializeComponent();
            this.Text = "Collection Report";
        }

        private void txtBillTo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void loadReportData()
        {
            try
            {
                dsReport = null;
                dsReport = new DataSet();

                System.Text.StringBuilder dbQuery = new System.Text.StringBuilder();
                dbQuery.Append("DECLARE @startdate DATETIME = CAST('" + dtmReportFrom.Value.ToString("yyyy-MM-dd hh:mm:ss tt") + @"' AS DATETIME);
                        DECLARE @enddate DATETIME = CAST('" + dtmReportTo.Value.ToString("yyyy-MM-dd hh:mm:ss tt") + @"' AS DATETIME);
                        DECLARE @ReceiptRightId INT = " + ReceiptRightId + ";");

                dsReport.Tables.Add(objMstCaller.GetDataTableData(dbQuery.ToString() + reportQuery(1), "CashCol"));
                dsReport.Tables.Add(objMstCaller.GetDataTableData(dbQuery.ToString() + reportQuery(2), "CheqCol"));
                dsReport.Tables.Add(objMstCaller.GetDataTableData(dbQuery.ToString() + reportQuery(3), "CredCol"));
                dsReport.Tables.Add(objMstCaller.GetDataTableData(dbQuery.ToString() + reportQuery(4), "ItemCol"));

                LoadReportData(dsReport.Tables[0], 1);
                LoadReportData(dsReport.Tables[1], 2);
                LoadReportData(dsReport.Tables[2], 3);
                LoadReportData(dsReport.Tables[3], 4);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Bill Statement");
            }
        }

        private void LoadReportData(DataTable dtData, int dgvId)
        {
            DataGridView dgv = null;
            switch (dgvId)
            { 
                case 1:
                    reportQuery(1);
                    dgv = dgvCashCollection;
                    break;
                case 2:
                    reportQuery(2);
                    dgv = dgvChequeCollection;
                    break;
                case 3:
                    reportQuery(3);
                    dgv = dgcCreditCollection;
                    break;
                default:
                    reportQuery(4);
                    dgv = dgvItemSaleSummary;
                    break;
            }


            if (columnValue != null) GetTotalCalFooter(columnValue, dtData);
            dgv.DataSource = dtData;
            foreach (DataGridViewColumn grdCol in dgv.Columns)
            {
                grdCol.SortMode = DataGridViewColumnSortMode.NotSortable;
                if (columnValue[0] != grdCol.Index && columnValue.Any(x => x == grdCol.Index))
                {
                    grdCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    grdCol.DefaultCellStyle.Format = "0.00";
                }
            }

            if (dgv.Rows.Count >= 2)
            {
                dgv.Rows[dgv.Rows.Count - 1].DefaultCellStyle.BackColor = System.Drawing.Color.Yellow;
                dgv.Rows[dgv.Rows.Count - 1].DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8, FontStyle.Bold);
            }
        }

        private string reportQuery(int queryOrder)
        {            
            if (queryOrder == 1)
            {
                columnValue = new int[] { 3, 4, 5, 6, 7, 8, 9, 10, 11 };
                return @"SELECT (ROW_NUMBER() over (order by T.[Cash Memo No.],T.[Recpt No.])) [Sr.NO], * FROM
                (SELECT A.receipt_No [Recpt No.],NULL [Cash Memo No.], CONVERT(VARCHAR(20),Rdate,106) [Recpt Date], CAST(b.amount_p AS DECIMAL(10,2)) [Advance Received], 
                 NULL [Restaurant Total], NULL [Misc Services], 0 [GST],NULL [CGST],NULL [SGST],NULL [IGST], CAST(b.amount_p AS DECIMAL(10,2)) [Total Cash Collection]
                FROM receipt_payment A with (nolock) JOIN receipt_payment_details B with (nolock) ON A.recpt_pay_id=B.recpt_pay_id 
                WHERE A.recpt_pay_char='¡' AND B.mode_of_pay_int=0 AND B.sno=1 AND CAST(Rdatetime AS DATEtime) BETWEEN @startdate AND @enddate AND A.ReceiptRightId=2 
                UNION ALL
                SELECT NULL [Recpt No.],Kot_No [Cash Memo No.], CONVERT(VARCHAR(20),kdate,106) [Recpt Date], null [Advance Received], Amount [Restaurant Total],
                NULL [Misc Services], ServTaxAmt [GST], [CGSTAmt],[SGSTAmt],[IGSTAmt], CAST(NetTotal AS DECIMAL(10,2)) [Total Cash Collection]
                FROM KOT WHERE KDATETime BETWEEN @startdate AND @enddate AND mod_of_bill=0 AND ReceiptRightId=@ReceiptRightId) T 
                ";
            }
            else if (queryOrder == 2)
            {
                columnValue = new int[] { 2, 7 };
                return @"SELECT (ROW_NUMBER() over (order by A.recpt_pay_id asc)) [Sr.NO], A.receipt_No [Recpt No.], CONVERT(VARCHAR(20),Rdate,106) [Recpt Date], (a.title + ' ' + a.cname) [Party Name], 
                B.mode_of_pay [Mode Of Pay], b.instrumentno [Chq/DD/RTGS Ref No.], b.issue_auth [Bank Name], CAST(b.amount_p AS DECIMAL(10,2)) [Amount]
                FROM receipt_payment A with (nolock) JOIN receipt_payment_details B with (nolock) ON A.recpt_pay_id=B.recpt_pay_id 
                WHERE A.recpt_pay_char='¡' AND CAST(Rdatetime AS DATEtime) BETWEEN @startdate AND @enddate AND B.mode_of_pay_int IN (1,4) AND ReceiptRightId=@ReceiptRightId AND B.sno=1
                ";
            }
            else if (queryOrder == 3)
            {
                columnValue = new int[] { 2, 7 };
                return @"SELECT (ROW_NUMBER() over (order by A.recpt_pay_id asc)) [Sr.NO],A.receipt_No [Recpt No.], CONVERT(VARCHAR(20),Rdate,106) [Recpt Date], (a.title + ' ' + a.cname) [Party Name], 
                B.mode_of_pay [Mode Of Pay], b.instrumentno [Chq/DD/RTGS Ref No.], b.issue_auth [Bank Name], CAST(b.amount_p AS DECIMAL(10,2)) [Amount]
                FROM receipt_payment A with (nolock) JOIN receipt_payment_details B with (nolock) ON A.recpt_pay_id=B.recpt_pay_id 
                WHERE A.recpt_pay_char='¡' AND CAST(Rdatetime AS DATEtime) BETWEEN @startdate AND @enddate AND B.mode_of_pay_int IN (6) AND B.sno=1 AND ReceiptRightId=@ReceiptRightId 
                ";
            }
            else
            {
                columnValue = new int[] { 1, 2, 3, 4, 5, 6, 7, 8 };
                return @";WITH ABC AS
                (
	                SELECT KOT_ID, REPLACE(CONVERT(VARCHAR(20),Kdate,106),' ','-') KDATE, ServTaxAmt, NetTotal FROM Kot 
	                WHERE CAST(Kdatetime AS DATEtime) between @startdate and @enddate and mod_of_bill=0 and  ReceiptRightId=@ReceiptRightId
                ),
                DEF AS
                (
	                SELECT D.KOT_ID, sum(CASE WHEN D.Food_Id = 1 THEN CAST(D.Amount AS DECIMAL(10,2)) ELSE NULL END) [Breakfast(1-1)],
	                sum(CASE WHEN D.Food_Id = 2 THEN CAST(D.Amount AS DECIMAL(10,2)) ELSE NULL END) [Lunch(2-1)],
	                sum(CASE WHEN D.Food_Id = 3 THEN CAST(D.Amount AS DECIMAL(10,2)) ELSE NULL END) [Dinner(3-1)],
	                sum(CASE WHEN D.Food_Id = 39 THEN CAST(D.Amount AS DECIMAL(10,2)) ELSE NULL END) [Mineral Water(39-1)],
	                sum(CASE WHEN D.Food_Id = 55 THEN CAST(D.Amount AS DECIMAL(10,2)) ELSE NULL END) [Tea-Coffee(39-1)]
	                FROM KOT_details D JOIN ABC ON D.KOT_ID = ABC.KOT_ID GROUP BY D.KOT_ID
                )
                SELECT (ROW_NUMBER() OVER (ORDER BY abc.KOT_ID)) [Sr. NO.], abc.KDATE [Cash Memo Date], def.[Breakfast(1-1)],def.[Lunch(2-1)],def.[Dinner(3-1)],
                def.[Mineral Water(39-1)],def.[Tea-Coffee(39-1)],abc.ServTaxAmt [GST], abc.NetTotal [Total]
                FROM ABC JOIN DEF ON ABC.KOT_ID=DEF.KOT_ID";
            }
        }        

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadReportData();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {        }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Bill Statement");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (dsReport != null && dsReport.Tables.Count > 0) 
            {
                string filePath = Application.StartupPath+"\\"+this.Text;
                //if (exportCaller.WriteDataTableToExcel(dtReport, this.Text, filePath, string.Empty))
                if (exportCaller.WriteDataGridViewToExcel(new DataGridView[] 
                { 
                    dgvItemSaleSummary, dgcCreditCollection, dgvChequeCollection, dgvCashCollection },
                    new string[] { dsReport.Tables[3].TableName, dsReport.Tables[2].TableName, dsReport.Tables[1].TableName, dsReport.Tables[0].TableName }, filePath, string.Empty))
                {
                    CustomMessageBox.ShowInformationMessage("Export Successfull !", "Export");
                    System.Diagnostics.Process.Start(filePath + ".xlsx");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadReportData();
        }

        private void GetTotalCalFooter(int[] column, DataTable reportData)
        {
            try
            {
                if (reportData != null)
                {
                    double[] totValue = new double[column.Length];
                    foreach (DataRow dr in reportData.Rows)
                    {
                        for (int i = 1; i < column.Length; i++)
                        {
                            totValue[i] += (!DBNull.Value.Equals(dr[column[i]]) ? Convert.ToDouble(dr[column[i]]) : 0);
                        }
                    }

                    totValue = totValue.Select(d => Math.Round(d * 16) / 16).ToArray();


                    reportData.Rows.Add(reportData.NewRow());
                    DataRow drNew = reportData.NewRow();
                    for (int i = 0; i < column.Length; i++)
                    {
                        if (i == 0)
                        {
                            if (reportData.Columns[column[i]].DataType == typeof(string)) drNew[column[i]] = "Total";
                        }
                        else
                        {
                            drNew[column[i]] = totValue[i];
                        }
                    }

                    reportData.Rows.Add(drNew);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Total Cal Footer Error !");
            }
        }
    }
}
