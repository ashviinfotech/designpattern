﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;
using SMH.DataAccess.Layer;
using System.Drawing;

namespace SmartHostelManagement.Reports
{
    public partial class frmBillStatement : Form
    {
        MasterCaller objMstCaller = new MasterCaller();
        ExportHelper exportCaller = new ExportHelper();
        CommonVariables.ReportSection _reportName;
        string strQuery = string.Empty;
        int[] columnValue;
        DataTable dtReport;

        public frmBillStatement(CommonVariables.ReportSection objReport)
        {
            _reportName = objReport;
            InitializeComponent();            
            reportPageSetup();
        }

        private void txtBillTo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void loadReportData()
        {
            try
            {
                System.Text.StringBuilder dbQuery = new System.Text.StringBuilder();
                if (btnRefresh.Capture)
                {
                    dbQuery.Append("DECLARE @startdate varchar(20) = '" + dtmReportFrom.Value.ToString("yyyy-MM-dd") + @"';
                        DECLARE @enddate varchar(20) = '" + dtmReportTo.Value.ToString("yyyy-MM-dd") + "';");
                }
                
                dbQuery.Append(reportQuery());

                dtReport = objMstCaller.GetDataTableData(dbQuery.ToString(), _reportName.ToString().Trim());
                if (columnValue != null) GetTotalCalFooter(columnValue);
                dgvReportData.DataSource = dtReport;
                foreach (DataGridViewColumn grdCol in dgvReportData.Columns)
                {
                    grdCol.SortMode = DataGridViewColumnSortMode.NotSortable;
                    if (columnValue[0] != grdCol.Index && columnValue.Any(x => x == grdCol.Index))
                    {
                        grdCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                        if ((_reportName.Equals(CommonVariables.ReportSection.HostelDayOccupancy) && radioButton1.Checked) ||
                            (_reportName.Equals(CommonVariables.ReportSection.HostelMonOccupancy) && radioButton1.Checked) ||
                            (_reportName.Equals(CommonVariables.ReportSection.SeminarDayOccupancy) && radioButton1.Checked) ||
                            (_reportName.Equals(CommonVariables.ReportSection.SeminarMonOccupancy) && radioButton1.Checked))
                            grdCol.DefaultCellStyle.Format = "0";
                        else
                            grdCol.DefaultCellStyle.Format = "0.00";
                    }
                }

                if (dtReport.Rows.Count >= 2)
                {
                    dgvReportData.Rows[dtReport.Rows.Count - 1].DefaultCellStyle.BackColor = System.Drawing.Color.Yellow;
                    dgvReportData.Rows[dtReport.Rows.Count - 1].DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8, FontStyle.Bold);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Bill Statement");
            }
        }

        private void reportPageSetup()
        {
            this.Text = _reportName.ToString();

            if (_reportName.Equals(CommonVariables.ReportSection.ReceiptSummary))
            {
                this.Text = "Recipet Summary";
                groupBox1.Visible = true;
                groupBox2.Visible = false;
                groupBox4.Visible = false;
            }
            else if (_reportName.Equals(CommonVariables.ReportSection.HotelCollection) ||
                _reportName.Equals(CommonVariables.ReportSection.SeminarCollection))
            {
                this.Text = "Collection Summary";
                groupBox1.Visible = true;
                groupBox2.Visible = true;
                groupBox4.Visible = false;
                groupBox2.BringToFront();
            }
            else if (_reportName.Equals(CommonVariables.ReportSection.HostelDayOccupancy) ||
                _reportName.Equals(CommonVariables.ReportSection.HostelMonOccupancy) ||
                _reportName.Equals(CommonVariables.ReportSection.SeminarDayOccupancy) ||
                _reportName.Equals(CommonVariables.ReportSection.SeminarMonOccupancy))
            {
                this.Text = (_reportName.Equals(CommonVariables.ReportSection.HostelDayOccupancy) ||
                    _reportName.Equals(CommonVariables.ReportSection.SeminarDayOccupancy)) ? "Occupancy Day wise" : "Occupancy Month wise";

                groupBox1.Visible = true;
                groupBox2.Visible = false;
                groupBox4.Visible = true;
                groupBox4.BringToFront();

                radioButton1.Text = (_reportName.Equals(CommonVariables.ReportSection.HostelDayOccupancy) ||
                    _reportName.Equals(CommonVariables.ReportSection.HostelMonOccupancy)) ? "Rooms" : "Conference";
                radioButton2.Text = "Collection";
                radioButton1.Checked = true;
            }
            else
            { 
                this.Text = "Cash Collection";
                groupBox1.Visible = true;
                groupBox2.Visible = false;
                groupBox4.Visible = false;
            }
        }


        private string reportQuery()
        {
            if (_reportName.Equals(CommonVariables.ReportSection.ReceiptSummary))
            {
                #region ReceiptSummary
                columnValue = new int[] {1,4,5,6,9,11};
                return @"DECLARE @tagchar char = '¡';
                SELECT (row_number() over (order by r.recpt_pay_id)) [Sl.No.], r.cname [Customer Name], REPLACE(CONVERT(varchar,r.rdate,106),' ','-') [Date], r.receipt_No [Receipt No], 
                CONVERT(DECIMAL(10,2),r.total_amtIncTDS) [Total Amount], CONVERT(DECIMAL(10,2),r.total_amtExGST) [AMT Exc TDS], CONVERT(DECIMAL(10,2),r.total_amtTDS) [TDS Amt],T.AdjType [Adj Type],T.Refno [Ref No],
                CONVERT(DECIMAL(10,2),T.amount_Adj) [Adjustment],(CASE WHEN T.Remarks IS NOT NULL THEN t.Remarks ELSE 'UNADJUSTMENT' END) Remarks ,
                CONVERT(DECIMAL(10,2),(r.total_amtIncTDS - ISNULL(T.amount_Adj,0))) [Balance],r.Description
                FROM receipt_payment R left join (select r.recpt_pay_id,R.AdjType,r.amount_Adj,r.Refno,
                ('--ADJUSTMENT-- Bill: ' + h.PrefixInv + ISNULL(cast(h.Bill_No as VARCHAR),'') +' '+ REPLACE(CONVERT(varchar,h.checkouttime_date,106),' ','-')) Remarks
                from receipt_payment_Adjust_details R with (nolock) left join HotelBILL H with (nolock) on r.hotelBill_ID = h.hotelBill_ID 
                where recpt_pay_id = r.recpt_pay_id) T on r.recpt_pay_id = t.recpt_pay_id
                where recpt_pay_char=@tagchar and activate_delete=0 and RPCANCEL=0 and CONVERT(date,Rdate) between @startdate AND @enddate
                order by R.recpt_pay_id";
                #endregion ReceiptSummary
            }
            else if (_reportName.Equals(CommonVariables.ReportSection.HotelCollection))
            {
                #region HotelCollection
                columnValue = new int[] { 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 };

                string strval = @"declare @roomdorm int = 1;
                SELECT (ROW_NUMBER() OVER (ORDER BY H.Bill_No)) AS [S.No.],(REPLACE(CONVERT(VARCHAR,H.Bdate,106),' ','-')) AS [Bill Date],
                H.Bill_No AS [Bill No],(H.Title_guest+' '+H.Name_guest) AS [Name of the Party],
                (SELECT SUM(CASE WHEN ISNULL(A.roomrent_amt,0) < 1001 THEN CONVERT(DECIMAL(10,2),ISNULL(A.roomrent_amt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Rent Less Than 1000],
                (SELECT SUM(CASE WHEN ISNULL(A.roomrent_amt,0) BETWEEN 1000 AND 2501 THEN CONVERT(DECIMAL(10,2),ISNULL(A.roomrent_amt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Rent 1000 TO 2500],
                (SELECT SUM(CASE WHEN ISNULL(A.roomrent_amt,0) > 2500 THEN CONVERT(DECIMAL(10,2),ISNULL(A.roomrent_amt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Rent More Than 2500],
                CONVERT(DECIMAL(10,2),H.DiningAmountTotal) [Meal],CONVERT(DECIMAL(10,2),H.CancelChargesAmountTotal) [Room Cancel Charge],CONVERT(DECIMAL(10,2),H.CatCancelChargesAmountTotal) [Meal Cancel],CONVERT(DECIMAL(10,2),H.MiscAmountTotal) [Misc Utility],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 00 THEN CONVERT(DECIMAL(10,2),ISNULL(A.roomrent_amt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 0%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 00 THEN CONVERT(DECIMAL(10,2),ISNULL(A.GSTAmt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Room GST 0%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 12 THEN CONVERT(DECIMAL(10,2),ISNULL(A.roomrent_amt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 12%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 12 THEN CONVERT(DECIMAL(10,2),ISNULL(A.GSTAmt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Room GST 12%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 18 THEN CONVERT(DECIMAL(10,2),ISNULL(A.roomrent_amt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 18%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 18 THEN CONVERT(DECIMAL(10,2),ISNULL(A.GSTAmt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Room GST 18%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 28 THEN CONVERT(DECIMAL(10,2),ISNULL(A.roomrent_amt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 28%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 28 THEN CONVERT(DECIMAL(10,2),ISNULL(A.GSTAmt,0)) ELSE 0 END) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Room GST 28%],
                (SELECT SUM(CASE WHEN ISNULL(A.ServTaxPerc,0) = 18 THEN CONVERT(DECIMAL(10,2),ISNULL(A.AMOUNT,0)) ELSE 0 END) FROM Hotel_DININGRoom_details A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 18%],
                (SELECT SUM(CASE WHEN ISNULL(A.ServTaxPerc,0) = 18 THEN CONVERT(DECIMAL(10,2),ISNULL(A.ServTaxAmt,0)) ELSE 0 END) FROM Hotel_DININGRoom_details A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Meal GST 18%],
                (SELECT SUM(CASE WHEN ISNULL(A.ServTaxPerc,0) = 05 THEN CONVERT(DECIMAL(10,2),ISNULL(A.AMOUNT,0)) ELSE 0 END) FROM Hotel_DININGRoom_details A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 5%],
                (SELECT SUM(CASE WHEN ISNULL(A.ServTaxPerc,0) = 05 THEN CONVERT(DECIMAL(10,2),ISNULL(A.ServTaxAmt,0)) ELSE 0 END) FROM Hotel_DININGRoom_details A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Meal GST 5%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 12 THEN CONVERT(DECIMAL(10,2),ISNULL(A.Cancel_charges_ttl,0)) ELSE 0 END) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 12%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 12 THEN CONVERT(DECIMAL(10,2),ISNULL(A.GSTAmt,0)) ELSE 0 END) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Meal GST 12%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 18 THEN CONVERT(DECIMAL(10,2),ISNULL(A.Cancel_charges_ttl,0)) ELSE 0 END) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 18%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 18 THEN CONVERT(DECIMAL(10,2),ISNULL(A.GSTAmt,0)) ELSE 0 END) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Meal GST 18%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 28 THEN CONVERT(DECIMAL(10,2),ISNULL(A.Cancel_charges_ttl,0)) ELSE 0 END) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Taxable Amt 28%],
                (SELECT SUM(CASE WHEN ISNULL(A.GSTRate,0) = 28 THEN CONVERT(DECIMAL(10,2),ISNULL(A.GSTAmt,0)) ELSE 0 END) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID) AS [Meal GST 28%],
                CONVERT(DECIMAL(10,2),H.roundoff) [Round Off], CONVERT(DECIMAL(10,2),(H.totalamt + H.DiningAmountTotal)) [Gross Amt], CONVERT(DECIMAL(10,2),H.advancerecd) [Recev. AmT], 
                (CASE WHEN cast((ISNULL(H.totalamt+H.DiningAmountTotal,0) - ISNULL(H.advancerecd,0)) as int) = 0 THEN 'Closed' ELSE 'Opened' END) [Balance]
                FROM HotelBILL H with (nolock) WHERE H.Room_Dormatory = @roomdorm ";

                strval += btnRefresh.Capture ? "AND CAST(H.date_of_final AS DATE) BETWEEN @startdate AND @enddate ORDER BY h.Bill_No" : "AND CAST(H.Bdate AS DATE) >= '" + CommonVariables.dtmFinancialStart.Date.ToString("yyyy-MM-dd") + "' AND H.Bill_No BETWEEN '" + txtFrom.Text + "' AND '" + txtUpto.Text + "' ORDER BY [Bill No]";
                return strval;
                #endregion HotelCollection
            }
            else if (_reportName.Equals(CommonVariables.ReportSection.SeminarCollection))
            {
                #region SeminarCollection
                columnValue = new int[] { 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17};

                string strval = @"declare @roomdorm int = 5;

                SELECT (ROW_NUMBER() OVER (ORDER BY H.hotelbill_ID)) AS [S.No.],(REPLACE(CONVERT(VARCHAR,H.Bdate,106),' ','-')) AS [Bill Date],
                H.Bill_No AS [Bill No],(H.Title_guest+' '+H.Name_guest) AS [Name of the Party],
                (CASE WHEN H.STExempted = 0 THEN ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.roomrent_amt)) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) ELSE 0 END) AS [From Conference (Non Exem)],
                (CASE WHEN H.STExempted = 1 THEN ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.roomrent_amt)) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) ELSE 0 END) AS [From Conference (Exem)],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.AMOUNT)) FROM HotelBill_MISC_DETAILS A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [From Logistics],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.CateringAMOUNT)) FROM HotelBill_CATERING_DETAILS A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [From Catering],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.Cancel_charges_ttl)) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [Booking Cancellation],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.Cancel_charges_ttl)) FROM HotelBillCatCancelDetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [Catering Cancellation],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.GSTAmt)) FROM hotelbilldetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [Gst 18% Conf.],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.Serctaxamt)) FROM HotelBill_MISC_DETAILS A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [GST 18% Logi.],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.GSTAmt)) FROM HotelBill_CATERING_DETAILS A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [GST 18% Cate.],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.servtax)) FROM HotelBillCancelCharges A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [GST 18% Booking Can.],
                ISNULL((SELECT SUM(CONVERT(DECIMAL(10,2),A.servtax)) FROM HotelBillCatCancelDetail A WHERE A.hotelBill_ID = H.hotelBill_ID GROUP BY A.hotelBill_ID),0) AS [GST 18% Cate. Can.],
                CONVERT(DECIMAL(10,2),H.roundoff) [Round Off], CONVERT(DECIMAL(10,2),H.totalamt) [Gross Amt], CONVERT(DECIMAL(10,2),H.advancerecd) [Recev. AmT], (CASE WHEN CONVERT(DECIMAL(10,2),(ISNULL(H.totalamt+h.roundoff,0) - ISNULL(H.advancerecd,0))) = 0 THEN 'Closed' ELSE 'Opened' END) [Balance]
                FROM HotelBILL H WHERE H.Room_Dormatory = @roomdorm ";

                strval += btnRefresh.Capture ? "AND CAST(H.Bdate AS DATE) BETWEEN @startdate AND @enddate ORDER BY CAST(H.Bdate AS DATE)" : "AND CAST(H.Bdate AS DATE) >= '" + CommonVariables.dtmFinancialStart.Date.ToString("yyyy-MM-dd") + "' AND H.Bill_No BETWEEN '" + txtFrom.Text + "' AND '" + txtUpto.Text + "' ORDER BY [Bill No]";
                return strval;
                #endregion SeminarCollection
            }
            else if (_reportName.Equals(CommonVariables.ReportSection.HostelDayOccupancy))
            {
                #region HostelDayOccupancy
                columnValue = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45 };
                return radioButton1.Checked ? @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=0 order by room_number_number

                DECLARE @sqlQuery NVARCHAR(MAX) = ';WITH DATES AS (SELECT [DATE] = CAST('''+@startdate+''' AS DATE)
                UNION ALL SELECT [DATE] = DATEADD(DAY,1,[DATE]) FROM Dates WHERE [DATE] < CAST('''+@enddate+''' AS DATE)
                ),ABC AS (SELECT Convert(date, b.date_ofdet) RDate,B.roomno FROM HotelBILL A JOIN hotelbilldetail B ON 
                A.hotelBill_ID=b.hotelBill_ID WHERE A.Room_Dormatory = 1 AND Convert(DATE, B.date_ofdet) 
                BETWEEN '''+@startdate+''' and '''+@enddate+'''), DEF AS (SELECT * FROM (SELECT RDate,roomno,COUNT(roomno) CROOM 
                FROM ABC GROUP BY RDate, roomno UNION SELECT RDate,''TOTAL'' ROOMNO,COUNT(roomno) CROOM FROM ABC GROUP BY RDate) T PIVOT
                (SUM(CROOM) FOR roomno IN (['+@columnList+'],[TOTAL])) AS PVT)
                SELECT Dates.DATE, ['+@columnList+'], [TOTAL] FROM Dates LEFT JOIN DEF ON  Dates.DATE = CAST(DEF.RDate AS DATE)
                ORDER BY DATES.DATE
                OPTION (MAXRECURSION 0);'
                exec (@sqlQuery);" : @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=0 order by room_number_number

                DECLARE @sqlQuery NVARCHAR(MAX) = ';WITH Dates AS (SELECT [DATE] = CAST('''+@startdate+''' AS DATE)
                UNION ALL SELECT [DATE] = DATEADD(DAY,1,[DATE]) FROM Dates WHERE [DATE] < CAST('''+@enddate+''' AS DATE)), 
                GHI AS(SELECT  Convert(date, b.date_ofdet) RDate, b.roomno, CONVERT(DECIMAL(10,2),ISNULL(b.total_amt_amt, 0)) Amount
                from HotelBILL A join hotelbilldetail B on A.hotelBill_ID=b.hotelBill_ID WHERE A.Room_Dormatory = 1 AND 
                CONVERT(date, b.date_ofdet) between CAST('''+@startdate+''' AS DATE) and CAST('''+@enddate+''' AS DATE)),
                DEF AS (SELECT RDate,['+@columnList+'],[TOTAL] FROM (SELECT ROOMNO, RDate, SUM(Amount) CTotal FROM GHI 
                group by roomno, RDate UNION SELECT ''TOTAL'' AS ROOMNO, RDate, SUM(Amount) CTotal FROM GHI group by RDate) 
                T Pivot (SUM(CTotal) for roomno in (['+@columnList+'], [TOTAL])) as Pvt)
                SELECT Dates.DATE, ['+@columnList+'], [TOTAL] FROM Dates LEFT JOIN DEF ON  Dates.DATE = CAST(DEF.RDate AS DATE)
                ORDER BY DATES.DATE
                OPTION (MAXRECURSION 0);'
                exec (@sqlQuery);";
                #endregion HostelDayOccupancy
            }
            else if (_reportName.Equals(CommonVariables.ReportSection.HostelMonOccupancy))
            {
                #region HostelMonOccupancy
                columnValue = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45 };
                return radioButton1.Checked ? @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=0 order by room_number_number

                SET @columnList=';WITH ABC AS (SELECT REPLACE(LTRIM(SUBSTRING(CONVERT(VARCHAR, B.date_ofdet, 106),3,9)),'' '',''-'') [RDATE],
                (YEAR(B.date_ofdet)*100+MONTH(B.date_ofdet)) MTH, B.roomno FROM HotelBILL A JOIN hotelbilldetail B ON A.hotelBill_ID = B.hotelBill_ID
                WHERE A.Room_Dormatory=1 and Convert(date, b.date_ofdet) between '''+@startdate+''' and '''+@enddate+'''
                ),DEF AS(SELECT Rdate [Mon-Yr],MTH,['+@columnList+'], [TOTAL] FROM (SELECT RDATE,MTH,roomno, COUNT(roomno) CTotal FROM ABC GROUP BY RDATE, MTH, roomno
                UNION SELECT RDATE,MTH,''TOTAL'' roomno, COUNT(roomno) CTotal FROM ABC GROUP BY RDATE, MTH) T PIVOT 
                (SUM(CTotal) FOR roomno IN (['+@columnList+'], [TOTAL])) AS PVT)
                SELECT [Mon-Yr],['+@columnList+'], [TOTAL] FROM DEF ORDER BY MTH' 
                EXEC (@columnList);" : @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=0 order by room_number_number

                SET @columnList=';WITH ABC AS (SELECT REPLACE(LTRIM(SUBSTRING(CONVERT(VARCHAR, B.date_ofdet, 106),3,9)),'' '',''-'') [RDATE],
                (YEAR(B.date_ofdet)*100+MONTH(B.date_ofdet)) MTH, B.roomno, CONVERT(DECIMAL(10,2),ISNULL(B.total_amt_amt,0)) AMOUNT FROM HotelBILL A 
                JOIN hotelbilldetail B ON A.hotelBill_ID = B.hotelBill_ID WHERE A.Room_Dormatory=1 and Convert(date, b.date_ofdet) 
                between '''+@startdate+''' and '''+@enddate+'''),DEF AS(SELECT Rdate [Mon-Yr],MTH,['+@columnList+'], [TOTAL] FROM 
                (SELECT RDATE,MTH,roomno, SUM(AMOUNT) CTotal FROM ABC GROUP BY RDATE, MTH, roomno
                UNION SELECT RDATE,MTH,''TOTAL'' roomno, SUM(AMOUNT) CTotal FROM ABC GROUP BY RDATE, MTH) T PIVOT 
                (SUM(CTotal) FOR roomno IN (['+@columnList+'], [TOTAL])) AS PVT)
                SELECT [Mon-Yr],['+@columnList+'], [TOTAL] FROM DEF ORDER BY MTH' 
                EXEC (@columnList);";
                #endregion HostelMonOccupancy
            }
            else if(_reportName.Equals(CommonVariables.ReportSection.SeminarDayOccupancy))
            {
                #region SeminarDayOccupancy
                columnValue = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
                return radioButton1.Checked ? @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=1 order by room_number_number

                DECLARE @sqlQuery NVARCHAR(MAX) = ';WITH Dates AS (SELECT [DATE] = CAST('''+@startdate+''' AS DATE)
                UNION ALL SELECT [DATE] = DATEADD(DAY,1,[DATE]) FROM Dates WHERE [DATE] < CAST('''+@enddate+''' AS DATE)
                ),GHI AS (select B.roomno,Convert(date, b.date_ofdet) RDate from HotelBILL A join hotelbilldetail B on 
                A.hotelBill_ID=b.hotelBill_ID where A.Room_Dormatory = 5 and Convert(date, b.date_ofdet) between 
                '''+@startdate+''' and '''+@enddate+'''),DEF AS (select RDate,['+@columnList+'],[TOTAL] from (
                select roomno, RDate, count(Roomno) CTotal FROM GHI GROUP BY RDATE,ROOMNO UNION select ''TOTAL'' roomno, 
                RDate, count(Roomno) CTotal FROM GHI GROUP BY RDATE) T Pivot (SUM(ctotal) for roomno in (['+@columnList+'],
                [TOTAL])) as Pvt) SELECT Dates.DATE, ['+@columnList+'],[TOTAL] FROM Dates LEFT JOIN DEF ON  
                Dates.DATE = CAST(DEF.RDate AS DATE) ORDER BY DATES.DATE
                OPTION (MAXRECURSION 0);'
                exec (@sqlQuery);" : @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=1 order by room_number_number

                DECLARE @sqlQuery NVARCHAR(MAX) = ';WITH Dates AS (SELECT [DATE] = CAST('''+@startdate+''' AS DATE)
                UNION ALL SELECT [DATE] = DATEADD(DAY,1,[DATE]) FROM Dates WHERE [DATE] < CAST('''+@enddate+''' AS DATE)
                ),GHI AS (select B.roomno,Convert(date, b.date_ofdet) RDate, CONVERT(DECIMAL(10,2),ISNULL(B.total_amt_amt,0)) AMOUNT
                from HotelBILL A join hotelbilldetail B on A.hotelBill_ID=b.hotelBill_ID where A.Room_Dormatory = 5 and 
                Convert(date, b.date_ofdet) between '''+@startdate+''' and '''+@enddate+'''),DEF AS (select RDate,
                ['+@columnList+'],[TOTAL] from (select roomno, RDate, SUM(AMOUNT) CTotal FROM GHI GROUP BY RDATE,ROOMNO 
                UNION select ''TOTAL'' roomno, RDate, SUM(AMOUNT) CTotal FROM GHI GROUP BY RDATE) T Pivot (SUM(CTOTAL) 
                for roomno in (['+@columnList+'],[TOTAL])) as Pvt) SELECT Dates.DATE, ['+@columnList+'],[TOTAL] FROM Dates 
                LEFT JOIN DEF ON  Dates.DATE = CAST(DEF.RDate AS DATE) ORDER BY DATES.DATE
                OPTION (MAXRECURSION 0);'
                exec (@sqlQuery);";
                #endregion SeminarDayOccupancy
            }
            else if (_reportName.Equals(CommonVariables.ReportSection.SeminarMonOccupancy))
            {
                #region SeminarMonOccupancy
                columnValue = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
                return radioButton1.Checked ? @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=1 order by room_number_number

                DECLARE @sqlQuery NVARCHAR(MAX)=';WITH ABC AS(SELECT REPLACE(LTRIM(SUBSTRING(CONVERT(VARCHAR, B.date_ofdet, 106),3,9)),'' '',''-'') [RDATE],
                (YEAR(B.date_ofdet)*100+MONTH(B.date_ofdet)) MTH, B.roomno FROM HotelBILL A JOIN hotelbilldetail B ON A.hotelBill_ID = B.hotelBill_ID 
                WHERE A.Room_Dormatory=5 and Convert(date, b.date_ofdet) BETWEEN '''+@startdate+''' and '''+@enddate+'''), DEF AS (SELECT Rdate [Mon-Yr],
                ['+@columnList+'],[TOTAL],MTH FROM (SELECT RDATE, MTH,ROOMNO, COUNT(ROOMNO) CTOTAL FROM ABC GROUP BY RDATE, MTH,ROOMNO UNION
                SELECT RDATE, MTH,''TOTAL'' AS ROOMNO, COUNT(ROOMNO) CTOTAL FROM ABC GROUP BY RDATE, MTH ) DET PIVOT (SUM(CTOTAL) FOR ROOMNO IN 
                (['+@columnList+'],[TOTAL])) AS PVT	) SELECT [Mon-Yr],['+@columnList+'],[TOTAL] FROM DEF ORDER BY MTH' 
                EXEC (@sqlQuery);" : @"DECLARE @columnList varchar(MAX)
                SET @columnList = NULL
                SELECT @columnList = COALESCE(@columnList + '],[','')+room_number_number 
                FROM room_number where room_number_ConferenceRoom=1 order by room_number_number

                DECLARE @sqlQuery NVARCHAR(MAX)=';WITH ABC AS(SELECT REPLACE(LTRIM(SUBSTRING(CONVERT(VARCHAR, B.date_ofdet, 106),3,9)),'' '',''-'') [RDATE],
                (YEAR(B.date_ofdet)*100+MONTH(B.date_ofdet)) MTH, B.roomno,CONVERT(DECIMAL(10,2),B.total_amt_amt) AMOUNT FROM HotelBILL A JOIN hotelbilldetail B 
                ON A.hotelBill_ID = B.hotelBill_ID WHERE A.Room_Dormatory=5 and Convert(date, b.date_ofdet) BETWEEN '''+@startdate+''' and '''+@enddate+'''), 
                DEF AS (SELECT Rdate [Mon-Yr],['+@columnList+'],[TOTAL],MTH FROM (SELECT RDATE, MTH,ROOMNO, SUM(AMOUNT) CTOTAL FROM ABC GROUP BY RDATE, MTH,
                ROOMNO UNION SELECT RDATE, MTH,''TOTAL'' AS ROOMNO, SUM(AMOUNT) CTOTAL FROM ABC GROUP BY RDATE, MTH ) DET PIVOT (SUM(CTOTAL) FOR ROOMNO IN 
                (['+@columnList+'],[TOTAL])) AS PVT	) SELECT [Mon-Yr],['+@columnList+'],[TOTAL] FROM DEF ORDER BY MTH' 
                EXEC (@sqlQuery);";
                #endregion SeminarMonOccupancy
            }
            else
            {
                #region SeminarMonOccupancy
                #endregion SeminarMonOccupancy
                return string.Empty;
            }
        }

        #region Comments Code
        //        private void loadPageData1()
//        {
//            try
//            {
//                dtReport = new DataTable();
//                string sqlQuery = string.Empty;

                
//                else if (reportName == "Monthly Occupancy")
//                {
//                    sqlQuery = @"DECLARE @startdate VARCHAR(100) = CAST('" + dtmReportFrom.Value.ToString("yyyy-MM-dd") + @"' as DATE);
//                    DECLARE @enddate VARCHAR(100) = CAST('" + dtmReportTo.Value.ToString("yyyy-MM-dd") + @"' as DATE);
//                    ";
//                }

//                dtReport = objMstCaller.GetDataTableData(sqlQuery, "DBTable");
//                dgvReportData.DataSource = dtReport;


////                decimal billamount = 0m, recvAmount = 0m;

////                string sqlQuery = @"SELECT T.SLNo,T.Bill_No,t.[Bill Date],t.[Dep. Date],t.Receipt_No [Receipt_No - Amount],t.[Bill Amount],T.[Recd. Amount],(t.[Bill Amount]-T.[Recd. Amount]) Balanced FROM 
////                (SELECT ROW_NUMBER() over (order by Bill_No) SLNo,Bill_No, REPLACE(CONVERT(NVARCHAR(20),Bdate,106),' ','/') [Bill Date],REPLACE(CONVERT(NVARCHAR(20),checkouttime_date,106),' ','/') [Dep. Date],
////                isnull(STUFF((SELECT '; ' + CONVERT(varchar(max),c.receipt_No)+' - '+CONVERT(varchar(max),cast(b.amount_Adj as dec(10,2))) FROM receipt_payment_Adjust_details b 
////                join receipt_payment c on b.recpt_pay_id=c.recpt_pay_id WHERE b.AdjType in ('" + (rdbRoomBill.Checked ? "Rooms" : "Dormatory") + @"') and b.hotelBill_ID=HotelBILL.hotelBill_ID
////                FOR XML PATH('')), 1, 1, ''),0) AS Receipt_No,cast(totalamt as dec(10,2)) [Bill Amount],(select sum(cast(a.amount_Adj as dec(10,2))) from receipt_payment_Adjust_details a 
////                where AdjType in ('" + (rdbRoomBill.Checked ? "Rooms" : "Dormatory") + @"') and hotelBill_ID = HotelBILL.hotelBill_ID) [Recd. Amount]
////                FROM HotelBILL WHERE Bill_No BETWEEN " + txtBillFrom.Text.Trim() + " AND " + txtBillTo.Text.Trim() + " AND Room_Dormatory=" + (rdbRoomBill.Checked ? 1 : 2) + ") T order by [Bill_No]";

////                dtReport = objReport.GetReportDataTable(sqlQuery);
////                dtReport.TableName = "BillSummaryDatewise";

////                if (dtReport != null)
////                {
////                    foreach (DataRow dr in dtReport.Rows)
////                    {
////                        billamount += (!DBNull.Value.Equals(dr["Bill Amount"]) ? Convert.ToDecimal(dr["Bill Amount"]) : 0);
////                        recvAmount += (!DBNull.Value.Equals(dr["Recd. Amount"]) ? Convert.ToDecimal(dr["Recd. Amount"]) : 0);
////                    }

////                    dtReport.Rows.Add(dtReport.NewRow());

////                    DataRow drw = dtReport.NewRow();
////                    drw["Dep. Date"] = "Total:";
////                    drw["Bill Amount"] = billamount.ToString("0.00");
////                    drw["Recd. Amount"] = recvAmount.ToString("0.00");
////                    dtReport.Rows.Add(drw);
////                }

////                dgvReportData.DataSource = dtReport;
////                foreach (DataGridViewColumn grdCol in dgvReportData.Columns)
////                {
////                    grdCol.SortMode = DataGridViewColumnSortMode.NotSortable;
////                    if (grdCol.Name != "SLNo" && grdCol.Name != "Bill Date" && grdCol.Name != "Dep. Date")
////                    {
////                        grdCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
////                    }
////                }

////                if (dtReport.Rows.Count > 2)
////                {
////                    dgvReportData.Rows[dtReport.Rows.Count - 1].DefaultCellStyle.BackColor = System.Drawing.Color.Yellow;
////                    dgvReportData.Rows[dtReport.Rows.Count - 1].DefaultCellStyle.Font = new Font("Verdana", 9, FontStyle.Bold);
////                }
//            }
//            catch (Exception ex)
//            {
//                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Bill Statement");
//            }
        //        }
        #endregion Comments Code

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadReportData();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
//                string sqlQuery = @"BEGIN
//                    DELETE FROM tempc;
//
//                    INSERT INTO tempc (sno,tempC_1,tempC_2,tempC_3,tempC_4,tempF_1,tempF_2,tempF_3,tempF_4) 
//                    SELECT T.SLNo,t.[Bill Date],t.[Dep. Date],t.Receipt_No [Receipt_No - Amount],(t.[Bill Amount]-T.[Recd. Amount]) Balanced,
//                    T.SLNo,T.Bill_No,t.[Bill Amount],T.[Recd. Amount] FROM 
//                    (SELECT ROW_NUMBER() over (order by Bill_No) SLNo,Bill_No, REPLACE(CONVERT(NVARCHAR(20),Bdate,106),' ','/') [Bill Date],REPLACE(CONVERT(NVARCHAR(20),checkouttime_date,106),' ','/') [Dep. Date],
//                    isnull(STUFF((SELECT '; ' + CONVERT(varchar(max),c.receipt_No)+' - '+CONVERT(varchar(max),cast(b.amount_Adj as dec(10,2))) FROM receipt_payment_Adjust_details b 
//                    join receipt_payment c on b.recpt_pay_id=c.recpt_pay_id WHERE b.AdjType in ('" + (rdbRoomBill.Checked ? "Rooms" : "Dormatory") + @"') and b.hotelBill_ID=HotelBILL.hotelBill_ID
//                    FOR XML PATH('')), 1, 1, ''),0) AS Receipt_No,cast(totalamt as dec(10,2)) [Bill Amount],(select sum(cast(a.amount_Adj as dec(10,2))) from receipt_payment_Adjust_details a 
//                    where AdjType in ('" + (rdbRoomBill.Checked ? "Rooms" : "Dormatory") + @"') and hotelBill_ID = HotelBILL.hotelBill_ID) [Recd. Amount]
//                    FROM HotelBILL WHERE Bill_No BETWEEN " + txtBillFrom.Text.Trim() + " AND " + txtBillTo.Text.Trim() + @"  
//                    AND Room_Dormatory=" + (rdbRoomBill.Checked ? 1 : 2) + ") T order by [Bill_No] END";

//                objReport.ExecReportDataTable(sqlQuery);    
//                frmbillreportview freport = new frmbillreportview();
//                freport.reportName = "rpt_ravi_BillStatementVYK.rpt";
//                freport.reportCaption = "Bill Statement For " + (rdbRoomBill.Checked ? "Rooms" : "Dormatory") + " From " + txtBillFrom.Text.Trim() + " To " + txtBillTo.Text.Trim();
//                freport.Show();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Bill Statement");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (dtReport != null) 
            {
                string filePath = Application.StartupPath+"\\"+this.Text;
                //if (exportCaller.WriteDataTableToExcel(dtReport, this.Text, filePath, string.Empty))
                if(exportCaller.WriteDataGridViewToExcel(new DataGridView[]{dgvReportData}, new string[]{this.Text}, filePath, string.Empty))
                {
                    CustomMessageBox.ShowInformationMessage("Export Successfull !", "Export");
                    System.Diagnostics.Process.Start(filePath + ".xlsx");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadReportData();
        }

        private void GetTotalCalFooter(int[] column)
        {
            try
            {
                if(this.dtReport != null)
                {
                    double[] totValue = new double[column.Length];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        for (int i = 1; i < column.Length; i++)
                        {
                            totValue[i] += (!DBNull.Value.Equals(dr[column[i]]) ? Convert.ToDouble(dr[column[i]]) : 0);
                        }
                    }

                    totValue = totValue.Select(d => Math.Round(d * 16) / 16).ToArray();

                    
                    dtReport.Rows.Add(dtReport.NewRow());
                    DataRow drNew = dtReport.NewRow();
                    for (int i = 0; i < column.Length; i++)
                    {
                        if (i == 0)
                        {
                            if (dtReport.Columns[column[i]].DataType == typeof(string)) drNew[column[i]] = "Total";
                        }
                        else
                        {
                            drNew[column[i]] = totValue[i];
                        }
                    }

                    dtReport.Rows.Add(drNew);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Total Cal Footer Error !");
            }
        }
    }
}
