﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Search
{
    public partial class frmMiscItemSearch : Form
    {
        MasterCaller objMasterData = new MasterCaller();
        public int channelid = 0;
        public EL.Misc_items objSMiscItems { get; set; }

        public frmMiscItemSearch()
        {
            InitializeComponent();
        }

        private void frmLoginSearch_Load(object sender, EventArgs e)
        {
            BindGridView();
        }

        private void BindGridView()
        {
            try
            {
                IList<EL.Misc_items> guestList = !string.IsNullOrEmpty(txtSearchName.Text) ? 
                    objMasterData.GetMiscItems().Where(x=> x.channelid == channelid && x.Misc_items_Name.ToUpper().Contains(txtSearchName.Text.Trim().ToUpper())).OrderBy(x => x.Misc_items_Name).ToList() :
                    objMasterData.GetMiscItems().Where(x => x.channelid == channelid).OrderBy(x => x.Misc_items_Name).ToList();

                var dbdata = guestList.Select((c, index) =>
                    new
                    {
                        c.Misc_items_Id,
                        SlNo = index + 1,
                        Item_Code = c.Misc_items_code,
                        Item_Name = c.Misc_items_Name,
                        c.Price,
                        c.Unit
                    });


                datagrdiview.DataSource = dbdata.ToList();
                datagrdiview.Columns["Misc_items_Id"].Visible = false;
                datagrdiview.Columns["SlNo"].Width = 45;
                datagrdiview.Columns["Item_Code"].Width = 50;
                datagrdiview.Columns["Item_Name"].Width = 200;
                datagrdiview.Columns["Price"].Width = 100;
                datagrdiview.Columns["Unit"].Width = 100;

                datagrdiview.Columns["Price"].DefaultCellStyle.Format = "0.00";
                datagrdiview.Columns["Unit"].DefaultCellStyle.Format = "0";
            }
            catch(Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Bind gridview");
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if(datagrdiview.SelectedRows.Count > 0)
                {
                    DataGridViewRow dr = datagrdiview.SelectedRows[0];
                    int miscid = Convert.ToInt32(dr.Cells["Misc_items_Id"].Value);
                    objSMiscItems = objMasterData.GetMiscItems().FirstOrDefault(x => x.Misc_items_Id == miscid);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in select data");
            }
        }

        private void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            BindGridView();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (datagrdiview.SelectedRows.Count > 0)
            {
                btnSelect_Click(sender, e);
            }
        }
    }
}
