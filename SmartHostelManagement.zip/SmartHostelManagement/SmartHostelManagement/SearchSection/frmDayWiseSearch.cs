﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Search
{
    public partial class frmDayWiseSearch : Form
    {
        DBData.ISIPMEntities dbContext = null;
        public int reservationID = 0;

        public frmDayWiseSearch()
        {
            InitializeComponent();
        }

        private void frmHotelSearch_Load(object sender, EventArgs e)
        {
            LoadPageData();
        }

        private void LoadPageData()
        {
            try
            {
                using (dbContext = new DBData.ISIPMEntities())
                {
                    var lstDayWise = (from a in dbContext.RESERVATION_DAYWISE_STATUS
                                      join b in dbContext.room_number on a.reservation_dormid equals b.room_number_ID
                                      into ab
                                      from f in ab.DefaultIfEmpty()
                                      join c in dbContext.ROOM_TYPE on a.RM_TYPE_ID1 equals c.RM_TYPE_ID
                                      into ac
                                      from g in ac.DefaultIfEmpty()
                                      join d in dbContext.ROOM_TYPE on a.RM_TYPE_ID2 equals d.RM_TYPE_ID
                                      into ad
                                      from h in ad.DefaultIfEmpty()
                                      where a.reservation_ID == reservationID
                                      select new 
                                      { 
                                          a.reservation_daywise_status_id,
                                          Cancel = a.RESERVATION_DAYWISE_CANCEL_STATUS.Any(x => x.reservation_daywise_status_id == a.reservation_daywise_status_id) ? true : false,
                                          a.reservation_CHECKIN,
                                          f.room_number_number, 
                                          RoomType = g.RM_TYPE_DESC, 
                                          DormType = h.RM_TYPE_DESC,
                                          a.reservation_Rooms,
                                          a.ROOMrate1,
                                          a.reservation_Dorm,
                                          a.ROOMrate2,
                                          a.reservation_remark
                                      }).ToList();

                    var dbData = lstDayWise.Select((x, index) => new
                    {
                        x.reservation_daywise_status_id,
                        Slno = index + 1,
                        x.Cancel,
                        Reserv_Date = x.reservation_CHECKIN.HasValue ? x.reservation_CHECKIN.Value.ToString("dd-MMM-yyyy") : string.Empty,
                        DormName = x.room_number_number,
                        x.RoomType,
                        NoOfRooms = x.reservation_Rooms,
                        Room_Rate = x.ROOMrate1,
                        x.DormType,
                        NoOfBeds = x.reservation_Dorm,
                        Dorm_Rate = x.ROOMrate2,
                        Remarks = x.reservation_remark
                    }).ToList();

                    dgvReservationDet.DataSource = dbData;

                    foreach (DataGridViewRow row in dgvReservationDet.Rows)
                    {
                        if(Convert.ToBoolean(row.Cells["Cancel"].Value) == true) row.DefaultCellStyle.BackColor = System.Drawing.Color.Red;
                    }
                    dgvReservationDet.Columns["reservation_daywise_status_id"].Visible = false;
                    dgvReservationDet.Columns["Cancel"].Visible = false;
                    dgvReservationDet.Columns["Room_Rate"].DefaultCellStyle.Format = "0.00";
                    dgvReservationDet.Columns["Dorm_Rate"].DefaultCellStyle.Format = "0.00";
                    dgvReservationDet.Columns["Reserv_Date"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    dgvReservationDet.Columns["NoOfRooms"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    dgvReservationDet.Columns["Room_Rate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    dgvReservationDet.Columns["NoOfBeds"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    dgvReservationDet.Columns["Dorm_Rate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in LoadPageData");
            }
        }

        private void dgvReservationDet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try 
	        {
                if (dgvReservationDet.SelectedRows.Count > 0)
                {
                    frmCancelReservation frmcancel = new frmCancelReservation();
                    DataGridViewRow grdRow = dgvReservationDet.SelectedRows[0];
                    //frmcancel.reservationDayWiseId = Convert.ToInt32(grdRow.Cells["reservation_daywise_status_id"].Value);
                    frmcancel.ShowDialog();
                }   		
	        }
	        catch (Exception ex)
	        {
                ExceptionLogging.SendErrorToText(ex,"dgvReservationDet_CellDoubleClick");
	        }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            dgvReservationDet_CellDoubleClick(sender, null);
        }
    }
}
