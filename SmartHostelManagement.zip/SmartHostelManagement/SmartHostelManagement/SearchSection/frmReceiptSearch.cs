﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;
using SmartHostelManagement.Master;

namespace SmartHostelManagement.Search
{
    public partial class frmReceiptSearch : Form
    {
        ReceiptCaller objReceiptData = new ReceiptCaller();
        public string recpTagChar { get; set; }
        public int receptPayId { get; set; }

        public frmReceiptSearch()
        {
            InitializeComponent();
            dtmReserFrom.Value = DateTime.Today.AddDays(-7);
            dtmResrvTo.Value = DateTime.Today;
        }

        private EL.FilterClass RefreshFilter()
        {
            return new EL.FilterClass
            {
                FinEnd = CommonVariables.dtmFinancialEnd.Year * 100 + CommonVariables.dtmFinancialEnd.Month,
                FinStart = CommonVariables.dtmFinancialStart.Year * 100 + CommonVariables.dtmFinancialStart.Month,
                FromDate = dtmReserFrom.Value,
                ToDate = dtmResrvTo.Value,
                BillNumber = 0,
                FolioNumber = 0,
                RecordCategory = 0,
                RecordNumber = 0,
                RoomCategory = 0,
                SearchByText = string.Empty,
                tagChar = this.recpTagChar,
                UniqueId = 0
            };
        }

        private void frmReceiptSearch_Load(object sender, EventArgs e)
        {
            try
            {
                IList<EL.receipt_payment> lstReceptPay = objReceiptData.GetListofReceiptData(RefreshFilter()).ToList();

                var dbData = lstReceptPay.Select((c, index) =>
                    new
                    {
                        SlNo = index + 1,
                        c.recpt_pay_id,
                        Reservation_Number = c.reservationnumber,
                        Guest_Name = c.cname,
                        Voucher = c.receipt_No,
                        Date = c.Rdate,
                        Amount = c.total_amt,
                        RecdBy = c.Recd_by
                    }).ToList();

                dgvReservationDet.DataSource = dbData.ToList();

                dgvReservationDet.Columns["recpt_pay_id"].Visible = false;
                dgvReservationDet.Columns["SlNo"].Frozen = true;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error on page load.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvReservationDet.SelectedRows.Count > -1)
                {
                    var test = dgvReservationDet.SelectedRows[0].Cells["recpt_pay_id"].Value;

                    this.receptPayId = Convert.ToInt32(test);
                }
                else
                    this.receptPayId = 0;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error on  button1_Click.");
            }
        }

        private void btnExist_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            frmReceiptSearch_Load(sender, e);
        }
    }
}
