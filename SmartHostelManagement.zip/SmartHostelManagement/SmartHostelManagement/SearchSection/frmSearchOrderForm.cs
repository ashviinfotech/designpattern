﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Search
{
    public partial class frmSearchOrderForm : Form
    {
        string sqlConString { get; set; }
        public int orderFormID { get; private set; }

        public frmSearchOrderForm()
        {
            InitializeComponent();
        }

        private void frmSearchOrderForm_Load(object sender, EventArgs e)
        {
            using (ISIPMEntities dbContext = new ISIPMEntities())
                this.sqlConString = dbContext.Database.Connection.ConnectionString;
            dtmFromDate.Value = DateTime.Today.AddDays(-30);
            dtmToDate.Value = DateTime.Today;
            LoadKotsData();
        }

        private void LoadKotsData()
        {
            try
            {
                string frmDate = dtmFromDate.Value.Date.ToString("MM/dd/yyyy");
                string toDate = dtmToDate.Value.Date.ToString("MM/dd/yyyy");

                string sqlQuery = @"SELECT ROW_NUMBER() OVER (ORDER BY ChannelOrder_Id ASC) Slno, ChannelOrder_Id, Bill_No,Bdate,Btime,Name_guest,addr1_guest [Address],addr2_guest [Address2]
                    FROM channelorder WHERE CAST(Bdate AS DATE) BETWEEN CAST('" + frmDate + "' AS DATE) AND CAST('" + toDate + "' AS DATE)  ORDER BY ChannelOrder_Id ASC";

                DataTable dtKot = new MasterCaller().GetDataTableData(sqlQuery, "ChannelOrder");

                dgvKotDetails.DataSource = dtKot;
                dgvKotDetails.Columns["Slno"].Frozen = true;
                dgvKotDetails.Columns["ChannelOrder_Id"].Visible = false;

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadKotsData();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvKotDetails.SelectedRows.Count > 0)
                {
                    this.orderFormID = Convert.ToInt32(dgvKotDetails.SelectedRows[0].Cells["ChannelOrder_Id"].Value);
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please select record !", "");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvKotDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvKotDetails.SelectedRows.Count > 0)
                {
                    this.orderFormID = Convert.ToInt32(dgvKotDetails.SelectedRows[0].Cells["ChannelOrder_Id"].Value);
                    this.Close();
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please select record !", "");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }
    }
}
