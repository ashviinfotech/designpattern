﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Search
{
    public partial class frmReservation : Form
    {
        ReservationCaller objReservBook = new ReservationCaller();

        public int reservationid { get; private set; }
        public int reservationNum { get; private set; }
        public string tagReservation { get; set; }

        public frmReservation()
        {
            InitializeComponent();
            rdbNumber.Checked = true;
        }

        EL.FilterClass RefreshFilter()
        {
            return new EL.FilterClass
            {
                BillNumber = 0,
                FinEnd = CommonVariables.dtmFinancialEnd.Year * 100 + CommonVariables.dtmFinancialEnd.Month,
                FinStart = CommonVariables.dtmFinancialStart.Year * 100 + CommonVariables.dtmFinancialStart.Month,
                FolioNumber = 0,
                RecordCategory = 0,
                FromDate = dtmReserFrom.Value,
                ToDate = dateTimePicker1.Value,
                RecordNumber = 0,
                RoomCategory = 0,
                SearchByText = string.Empty,
                tagChar = tagReservation,
                UniqueId = 0,
                Cancel = false
            };
        }

        private void frmReservation_Load(object sender, EventArgs e)
        {
            try
            {
                IList<EL.RESERVATION_CHECKIN_WALKIN> lstReserDetails = rdbNumber.Checked ? 
                    objReservBook.GetListOfCancelActiveReservation(RefreshFilter()).OrderBy(x=>x.reservation_NUMBER).ToList() :
                    objReservBook.GetListOfCancelActiveReservation(RefreshFilter()).OrderBy(x => x.reservation_PI_frstname).ToList();

                var dbData = lstReserDetails.Select((c, index) =>
                    new
                    {
                        SlNo = index + 1,
                        c.reservation_ID,
                        Reservation_Number = c.reservation_NUMBER,
                        Rooms_No = c.reservation_ROOMS,
                        Name = c.reservation_PI_frstname,
                        Period_Form = c.reservation_CHECKIN.HasValue ? Convert.ToDateTime(c.reservation_CHECKIN).ToString("dd/MMM/yyyy") : string.Empty,
                        Period_To = c.reservation_CHKOUT.HasValue ? Convert.ToDateTime(c.reservation_CHKOUT).ToString("dd/MMM/yyyy") : string.Empty,
                        CheckIn = c.reservation_realCHECKIN.HasValue ? Convert.ToDateTime(c.reservation_realCHECKIN).ToString("dd/MMM/yyyy hh:mm") : string.Empty,
                        CheckOut = c.reservation_realCHECKOUT.HasValue ? Convert.ToDateTime(c.reservation_realCHECKOUT).ToString("dd/MMM/yyyy hh:mm") : string.Empty
                    }).ToList();

                dgvReservationDet.DataSource = dbData.ToList();

                dgvReservationDet.Columns["reservation_ID"].Visible = false;
                dgvReservationDet.Columns["SlNo"].Frozen = true;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex,"-->Error on page load.");
            }
        } 

        private void btnExist_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgvReservationDet.SelectedRows.Count > -1)
            {
                var test = dgvReservationDet.SelectedRows[0].Cells["reservation_ID"].Value;
                this.reservationid = Convert.ToInt32(test);
                this.reservationNum = Convert.ToInt32(dgvReservationDet.SelectedRows[0].Cells["Reservation_Number"].Value);
                this.Close();
            }
            else
            {
                this.reservationid = 0;
                this.reservationNum = 0;
            }   
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            frmReservation_Load(sender, e);
        }

        private void rdbName_CheckedChanged(object sender, EventArgs e)
        {
            frmReservation_Load(sender, e);
        }

        private void rdbNumber_CheckedChanged(object sender, EventArgs e)
        {
            frmReservation_Load(sender, e);
        }
    }
}
