﻿namespace SmartHostelManagement
{
    partial class MasterLayout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MasterLayout));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.masterMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.nationalityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.titleMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.companyGuestMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guestTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guestMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.roomTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.companyDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.countryMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gSTReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.customerCardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomBillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dormatoryBillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dailyEntryFormCombinedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dailyEntryFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiptVoucherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.roomUnbilledToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dormatoryUnbilledToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentVoucherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.modifyCFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mergeCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.membershipDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiptSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.hostelMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelEstimatetoolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelBookingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelBookingStatusChartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.collectionSummaryToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.occupancyChartDAILYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.occupancyChartMONTHLYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cashCollectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.partyWiseSummaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.collectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revenueSummaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.revenueDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unbilledCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statementOfNationalityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.advanceSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statementOfCashRecieiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.billStatementToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.billStatementDateWiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listOfRoomTypesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listOfCashReceiptTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listOfAdditionalGuestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cFormDateWiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.partyWiseSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monthlyHostelOccupancyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountwiseAdvanceSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.semicaterMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miscHeadMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seminarBookingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seminarBookingStatusChartTimeBasisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.seminarBookingStatusChartDayBasisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.seminarBillingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelledReservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.semReportMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.occupancyByNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collectionSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collectionSummaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.occupancyRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revenueSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revenueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unbilledPartyListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemWiseSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conferenceHallCancellationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditSaleRegisterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.billStatementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.billStatementForSeminarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.occupancyChartDailyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.occupancyChartMONTHLYToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cashCollectionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.miscHeadMasterToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.miscEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.cateringOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orderChartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prepareChannelBillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.channelBillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buffetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.waiterMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMasterToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rawMaterialKitchenMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReceiptBOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kOTEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.vendorMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.storeInventoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.storeReceiptMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.storeReturbMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.requistionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.requistionCreatedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.requisitionIssuedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userPermissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeFinancialYearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.existToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterMenu,
            this.transMenu,
            this.hostelMenu,
            this.toolStripMenuItem1,
            this.reportMenu,
            this.semicaterMenu,
            this.semReportMenu,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.securityToolStripMenuItem,
            this.windowsToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.semicaterMenu;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1002, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // masterMenu
            // 
            this.masterMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nationalityToolStripMenuItem,
            this.titleMasterToolStripMenuItem,
            this.guestToolStripMenuItem,
            this.roomMenuItem1,
            this.toolStripSeparator1,
            this.companyDetailsToolStripMenuItem,
            this.countryMasterToolStripMenuItem,
            this.accountTypeToolStripMenuItem,
            this.gSTReturnToolStripMenuItem});
            this.masterMenu.Name = "masterMenu";
            this.masterMenu.Size = new System.Drawing.Size(55, 20);
            this.masterMenu.Text = "&Master";
            // 
            // nationalityToolStripMenuItem
            // 
            this.nationalityToolStripMenuItem.Name = "nationalityToolStripMenuItem";
            this.nationalityToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.nationalityToolStripMenuItem.Text = "Nationality";
            this.nationalityToolStripMenuItem.Click += new System.EventHandler(this.nationalityToolStripMenuItem_Click);
            // 
            // titleMasterToolStripMenuItem
            // 
            this.titleMasterToolStripMenuItem.Name = "titleMasterToolStripMenuItem";
            this.titleMasterToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.titleMasterToolStripMenuItem.Text = "Title Master";
            this.titleMasterToolStripMenuItem.Click += new System.EventHandler(this.titleMasterToolStripMenuItem_Click);
            // 
            // guestToolStripMenuItem
            // 
            this.guestToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companyGuestMasterToolStripMenuItem,
            this.guestTypeToolStripMenuItem,
            this.guestMasterToolStripMenuItem});
            this.guestToolStripMenuItem.Name = "guestToolStripMenuItem";
            this.guestToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.guestToolStripMenuItem.Text = "Guest ";
            // 
            // companyGuestMasterToolStripMenuItem
            // 
            this.companyGuestMasterToolStripMenuItem.Name = "companyGuestMasterToolStripMenuItem";
            this.companyGuestMasterToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.companyGuestMasterToolStripMenuItem.Text = "Company Guest Master";
            this.companyGuestMasterToolStripMenuItem.Click += new System.EventHandler(this.companyGuestMasterToolStripMenuItem_Click);
            // 
            // guestTypeToolStripMenuItem
            // 
            this.guestTypeToolStripMenuItem.Name = "guestTypeToolStripMenuItem";
            this.guestTypeToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.guestTypeToolStripMenuItem.Text = "Guest Type";
            this.guestTypeToolStripMenuItem.Click += new System.EventHandler(this.guestTypeToolStripMenuItem_Click);
            // 
            // guestMasterToolStripMenuItem
            // 
            this.guestMasterToolStripMenuItem.Name = "guestMasterToolStripMenuItem";
            this.guestMasterToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.guestMasterToolStripMenuItem.Text = "Guest Master";
            this.guestMasterToolStripMenuItem.Click += new System.EventHandler(this.guestMasterToolStripMenuItem_Click);
            // 
            // roomMenuItem1
            // 
            this.roomMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.roomTypeToolStripMenuItem,
            this.roomNumberToolStripMenuItem});
            this.roomMenuItem1.Name = "roomMenuItem1";
            this.roomMenuItem1.Size = new System.Drawing.Size(164, 22);
            this.roomMenuItem1.Text = "Rooms";
            // 
            // roomTypeToolStripMenuItem
            // 
            this.roomTypeToolStripMenuItem.Name = "roomTypeToolStripMenuItem";
            this.roomTypeToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.roomTypeToolStripMenuItem.Text = "Room Type";
            this.roomTypeToolStripMenuItem.Click += new System.EventHandler(this.roomTypeToolStripMenuItem_Click);
            // 
            // roomNumberToolStripMenuItem
            // 
            this.roomNumberToolStripMenuItem.Name = "roomNumberToolStripMenuItem";
            this.roomNumberToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.roomNumberToolStripMenuItem.Text = "Room Number";
            this.roomNumberToolStripMenuItem.Click += new System.EventHandler(this.roomNumberToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(161, 6);
            // 
            // companyDetailsToolStripMenuItem
            // 
            this.companyDetailsToolStripMenuItem.Name = "companyDetailsToolStripMenuItem";
            this.companyDetailsToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.companyDetailsToolStripMenuItem.Text = "Company Details";
            this.companyDetailsToolStripMenuItem.Click += new System.EventHandler(this.roomsToolStripMenuItem_Click);
            // 
            // countryMasterToolStripMenuItem
            // 
            this.countryMasterToolStripMenuItem.Name = "countryMasterToolStripMenuItem";
            this.countryMasterToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.countryMasterToolStripMenuItem.Text = "Country";
            this.countryMasterToolStripMenuItem.Click += new System.EventHandler(this.roomNumberMasterToolStripMenuItem_Click);
            // 
            // accountTypeToolStripMenuItem
            // 
            this.accountTypeToolStripMenuItem.Name = "accountTypeToolStripMenuItem";
            this.accountTypeToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.accountTypeToolStripMenuItem.Text = "Account Type";
            this.accountTypeToolStripMenuItem.Click += new System.EventHandler(this.accountTypeToolStripMenuItem_Click);
            // 
            // gSTReturnToolStripMenuItem
            // 
            this.gSTReturnToolStripMenuItem.Name = "gSTReturnToolStripMenuItem";
            this.gSTReturnToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.gSTReturnToolStripMenuItem.Text = "GST Return";
            this.gSTReturnToolStripMenuItem.Click += new System.EventHandler(this.gSTReturnToolStripMenuItem_Click);
            // 
            // transMenu
            // 
            this.transMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerCardToolStripMenuItem,
            this.roomBillToolStripMenuItem,
            this.dormatoryBillToolStripMenuItem,
            this.dailyEntryFormCombinedToolStripMenuItem,
            this.dailyEntryFormToolStripMenuItem,
            this.receiptVoucherToolStripMenuItem,
            this.toolStripSeparator3,
            this.roomUnbilledToolStripMenuItem,
            this.dormatoryUnbilledToolStripMenuItem,
            this.paymentVoucherToolStripMenuItem,
            this.toolStripSeparator4,
            this.modifyCFormToolStripMenuItem,
            this.mergeCustomerToolStripMenuItem,
            this.membershipDetailsToolStripMenuItem,
            this.receiptSummaryToolStripMenuItem,
            this.toolStripSeparator2});
            this.transMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.transMenu.Name = "transMenu";
            this.transMenu.Size = new System.Drawing.Size(79, 20);
            this.transMenu.Text = "&Transaction";
            // 
            // customerCardToolStripMenuItem
            // 
            this.customerCardToolStripMenuItem.Name = "customerCardToolStripMenuItem";
            this.customerCardToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.customerCardToolStripMenuItem.Text = "Customer Card";
            this.customerCardToolStripMenuItem.Click += new System.EventHandler(this.customerCardToolStripMenuItem_Click);
            // 
            // roomBillToolStripMenuItem
            // 
            this.roomBillToolStripMenuItem.Name = "roomBillToolStripMenuItem";
            this.roomBillToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.roomBillToolStripMenuItem.Text = "Room Bill";
            this.roomBillToolStripMenuItem.Click += new System.EventHandler(this.roomBillToolStripMenuItem_Click);
            // 
            // dormatoryBillToolStripMenuItem
            // 
            this.dormatoryBillToolStripMenuItem.Enabled = false;
            this.dormatoryBillToolStripMenuItem.Name = "dormatoryBillToolStripMenuItem";
            this.dormatoryBillToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.dormatoryBillToolStripMenuItem.Text = "Dormatory Bill";
            this.dormatoryBillToolStripMenuItem.Visible = false;
            this.dormatoryBillToolStripMenuItem.Click += new System.EventHandler(this.dormatoryBillToolStripMenuItem_Click);
            // 
            // dailyEntryFormCombinedToolStripMenuItem
            // 
            this.dailyEntryFormCombinedToolStripMenuItem.Enabled = false;
            this.dailyEntryFormCombinedToolStripMenuItem.Name = "dailyEntryFormCombinedToolStripMenuItem";
            this.dailyEntryFormCombinedToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.dailyEntryFormCombinedToolStripMenuItem.Text = "Daily Entry form Combined";
            this.dailyEntryFormCombinedToolStripMenuItem.Visible = false;
            this.dailyEntryFormCombinedToolStripMenuItem.Click += new System.EventHandler(this.dailyEntryFormCombinedToolStripMenuItem_Click);
            // 
            // dailyEntryFormToolStripMenuItem
            // 
            this.dailyEntryFormToolStripMenuItem.Name = "dailyEntryFormToolStripMenuItem";
            this.dailyEntryFormToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.dailyEntryFormToolStripMenuItem.Text = "Daily Entry Form";
            this.dailyEntryFormToolStripMenuItem.Click += new System.EventHandler(this.dailyEntryFormToolStripMenuItem_Click);
            // 
            // receiptVoucherToolStripMenuItem
            // 
            this.receiptVoucherToolStripMenuItem.Name = "receiptVoucherToolStripMenuItem";
            this.receiptVoucherToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.receiptVoucherToolStripMenuItem.Text = "Receipt Voucher";
            this.receiptVoucherToolStripMenuItem.Click += new System.EventHandler(this.receiptVoucherToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(215, 6);
            // 
            // roomUnbilledToolStripMenuItem
            // 
            this.roomUnbilledToolStripMenuItem.Enabled = false;
            this.roomUnbilledToolStripMenuItem.Name = "roomUnbilledToolStripMenuItem";
            this.roomUnbilledToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.roomUnbilledToolStripMenuItem.Text = "Room Unbilled";
            this.roomUnbilledToolStripMenuItem.Visible = false;
            this.roomUnbilledToolStripMenuItem.Click += new System.EventHandler(this.roomUnbilledToolStripMenuItem_Click);
            // 
            // dormatoryUnbilledToolStripMenuItem
            // 
            this.dormatoryUnbilledToolStripMenuItem.Enabled = false;
            this.dormatoryUnbilledToolStripMenuItem.Name = "dormatoryUnbilledToolStripMenuItem";
            this.dormatoryUnbilledToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.dormatoryUnbilledToolStripMenuItem.Text = "Dormatory Unbilled";
            this.dormatoryUnbilledToolStripMenuItem.Visible = false;
            this.dormatoryUnbilledToolStripMenuItem.Click += new System.EventHandler(this.dormatoryUnbilledToolStripMenuItem_Click);
            // 
            // paymentVoucherToolStripMenuItem
            // 
            this.paymentVoucherToolStripMenuItem.Name = "paymentVoucherToolStripMenuItem";
            this.paymentVoucherToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.paymentVoucherToolStripMenuItem.Text = "Receipt/Payment Voucher";
            this.paymentVoucherToolStripMenuItem.Click += new System.EventHandler(this.paymentVoucherToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(215, 6);
            this.toolStripSeparator4.Visible = false;
            // 
            // modifyCFormToolStripMenuItem
            // 
            this.modifyCFormToolStripMenuItem.Enabled = false;
            this.modifyCFormToolStripMenuItem.Name = "modifyCFormToolStripMenuItem";
            this.modifyCFormToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.modifyCFormToolStripMenuItem.Text = "Modify C-Form Number";
            this.modifyCFormToolStripMenuItem.Visible = false;
            this.modifyCFormToolStripMenuItem.Click += new System.EventHandler(this.modifyCFormToolStripMenuItem_Click);
            // 
            // mergeCustomerToolStripMenuItem
            // 
            this.mergeCustomerToolStripMenuItem.Enabled = false;
            this.mergeCustomerToolStripMenuItem.Name = "mergeCustomerToolStripMenuItem";
            this.mergeCustomerToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.mergeCustomerToolStripMenuItem.Text = "Merge Customers";
            this.mergeCustomerToolStripMenuItem.Visible = false;
            this.mergeCustomerToolStripMenuItem.Click += new System.EventHandler(this.mergeCustomerToolStripMenuItem_Click);
            // 
            // membershipDetailsToolStripMenuItem
            // 
            this.membershipDetailsToolStripMenuItem.Enabled = false;
            this.membershipDetailsToolStripMenuItem.Name = "membershipDetailsToolStripMenuItem";
            this.membershipDetailsToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.membershipDetailsToolStripMenuItem.Text = "Membership Details";
            this.membershipDetailsToolStripMenuItem.Visible = false;
            this.membershipDetailsToolStripMenuItem.Click += new System.EventHandler(this.membershipDetailsToolStripMenuItem_Click);
            // 
            // receiptSummaryToolStripMenuItem
            // 
            this.receiptSummaryToolStripMenuItem.Name = "receiptSummaryToolStripMenuItem";
            this.receiptSummaryToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.receiptSummaryToolStripMenuItem.Text = "Receipt Summary";
            this.receiptSummaryToolStripMenuItem.Click += new System.EventHandler(this.receiptSummaryToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(215, 6);
            // 
            // hostelMenu
            // 
            this.hostelMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hostelEstimatetoolStripMenuItem1,
            this.hostelBookingToolStripMenuItem,
            this.hostelBookingStatusChartToolStripMenuItem});
            this.hostelMenu.Name = "hostelMenu";
            this.hostelMenu.Size = new System.Drawing.Size(53, 20);
            this.hostelMenu.Text = "&Hostel";
            // 
            // hostelEstimatetoolStripMenuItem1
            // 
            this.hostelEstimatetoolStripMenuItem1.Name = "hostelEstimatetoolStripMenuItem1";
            this.hostelEstimatetoolStripMenuItem1.Size = new System.Drawing.Size(219, 22);
            this.hostelEstimatetoolStripMenuItem1.Text = "Hostel Estimate";
            this.hostelEstimatetoolStripMenuItem1.Click += new System.EventHandler(this.hostelEstimatetoolStripMenuItem1_Click);
            // 
            // hostelBookingToolStripMenuItem
            // 
            this.hostelBookingToolStripMenuItem.Name = "hostelBookingToolStripMenuItem";
            this.hostelBookingToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.hostelBookingToolStripMenuItem.Text = "Hostel Booking";
            this.hostelBookingToolStripMenuItem.Click += new System.EventHandler(this.hostelBookingToolStripMenuItem_Click);
            // 
            // hostelBookingStatusChartToolStripMenuItem
            // 
            this.hostelBookingStatusChartToolStripMenuItem.Name = "hostelBookingStatusChartToolStripMenuItem";
            this.hostelBookingStatusChartToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.hostelBookingStatusChartToolStripMenuItem.Text = "Hostel Booking status chart";
            this.hostelBookingStatusChartToolStripMenuItem.Click += new System.EventHandler(this.hostelBookingStatusChartToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.collectionSummaryToolStripMenuItem2,
            this.occupancyChartDAILYToolStripMenuItem,
            this.occupancyChartMONTHLYToolStripMenuItem,
            this.cashCollectionToolStripMenuItem,
            this.partyWiseSummaryToolStripMenuItem1});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(91, 20);
            this.toolStripMenuItem1.Text = "&Hostel &Report";
            // 
            // collectionSummaryToolStripMenuItem2
            // 
            this.collectionSummaryToolStripMenuItem2.Name = "collectionSummaryToolStripMenuItem2";
            this.collectionSummaryToolStripMenuItem2.Size = new System.Drawing.Size(225, 22);
            this.collectionSummaryToolStripMenuItem2.Text = "Collection Summary";
            this.collectionSummaryToolStripMenuItem2.Click += new System.EventHandler(this.collectionSummaryToolStripMenuItem2_Click);
            // 
            // occupancyChartDAILYToolStripMenuItem
            // 
            this.occupancyChartDAILYToolStripMenuItem.Name = "occupancyChartDAILYToolStripMenuItem";
            this.occupancyChartDAILYToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.occupancyChartDAILYToolStripMenuItem.Text = "Occupancy Chart DAILY";
            this.occupancyChartDAILYToolStripMenuItem.Click += new System.EventHandler(this.occupancyChartDAILYToolStripMenuItem_Click);
            // 
            // occupancyChartMONTHLYToolStripMenuItem
            // 
            this.occupancyChartMONTHLYToolStripMenuItem.Name = "occupancyChartMONTHLYToolStripMenuItem";
            this.occupancyChartMONTHLYToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.occupancyChartMONTHLYToolStripMenuItem.Text = "Occupancy Chart MONTHLY";
            this.occupancyChartMONTHLYToolStripMenuItem.Click += new System.EventHandler(this.occupancyChartMONTHLYToolStripMenuItem_Click);
            // 
            // cashCollectionToolStripMenuItem
            // 
            this.cashCollectionToolStripMenuItem.Name = "cashCollectionToolStripMenuItem";
            this.cashCollectionToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.cashCollectionToolStripMenuItem.Text = "Cash Collection";
            this.cashCollectionToolStripMenuItem.Click += new System.EventHandler(this.cashCollectionToolStripMenuItem_Click);
            // 
            // partyWiseSummaryToolStripMenuItem1
            // 
            this.partyWiseSummaryToolStripMenuItem1.Name = "partyWiseSummaryToolStripMenuItem1";
            this.partyWiseSummaryToolStripMenuItem1.Size = new System.Drawing.Size(225, 22);
            this.partyWiseSummaryToolStripMenuItem1.Text = "Party Wise Summary";
            this.partyWiseSummaryToolStripMenuItem1.Click += new System.EventHandler(this.partyWiseSummaryToolStripMenuItem1_Click);
            // 
            // reportMenu
            // 
            this.reportMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.collectionToolStripMenuItem,
            this.revenueSummaryToolStripMenuItem1,
            this.revenueDetailToolStripMenuItem,
            this.unbilledCustomerToolStripMenuItem,
            this.statementOfNationalityToolStripMenuItem,
            this.salesSummaryToolStripMenuItem,
            this.advanceSummaryToolStripMenuItem,
            this.statementOfCashRecieiptToolStripMenuItem,
            this.billStatementToolStripMenuItem1,
            this.billStatementDateWiseToolStripMenuItem,
            this.listOfRoomTypesToolStripMenuItem,
            this.listOfCashReceiptTypeToolStripMenuItem,
            this.listOfAdditionalGuestToolStripMenuItem,
            this.cFormDateWiseToolStripMenuItem,
            this.cFormToolStripMenuItem,
            this.partyWiseSummaryToolStripMenuItem,
            this.monthlyHostelOccupancyToolStripMenuItem,
            this.accountwiseAdvanceSummaryToolStripMenuItem});
            this.reportMenu.Enabled = false;
            this.reportMenu.Name = "reportMenu";
            this.reportMenu.Size = new System.Drawing.Size(59, 20);
            this.reportMenu.Text = "&Reports";
            this.reportMenu.Visible = false;
            // 
            // collectionToolStripMenuItem
            // 
            this.collectionToolStripMenuItem.Name = "collectionToolStripMenuItem";
            this.collectionToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.collectionToolStripMenuItem.Text = "Collection";
            this.collectionToolStripMenuItem.Click += new System.EventHandler(this.collectionToolStripMenuItem_Click);
            // 
            // revenueSummaryToolStripMenuItem1
            // 
            this.revenueSummaryToolStripMenuItem1.Name = "revenueSummaryToolStripMenuItem1";
            this.revenueSummaryToolStripMenuItem1.Size = new System.Drawing.Size(273, 22);
            this.revenueSummaryToolStripMenuItem1.Text = "Revenue Summary";
            this.revenueSummaryToolStripMenuItem1.Click += new System.EventHandler(this.revenueSummaryToolStripMenuItem1_Click);
            // 
            // revenueDetailToolStripMenuItem
            // 
            this.revenueDetailToolStripMenuItem.Name = "revenueDetailToolStripMenuItem";
            this.revenueDetailToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.revenueDetailToolStripMenuItem.Text = "Revenue Detail";
            this.revenueDetailToolStripMenuItem.Click += new System.EventHandler(this.revenueDetailToolStripMenuItem_Click);
            // 
            // unbilledCustomerToolStripMenuItem
            // 
            this.unbilledCustomerToolStripMenuItem.Name = "unbilledCustomerToolStripMenuItem";
            this.unbilledCustomerToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.unbilledCustomerToolStripMenuItem.Text = "Unbilled Customer";
            this.unbilledCustomerToolStripMenuItem.Click += new System.EventHandler(this.unbilledCustomerToolStripMenuItem_Click);
            // 
            // statementOfNationalityToolStripMenuItem
            // 
            this.statementOfNationalityToolStripMenuItem.Name = "statementOfNationalityToolStripMenuItem";
            this.statementOfNationalityToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.statementOfNationalityToolStripMenuItem.Text = "Statement of Nationality";
            this.statementOfNationalityToolStripMenuItem.Click += new System.EventHandler(this.statementOfNationalityToolStripMenuItem_Click);
            // 
            // salesSummaryToolStripMenuItem
            // 
            this.salesSummaryToolStripMenuItem.Name = "salesSummaryToolStripMenuItem";
            this.salesSummaryToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.salesSummaryToolStripMenuItem.Text = "Sales Summary";
            this.salesSummaryToolStripMenuItem.Click += new System.EventHandler(this.salesSummaryToolStripMenuItem_Click);
            // 
            // advanceSummaryToolStripMenuItem
            // 
            this.advanceSummaryToolStripMenuItem.Name = "advanceSummaryToolStripMenuItem";
            this.advanceSummaryToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.advanceSummaryToolStripMenuItem.Text = "Advance Summary";
            this.advanceSummaryToolStripMenuItem.Click += new System.EventHandler(this.advanceSummaryToolStripMenuItem_Click);
            // 
            // statementOfCashRecieiptToolStripMenuItem
            // 
            this.statementOfCashRecieiptToolStripMenuItem.Name = "statementOfCashRecieiptToolStripMenuItem";
            this.statementOfCashRecieiptToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.statementOfCashRecieiptToolStripMenuItem.Text = "Statement of Cash Receipt against bill";
            this.statementOfCashRecieiptToolStripMenuItem.Click += new System.EventHandler(this.statementOfCashRecieiptToolStripMenuItem_Click);
            // 
            // billStatementToolStripMenuItem1
            // 
            this.billStatementToolStripMenuItem1.Name = "billStatementToolStripMenuItem1";
            this.billStatementToolStripMenuItem1.Size = new System.Drawing.Size(273, 22);
            this.billStatementToolStripMenuItem1.Text = "Bill Statement";
            this.billStatementToolStripMenuItem1.Click += new System.EventHandler(this.billStatementToolStripMenuItem1_Click);
            // 
            // billStatementDateWiseToolStripMenuItem
            // 
            this.billStatementDateWiseToolStripMenuItem.Name = "billStatementDateWiseToolStripMenuItem";
            this.billStatementDateWiseToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.billStatementDateWiseToolStripMenuItem.Text = "Bill Statement (Date Wise)";
            this.billStatementDateWiseToolStripMenuItem.Click += new System.EventHandler(this.billStatementDateWiseToolStripMenuItem_Click);
            // 
            // listOfRoomTypesToolStripMenuItem
            // 
            this.listOfRoomTypesToolStripMenuItem.Name = "listOfRoomTypesToolStripMenuItem";
            this.listOfRoomTypesToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.listOfRoomTypesToolStripMenuItem.Text = "List of Room Types";
            this.listOfRoomTypesToolStripMenuItem.Click += new System.EventHandler(this.listOfRoomTypesToolStripMenuItem_Click);
            // 
            // listOfCashReceiptTypeToolStripMenuItem
            // 
            this.listOfCashReceiptTypeToolStripMenuItem.Name = "listOfCashReceiptTypeToolStripMenuItem";
            this.listOfCashReceiptTypeToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.listOfCashReceiptTypeToolStripMenuItem.Text = "List of Cash Receipt Type";
            this.listOfCashReceiptTypeToolStripMenuItem.Click += new System.EventHandler(this.listOfCashReceiptTypeToolStripMenuItem_Click);
            // 
            // listOfAdditionalGuestToolStripMenuItem
            // 
            this.listOfAdditionalGuestToolStripMenuItem.Name = "listOfAdditionalGuestToolStripMenuItem";
            this.listOfAdditionalGuestToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.listOfAdditionalGuestToolStripMenuItem.Text = "List of Additional Guest";
            this.listOfAdditionalGuestToolStripMenuItem.Click += new System.EventHandler(this.listOfAdditionalGuestToolStripMenuItem_Click);
            // 
            // cFormDateWiseToolStripMenuItem
            // 
            this.cFormDateWiseToolStripMenuItem.Name = "cFormDateWiseToolStripMenuItem";
            this.cFormDateWiseToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.cFormDateWiseToolStripMenuItem.Text = "C-Form Date Wise";
            this.cFormDateWiseToolStripMenuItem.Click += new System.EventHandler(this.cFormDateWiseToolStripMenuItem_Click);
            // 
            // cFormToolStripMenuItem
            // 
            this.cFormToolStripMenuItem.Name = "cFormToolStripMenuItem";
            this.cFormToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.cFormToolStripMenuItem.Text = "C-Form";
            this.cFormToolStripMenuItem.Click += new System.EventHandler(this.cFormToolStripMenuItem_Click);
            // 
            // partyWiseSummaryToolStripMenuItem
            // 
            this.partyWiseSummaryToolStripMenuItem.Name = "partyWiseSummaryToolStripMenuItem";
            this.partyWiseSummaryToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.partyWiseSummaryToolStripMenuItem.Text = "Party Wise Summary";
            this.partyWiseSummaryToolStripMenuItem.Click += new System.EventHandler(this.partyWiseSummaryToolStripMenuItem_Click);
            // 
            // monthlyHostelOccupancyToolStripMenuItem
            // 
            this.monthlyHostelOccupancyToolStripMenuItem.Name = "monthlyHostelOccupancyToolStripMenuItem";
            this.monthlyHostelOccupancyToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.monthlyHostelOccupancyToolStripMenuItem.Text = "Monthly Hostel Occupancy";
            this.monthlyHostelOccupancyToolStripMenuItem.Click += new System.EventHandler(this.monthlyHostelOccupancyToolStripMenuItem_Click);
            // 
            // accountwiseAdvanceSummaryToolStripMenuItem
            // 
            this.accountwiseAdvanceSummaryToolStripMenuItem.Name = "accountwiseAdvanceSummaryToolStripMenuItem";
            this.accountwiseAdvanceSummaryToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.accountwiseAdvanceSummaryToolStripMenuItem.Text = "Account-wise Advance Summary";
            this.accountwiseAdvanceSummaryToolStripMenuItem.Click += new System.EventHandler(this.accountwiseAdvanceSummaryToolStripMenuItem_Click);
            // 
            // semicaterMenu
            // 
            this.semicaterMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuMasterToolStripMenuItem,
            this.miscHeadMasterToolStripMenuItem,
            this.seminarBookingToolStripMenuItem,
            this.seminarBookingStatusChartTimeBasisToolStripMenuItem,
            this.toolStripMenuItem2,
            this.seminarBookingStatusChartDayBasisToolStripMenuItem,
            this.toolStripMenuItem3,
            this.seminarBillingToolStripMenuItem,
            this.reservationToolStripMenuItem,
            this.cancelledReservationToolStripMenuItem});
            this.semicaterMenu.Name = "semicaterMenu";
            this.semicaterMenu.Size = new System.Drawing.Size(62, 20);
            this.semicaterMenu.Text = "&Seminar";
            // 
            // menuMasterToolStripMenuItem
            // 
            this.menuMasterToolStripMenuItem.Enabled = false;
            this.menuMasterToolStripMenuItem.Name = "menuMasterToolStripMenuItem";
            this.menuMasterToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.menuMasterToolStripMenuItem.Text = "Menu Master";
            this.menuMasterToolStripMenuItem.Visible = false;
            this.menuMasterToolStripMenuItem.Click += new System.EventHandler(this.menuMasterToolStripMenuItem_Click);
            // 
            // miscHeadMasterToolStripMenuItem
            // 
            this.miscHeadMasterToolStripMenuItem.Enabled = false;
            this.miscHeadMasterToolStripMenuItem.Name = "miscHeadMasterToolStripMenuItem";
            this.miscHeadMasterToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.miscHeadMasterToolStripMenuItem.Text = "Misc Head Master";
            this.miscHeadMasterToolStripMenuItem.Visible = false;
            this.miscHeadMasterToolStripMenuItem.Click += new System.EventHandler(this.miscHeadMasterToolStripMenuItem_Click);
            // 
            // seminarBookingToolStripMenuItem
            // 
            this.seminarBookingToolStripMenuItem.Name = "seminarBookingToolStripMenuItem";
            this.seminarBookingToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.seminarBookingToolStripMenuItem.Text = "Seminar Booking";
            this.seminarBookingToolStripMenuItem.Click += new System.EventHandler(this.seminarBookingToolStripMenuItem_Click);
            // 
            // seminarBookingStatusChartTimeBasisToolStripMenuItem
            // 
            this.seminarBookingStatusChartTimeBasisToolStripMenuItem.Name = "seminarBookingStatusChartTimeBasisToolStripMenuItem";
            this.seminarBookingStatusChartTimeBasisToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.seminarBookingStatusChartTimeBasisToolStripMenuItem.Text = "Seminar Booking Status Chart Time Basis";
            this.seminarBookingStatusChartTimeBasisToolStripMenuItem.Click += new System.EventHandler(this.seminarBookingStatusChartTimeBasisToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(311, 22);
            this.toolStripMenuItem2.Text = "Seminar Booking Status Chart Day Basis Days";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // seminarBookingStatusChartDayBasisToolStripMenuItem
            // 
            this.seminarBookingStatusChartDayBasisToolStripMenuItem.Name = "seminarBookingStatusChartDayBasisToolStripMenuItem";
            this.seminarBookingStatusChartDayBasisToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.seminarBookingStatusChartDayBasisToolStripMenuItem.Text = "Seminar Booking Status Chart Day Basis";
            this.seminarBookingStatusChartDayBasisToolStripMenuItem.Click += new System.EventHandler(this.seminarBookingStatusChartDayBasisToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(311, 22);
            this.toolStripMenuItem3.Text = "Seminar Estimate";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // seminarBillingToolStripMenuItem
            // 
            this.seminarBillingToolStripMenuItem.Name = "seminarBillingToolStripMenuItem";
            this.seminarBillingToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.seminarBillingToolStripMenuItem.Text = "Seminar Billing";
            this.seminarBillingToolStripMenuItem.Click += new System.EventHandler(this.seminarBillingToolStripMenuItem_Click);
            // 
            // reservationToolStripMenuItem
            // 
            this.reservationToolStripMenuItem.Enabled = false;
            this.reservationToolStripMenuItem.Name = "reservationToolStripMenuItem";
            this.reservationToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.reservationToolStripMenuItem.Text = "Reservation Without Advance";
            this.reservationToolStripMenuItem.Visible = false;
            this.reservationToolStripMenuItem.Click += new System.EventHandler(this.reservationToolStripMenuItem_Click);
            // 
            // cancelledReservationToolStripMenuItem
            // 
            this.cancelledReservationToolStripMenuItem.Enabled = false;
            this.cancelledReservationToolStripMenuItem.Name = "cancelledReservationToolStripMenuItem";
            this.cancelledReservationToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.cancelledReservationToolStripMenuItem.Text = "Cancelled Reservation";
            this.cancelledReservationToolStripMenuItem.Visible = false;
            this.cancelledReservationToolStripMenuItem.Click += new System.EventHandler(this.cancelledReservationToolStripMenuItem_Click);
            // 
            // semReportMenu
            // 
            this.semReportMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.occupancyByNameToolStripMenuItem,
            this.collectionSummaryToolStripMenuItem,
            this.collectionSummaryToolStripMenuItem1,
            this.occupancyRateToolStripMenuItem,
            this.revenueSummaryToolStripMenuItem,
            this.revenueToolStripMenuItem,
            this.unbilledPartyListToolStripMenuItem,
            this.itemWiseSummaryToolStripMenuItem,
            this.conferenceHallCancellationToolStripMenuItem,
            this.creditSaleRegisterToolStripMenuItem,
            this.billStatementToolStripMenuItem,
            this.billStatementForSeminarToolStripMenuItem,
            this.occupancyChartDailyToolStripMenuItem1,
            this.occupancyChartMONTHLYToolStripMenuItem1,
            this.cashCollectionToolStripMenuItem1});
            this.semReportMenu.Name = "semReportMenu";
            this.semReportMenu.Size = new System.Drawing.Size(105, 20);
            this.semReportMenu.Text = "&Seminar Reports";
            // 
            // occupancyByNameToolStripMenuItem
            // 
            this.occupancyByNameToolStripMenuItem.Enabled = false;
            this.occupancyByNameToolStripMenuItem.Name = "occupancyByNameToolStripMenuItem";
            this.occupancyByNameToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.occupancyByNameToolStripMenuItem.Text = "Occupancy By Name";
            this.occupancyByNameToolStripMenuItem.Visible = false;
            this.occupancyByNameToolStripMenuItem.Click += new System.EventHandler(this.occupancyByNameToolStripMenuItem_Click);
            // 
            // collectionSummaryToolStripMenuItem
            // 
            this.collectionSummaryToolStripMenuItem.Name = "collectionSummaryToolStripMenuItem";
            this.collectionSummaryToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.collectionSummaryToolStripMenuItem.Text = "Collection Summary";
            this.collectionSummaryToolStripMenuItem.Click += new System.EventHandler(this.collectionSummaryToolStripMenuItem_Click);
            // 
            // collectionSummaryToolStripMenuItem1
            // 
            this.collectionSummaryToolStripMenuItem1.Enabled = false;
            this.collectionSummaryToolStripMenuItem1.Name = "collectionSummaryToolStripMenuItem1";
            this.collectionSummaryToolStripMenuItem1.Size = new System.Drawing.Size(237, 22);
            this.collectionSummaryToolStripMenuItem1.Text = "Collection Summary (Bill Wise)";
            this.collectionSummaryToolStripMenuItem1.Visible = false;
            this.collectionSummaryToolStripMenuItem1.Click += new System.EventHandler(this.collectionSummaryToolStripMenuItem1_Click);
            // 
            // occupancyRateToolStripMenuItem
            // 
            this.occupancyRateToolStripMenuItem.Enabled = false;
            this.occupancyRateToolStripMenuItem.Name = "occupancyRateToolStripMenuItem";
            this.occupancyRateToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.occupancyRateToolStripMenuItem.Text = "Occupancy Rate";
            this.occupancyRateToolStripMenuItem.Visible = false;
            this.occupancyRateToolStripMenuItem.Click += new System.EventHandler(this.occupancyRateToolStripMenuItem_Click);
            // 
            // revenueSummaryToolStripMenuItem
            // 
            this.revenueSummaryToolStripMenuItem.Enabled = false;
            this.revenueSummaryToolStripMenuItem.Name = "revenueSummaryToolStripMenuItem";
            this.revenueSummaryToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.revenueSummaryToolStripMenuItem.Text = "Revenue Summary";
            this.revenueSummaryToolStripMenuItem.Visible = false;
            this.revenueSummaryToolStripMenuItem.Click += new System.EventHandler(this.revenueSummaryToolStripMenuItem_Click);
            // 
            // revenueToolStripMenuItem
            // 
            this.revenueToolStripMenuItem.Enabled = false;
            this.revenueToolStripMenuItem.Name = "revenueToolStripMenuItem";
            this.revenueToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.revenueToolStripMenuItem.Text = "Revenue Detail";
            this.revenueToolStripMenuItem.Visible = false;
            this.revenueToolStripMenuItem.Click += new System.EventHandler(this.revenueToolStripMenuItem_Click);
            // 
            // unbilledPartyListToolStripMenuItem
            // 
            this.unbilledPartyListToolStripMenuItem.Enabled = false;
            this.unbilledPartyListToolStripMenuItem.Name = "unbilledPartyListToolStripMenuItem";
            this.unbilledPartyListToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.unbilledPartyListToolStripMenuItem.Text = "Unbilled Party List";
            this.unbilledPartyListToolStripMenuItem.Visible = false;
            this.unbilledPartyListToolStripMenuItem.Click += new System.EventHandler(this.unbilledPartyListToolStripMenuItem_Click);
            // 
            // itemWiseSummaryToolStripMenuItem
            // 
            this.itemWiseSummaryToolStripMenuItem.Enabled = false;
            this.itemWiseSummaryToolStripMenuItem.Name = "itemWiseSummaryToolStripMenuItem";
            this.itemWiseSummaryToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.itemWiseSummaryToolStripMenuItem.Text = "Item Wise Summary to Party";
            this.itemWiseSummaryToolStripMenuItem.Visible = false;
            this.itemWiseSummaryToolStripMenuItem.Click += new System.EventHandler(this.itemWiseSummaryToolStripMenuItem_Click);
            // 
            // conferenceHallCancellationToolStripMenuItem
            // 
            this.conferenceHallCancellationToolStripMenuItem.Enabled = false;
            this.conferenceHallCancellationToolStripMenuItem.Name = "conferenceHallCancellationToolStripMenuItem";
            this.conferenceHallCancellationToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.conferenceHallCancellationToolStripMenuItem.Text = "Conference Hall Cancellation";
            this.conferenceHallCancellationToolStripMenuItem.Visible = false;
            this.conferenceHallCancellationToolStripMenuItem.Click += new System.EventHandler(this.conferenceHallCancellationToolStripMenuItem_Click);
            // 
            // creditSaleRegisterToolStripMenuItem
            // 
            this.creditSaleRegisterToolStripMenuItem.Enabled = false;
            this.creditSaleRegisterToolStripMenuItem.Name = "creditSaleRegisterToolStripMenuItem";
            this.creditSaleRegisterToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.creditSaleRegisterToolStripMenuItem.Text = "Credit Sale Register";
            this.creditSaleRegisterToolStripMenuItem.Visible = false;
            this.creditSaleRegisterToolStripMenuItem.Click += new System.EventHandler(this.creditSaleRegisterToolStripMenuItem_Click);
            // 
            // billStatementToolStripMenuItem
            // 
            this.billStatementToolStripMenuItem.Enabled = false;
            this.billStatementToolStripMenuItem.Name = "billStatementToolStripMenuItem";
            this.billStatementToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.billStatementToolStripMenuItem.Text = "Bill Statement for catering";
            this.billStatementToolStripMenuItem.Visible = false;
            this.billStatementToolStripMenuItem.Click += new System.EventHandler(this.billStatementToolStripMenuItem_Click);
            // 
            // billStatementForSeminarToolStripMenuItem
            // 
            this.billStatementForSeminarToolStripMenuItem.Enabled = false;
            this.billStatementForSeminarToolStripMenuItem.Name = "billStatementForSeminarToolStripMenuItem";
            this.billStatementForSeminarToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.billStatementForSeminarToolStripMenuItem.Text = "Bill Statement for Seminar";
            this.billStatementForSeminarToolStripMenuItem.Visible = false;
            this.billStatementForSeminarToolStripMenuItem.Click += new System.EventHandler(this.billStatementForSeminarToolStripMenuItem_Click);
            // 
            // occupancyChartDailyToolStripMenuItem1
            // 
            this.occupancyChartDailyToolStripMenuItem1.Name = "occupancyChartDailyToolStripMenuItem1";
            this.occupancyChartDailyToolStripMenuItem1.Size = new System.Drawing.Size(237, 22);
            this.occupancyChartDailyToolStripMenuItem1.Text = "Occupancy Chart DAILY";
            this.occupancyChartDailyToolStripMenuItem1.Click += new System.EventHandler(this.occupancyChartDailyToolStripMenuItem1_Click);
            // 
            // occupancyChartMONTHLYToolStripMenuItem1
            // 
            this.occupancyChartMONTHLYToolStripMenuItem1.Name = "occupancyChartMONTHLYToolStripMenuItem1";
            this.occupancyChartMONTHLYToolStripMenuItem1.Size = new System.Drawing.Size(237, 22);
            this.occupancyChartMONTHLYToolStripMenuItem1.Text = "Occupancy Chart MONTHLY";
            this.occupancyChartMONTHLYToolStripMenuItem1.Click += new System.EventHandler(this.occupancyChartMONTHLYToolStripMenuItem1_Click);
            // 
            // cashCollectionToolStripMenuItem1
            // 
            this.cashCollectionToolStripMenuItem1.Name = "cashCollectionToolStripMenuItem1";
            this.cashCollectionToolStripMenuItem1.Size = new System.Drawing.Size(237, 22);
            this.cashCollectionToolStripMenuItem1.Text = "Cash Collection";
            this.cashCollectionToolStripMenuItem1.Click += new System.EventHandler(this.cashCollectionToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miscHeadMasterToolStripMenuItem1,
            this.miscEntryToolStripMenuItem});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(77, 20);
            this.toolStripMenuItem4.Text = "&Misc. Entry";
            // 
            // miscHeadMasterToolStripMenuItem1
            // 
            this.miscHeadMasterToolStripMenuItem1.Name = "miscHeadMasterToolStripMenuItem1";
            this.miscHeadMasterToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.miscHeadMasterToolStripMenuItem1.Text = "Misc Head Master";
            this.miscHeadMasterToolStripMenuItem1.Click += new System.EventHandler(this.miscHeadMasterToolStripMenuItem1_Click);
            // 
            // miscEntryToolStripMenuItem
            // 
            this.miscEntryToolStripMenuItem.Name = "miscEntryToolStripMenuItem";
            this.miscEntryToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.miscEntryToolStripMenuItem.Text = "Misc Entry";
            this.miscEntryToolStripMenuItem.Click += new System.EventHandler(this.miscEntryToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cateringOrderToolStripMenuItem,
            this.orderChartToolStripMenuItem,
            this.prepareChannelBillToolStripMenuItem,
            this.channelBillToolStripMenuItem});
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(79, 20);
            this.toolStripMenuItem5.Text = "Order Entry";
            // 
            // cateringOrderToolStripMenuItem
            // 
            this.cateringOrderToolStripMenuItem.Name = "cateringOrderToolStripMenuItem";
            this.cateringOrderToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cateringOrderToolStripMenuItem.Text = "Catering Order";
            this.cateringOrderToolStripMenuItem.Click += new System.EventHandler(this.cateringOrderToolStripMenuItem_Click);
            // 
            // orderChartToolStripMenuItem
            // 
            this.orderChartToolStripMenuItem.Name = "orderChartToolStripMenuItem";
            this.orderChartToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.orderChartToolStripMenuItem.Text = "Order Chart";
            this.orderChartToolStripMenuItem.Click += new System.EventHandler(this.orderChartToolStripMenuItem_Click);
            // 
            // prepareChannelBillToolStripMenuItem
            // 
            this.prepareChannelBillToolStripMenuItem.Name = "prepareChannelBillToolStripMenuItem";
            this.prepareChannelBillToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.prepareChannelBillToolStripMenuItem.Text = "Prepare Channel Bill";
            this.prepareChannelBillToolStripMenuItem.Click += new System.EventHandler(this.prepareChannelBillToolStripMenuItem_Click);
            // 
            // channelBillToolStripMenuItem
            // 
            this.channelBillToolStripMenuItem.Name = "channelBillToolStripMenuItem";
            this.channelBillToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.channelBillToolStripMenuItem.Text = "Channel Bill";
            this.channelBillToolStripMenuItem.Click += new System.EventHandler(this.channelBillToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuGroupToolStripMenuItem,
            this.buffetToolStripMenuItem,
            this.waiterMasterToolStripMenuItem,
            this.menuMasterToolStripMenuItem1,
            this.rawMaterialKitchenMasterToolStripMenuItem,
            this.menuReceiptBOMToolStripMenuItem,
            this.kOTEntryToolStripMenuItem});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(114, 20);
            this.toolStripMenuItem6.Text = "Kitchen/Resturant";
            // 
            // menuGroupToolStripMenuItem
            // 
            this.menuGroupToolStripMenuItem.Name = "menuGroupToolStripMenuItem";
            this.menuGroupToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.menuGroupToolStripMenuItem.Text = "Menu Group";
            this.menuGroupToolStripMenuItem.Click += new System.EventHandler(this.menuGroupToolStripMenuItem_Click);
            // 
            // buffetToolStripMenuItem
            // 
            this.buffetToolStripMenuItem.Name = "buffetToolStripMenuItem";
            this.buffetToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.buffetToolStripMenuItem.Text = "Buffet";
            this.buffetToolStripMenuItem.Click += new System.EventHandler(this.buffetToolStripMenuItem_Click);
            // 
            // waiterMasterToolStripMenuItem
            // 
            this.waiterMasterToolStripMenuItem.Name = "waiterMasterToolStripMenuItem";
            this.waiterMasterToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.waiterMasterToolStripMenuItem.Text = "Waiter Master";
            this.waiterMasterToolStripMenuItem.Click += new System.EventHandler(this.waiterMasterToolStripMenuItem_Click);
            // 
            // menuMasterToolStripMenuItem1
            // 
            this.menuMasterToolStripMenuItem1.Name = "menuMasterToolStripMenuItem1";
            this.menuMasterToolStripMenuItem1.Size = new System.Drawing.Size(224, 22);
            this.menuMasterToolStripMenuItem1.Text = "Menu Master";
            this.menuMasterToolStripMenuItem1.Click += new System.EventHandler(this.menuMasterToolStripMenuItem1_Click);
            // 
            // rawMaterialKitchenMasterToolStripMenuItem
            // 
            this.rawMaterialKitchenMasterToolStripMenuItem.Name = "rawMaterialKitchenMasterToolStripMenuItem";
            this.rawMaterialKitchenMasterToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.rawMaterialKitchenMasterToolStripMenuItem.Text = "Raw Material Kitchen Master";
            this.rawMaterialKitchenMasterToolStripMenuItem.Click += new System.EventHandler(this.rawMaterialKitchenMasterToolStripMenuItem_Click);
            // 
            // menuReceiptBOMToolStripMenuItem
            // 
            this.menuReceiptBOMToolStripMenuItem.Name = "menuReceiptBOMToolStripMenuItem";
            this.menuReceiptBOMToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.menuReceiptBOMToolStripMenuItem.Text = "Menu/Receipt BOM";
            this.menuReceiptBOMToolStripMenuItem.Click += new System.EventHandler(this.menuReceiptBOMToolStripMenuItem_Click);
            // 
            // kOTEntryToolStripMenuItem
            // 
            this.kOTEntryToolStripMenuItem.Name = "kOTEntryToolStripMenuItem";
            this.kOTEntryToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.kOTEntryToolStripMenuItem.Text = "KOT Entry";
            this.kOTEntryToolStripMenuItem.Click += new System.EventHandler(this.kOTEntryToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vendorMasterToolStripMenuItem,
            this.storeInventoryToolStripMenuItem,
            this.requistionToolStripMenuItem});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(51, 20);
            this.toolStripMenuItem7.Text = "Stores";
            // 
            // vendorMasterToolStripMenuItem
            // 
            this.vendorMasterToolStripMenuItem.Name = "vendorMasterToolStripMenuItem";
            this.vendorMasterToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.vendorMasterToolStripMenuItem.Text = "Vendor Master";
            // 
            // storeInventoryToolStripMenuItem
            // 
            this.storeInventoryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.storeReceiptMasterToolStripMenuItem,
            this.storeReturbMasterToolStripMenuItem});
            this.storeInventoryToolStripMenuItem.Name = "storeInventoryToolStripMenuItem";
            this.storeInventoryToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.storeInventoryToolStripMenuItem.Text = "Store Inventory";
            // 
            // storeReceiptMasterToolStripMenuItem
            // 
            this.storeReceiptMasterToolStripMenuItem.Name = "storeReceiptMasterToolStripMenuItem";
            this.storeReceiptMasterToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.storeReceiptMasterToolStripMenuItem.Text = "Store Receipt Master";
            // 
            // storeReturbMasterToolStripMenuItem
            // 
            this.storeReturbMasterToolStripMenuItem.Name = "storeReturbMasterToolStripMenuItem";
            this.storeReturbMasterToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.storeReturbMasterToolStripMenuItem.Text = "Store Returb Master";
            // 
            // requistionToolStripMenuItem
            // 
            this.requistionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.requistionCreatedToolStripMenuItem,
            this.requisitionIssuedToolStripMenuItem});
            this.requistionToolStripMenuItem.Name = "requistionToolStripMenuItem";
            this.requistionToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.requistionToolStripMenuItem.Text = "Requisition";
            // 
            // requistionCreatedToolStripMenuItem
            // 
            this.requistionCreatedToolStripMenuItem.Name = "requistionCreatedToolStripMenuItem";
            this.requistionCreatedToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.requistionCreatedToolStripMenuItem.Text = "Requisition Created";
            // 
            // requisitionIssuedToolStripMenuItem
            // 
            this.requisitionIssuedToolStripMenuItem.Name = "requisitionIssuedToolStripMenuItem";
            this.requisitionIssuedToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.requisitionIssuedToolStripMenuItem.Text = "Requisition Issued";
            // 
            // securityToolStripMenuItem
            // 
            this.securityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataBackupToolStripMenuItem,
            this.loginToolStripMenuItem1,
            this.changePasswordToolStripMenuItem,
            this.userPermissionToolStripMenuItem});
            this.securityToolStripMenuItem.Name = "securityToolStripMenuItem";
            this.securityToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.securityToolStripMenuItem.Text = "Security";
            // 
            // dataBackupToolStripMenuItem
            // 
            this.dataBackupToolStripMenuItem.Name = "dataBackupToolStripMenuItem";
            this.dataBackupToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.dataBackupToolStripMenuItem.Text = "Data Backup";
            this.dataBackupToolStripMenuItem.Click += new System.EventHandler(this.dataBackupToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem1
            // 
            this.loginToolStripMenuItem1.Name = "loginToolStripMenuItem1";
            this.loginToolStripMenuItem1.Size = new System.Drawing.Size(183, 22);
            this.loginToolStripMenuItem1.Text = "Login Creation Form";
            this.loginToolStripMenuItem1.Click += new System.EventHandler(this.loginToolStripMenuItem1_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // userPermissionToolStripMenuItem
            // 
            this.userPermissionToolStripMenuItem.Name = "userPermissionToolStripMenuItem";
            this.userPermissionToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.userPermissionToolStripMenuItem.Text = "User Permission";
            this.userPermissionToolStripMenuItem.Click += new System.EventHandler(this.userPermissionToolStripMenuItem_Click);
            // 
            // windowsToolStripMenuItem
            // 
            this.windowsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeFinancialYearToolStripMenuItem,
            this.aboutUsToolStripMenuItem,
            this.loginToolStripMenuItem,
            this.existToolStripMenuItem});
            this.windowsToolStripMenuItem.Name = "windowsToolStripMenuItem";
            this.windowsToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.windowsToolStripMenuItem.Text = "Windows";
            // 
            // changeFinancialYearToolStripMenuItem
            // 
            this.changeFinancialYearToolStripMenuItem.Name = "changeFinancialYearToolStripMenuItem";
            this.changeFinancialYearToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.changeFinancialYearToolStripMenuItem.Text = "Change Financial Year";
            this.changeFinancialYearToolStripMenuItem.Click += new System.EventHandler(this.changeFinancialYearToolStripMenuItem_Click);
            // 
            // aboutUsToolStripMenuItem
            // 
            this.aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            this.aboutUsToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.aboutUsToolStripMenuItem.Text = "About Us";
            this.aboutUsToolStripMenuItem.Click += new System.EventHandler(this.aboutUsToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.loginToolStripMenuItem.Text = "Login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // existToolStripMenuItem
            // 
            this.existToolStripMenuItem.Name = "existToolStripMenuItem";
            this.existToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.existToolStripMenuItem.Text = "Exit";
            this.existToolStripMenuItem.Click += new System.EventHandler(this.existToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel,
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip.Location = new System.Drawing.Point(0, 474);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1002, 25);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.toolStripStatusLabel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(246, 20);
            this.toolStripStatusLabel.Spring = true;
            this.toolStripStatusLabel.Text = "Status";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.ActiveLinkColor = System.Drawing.Color.Black;
            this.toolStripStatusLabel1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(246, 20);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel2.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(246, 20);
            this.toolStripStatusLabel2.Spring = true;
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel3.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(246, 20);
            this.toolStripStatusLabel3.Spring = true;
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // MasterLayout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 499);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MasterLayout";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Smart Management Hostel (SMH)";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mdiMasterLayout_FormClosing);
            this.Load += new System.EventHandler(this.MasterLayout_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem transMenu;
        private System.Windows.Forms.ToolStripMenuItem masterMenu;
        private System.Windows.Forms.ToolStripMenuItem reportMenu;
        private System.Windows.Forms.ToolStripMenuItem hostelMenu;
        private System.Windows.Forms.ToolStripMenuItem semicaterMenu;
        private System.Windows.Forms.ToolStripMenuItem semReportMenu;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem collectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revenueSummaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem revenueDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unbilledCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statementOfNationalityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem advanceSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statementOfCashRecieiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem billStatementToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem billStatementDateWiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listOfRoomTypesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listOfCashReceiptTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listOfAdditionalGuestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cFormDateWiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem partyWiseSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem monthlyHostelOccupancyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountwiseAdvanceSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hostelBookingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hostelBookingStatusChartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miscHeadMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seminarBookingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seminarBookingStatusChartTimeBasisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seminarBookingStatusChartDayBasisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seminarBillingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reservationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelledReservationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem occupancyByNameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collectionSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collectionSummaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem occupancyRateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revenueSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revenueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unbilledPartyListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemWiseSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conferenceHallCancellationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem creditSaleRegisterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem billStatementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem billStatementForSeminarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem securityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataBackupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userPermissionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeFinancialYearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutUsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem existToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerCardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomBillToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dormatoryBillToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dailyEntryFormCombinedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dailyEntryFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiptVoucherToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem roomUnbilledToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dormatoryUnbilledToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentVoucherToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem modifyCFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mergeCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nationalityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem titleMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companyDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripMenuItem countryMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem membershipDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companyGuestMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guestTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guestMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem roomTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomNumberToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem accountTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gSTReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiptSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem hostelEstimatetoolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem collectionSummaryToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem occupancyChartDAILYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem occupancyChartMONTHLYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cashCollectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem partyWiseSummaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem occupancyChartDailyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem occupancyChartMONTHLYToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cashCollectionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem miscHeadMasterToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem miscEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem cateringOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orderChartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prepareChannelBillToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem channelBillToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem menuGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buffetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem waiterMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuMasterToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rawMaterialKitchenMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuReceiptBOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kOTEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem vendorMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storeInventoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storeReceiptMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storeReturbMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem requistionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem requistionCreatedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem requisitionIssuedToolStripMenuItem;
    }
}



