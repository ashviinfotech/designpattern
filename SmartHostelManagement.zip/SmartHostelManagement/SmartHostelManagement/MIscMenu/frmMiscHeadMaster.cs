﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.MiscMaster
{
    public partial class frmMiscHeadMaster : Form
    {
        public int ChannelId = 0;
        public string channelname = string.Empty;

        public frmMiscHeadMaster()
        {
            InitializeComponent();
        }

        private void frmNationality_Load(object sender, EventArgs e)
        {
            BindGridview();
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (datagrdiview.SelectedRows.Count > 0)
                {
                    ChannelId = (int)datagrdiview.SelectedRows[0].Cells[0].Value;
                    channelname = (string)datagrdiview.SelectedRows[0].Cells[2].Value;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
            this.Close();
        }

        void BindGridview()
        {
            try
            {
                using (DBData.ISIPMEntities dbContext = new DBData.ISIPMEntities())
                {
                    IList<DBData.ChannelMaster> lstChannelMaster = dbContext.ChannelMasters
                        .Where(x => x.KotMis.Value == (ChannelId == 0 ? false : true)).ToList();
                    var dbdata = lstChannelMaster.Select((c, index) =>
                    new
                    {
                        c.Channelid,
                        SlNo = index + 1,
                        c.ChannelName,
                        c.ChannelCode
                    }).OrderBy(x => x.Channelid);

                    datagrdiview.DataSource = dbdata.ToList();
                    datagrdiview.Columns["Channelid"].Visible = false;
                    datagrdiview.Columns["SlNo"].Width = 100;
                    datagrdiview.Columns["ChannelName"].Width = 200;
                    datagrdiview.Columns["ChannelCode"].Width = 200;
                }                
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "BindGridview");
            }
        }
        
        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnExit_Click(object sender, FormClosingEventArgs e)
        {

        }
    }
}
