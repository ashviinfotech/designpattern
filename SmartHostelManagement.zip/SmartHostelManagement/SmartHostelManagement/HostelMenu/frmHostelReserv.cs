﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Hostel
{
    public partial class frmHostelReserv : Form
    {
        ReservationCaller objReservBook = new ReservationCaller();
        MasterCaller objMasterData = new MasterCaller();
        GuestCaller objGuestMaster = new GuestCaller();
        HostelCaller objHostelBook = new HostelCaller();
        ReceiptCaller objReceiptBook = new ReceiptCaller();
        AlphaPanel aplhaPanel = new AlphaPanel();

        public int reservationId { get; set; }
        bool editPage = false;
        int rowDetailIndex = -1;
        readonly string reservTagChar = Convert.ToString((char)Convert.ToInt32(CommonVariables.SpecialTag.HostelBook));

        public EL.RESERVATION_CHECKIN_WALKIN objReservation { get; set; }
        List<EL.RESERVATION_DETAILS_STATUS> lstReservDetails { get; set; }

        public frmHostelReserv()
        {
            InitializeComponent();
        }

        private void frmHostelReserv_Load(object sender, EventArgs e)
        {
            BindTitle();
            BindHallName();
            BindRoomType();
            if (this.reservationId > 0)
            {
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.reservationId;
                resetPageData();
                this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                FillPageReservData();
            }
            else if (this.objReservation != null && this.objReservation.reservation_ID == 0 && this.objReservation.GUEST_NUM.HasValue)
            {
                GuestMasteretails(this.objReservation.GUEST_NUM.Value);
            }
            else
                btnLast_Click(sender, e);
            btnDelete.Enabled = false;
        }

        EL.FilterClass RefreshFilter()
        {
            return new EL.FilterClass
            {
                FinEnd = CommonVariables.dtmFinancialEnd.Year * 100 + CommonVariables.dtmFinancialEnd.Month,
                FinStart = CommonVariables.dtmFinancialStart.Year * 100 + CommonVariables.dtmFinancialStart.Month,
                BillNumber = 0,
                FolioNumber = 0,
                RecordCategory = 0,
                RecordNumber = 0,
                RoomCategory = 0,
                SearchByText = string.Empty,
                tagChar = reservTagChar,
                UniqueId = 0
            };
        }

        private void BindTitle()
        {
            try
            {
                List<EL.MasterTitle> lstTitle = objMasterData.GetTitleMaster().OrderBy(x => x.Titlename).ToList();
                lstTitle.Insert(0, new EL.MasterTitle { Titleid = 0, Titlename = string.Empty });
                cmbTitle.DataSource = lstTitle;
                cmbTitle.DisplayMember = "Titlename";
                cmbTitle.ValueMember = "Titleid";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindTitle");
            }
        }

        private void BindHallName()
        {
            try
            {
                List<EL.room_number> lstRoomNum = objMasterData.GetRoomNumber().Where(x => x.Dormatory == 1).OrderBy(x => x.room_number_number).ToList();
                lstRoomNum.Insert(0, new EL.room_number { room_number_ID = 0, room_number_number = string.Empty });

                List<EL.room_number> lstReservRoomNum = objMasterData.GetRoomNumber().Where(x => x.Dormatory == 1).OrderBy(x => x.room_number_number).ToList();
                lstReservRoomNum.Insert(0, new EL.room_number { room_number_ID = 0, room_number_number = string.Empty });

                cmbDorm.DataSource = lstRoomNum;
                cmbDorm.DisplayMember = "room_number_number";
                cmbDorm.ValueMember = "room_number_ID";

                cmbDetDorm.DataSource = lstReservRoomNum;
                cmbDetDorm.DisplayMember = "room_number_number";
                cmbDetDorm.ValueMember = "room_number_ID";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindHallName");
            }
        }
        
        private void BindRoomType()
        {
            List<EL.ROOM_TYPE> lstRoomTypeA = objMasterData.GetRoomType().Where(x => x.Room_dorm == 0).ToList();
            lstRoomTypeA.Insert(0, new EL.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_DESC = string.Empty });
            List<EL.ROOM_TYPE> lstRoomTypeB = objMasterData.GetRoomType().Where(x => x.Room_dorm == 0).ToList();
            lstRoomTypeB.Insert(0, new EL.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_DESC = string.Empty });
            List<EL.ROOM_TYPE> lstDormTypeA = objMasterData.GetRoomType().Where(x => x.Room_dorm == 1).ToList();
            lstDormTypeA.Insert(0, new EL.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_DESC = string.Empty });
            List<EL.ROOM_TYPE> lstDormTypeB = objMasterData.GetRoomType().Where(x => x.Room_dorm == 1).ToList();
            lstDormTypeB.Insert(0, new EL.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_DESC = string.Empty });

            cmbRoomType.DataSource = lstRoomTypeA.Select(x => new { roomdesc = x.RM_TYPE_ID > 0 ? x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")" : "", x.RM_TYPE_ID }).ToList();
            cmbRoomType.DisplayMember = "roomdesc";
            cmbRoomType.ValueMember = "RM_TYPE_ID";

            cmbDetRoomType.DataSource = lstRoomTypeB.Select(x => new { roomdesc = x.RM_TYPE_ID > 0 ? x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")" : "", x.RM_TYPE_ID }).ToList();
            cmbDetRoomType.DisplayMember = "roomdesc";
            cmbDetRoomType.ValueMember = "RM_TYPE_ID";

            cmbDormType.DataSource = lstDormTypeA.Select(x => new { roomdesc = x.RM_TYPE_ID > 0 ? x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")" : "", x.RM_TYPE_ID }).ToList();
            cmbDormType.DisplayMember = "roomdesc";
            cmbDormType.ValueMember = "RM_TYPE_ID";

            cmbDetDormType.DataSource = lstDormTypeB.Select(x => new { roomdesc = x.RM_TYPE_ID > 0 ? x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")" : "", x.RM_TYPE_ID }).ToList();
            cmbDetDormType.DisplayMember = "roomdesc";
            cmbDetDormType.ValueMember = "RM_TYPE_ID";
        }

        private void resetPageData()
        {
            this.objReservation = null;
            this.reservationId = 0;

            txtEntryNo.Text = string.Empty;
            dtmReservTo.Value = DateTime.Now;
            cmbTitle.SelectedIndex = 0;
            txtCustName.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtAddress2.Text = string.Empty;
            txtNoRoom.Text = string.Empty;
            txtNoBeds.Text = string.Empty;
            cmbDorm.SelectedIndex = 0;
            dtmFromDate.Value = DateTime.Now;
            dtmTodate.Value = DateTime.Now;
            txtUpto.Text = "1";
            txtRemarks.Text = string.Empty;
            txtRoomFolioNo.Text = string.Empty;
            //txtDormFolio.Text = string.Empty;
            txtAddress3.Text = string.Empty;
            txtRoomTypeRent.Text = string.Empty;
            txtDormTypeRent.Text = string.Empty;
            chkServiceExmpt.Checked = false;
            cmbRoomType.SelectedIndex = 0;
            cmbDormType.SelectedIndex = 0;

            lblResrvStatus.Text = string.Empty;
            lblCustStatus.Text = string.Empty;
            lblTotalReceipt.Text = string.Empty;

            txtReceipt0.Text = string.Empty;
            txtReceipt1.Text = string.Empty;
            txtReceipt2.Text = string.Empty;
            txtReceipt3.Text = string.Empty;
            //txtReceipt4.Text = string.Empty;

            lblReceiptAmt0.Text = string.Empty;
            lblReceiptNo1.Text = string.Empty;
            lblReceiptNo2.Text = string.Empty;
            lblReceiptNo3.Text = string.Empty;
            //lblReceiptNo4.Text = string.Empty;

            lblRecepDesc0.Text = string.Empty;
            lblRecepDesc1.Text = string.Empty;
            lblRecepDesc2.Text = string.Empty;
            lblRecepDesc3.Text = string.Empty;
            //lblRecepDesc4.Text = string.Empty;

            this.lstReservDetails = null;
            resetDetailsSection();
            BindReservationStatus();
        }

        private void FillPageReservData()
        {
            try
            {
                if (this.objReservation != null)
                {
                    this.Text = "Hostel Reservation Entry : " + this.objReservation.reservation_PI_title + " " + this.objReservation.reservation_PI_frstname;

                    #region Tab 1 Entry
                    txtEntryNo.Text = this.objReservation.reservation_NUMBER.HasValue ? this.objReservation.reservation_NUMBER.Value.ToString() : string.Empty;
                    dtmReservTo.Value = this.objReservation.reservation_DATEofRESERV.HasValue ? this.objReservation.reservation_DATEofRESERV.Value : DateTime.Now;
                    cmbTitle.Text = this.objReservation.reservation_PI_title;
                    txtCustName.Text = this.objReservation.reservation_PI_frstname;
                    txtAddress.Text = this.objReservation.reservation_PI_street;
                    txtAddress2.Text = this.objReservation.reservation_PI_street1;
                    txtAddress3.Text = this.objReservation.reservation_PI_organ;
                    #endregion Tab 1 Entry

                    #region Tab 1 Add ReservDet
                    txtNoRoom.Text = this.objReservation.reservation_NUMBER_ROOMS.HasValue ? this.objReservation.reservation_NUMBER_ROOMS.Value.ToString() : string.Empty;
                    txtNoBeds.Text = this.objReservation.reservation_NUMBER_BEDS.HasValue ? this.objReservation.reservation_NUMBER_BEDS.Value.ToString() : string.Empty;
                    cmbDorm.SelectedValue = this.objReservation.reservation_dormid.HasValue ? this.objReservation.reservation_dormid.Value : 0;
                    dtmFromDate.Value = this.objReservation.reservation_CHECKIN.HasValue ? this.objReservation.reservation_CHECKIN.Value : DateTime.Now;
                    dtmTodate.Value = this.objReservation.reservation_CHKOUT.HasValue ? this.objReservation.reservation_CHKOUT.Value : DateTime.Now;
                    txtUpto.Text = this.objReservation.reservation_UptoDays.HasValue ? this.objReservation.reservation_UptoDays.Value.ToString() : string.Empty;
                    txtRoomFolioNo.Text = this.objReservation.reservation_roomfolio.HasValue ? this.objReservation.reservation_roomfolio.Value.ToString() : string.Empty;
                    txtRemarks.Text = this.objReservation.ReservRemarks;
                    cmbRoomType.SelectedValue = this.objReservation.RM_TYPE_ID1.HasValue ? this.objReservation.RM_TYPE_ID1.Value : 0;
                    cmbDormType.SelectedValue = this.objReservation.RM_TYPE_ID2.HasValue ? this.objReservation.RM_TYPE_ID2.Value : 0;
                    txtRoomTypeRent.Text = this.objReservation.ROOMrate1.HasValue ? this.objReservation.ROOMrate1.Value.ToString("0.00") : "0.00";
                    txtDormTypeRent.Text = this.objReservation.ROOMrate2.HasValue ? this.objReservation.ROOMrate2.Value.ToString("0.00") : "0.00";
                    #endregion Tab 1 Add ReservDet

                    #region Tab 1 Receipt Entry
                    lblCustStatus.Text = objReservation.reservation_ID > 0 ? "Existing Entry" : "New Entry";
                    lblResrvStatus.Text = string.Empty;

                    txtReceipt0.Text = this.objReservation.Reserv_Status_receiptNo0.HasValue ? this.objReservation.Reserv_Status_receiptNo0.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt0, null);
                    txtReceipt1.Text = this.objReservation.Reserv_Status_receiptNo1.HasValue ? this.objReservation.Reserv_Status_receiptNo1.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt1, null);
                    txtReceipt2.Text = this.objReservation.Reserv_Status_receiptNo2.HasValue ? this.objReservation.Reserv_Status_receiptNo2.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt2, null);
                    txtReceipt3.Text = this.objReservation.Reserv_Status_receiptNo3.HasValue ? this.objReservation.Reserv_Status_receiptNo3.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt3, null);
                    //txtReceipt4.Text = this.objReservation.Reserv_Status_receiptNo4.HasValue ? this.objReservation.Reserv_Status_receiptNo4.Value.ToString() : string.Empty;
                    //txtReceipt0_Leave(txtReceipt4, null);
                    #endregion Tab 1 Receipt Entry

                    decimal totalAmt = 0m;
                    if (!string.IsNullOrEmpty(lblReceiptAmt0.Text)) totalAmt += Convert.ToDecimal(lblReceiptAmt0.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo1.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo1.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo2.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo2.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo3.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo3.Text);
                    //if (!string.IsNullOrEmpty(lblReceiptNo4.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo4.Text);

                    lblTotalReceipt.Text = "Adv Recpt. : " + totalAmt.ToString("0.00");
                    if (totalAmt > 0) lblCustStatus.BackColor = System.Drawing.Color.Red;
                    else lblCustStatus.BackColor = System.Drawing.Color.LightSkyBlue;

                    this.lstReservDetails = this.objReservation.RESERVATION_DETAILS_STATUS.ToList();
                    BindReservationStatus();

                    if (this.objReservation.reservation_ID > 0 && !editPage)
                    {
                        btnUndo.Enabled = false;
                        btnSave.Enabled = false;
                        btnAddNew.Enabled = true;
                        btnEdit.Enabled = true;
                        btnDelete.Enabled = false;

                        splitContainer1.Panel1.Controls.Add(aplhaPanel);
                        aplhaPanel.Dock = DockStyle.Fill;
                        aplhaPanel.BringToFront();
                    }
                }
                else
                {
                    splitContainer1.Panel1.Controls.Remove(aplhaPanel);
                    btnUndo.Enabled = false;
                    btnSave.Enabled = true;
                    btnAddNew.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error In FillPageReservData");
            }
        }

        private void txtReceipt0_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void txtCustName_Leave(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(TextBox))
            {
                TextBox txtCap = (TextBox)sender;
                txtCap.Text = CommonBaseFN.ConvertFirstLetterToCapital(txtCap.Text.Trim());
            }
        }

        private void txtEntryNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender.GetType() == typeof(ComboBox))
                {
                    if ((ComboBox)sender == cmbTitle) txtCustName.Focus();
                    if ((ComboBox)sender == cmbDorm) dtmTodate.Focus();
                    if ((ComboBox)sender == cmbDetDorm) txtDetRemarks.Focus();
                }
                else if (sender.GetType() == typeof(DateTimePicker))
                {
                    if ((DateTimePicker)sender == dtmReservTo) cmbTitle.Focus();
                    if ((DateTimePicker)sender == dtmTodate) txtUpto.Focus();
                    if ((DateTimePicker)sender == dtmFromDate) txtRemarks.Focus();
                    if ((DateTimePicker)sender == dtmDetUptoReserv) dtmDetFromReserv.Focus();
                    if ((DateTimePicker)sender == dtmDetFromReserv) txtNoOfRooms.Focus();
                    if ((DateTimePicker)sender == dateTimePicker6) dateTimePicker7.Focus();
                }
                else if (sender.GetType() == typeof(TextBox))
                {
                    if ((TextBox)sender == txtEntryNo) dtmReservTo.Focus();
                    if ((TextBox)sender == txtCustName) txtAddress.Focus();
                    if ((TextBox)sender == txtAddress) txtAddress2.Focus();
                    if ((TextBox)sender == txtAddress2) txtNoRoom.Focus();
                    if ((TextBox)sender == txtNoRoom) txtNoBeds.Focus();
                    if ((TextBox)sender == txtNoBeds) cmbDorm.Focus();
                    if ((TextBox)sender == txtUpto)
                    {
                        int dayNo = 0;
                        if (int.TryParse(txtUpto.Text.Trim(), out dayNo) && dayNo > 0)
                            dtmTodate.Value = dtmFromDate.Value.Date.AddDays(dayNo);
                        dtmTodate.Focus();
                    } 
                    if ((TextBox)sender == txtRemarks) txtRoomFolioNo.Focus();
                    if ((TextBox)sender == txtRoomFolioNo) dtmDetUptoReserv.Focus();
                    if ((TextBox)sender == txtNoOfRooms) txtNoOfBeds.Focus();
                    if ((TextBox)sender == txtNoOfBeds) cmbDetDorm.Focus();
                    if ((TextBox)sender == txtDetRemarks) txtReceipt0.Focus();
                    if ((TextBox)sender == txtReceipt0) txtReceipt1.Focus();
                    if ((TextBox)sender == txtReceipt1) txtReceipt2.Focus();
                    if ((TextBox)sender == txtReceipt2) txtReceipt3.Focus();
                    //if ((TextBox)sender == txtReceipt3) txtReceipt4.Focus();
                    //if ((TextBox)sender == txtReceipt4) dateTimePicker6.Focus();
                }

            }
        }

        private void txtReceipt0_Leave(object sender, EventArgs e)
        {
            try
            {
                int receiptNo = 0;
                if (sender.GetType() == typeof(TextBox) && int.TryParse(((TextBox)sender).Text, out receiptNo))
                {
                    EL.FilterClass objFilter = RefreshFilter();
                    objFilter.tagChar = Convert.ToString((char)CommonVariables.SpecialTag.Reciept);
                    objFilter.RecordNumber = receiptNo;

                    EL.receipt_payment objReceipt = objReceiptBook.GetReceiptByID(objFilter, CommonVariables.RecordCatergory.None);
                    if (objReceipt == null) objReceipt = new EL.receipt_payment();
                    if (sender == txtReceipt0)
                    {
                        this.objReservation.Reserv_Status_receiptNo0 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id0 = objReceipt.recpt_pay_id;
                        lblReceiptAmt0.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc0.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt1)
                    {
                        this.objReservation.Reserv_Status_receiptNo1 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id1 = objReceipt.recpt_pay_id;
                        lblReceiptNo1.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc1.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt2)
                    {
                        this.objReservation.Reserv_Status_receiptNo2 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id2 = objReceipt.recpt_pay_id;
                        lblReceiptNo2.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc2.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt3)
                    {
                        this.objReservation.Reserv_Status_receiptNo3 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id3 = objReceipt.recpt_pay_id;
                        lblReceiptNo3.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc3.Text = objReceipt.ONACOF;
                    }
                    //else if (sender == txtReceipt4)
                    //{
                    //    this.objReservation.Reserv_Status_receiptNo4 = objReceipt.receipt_No;
                    //    this.objReservation.recpt_pay_id4 = objReceipt.recpt_pay_id;
                    //    lblReceiptNo4.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                    //    lblRecepDesc4.Text = objReceipt.ONACOF;
                    //}

                    IList<EL.receipt_payment_Adjust_details> lstAdtype = objReceipt.receipt_payment_Adjust_details.Where(x => x.AdjType.ToUpper() == "ROOMS" ||
                        x.AdjType.ToUpper() == "DORMATORY" || x.AdjType.ToUpper() == "SEMINAR").ToList();
                    foreach (EL.receipt_payment_Adjust_details objAdjType in lstAdtype)
                    {
                        if (!string.IsNullOrEmpty(lblResrvStatus.Text)) lblResrvStatus.Text += " | ";
                        lblResrvStatus.Text += objAdjType.Refno.ToString() + " / " + objAdjType.AdjType.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in txtReceipt0_Leave");
            }
        }

        private void btnAddGuest_Click(object sender, EventArgs e)
        {
            try
            {
                using (Master.frmGuestMaster frmGuest = new Master.frmGuestMaster())
                {
                    frmGuest.ShowDialog();
                    GuestMasteretails(frmGuest.guestnum);
                }
            }
            catch (Exception ex)
            {   
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnAddGuest_Click");
            }
        }

        private void GuestMasteretails(int guestnumber)
        {
            EL.Mast_guest objGuest = objGuestMaster.GuestDetailByID(new EL.Mast_guest { GUEST_NUM = guestnumber });
            if (objGuest != null)
            {
                if (objReservation != null)
                {
                    this.objReservation.GUEST_NUM = objGuest.GUEST_NUM;
                    this.objReservation.reservation_weekday_overriderates = objGuest.G_override_rate;
                    this.objReservation.reservation_taxINCIDENTIALS = objGuest.G_tax_incidencials;
                    this.objReservation.reservation_PI_title = objGuest.G_TITLE;
                    this.objReservation.reservation_PI_frstname = objGuest.G_FNAME;
                    this.objReservation.reservation_PI_lastname = objGuest.G_LNAME;
                    this.objReservation.reservation_PI_street = objGuest.G_Street;
                    this.objReservation.reservation_PI_city = objGuest.G_CITY;
                    this.objReservation.reservation_PI_state = objGuest.G_STATE;
                    this.objReservation.reservation_PI_country = objGuest.G_COUNTRY;
                    this.objReservation.reservation_PI_zip = objGuest.G_ZIP;
                    this.objReservation.reservation_PI_street1 = objGuest.G_PHONE1 + " " + objGuest.G_PHONE2 + " " + objGuest.G_EMAIL;
                }
                else
                {
                    resetPageData();
                    this.objReservation = new EL.RESERVATION_CHECKIN_WALKIN
                    {
                        tag_reserv_chkin_walkin = this.reservTagChar,
                        GUEST_NUM = objGuest.GUEST_NUM,
                        reservation_weekday_overriderates = objGuest.G_override_rate,
                        reservation_taxINCIDENTIALS = objGuest.G_tax_incidencials,
                        reservation_PI_title = objGuest.G_TITLE,
                        reservation_PI_frstname = objGuest.G_FNAME,
                        reservation_PI_lastname = objGuest.G_LNAME,
                        reservation_PI_street = objGuest.G_Street,
                        reservation_PI_city = objGuest.G_CITY,
                        reservation_PI_state = objGuest.G_STATE,
                        reservation_PI_country = objGuest.G_COUNTRY,
                        reservation_PI_zip = objGuest.G_ZIP,
                        reservation_PI_street1 = objGuest.G_PHONE1 + " " + objGuest.G_PHONE2 + " " + objGuest.G_EMAIL,

                        reservation_PI_organ = string.Empty,
                        reservation_discount_TYPE = false,
                        reservation_OI_sentINbatch = false,
                        activate_delete = false,
                        charge_frm_day_reserv = false,
                        change_room = false,
                        discountperamt = false,
                        LTXtraIncl = false,
                        CompanyStatus = false,
                        Amtconsolidated = false,
                        Reservation_groupmaster = false,
                        reservation_NUMBER_ROOMS = 0,
                        reservation_ISagainstReserv = 0,
                        cancelreservation = 0,

                        #region Main Columns to be filled
                        //reservation_ID;
                        //reservation_NUMBER;
                        //reservation_CHECKIN;
                        //reservation_CHKOUT;
                        //reservation_DATEofRESERV;
                        //id;
                        //date_of_add;
                        //id1;
                        //date_of_mod;
                        //hotelbillno;
                        //MachineName = maschinename;
                        //reservation_UptoDays;
                        //ReservRemarks;
                        //reservation_GuestRem;
                        //reservation_NUMBER_BEDS;
                        //Reserv_Status_receiptNo0;
                        //recpt_pay_id0;
                        //Reserv_Status_receiptNo1;
                        //recpt_pay_id1;
                        //Reserv_Status_receiptNo2;
                        //recpt_pay_id2;
                        //Reserv_Status_receiptNo3;
                        //recpt_pay_id3;
                        //Reserv_Status_receiptNo4;
                        //recpt_pay_id4;
                        //Reserv_Status_receiptNo5;
                        //recpt_pay_id5;
                        //Reserv_Status_receiptNo6;
                        //recpt_pay_id6;
                        //Reserv_Status_receiptNo7;
                        //recpt_pay_id7;
                        //Reserv_LodgingRequirement;
                        //Reserv_SemConfChargesDetails;
                        //Reserv_CateringRequirement;
                        //Reserv_OtherRequirement;
                        //Reserv_BillNumber;
                        //Reserv_advanceDet;
                        //Reserv_CaterPersons;
                        //reservation_dormid;
                        //reservation_Catering_TotalBillAmt;
                        //reservation_Catering_TotalReceiptAmt;
                        //reservation_Catering_BalanceAmt;
                        //createdby;
                        //modifiedby;
                        //reservation_DateofCancel;
                        #endregion Main Columns to be filled

                        #region Not in Used
                        //reservation_weekday
                        //reservation_weekend;
                        //this.objReservation.reservation_NUMBER_pref;
                        //this.objReservation.reservation_NIGHTS;
                        //reservation_ROOMS;
                        //this.objReservation.reservation_ADULTS;
                        //this.objReservation.reservation_CHILDS;
                        //this.objReservation.RM_TYPE_ID;
                        //this.objReservation.Rate_type_ID;
                        //this.objReservation.rate_code_id;
                        //this.objReservation.Discount_code_id;
                        //this.objReservation.reservation_discount_amt;
                        //this.objReservation.room_change_id;
                        //this.objReservation.reservation_deposits;
                        //this.objReservation.reservation_ASSIGNED;
                        //this.objReservation.group_code_id;
                        //this.objReservation.reservation_PI_phone1;
                        //this.objReservation.reservation_PI_phone2;
                        //this.objReservation.reservation_PI_reference;
                        //this.objReservation.reservation_OI_holdtype;
                        //this.objReservation.reservation_OI_number;
                        //this.objReservation.reservation_OI_expDATE;
                        //this.objReservation.reservation_OI_nameONcard;
                        //this.objReservation.reservation_OI_DIRECT_BILL;
                        //this.objReservation.reservation_OI_DIRECT_Company;
                        //this.objReservation.reservation_OI_madeBY;
                        //this.objReservation.reservation_OI_emil_addr;
                        //this.objReservation.reservation_OI_lettersent;
                        //this.objReservation.reservation_OI_language;
                        //this.objReservation.TRAVEL_AGENT_ID;
                        //this.objReservation.market_code_id;
                        //this.objReservation.airport_id;
                        //this.objReservation.reservation_CF_arrivalTIME;
                        //this.objReservation.reservation_CF_arrivalFLIGHT;
                        //this.objReservation.reservation_CF_departureTIME;
                        //this.objReservation.reservation_CF_departureFLIGHT;
                        //this.objReservation.reservation_CF_SCUBAlesson;
                        //this.objReservation.reservation_guestNOTES;
                        //this.objReservation.reservation_housekeeping;
                        //this.objReservation.Account_id;
                        //this.objReservation.reservation_deposit_AMOUNT;
                        //this.objReservation.reservation_deposit_voucher;
                        //this.objReservation.expected_time_stay;
                        //this.objReservation.room_number_ID;
                        //this.objReservation.reservation_realCHECKIN;
                        //this.objReservation.reservation_realCHECKOUT;
                        //this.objReservation.reservation_rateROOM;
                        //this.objReservation.id2;
                        //this.objReservation.date_of_add2;
                        //this.objReservation.id3;
                        //this.objReservation.date_of_add3;
                        //this.objReservation.reservation_xtrabed_amt;
                        //this.objReservation.reservation_rel_with_lodg;
                        //this.objReservation.reservation_nationality;
                        //this.objReservation.reservation_age;
                        //this.objReservation.reservation_pra;
                        //this.objReservation.reservation_dt_ap_arriv;
                        //this.objReservation.reservation_from_lodg_arrv;
                        //this.objReservation.reservation_reas_visit;
                        //this.objReservation.reservation_prob_dur_stay_in;
                        //this.objReservation.reservation_nat_accom;
                        //this.objReservation.reservation_next_proc;
                        //this.objReservation.reservation_passport;
                        //this.objReservation.reservation_addr_ind;
                        //this.objReservation.reservation_emp_ind;
                        //this.objReservation.reservation_no_dt_cert;
                        //this.objReservation.reservation_remark;
                        //this.objReservation.change_room_reser_id;
                        //this.objReservation.change_room_reser_id_PAR;
                        //this.objReservation.act_service_charges;
                        //this.objReservation.GRNo;
                        //this.objReservation.Discount; 
                        //this.objReservation.Comp_NUM;
                        //this.objReservation.CGuest_num;
                        //this.objReservation.planid;
                        //this.objReservation.ROOM_TYPE_ID;                            
                        //this.objReservation.reservation_extrabedFrom;
                        //this.objReservation.reservation_extrabedTo;
                        //this.objReservation.reservation_ExtraBedUptoDays;
                        //this.objReservation.ReserveType;
                        //this.objReservation.NoofaddlCust;
                        //this.objReservation.reservation_nationality2;
                        //this.objReservation.reservation_nationality1;
                        //this.objReservation.reservation_GuestRem2;
                        //this.objReservation.reservation_GuestRem1;
                        //this.objReservation.GRNo2;
                        //this.objReservation.GRNo1;
                        //this.objReservation.reservation_ADULTS2;
                        //this.objReservation.reservation_ADULTS1;
                        //this.objReservation.reservation_PI_title2;
                        //this.objReservation.reservation_PI_frstname2;
                        //this.objReservation.reservation_PI_title1;
                        //this.objReservation.reservation_PI_frstname1;
                        //this.objReservation.reservation_PI_reservtype;
                        //this.objReservation.reservation_Cformno;
                        //this.objReservation.hotelBillnodorm;
                        //this.objReservation.currentbookno;
                        //this.objReservation.reservation_NoRoom2;
                        //this.objReservation.reservation_NoDorm2;
                        //this.objReservation.reservation_NoRoom1;
                        //this.objReservation.reservation_NoDorm1;
                        //this.objReservation.reservation_NoRoom;
                        //this.objReservation.reservation_NoDorm;
                        //this.objReservation.reservation_shortname;
                        //this.objReservation.reservation_againstReserv;
                        //this.objReservation.reservation_roomfolio;
                        //this.objReservation.reservation_dormfolio;
                        //this.objReservation.reservation_LastPlaceStay;
                        //this.objReservation.reservation_sex;
                        //this.objReservation.reservation_DOB;
                        //this.objReservation.reservation_nationalityByBirth;
                        //this.objReservation.reservation_Parentage;
                        //this.objReservation.reservation_at_lodg_arrv;
                        //this.objReservation.reservation_PhNo;
                        //this.objReservation.reservation_Email;
                        //this.objReservation.reservation_addr_native;
                        //this.objReservation.reservation_DateRegn;
                        //this.objReservation.reservation_PlaceIssueRegn;
                        //this.objReservation.reservation_passportPlace;
                        //this.objReservation.reservation_passportDate;
                        //this.objReservation.reservation_passportExpiry;
                        //this.objReservation.reservation_VISAType;
                        //this.objReservation.reservation_VISA;
                        //this.objReservation.reservation_VISAPlace;
                        //this.objReservation.reservation_VISADate;
                        //this.objReservation.reservation_VISAExpiry;
                        //this.objReservation.reservation_OtherLodger;
                        #endregion Not in Used
                    };
                }
                FillPageReservData();
            }
        }

        private void btnSelectGuest_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmGuestSearch frmGuest = new frmGuestSearch())
                {
                    frmGuest.guestName = txtCustName.Text;
                    frmGuest.searchTypeObject = typeof(EL.Mast_guest);
                    frmGuest.ShowDialog();
                    if (frmGuest.GuestNum > 0)
                    {
                        GuestMasteretails(frmGuest.GuestNum);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnOpenByEntryNo_Click");
            }
        }        

        private void btnSemniarBook_Click(object sender, EventArgs e)
        {
            if (this.objReservation != null && this.objReservation.reservation_ID > 0)
            {
                //using (frmSeminarReservation frmSeminar = new frmSeminarReservation())
                //{
                //    this.Hide();
                //    frmSeminar.objReservation = new EL.RESERVATION_CHECKIN_WALKIN { GUEST_NUM = objReservation.GUEST_NUM };
                //    frmSeminar.ShowDialog();
                //    this.Close();
                //}
            }
            else
                CustomMessageBox.ShowInformationMessage("Please save current reservation details", string.Empty);
        }

        private void btnRoomFolio_Click(object sender, EventArgs e)
        {
            //try
            //{

            //}
            //catch (Exception ex)
            //{
            //    CommanBaseFN.ErrorPrint("", ex);
            //}
        }

        private void btnDormFolio_Click(object sender, EventArgs e)
        {
            //try
            //{

            //}
            //catch (Exception ex)
            //{
            //    CommanBaseFN.ErrorPrint("", ex);
            //}
        }

        #region Reservation Detail Status
        private void resetDetailsSection()
        {
            rowDetailIndex = -1;
            //dtmDetFromReserv.Value = DateTime.Today.Date;
            //dtmDetUptoReserv.Value = DateTime.Today.Date;
            txtNoOfRooms.Text = string.Empty;
            txtNoOfBeds.Text = string.Empty;
            txtDetRemarks.Text = string.Empty;
            if (cmbDetDorm.Items.Count > 0) cmbDetDorm.SelectedIndex = 0;
            txtDetRoomTypeAmt.Text = string.Empty;
            txtDetDormTypeAmt.Text = string.Empty;
            cmbDetDormType.SelectedIndex = 0;
            cmbDetRoomType.SelectedIndex = 0;
        }

        private void BindReservationStatus()
        {
            try
            {
                if (this.lstReservDetails == null) lstReservDetails = new List<EL.RESERVATION_DETAILS_STATUS>();
                
                int indexs = 1;
                var dbData = (from c in lstReservDetails
                              join d in objMasterData.GetRoomNumber() on c.reservation_dormid equals d.room_number_ID
                                  into ps
                              from d in ps.DefaultIfEmpty()
                              join e in objMasterData.GetRoomType() on c.RM_TYPE_ID1 equals e.RM_TYPE_ID into rq 
                              from e in rq.DefaultIfEmpty()
                              join f in objMasterData.GetRoomType() on c.RM_TYPE_ID2 equals f.RM_TYPE_ID into st
                              from f in st.DefaultIfEmpty()
                              select new
                              {
                                  c.reservation_status_id,
                                  SlNo = indexs++,
                                  From_Date = c.reservation_CHECKIN,
                                  Upto_Date = c.reservation_CHKOUT,
                                  Rooms = c.reservation_Rooms,
                                  RoomType = e != null ? e.RM_TYPE_DESC : string.Empty,
                                  RoomAmt = c.ROOMrate1.HasValue ? c.ROOMrate1.Value.ToString("0.00") : "0.00",
                                  Beds = c.reservation_Dorm,
                                  Dormators = d == null ? string.Empty : d.room_number_number,
                                  DormType = f != null ? f.RM_TYPE_DESC : string.Empty,
                                  DormAmt = c.ROOMrate2.HasValue ? c.ROOMrate2.Value.ToString("0.00") : "0.00",
                                  Remarks = c.reservation_remark
                              }).ToList();

                grdReservDetails.DataSource = dbData;
                grdReservDetails.Columns["reservation_status_id"].Visible = false;
                grdReservDetails.Columns["From_Date"].DefaultCellStyle.Format = "dd/MMM/yyyy";
                grdReservDetails.Columns["Upto_Date"].DefaultCellStyle.Format = "dd/MMM/yyyy";
                grdReservDetails.Columns["Rooms"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                grdReservDetails.Columns["RoomAmt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                grdReservDetails.Columns["Beds"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                grdReservDetails.Columns["Dormators"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                grdReservDetails.Columns["DormAmt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindReservationStatus");
            }
        }

        private void btnDetNew_Click(object sender, EventArgs e)
        {
            resetDetailsSection();
        }

        private void btnDetAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (objReservation != null)
                {
                    if (this.rowDetailIndex > -1 && this.lstReservDetails.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(txtNoOfRooms.Text)) this.lstReservDetails[this.rowDetailIndex].reservation_Rooms = Convert.ToInt32(txtNoOfRooms.Text);
                        if (cmbDetDorm.SelectedIndex > 0) this.lstReservDetails[this.rowDetailIndex].reservation_dormid = Convert.ToInt32(cmbDetDorm.SelectedValue);
                        if (!string.IsNullOrEmpty(txtNoOfBeds.Text)) this.lstReservDetails[this.rowDetailIndex].reservation_Dorm = Convert.ToInt32(txtNoOfBeds.Text);
                        this.lstReservDetails[this.rowDetailIndex].reservation_CHKOUT = dtmDetUptoReserv.Value.Date;
                        this.lstReservDetails[this.rowDetailIndex].reservation_CHECKIN = dtmDetFromReserv.Value.Date;
                        this.lstReservDetails[this.rowDetailIndex].reservation_remark = txtDetRemarks.Text;

                        if(cmbDetRoomType.SelectedIndex > 0) this.lstReservDetails[this.rowDetailIndex].RM_TYPE_ID1 = (int)cmbDetRoomType.SelectedValue;
                        if (!string.IsNullOrEmpty(txtDetRoomTypeAmt.Text)) this.lstReservDetails[this.rowDetailIndex].ROOMrate1 = Convert.ToDouble(txtDetRoomTypeAmt.Text);
                        if(cmbDetDormType.SelectedIndex > 0) this.lstReservDetails[this.rowDetailIndex].RM_TYPE_ID2 = (int)cmbDetDormType.SelectedValue;
                        if (!string.IsNullOrEmpty(txtDetDormTypeAmt.Text)) this.lstReservDetails[this.rowDetailIndex].ROOMrate2 = Convert.ToDouble(txtDetDormTypeAmt.Text);
                    }
                    else
                    {
                        EL.RESERVATION_DETAILS_STATUS objReserDet = new EL.RESERVATION_DETAILS_STATUS();
                        objReserDet.reservation_ID = objReservation.reservation_ID;
                        if (!string.IsNullOrEmpty(txtNoOfRooms.Text)) objReserDet.reservation_Rooms = Convert.ToInt32(txtNoOfRooms.Text);
                        objReserDet.reservation_remark = txtDetRemarks.Text;
                        if (cmbDetDorm.SelectedIndex > 0) objReserDet.reservation_dormid = Convert.ToInt32(cmbDetDorm.SelectedValue);
                        if (!string.IsNullOrEmpty(txtNoOfBeds.Text)) objReserDet.reservation_Dorm = Convert.ToInt32(txtNoOfBeds.Text);
                        objReserDet.reservation_CHKOUT = dtmDetUptoReserv.Value.Date;
                        objReserDet.reservation_CHECKIN = dtmDetFromReserv.Value.Date;

                        if (cmbDetRoomType.SelectedIndex > 0) objReserDet.RM_TYPE_ID1 = (int)cmbDetRoomType.SelectedValue;
                        if (!string.IsNullOrEmpty(txtDetRoomTypeAmt.Text)) objReserDet.ROOMrate1 = Convert.ToDouble(txtDetRoomTypeAmt.Text);
                        if (cmbDetDormType.SelectedIndex > 0) objReserDet.RM_TYPE_ID2 = (int)cmbDetDormType.SelectedValue;
                        if (!string.IsNullOrEmpty(txtDetDormTypeAmt.Text)) objReserDet.ROOMrate2 = Convert.ToDouble(txtDetDormTypeAmt.Text);

                        this.lstReservDetails.Add(objReserDet);
                    }
                    resetDetailsSection();
                    BindReservationStatus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDetAdd_Click");
            }
        }

        private void btnDetRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.rowDetailIndex > -1 && this.lstReservDetails.Count > 0)
                {
                    this.lstReservDetails.RemoveAt(this.rowDetailIndex);
                    resetDetailsSection();
                    BindReservationStatus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDetRemove_Click");
            }
        }

        private void grdReservDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex > -1)
                {
                    var currLst = lstReservDetails[e.RowIndex];
                    this.rowDetailIndex = e.RowIndex;

                    if (currLst.reservation_CHECKIN.HasValue) dtmDetFromReserv.Value = currLst.reservation_CHECKIN.Value;
                    if (currLst.reservation_CHKOUT.HasValue) dtmDetUptoReserv.Value = currLst.reservation_CHKOUT.Value;

                    txtNoOfRooms.Text = currLst.reservation_Rooms.HasValue ? currLst.reservation_Rooms.Value.ToString() : string.Empty;
                    txtNoOfBeds.Text = currLst.reservation_Dorm.HasValue ? currLst.reservation_Dorm.Value.ToString() : string.Empty;
                    cmbDetDorm.SelectedValue = currLst.reservation_dormid.HasValue ? currLst.reservation_dormid.Value : 0;
                    txtDetRemarks.Text = currLst.reservation_remark;

                    cmbDetRoomType.SelectedValue = currLst.RM_TYPE_ID1.HasValue ? currLst.RM_TYPE_ID1.Value : 0;
                    cmbDetDormType.SelectedValue = currLst.RM_TYPE_ID2.HasValue ? currLst.RM_TYPE_ID2.Value : 0;
                    txtDetRoomTypeAmt.Text = currLst.ROOMrate1.HasValue ? currLst.ROOMrate1.Value.ToString() : string.Empty;
                    txtDetDormTypeAmt.Text = currLst.ROOMrate2.HasValue ? currLst.ROOMrate2.Value.ToString() : string.Empty;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in grdReservDetails_CellDoubleClick");
            }
        }
        #endregion Reservation Detail Status

        #region Bottom Action
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            resetPageData();
            splitContainer1.Panel1.Controls.Remove(this.aplhaPanel);
            btnUndo.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            editPage = true;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel1.Controls.Remove(this.aplhaPanel);
            btnUndo.Enabled = true;
            btnSave.Enabled = true;
            btnAddNew.Enabled = false;
            btnEdit.Enabled = false;
            editPage = true;
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            editPage = false;
            EL.FilterClass objFilter = RefreshFilter();
            objFilter.UniqueId = this.objReservation.reservation_ID;
            resetPageData();
            if (objFilter.UniqueId > 0)
            {
                this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                FillPageReservData();
            }
            else
                btnLast_Click(sender, e);
        }

        private bool ValidateFormData()
        {
            if (string.IsNullOrEmpty(txtCustName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please select Customer !!", this.Text);
                txtCustName.Focus();
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateFormData() && this.objReservation != null)
                {
                    bool isNew = false;

                    objReservation.reservation_DATEofRESERV = dtmReservTo.Value.Date;
                    if (!string.IsNullOrEmpty(txtNoRoom.Text)) objReservation.reservation_NUMBER_ROOMS = Convert.ToInt32(txtNoRoom.Text);
                    else objReservation.reservation_NUMBER_ROOMS = null;
                    if (!string.IsNullOrEmpty(txtNoBeds.Text)) objReservation.reservation_NUMBER_BEDS = Convert.ToInt32(txtNoBeds.Text);
                    else objReservation.reservation_NUMBER_BEDS = null;
                    if (cmbDorm.SelectedIndex > 0) objReservation.reservation_dormid = Convert.ToInt32(cmbDorm.SelectedValue);
                    else objReservation.reservation_dormid = null;
                    objReservation.reservation_CHECKIN = dtmFromDate.Value.Date;
                    objReservation.reservation_CHKOUT = dtmTodate.Value.Date;
                    objReservation.reservation_UptoDays = (dtmTodate.Value.Date - dtmFromDate.Value.Date).Days == 0 ? 1 : (dtmTodate.Value.Date - dtmFromDate.Value.Date).Days;
                    objReservation.ReservRemarks = txtRemarks.Text;
                    objReservation.MachineName = Environment.MachineName;

                    objReservation.ROOMrate1 = !string.IsNullOrEmpty(txtRoomTypeRent.Text) ? Convert.ToDouble(txtRoomTypeRent.Text) : 0;
                    objReservation.ROOMrate2 = !string.IsNullOrEmpty(txtDormTypeRent.Text) ? Convert.ToDouble(txtDormTypeRent.Text) : 0;
                    objReservation.RM_TYPE_ID1 = cmbRoomType.SelectedIndex > 0 ? (int)cmbRoomType.SelectedValue : 0;
                    objReservation.RM_TYPE_ID2 = cmbDormType.SelectedIndex > 0 ? (int)cmbDormType.SelectedValue : 0;
                    objReservation.stexempted = chkServiceExmpt.Checked;
                    objReservation.BundledServ = chkServiceBundle.Checked;


                    if (this.objReservation.reservation_ID > 0)
                    {
                        #region Main Edit
                        objReservation.id1 = Frm_Login.UserLogin.log_id;
                        objReservation.date_of_mod = DateTime.Now;
                        objReservation.modifiedby = Frm_Login.UserLogin.loginID;
                        #endregion Main Edit
                    }
                    else
                    {
                        isNew = true;

                        #region Main Add
                        objReservation.id = Frm_Login.UserLogin.log_id;
                        objReservation.date_of_add = DateTime.Now;
                        objReservation.createdby = Frm_Login.UserLogin.loginID;
                        objReservation.ReceiptRightId = 2;
                        objReservation.ReceiptRightDesc = "Residence";
                        #endregion Main Add
                    }

                    objReservation.RESERVATION_DETAILS_STATUS = lstReservDetails;

                    EL.RESERVATION_CHECKIN_WALKIN objNewReservation = isNew ? objReservBook.SaveReservation(this.objReservation) : objReservBook.UpdateReservation(this.objReservation);
                    
                    resetPageData();
                    this.objReservation = objNewReservation;
                    if (this.objReservation != null)
                        CustomMessageBox.ShowInformationMessage("Record Saved !!!", this.Text);
                    else if (this.objReservation == null && (Button)sender == btnDelete)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Saved !!!", this.Text);
                        btnAddNew_Click(sender, e);
                    }
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!!", this.Text);
                    
                    editPage = false;
                    FillPageReservData();
                    
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Unable to save data", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in Save data");
            }
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {

        }

        private void btnReceipt_Click(object sender, EventArgs e)
        {
            editPage = false;
            using (Transaction.frmVoucher frmVouch = new Transaction.frmVoucher())
            {
                frmVouch.reservationID = (this.objReservation != null) ? this.objReservation.reservation_ID : 0;
                frmVouch.ShowDialog();
                int reservid = (this.objReservation != null) ? this.objReservation.reservation_ID : 0;
                resetPageData();
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = reservid;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                FillPageReservData();
            }
        }

        private void btnMemo_Click(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                frmRoomEstimate frmEsimate = new frmRoomEstimate();
                frmEsimate.reservationID = (this.objReservation != null && this.objReservation.reservation_ID > 0 ? this.objReservation.reservation_ID : 0);
                frmEsimate.StartPosition = FormStartPosition.CenterScreen;
                frmEsimate.ShowDialog();
                this.Show();
                this.FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in btnPrint_Click");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                using (frmReservation frmSearch = new frmReservation())
                {
                    frmSearch.tagReservation = this.reservTagChar;
                    frmSearch.ShowDialog();
                    if (frmSearch.reservationid > 0)
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        objFilter.UniqueId = frmSearch.reservationid;
                        resetPageData();
                        this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                        FillPageReservData();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error In btnOpenByEntryNo_Click");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Hostel Booking ?") == System.Windows.Forms.DialogResult.OK)
                {
                    this.objReservation.cancelreservation = 0;
                    this.objReservation.activate_delete = true;
                    btnSave_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnOpenByEntryNo_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                string strValue = string.Empty;
                int entryno = 0;
                if (CustomFormFunction.InputBox("Search by Entry No", "Please enter Entry No", ref strValue) == System.Windows.Forms.DialogResult.OK)
                {
                    if (int.TryParse(strValue, out entryno))
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        objFilter.RecordNumber = entryno;
                        EL.RESERVATION_CHECKIN_WALKIN objReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);

                        if (objReserv != null)
                        {
                            resetPageData();
                            this.objReservation = objReserv;
                            FillPageReservData();
                        }
                        else
                            CustomMessageBox.ShowHandMessage("Record not found", this.Text);
                    }
                    else
                        CustomMessageBox.ShowHandMessage("Invalid Input !!!", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnOpenByEntryNo_Click");
            }
        }
        #endregion Bottom Action

        #region First Last Next Previous
        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(RefreshFilter(), CommonVariables.RecordCatergory.First);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is First record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In First Records");
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.objReservation != null ? this.objReservation.reservation_ID : 0;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.Previous);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is First record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Previous Records");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.objReservation != null ? this.objReservation.reservation_ID : 0;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.Next);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is last record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Next Records");
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(RefreshFilter(), CommonVariables.RecordCatergory.Last);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is last record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Last Records");
            }
        }
        #endregion First Last Next Previous

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancellation_Click(object sender, EventArgs e)
        {
            using (frmCancelReservation frmCancelView = new frmCancelReservation())
            {
                frmCancelView.IsCancelForm = true;
                frmCancelView.reservationId = objReservation.reservation_ID;
                frmCancelView.reservationnumber = objReservation.reservation_NUMBER.HasValue ? objReservation.reservation_NUMBER.Value : 0;
                frmCancelView.title = objReservation.reservation_PI_title;
                frmCancelView.cname = objReservation.reservation_PI_frstname;
                frmCancelView.address = objReservation.reservation_PI_street;
                frmCancelView.address2 = objReservation.reservation_PI_street1;
                frmCancelView.reservdate = objReservation.reservation_DATEofRESERV.HasValue ? objReservation.reservation_DATEofRESERV.Value : DateTime.Now;
                frmCancelView.ShowDialog();
            }
        }

        private void BtnCancelHistory_Click(object sender, EventArgs e)
        {
            using (Search.frmCancelReservation frmCancelView = new frmCancelReservation())
            {
                frmCancelView.IsCancelForm = false;
                frmCancelView.reservationId = objReservation.reservation_ID;
                frmCancelView.reservationnumber = objReservation.reservation_NUMBER.HasValue ? objReservation.reservation_NUMBER.Value : 0;
                frmCancelView.title = objReservation.reservation_PI_title;
                frmCancelView.cname = objReservation.reservation_PI_frstname;
                frmCancelView.address = objReservation.reservation_PI_street;
                frmCancelView.address2 = objReservation.reservation_PI_street1;
                frmCancelView.reservdate = objReservation.reservation_DATEofRESERV.HasValue ? objReservation.reservation_DATEofRESERV.Value : DateTime.Now;
                frmCancelView.ShowDialog();
            }
        }

        private void cmbDormType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox cmbType = (ComboBox)sender;
                if (cmbType != null && cmbType.SelectedIndex > 0)
                {
                    int rmtypid = (int)cmbType.SelectedValue;
                    DBData.ROOM_TYPE_rates rmTypeRate = new DBData.ISIPMEntities().ROOM_TYPE_rates.Where(x => x.RM_TYPE_ID == rmtypid)
                        .OrderByDescending(x => x.RM_TYPE_rate_ID).FirstOrDefault();
                    if (rmTypeRate != null)
                    {
                        if (cmbType == cmbRoomType)
                        {
                            txtRoomTypeRent.Text = rmTypeRate.Room_Type_rate.HasValue ? rmTypeRate.Room_Type_rate.Value.ToString("0.00") : "0.00";
                        }
                        else if (cmbType == cmbDormType)
                        {
                            txtDormTypeRent.Text = rmTypeRate.Room_Type_rate.HasValue ? rmTypeRate.Room_Type_rate.Value.ToString("0.00") : "0.00";
                        }
                        else if (cmbType == cmbDetDormType)
                        {
                            txtDetDormTypeAmt.Text = rmTypeRate.Room_Type_rate.HasValue ? rmTypeRate.Room_Type_rate.Value.ToString("0.00") : "0.00";
                        }
                        else if (cmbType == cmbDetRoomType)
                        {
                            txtDetRoomTypeAmt.Text = rmTypeRate.Room_Type_rate.HasValue ? rmTypeRate.Room_Type_rate.Value.ToString("0.00") : "0.00";
                        }
                    }
                }
                else
                {
                    if (cmbType == cmbRoomType)
                    {
                        txtRoomTypeRent.Text = "0.00";
                    }
                    else if (cmbType == cmbDormType)
                    {
                        txtDormTypeRent.Text = "0.00";
                    }
                    else if (cmbType == cmbDetDormType)
                    {
                        txtDetDormTypeAmt.Text = "0.00";
                    }
                    else if (cmbType == cmbDetRoomType)
                    {
                        txtDetRoomTypeAmt.Text = "0.00";
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void cmbRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbDormType_SelectedIndexChanged(sender, e);
        }
    }
}
