﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Hostel
{
    public partial class frmHostelPlanerChart : Form
    {
        //Report objReportData = new ReportData();
        MasterCaller objReportData = new MasterCaller();
        HostelCaller objHostelData = new HostelCaller();
        DataTable dtChartData { get; set; }
        DataTable dtDetails { get; set; }
        Random randonGen = new Random();
        Dictionary<int, System.Drawing.Color> chartColor = new Dictionary<int, System.Drawing.Color>();

        public frmHostelPlanerChart()
        {
            InitializeComponent();
        }

        private void frmHostelPlanerChart_Load(object sender, EventArgs e)
        {
            dtmFromDate.Value = DateTime.Now;
            chkMergeCell.Checked = true;
            rdbBoth.Checked = true;
            dtmTodate.Value = DateTime.Now.AddDays(20);
            lblRoomDet.Text = "Room No :";
            lblDate.Text = "Dated :";
            loadPageData();
        }

        private void loadPageData()
        {
            try
            {
                DateTime dtFrm = dtmFromDate.Value;
                string filtrPeriod = string.Empty;

                while (dtFrm <= dtmTodate.Value)
                {
                    filtrPeriod += dtFrm.ToString("dd/MMM/yyyy") + ",";
                    dtFrm = dtFrm.AddDays(1);
                }

                string sqlQryRoom = string.Empty;
                string sqlQryReserv = string.Empty;
                if (rdbDormatory.Checked)
                {
                    sqlQryRoom = "SELECT room_number_ID,room_number_number FROM room_number WHERE Dormatory=1 AND room_number_conferenceRoom=0 ORDER BY Dormatory, room_number_number";
                    sqlQryReserv = @"select (b.reservation_PI_title+' '+b.reservation_PI_frstname+'  '+convert(varchar,b.reservation_number)+'   {'+convert(varchar,b.RESERVATION_CHECKIN,106)+' - '+convert(varchar,b.RESERVATION_CHKOUT,106)+'}') as Name,
                            a.RESERVATION_CHECKIN,b.reservation_ID,a.reservation_Rooms,a.reservation_dormid 
                            from RESERVATION_DAYWISE_STATUS a join RESERVATION_CHECKIN_WALKIN b on a.RESERVATION_id=b.RESERVATION_id
                            where b.tag_reserv_chkin_walkin='›' and a.reservation_dormid != 0 and Convert(Date,a.RESERVATION_CHECKIN) between 
                            '" + dtmFromDate.Value.Date.ToString("yyyy-MM-dd") + "' and '" + dtmTodate.Value.Date.ToString("yyyy-MM-dd") + "' order by a.reservation_ID";
                }
                else if (rdbRooms.Checked)
                {
                    sqlQryRoom = "SELECT room_number_ID,room_number_number FROM room_number WHERE Dormatory=0 AND room_number_conferenceRoom=0 ORDER BY Dormatory, room_number_number";
                    sqlQryReserv = @"select (b.reservation_PI_title+' '+b.reservation_PI_frstname+'  '+convert(varchar,b.reservation_number)+'   {'+convert(varchar,b.RESERVATION_CHECKIN,106)+' - '+convert(varchar,b.RESERVATION_CHKOUT,106)+'}') as Name,
                            a.RESERVATION_CHECKIN,b.reservation_ID,a.reservation_Rooms,a.reservation_dormid 
                            from RESERVATION_DAYWISE_STATUS a join RESERVATION_CHECKIN_WALKIN b on a.RESERVATION_id=b.RESERVATION_id
                            where b.tag_reserv_chkin_walkin='›' and a.reservation_Rooms != 0 and Convert(Date,a.RESERVATION_CHECKIN) between 
                            '" + dtmFromDate.Value.Date.ToString("yyyy-MM-dd") + "' and '" + dtmTodate.Value.Date.ToString("yyyy-MM-dd") + "' order by a.reservation_ID";
                }
                else
                {
                    sqlQryRoom = "SELECT room_number_ID,room_number_number FROM room_number WHERE room_number_conferenceRoom=0 ORDER BY Dormatory, room_number_number";
                    sqlQryReserv = @"select (b.reservation_PI_title+' '+b.reservation_PI_frstname+'  '+convert(varchar,b.reservation_number)+'   {'+convert(varchar,b.RESERVATION_CHECKIN,106)+' - '+convert(varchar,b.RESERVATION_CHKOUT,106)+'}') as Name,
                            a.RESERVATION_CHECKIN,b.reservation_ID,a.reservation_Rooms,a.reservation_dormid 
                            from RESERVATION_DAYWISE_STATUS a join RESERVATION_CHECKIN_WALKIN b on a.RESERVATION_id=b.RESERVATION_id
                            where b.tag_reserv_chkin_walkin='›' and (a.reservation_Rooms!=0 OR a.reservation_dormid!=0) and Convert(Date,a.RESERVATION_CHECKIN) between 
                            '" + dtmFromDate.Value.Date.ToString("yyyy-MM-dd") + "' and '" + dtmTodate.Value.Date.ToString("yyyy-MM-dd") + "' order by a.reservation_ID";
                }

                if (this.dtChartData != null) this.dtChartData = null;
                this.dtChartData = objReportData.GetDataTableData(sqlQryRoom, "Rooms");
                DataTable dtReserv = objReportData.GetDataTableData(sqlQryReserv, "Reserv");

                string[] dateColumns = filtrPeriod.Remove(filtrPeriod.Length - 1, 1).Split(',');
                foreach (string strDate in dateColumns) dtChartData.Columns.Add(new DataColumn { DataType = typeof(string), ColumnName = strDate });

                foreach (DataRow dr in dtReserv.Rows)
                {
                    foreach (DataColumn col in this.dtChartData.Columns)
                    {
                        if (Convert.ToDateTime(dr["RESERVATION_CHECKIN"]).ToString("dd/MMM/yyyy") == col.ColumnName)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["reservation_Rooms"])) && Convert.ToInt32(dr["reservation_Rooms"]) != 0)
                            {
                                IEnumerable<DataRow> datarow = this.dtChartData.Rows.Cast<DataRow>().Where(r => r[col.ColumnName].ToString() == "").Take(Convert.ToInt32(dr["reservation_Rooms"]));
                                datarow.ToList().ForEach(r => r.SetField(col.ColumnName, Convert.ToString(dr["reservation_ID"])));
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["reservation_dormid"])) && Convert.ToInt32(dr["reservation_dormid"]) != 0)
                            {
                                IEnumerable<DataRow> datarow = this.dtChartData.Rows.Cast<DataRow>().Where(r => r[col.ColumnName].ToString() == "" && Convert.ToInt32(r["room_number_ID"]) == Convert.ToInt32(dr["reservation_dormid"]));
                                datarow.ToList().ForEach(r => r.SetField(col.ColumnName, Convert.ToString(dr["reservation_ID"])));
                            }
                        }
                    }

                    if (!DBNull.Value.Equals(dr["reservation_ID"]) && Convert.ToInt32(dr["reservation_ID"]) > 0)
                    {
                        int reservId = Convert.ToInt32(dr["reservation_ID"]);

                        if (!chartColor.Any(x => x.Key == Convert.ToInt32(dr["reservation_ID"])))
                        {
                            var sColor = System.Drawing.Color.FromArgb(randonGen.Next(0, 255), randonGen.Next(0, 255), randonGen.Next(0, 255));
                            if (sColor == System.Drawing.Color.LimeGreen || sColor == System.Drawing.Color.Red)
                                System.Drawing.Color.FromArgb(randonGen.Next(0, 255), randonGen.Next(0, 255), randonGen.Next(0, 255));

                            if (objHostelData.GetHostelBillByReserveID(reservId).Any(x => x.Room_Dormatory != 5 && x.Bill_No.HasValue))
                                chartColor.Add(reservId, System.Drawing.Color.Red);
                            else
                                chartColor.Add(reservId, sColor);
                        }

                    }
                }

                dgvSemChart.DataSource = null;
                dgvSemChart.DataSource = GetChartData(this.dtChartData);

                dgvSemChart.Columns["room_number_number"].HeaderText = string.Empty;
                dgvSemChart.Columns["room_number_number"].Frozen = true;
                dgvSemChart.Columns["room_number_number"].DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                dgvSemChart.Columns["room_number_ID"].Visible = false;

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error on loading data in chart");
            }
        }

        private DataTable GetChartData(DataTable dtData)
        {
            if (this.dtDetails != null) this.dtDetails = null;

            DataTable newData = new DataTable { TableName = dtData.TableName };
            foreach (DataColumn dtCol in dtData.Columns)
                newData.Columns.Add(new DataColumn { DataType = typeof(string), ColumnName = dtCol.ColumnName });
            foreach (DataRow drRow in dtData.Rows)
            {
                DataRow nRow = newData.NewRow();
                foreach (DataColumn dtCol in dtData.Columns)
                {
                    string strVal = Convert.ToString(drRow[dtCol.ColumnName]);

                    if (dtCol.ColumnName != "room_number_number" && dtCol.ColumnName != "room_number_ID" && !string.IsNullOrEmpty(strVal))
                    {
                        string sqlQuery = @"select *,(T.Amount - T.ADJ) Balanced from(
                            select A.reservation_ID,(A.reservation_PI_title+A.reservation_PI_frstname) name,A.reservation_NUMBER,
                            H.Bill_No,H.hotelBill_ID, cast(H.totalamt as decimal(10,2)) Amount, 
                            cast((select isnull(SUM(amount_Adj),0) 
                            from receipt_payment_Adjust_details where hotelBill_ID=A.reservation_ID AND AdjType='Seminar') as decimal(10,2)) ADJ
                            from RESERVATION_CHECKIN_WALKIN A left join HotelBILL H ON A.reservation_ID=H.reservation_ID WHERE A.reservation_ID=" + strVal + " ) T";

                        DataTable dt = objReportData.GetDataTableData(sqlQuery, "Table1");
                        DataRow dr = dt.Rows[0];
                        nRow[dtCol.ColumnName] = Convert.ToString(dr["Name"]) + " " + Convert.ToString(dr["reservation_NUMBER"]);
                        if (dtDetails == null)
                            dtDetails = dt;
                        else
                        {
                            dtDetails.NewRow();
                            dtDetails.Rows.Add(dr.ItemArray);
                        }
                    }
                    else
                        nRow[dtCol.ColumnName] = strVal;

                }
                newData.Rows.Add(nRow);
            }

            return newData;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadPageData();
        }

        private void dgvSemChart_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex > 1 && e.RowIndex > -1)
                {
                    string reserVal = Convert.ToString(dtChartData.Rows[e.RowIndex][e.ColumnIndex]);
                    if (!string.IsNullOrEmpty(reserVal))
                    {
                        DataRow[] rd = this.dtDetails.Select("reservation_ID=" + reserVal);
                        if (rd != null)
                        {
                            lblRoomDet.Text = "Room No : " + Convert.ToString(dtChartData.Rows[e.RowIndex]["room_number_number"]);
                            lblDate.Text = "Dated : " + Convert.ToString(dtChartData.Columns[e.ColumnIndex].ColumnName);
                            txtResrvStatus.Text = "Name : " + Convert.ToString(rd[0]["name"]) + Environment.NewLine +
                                "Advance : " + Convert.ToString(rd[0]["ADJ"]) + Environment.NewLine +
                                "Bill Status : Bill No. : " + Convert.ToString(rd[0]["Bill_No"]) + " - Amt : " + Convert.ToString(rd[0]["Amount"]) + Environment.NewLine +
                                "Balance : " + Convert.ToString(rd[0]["Balanced"]);
                        }
                    }
                    else
                    {
                        lblRoomDet.Text = "Room No : ";
                        lblDate.Text = "Dated : ";
                        txtResrvStatus.Text = string.Empty;
                    }
                }
                else
                {
                    lblRoomDet.Text = "Room No : ";
                    lblDate.Text = "Dated : ";
                    txtResrvStatus.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in dgvSemChart_CellMouseEnter");
            }
        }

        private void dgvSemChart_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow grdRow in dgvSemChart.Rows)
            {
                foreach (DataGridViewCell dgCell in grdRow.Cells)
                {
                    if (dgCell.ColumnIndex > 1)
                    {
                        int cellindex = dgCell.ColumnIndex - 1;
                        string reservVal = Convert.ToString(dgCell.Value);
                        string prevVal = ((cellindex == 0 && cellindex == 1) ? string.Empty : Convert.ToString(grdRow.Cells[cellindex]));
                        if (!string.IsNullOrEmpty(reservVal))
                        {
                            string reserid = Convert.ToString(this.dtChartData.Rows[grdRow.Index][dgCell.ColumnIndex]);
                            DataRow[] rd = this.dtDetails.Select("reservation_ID=" + reserid);
                            if (rd != null && (string.IsNullOrEmpty(Convert.ToString(rd[0]["ADJ"])) && Convert.ToDecimal(rd[0]["ADJ"]) == 0))
                            {
                                dgCell.Style.BackColor = System.Drawing.Color.White;
                            }
                            else
                            {
                                if (chartColor.Any(x => x.Key == Convert.ToInt32(reserid)))
                                {
                                    dgCell.Style.BackColor = chartColor.FirstOrDefault(x => x.Key == Convert.ToInt32(reserid)).Value;
                                }
                            }

                            if (chkMergeCell.Checked && prevVal.Equals(reservVal))
                            {

                            }

                        }
                        else
                            dgCell.Style.BackColor = System.Drawing.Color.LimeGreen;
                    }
                }
            }
        }

        private void dgvSemChart_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex > 1 && e.RowIndex > -1)
                {
                    string reserVal = Convert.ToString(dtChartData.Rows[e.RowIndex][e.ColumnIndex]);
                    if (!string.IsNullOrEmpty(reserVal))
                    {
                        using (frmHostelReserv objSemReser = new frmHostelReserv())
                        {
                            objSemReser.reservationId = Convert.ToInt32(reserVal);
                            objSemReser.ShowDialog();
                        }
                    }
                }
                else
                {
                    lblRoomDet.Text = "Room No : ";
                    lblDate.Text = "Dated : ";
                    txtResrvStatus.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in get Data");
            }
        }

        private void btnOpenResrv_Click(object sender, EventArgs e)
        {

        }

        private void btnEixt_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {

        }        
    }
}
