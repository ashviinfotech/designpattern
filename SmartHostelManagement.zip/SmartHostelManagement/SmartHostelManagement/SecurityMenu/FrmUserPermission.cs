﻿using System;
using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
using System.Linq;
//using System.Reflection;
//using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;

namespace SmartHostelManagement.Security
{
    public partial class FrmUserPermission : Form
    {
        LoginAuth objloginAuth = new LoginAuth();
        EL.login objLogin { get; set; }
        private IDictionary<string, string> lstOfformName { get; set; }
        public FrmUserPermission()
        {
            InitializeComponent();
        }

        private void FrmUserPermission_Load(object sender, EventArgs e)
        {
            LoadUserList();
            listofFormName();            

            #region Commented Code
            //Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            //string frmName = string.Empty;
            //foreach (Assembly a in assemblies)
            //{
            //    var lstForms = a.GetTypes().Where(x=>x.BaseType == typeof(Form)).ToList();
            //    foreach (var items in lstForms)
            //    {
            //        var emptyCtor = items.GetConstructor(Type.EmptyTypes);
            //        if (emptyCtor != null)
            //        {
            //            try
            //            {
            //                Form f = (Form)emptyCtor.Invoke(new object[] { });
            //                listBox1.Items.Add(f.Text);
            //                frmName += f.Text + ", ";
            //            }
            //            catch 
            //            {

            //            }

            //        }
            //    }
            //    //lstForms[0]




            //    //foreach (Type t in types)
            //    //{
            //    //    if (t.BaseType == typeof(Form))
            //    //    {
            //    //        listBox1.Items.Add(t.ToString());
            //    //        listView1.Items.Add(t.ToString());
            //    //    }
            //   //}
            //}
            #endregion
        }

        private void LoadUserList()
        {
            try
            {
                IList<EL.login> lstUser = objloginAuth.GetLoginUsersDetails().Where(x=> x.DeactivateAcc != true).ToList();
                lstUser.Insert(0, new EL.login { log_id = 0, name = "--Select--" });
                IList<EL.login> lstUser2 = objloginAuth.GetLoginUsersDetails().Where(x => x.DeactivateAcc != true).ToList();
                lstUser2.Insert(0, new EL.login { log_id = 0, name = "--Select--" });

                cmbUserList.DataSource = lstUser;
                cmbUserList.ValueMember = "log_id";
                cmbUserList.DisplayMember = "name";

                cmbPreviousRole.DataSource = lstUser2;
                cmbPreviousRole.ValueMember = "log_id";
                cmbPreviousRole.DisplayMember = "name";

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "SetValuesOfControls");
            }
        }

        private void listofFormName()
        {
            Dictionary<string, string> dicFromName = new Dictionary<string, string>
            {
                { "frmCustomer" , "Customer Card" },
                { "frmRoomBill" , "Room Bill" },
                { "frmDormatoryBill" , "Dormatory Bill" },
                { "frmOccupancy" , "Daily Entry Form" },
                { "frmVoucher" , "Receipt Voucher" },
                { "frmUnbilledRoom" , "Unbilled Room" },
                { "frmUnbilledDormatory" , "Unbilled Dormatory" },
                { "frmPayRefund" , "Payment Voucher" },
                { "frmMembership" , "Membership" },
                { "frmMergeCustomer" , "Merge Customer" },
                { "frmRoomType", "Room Type Master" },
                { "frmRoomNumber", "Room Number Master" },
                { "frmNationality", "Nationality Master" },
                { "frmTitleMaster", "Title Master" },
                { "frmGuestMaster", "Guest Master" },
                { "frmHostelReserv", "Hostel Booking" },
                { "frmHostelPlanerChart", "Hostel Booking Chart" },
                { "frmSemOccupancy", "Occupancy By Name" },
                { "frmSemCollectionSum", "Collection Summary" },
                { "frmSemCollection", "Collection Summary (Bill Wise)" },
                { "frmSemOccupancyRate", "Occupancy Rate" },
                { "frmSemRevenueSum", "Seminar Revenue Summary" },
                { "frmSemRevenueDetail", "Seminar Revenue Details" },
                { "frmSemUnbilledBill", "Unbilled Party List" },
                { "frmSemItemSummary", "Item Wise Summary to Party" },
                { "frmSemCrediSaleRegister", "Credit Sale Register" },
                { "frmSemCateringStatementDatewise", "Bill Statement for Catering" },
                { "frmSemStatementDateWise", "Bill Statement for Seminar" },
                { "frmItemListMaster", "Misc Head Master" },
                { "frmSeminarReservation", "Seminar Booking" },
                { "frmSeminarChart", "Seminar Booking Chart" },
                { "frmSeminarBill", "Seminar Bill" },
                { "frmSemiReserCancel", "Seminar Cancel" },
                { "frmCollection", "Collection" },
                { "frmRevenueSummary", "Revenue Summary" },
                { "frmRevenueDetails", "Revenue Detail" },
                { "frmUnbilledCustomer", "Unbilled Customer" },
                { "frmStatementofNationality", "Statement Of Nationality" },
                { "frmSaleSummary", "Sale Summary" },
                { "frmAdvanceSummary", "Advance Summary" },
                { "frmCashReceiptAgainst", "Cash Receipt Against" },
                { "frmBillStatement", "Bill Statement" },
                { "frmBillStatementDateWise", "Bill Statement Date Wise" },
                { "frmListofRoom", "List Of Room" },
                { "frmListofCashReceipt", "List Of Cash Receipt" },
                { "frmListOfAdditionalGuest", "List Of Additional Guest" },
                { "frmPartyWiseSummary", "Party Wise Summary" },
                { "frmMonthlyOccupancy", "Monthly Occupancy" },
                { "frmAccountAdvanceSummary", "Account Advance Summary" },
                { "frmBackupdata", "Backup Data" },
                { "frmLoginCreation", "Login Creation" },
                { "frmChangePassword", "Change Password" },
                { "FrmUserPermission", "User Permission" }
            };

            lstOfformName = dicFromName;

            foreach (var item in lstOfformName)
            {
                dgvformName.Rows.Add(item.Key, item.Value);
            }
            dgvformName.ClearSelection();
        }

        private void cmbUserList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbUserList.SelectedIndex > 0)
                {
                    this.objLogin = objloginAuth.GetLoginDetails(new EL.login { log_id = Convert.ToInt32(cmbUserList.SelectedValue) });
                    dgvformName.ClearSelection();
                    dgvformName_CellClick(sender, null);
                }
                else
                {
                    this.objLogin = null;
                    dgvformName.ClearSelection();
                    dgvformName_CellClick(sender, null);                    
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "cmbUserList_SelectedIndexChanged");
            }
        }

        private void dgvformName_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //if (e.ColumnIndex > 0 && e.RowIndex >= -1)
                //{
                //    string strformId = Convert.ToString(dgvformName.Rows[e.RowIndex].Cells[0].Value);
                //    EL.login_perm_Hotel objPerm = new EL.login_perm_Hotel();// = this.objLogin.login_perm_Hotels_extra.FirstOrDefault(x => x.form_name.ToUpper() == strformId.ToUpper());

                //    if (objPerm != null)
                //    {
                //        if (objPerm.per_add.HasValue && objPerm.per_add.Value)
                //            chkListPermission.SetItemCheckState(0, CheckState.Checked);
                //        else
                //            chkListPermission.SetItemCheckState(0, CheckState.Unchecked);

                //        if (objPerm.per_mod.HasValue && objPerm.per_mod.Value)
                //            chkListPermission.SetItemCheckState(1, CheckState.Checked);
                //        else
                //            chkListPermission.SetItemCheckState(1, CheckState.Unchecked);

                //        if (objPerm.per_view.HasValue && objPerm.per_view.Value)
                //            chkListPermission.SetItemCheckState(2, CheckState.Checked);
                //        else
                //            chkListPermission.SetItemCheckState(2, CheckState.Unchecked);

                //        if (objPerm.per_del.HasValue && objPerm.per_del.Value)
                //            chkListPermission.SetItemCheckState(3, CheckState.Checked);
                //        else
                //            chkListPermission.SetItemCheckState(3, CheckState.Unchecked);

                //        if (objPerm.per_print.HasValue && objPerm.per_print.Value)
                //            chkListPermission.SetItemCheckState(4, CheckState.Checked);
                //        else
                //            chkListPermission.SetItemCheckState(4, CheckState.Unchecked);

                //        if (objPerm.percheckout.HasValue && objPerm.percheckout.Value)
                //            chkListPermission.SetItemCheckState(5, CheckState.Checked);
                //        else
                //            chkListPermission.SetItemCheckState(5, CheckState.Unchecked);
                //    }
                //    else
                //    {
                //        chkListPermission.SetItemCheckState(0, CheckState.Unchecked);
                //        chkListPermission.SetItemCheckState(1, CheckState.Unchecked);
                //        chkListPermission.SetItemCheckState(2, CheckState.Unchecked);
                //        chkListPermission.SetItemCheckState(3, CheckState.Unchecked);
                //        chkListPermission.SetItemCheckState(4, CheckState.Unchecked);
                //        chkListPermission.SetItemCheckState(5, CheckState.Unchecked);
                //    }
                //}
                //else
                //{
                //    chkListPermission.SetItemCheckState(0, CheckState.Unchecked);
                //    chkListPermission.SetItemCheckState(1, CheckState.Unchecked);
                //    chkListPermission.SetItemCheckState(2, CheckState.Unchecked);
                //    chkListPermission.SetItemCheckState(3, CheckState.Unchecked);
                //    chkListPermission.SetItemCheckState(4, CheckState.Unchecked);
                //    chkListPermission.SetItemCheckState(5, CheckState.Unchecked);
                //}
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "dgvformName_CellClick");
            }
        }

        private void btnDeleteRoles_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbUserList.SelectedIndex > 0)
                {
                    EL.login delLogin = new EL.login { log_id = Convert.ToInt32(cmbUserList.SelectedValue) };
                    if (CustomMessageBox.ShowDialogBoxMessage("Delete this User Rights ?") == System.Windows.Forms.DialogResult.OK)
                    {
                        if (objloginAuth.DeleteUserPermission(delLogin))
                        {
                            CustomMessageBox.ShowInformationMessage("Record Deleted !!", this.Text);
                        }
                        else
                        {
                            CustomMessageBox.ShowInformationMessage("Unable to delete this User rights !!", this.Text);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chkListPermission.Items.Count; i++)
            {
                chkListPermission.SetItemChecked(i, true);
            }
        }

        private void btnUnSelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chkListPermission.Items.Count; i++)
            {
                chkListPermission.SetItemChecked(i, false);
            }
        }

        private void btnLoginDetails_Click(object sender, EventArgs e)
        {

        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            cmbUserList.SelectedIndex = 0;
            cmbPreviousRole.SelectedIndex = 0;
            btnUnSelectAll_Click(null, null);
            dgvformName.Rows.Clear();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (objLogin != null)
                {
                    if (objLogin.login_perm_Hotels == null) objLogin.login_perm_Hotels = new List<EL.login_perm_Hotel>();

                    if (objLogin.login_perm_Hotels.Any(x => x.form_name.ToUpper() == Convert.ToString(dgvformName.SelectedCells[0].Value).ToUpper()))
                    {
                        int indexL = objLogin.login_perm_Hotels.FindIndex(x => x.form_name.ToUpper() == Convert.ToString(dgvformName.SelectedCells[0].Value).ToUpper());
                        objLogin.login_perm_Hotels[indexL].per_add = chkListPermission.GetItemChecked(0);
                        objLogin.login_perm_Hotels[indexL].per_mod = chkListPermission.GetItemChecked(1);
                        objLogin.login_perm_Hotels[indexL].per_view = chkListPermission.GetItemChecked(2);
                        objLogin.login_perm_Hotels[indexL].per_del = chkListPermission.GetItemChecked(3);
                        objLogin.login_perm_Hotels[indexL].per_print = chkListPermission.GetItemChecked(4);
                        objLogin.login_perm_Hotels[indexL].percheckout = chkListPermission.GetItemChecked(5);
                    }
                    else
                    {
                        objLogin.login_perm_Hotels.Add(new EL.login_perm_Hotel
                        {
                            log_id = objLogin.log_id,
                            per_add = chkListPermission.GetItemChecked(0),
                            per_mod = chkListPermission.GetItemChecked(1),
                            per_view = chkListPermission.GetItemChecked(2),
                            per_del = chkListPermission.GetItemChecked(3),
                            per_print = chkListPermission.GetItemChecked(4),
                            percheckout = chkListPermission.GetItemChecked(5),
                            form_name = Convert.ToString(dgvformName.SelectedCells[0].Value)
                        });
                    }

                    if (objloginAuth.CreateUpdateUserPermission(objLogin))
                        CustomMessageBox.ShowInformationMessage("Record has bee updated.", "Delete");
                    else
                        CustomMessageBox.ShowInformationMessage("Record not update.", "Delete");
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please select user/permission.", "Delete");
                }

                btnRefersh_Click(sender, e);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Delete All roles");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete all role of selected user ?") == DialogResult.Yes)
                {
                    objLogin.login_perm_Hotels = new List<EL.login_perm_Hotel>();
                    if (objloginAuth.CreateUpdateUserPermission(objLogin))
                        CustomMessageBox.ShowInformationMessage("Record has bee updated.", "Delete");
                    else
                        CustomMessageBox.ShowInformationMessage("Record not update.", "Delete");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Delete All roles");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }        
    }
}
