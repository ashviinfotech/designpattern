﻿using System;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Security
{
    public partial class frmChangePassword : Form
    {
        LoginAuth objLoginAuth = new LoginAuth();

        public frmChangePassword()
        {
            InitializeComponent();
        }

        private void btnChangePwd_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtNewPwd.Text) && !string.IsNullOrEmpty(txtCnfrmPwd.Text))
                {
                    if (txtNewPwd.Text.Trim().Equals(txtCnfrmPwd.Text.Trim()))
                    {
                        EL.login objLogin = objLoginAuth.GetLoginDetails(Frm_Login.UserLogin);
                        if (objLogin != null)
                        {
                            if (!string.IsNullOrEmpty(txtNewUserID.Text.Trim()))
                                objLogin.loginID = txtNewUserID.Text.Trim();
                            objLogin.password = txtNewPwd.Text.Trim();

                            if(objLoginAuth.UpdateUserLogin(objLogin))
                                CustomMessageBox.ShowInformationMessage("Password Change Successfull !!!", this.Text);
                            else
                                CustomMessageBox.ShowInformationMessage("Password not Change !!!", this.Text);

                            txtNewUserID.Text = string.Empty;
                            txtPassword.Text = string.Empty;
                            txtNewPwd.Text = string.Empty;
                            txtCnfrmPwd.Text = string.Empty;
                        }
                    }
                    else
                    {
                        CustomMessageBox.ShowInformationMessage("Password not matched !!", this.Text);
                        txtCnfrmPwd.Text = string.Empty;
                        txtNewPwd.Text = string.Empty;
                        txtNewPwd.Focus();
                    }
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please enter Password !!", this.Text);
                    txtCnfrmPwd.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, this.Text);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
