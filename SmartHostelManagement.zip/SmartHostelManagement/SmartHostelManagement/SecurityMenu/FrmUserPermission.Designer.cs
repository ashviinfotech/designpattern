﻿namespace SmartHostelManagement.Security
{
    partial class FrmUserPermission
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvformName = new System.Windows.Forms.DataGridView();
            this.btnRefersh = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbUserList = new System.Windows.Forms.ComboBox();
            this.btnDeleteRoles = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkListPermission = new System.Windows.Forms.CheckedListBox();
            this.btnUnSelectAll = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbPreviousRole = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLoginDetails = new System.Windows.Forms.Button();
            this.btnSelectAll = new System.Windows.Forms.Button();
            this.formid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FormsName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvformName)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.dgvformName);
            this.groupBox1.Location = new System.Drawing.Point(15, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(397, 374);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Forms Names";
            // 
            // dgvformName
            // 
            this.dgvformName.AllowUserToAddRows = false;
            this.dgvformName.AllowUserToDeleteRows = false;
            this.dgvformName.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvformName.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvformName.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvformName.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvformName.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.formid,
            this.FormsName});
            this.dgvformName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvformName.Location = new System.Drawing.Point(3, 18);
            this.dgvformName.MultiSelect = false;
            this.dgvformName.Name = "dgvformName";
            this.dgvformName.ReadOnly = true;
            this.dgvformName.RowHeadersVisible = false;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvformName.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvformName.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvformName.ShowCellErrors = false;
            this.dgvformName.ShowCellToolTips = false;
            this.dgvformName.ShowEditingIcon = false;
            this.dgvformName.ShowRowErrors = false;
            this.dgvformName.Size = new System.Drawing.Size(391, 353);
            this.dgvformName.TabIndex = 87;
            this.dgvformName.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvformName_CellClick);
            // 
            // btnRefersh
            // 
            this.btnRefersh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefersh.Location = new System.Drawing.Point(428, 401);
            this.btnRefersh.Name = "btnRefersh";
            this.btnRefersh.Size = new System.Drawing.Size(80, 31);
            this.btnRefersh.TabIndex = 4;
            this.btnRefersh.Text = "Referesh";
            this.btnRefersh.UseVisualStyleBackColor = true;
            this.btnRefersh.Click += new System.EventHandler(this.btnRefersh_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 14);
            this.label3.TabIndex = 3;
            this.label3.Text = "User Id :";
            // 
            // cmbUserList
            // 
            this.cmbUserList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbUserList.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUserList.FormattingEnabled = true;
            this.cmbUserList.Location = new System.Drawing.Point(90, 18);
            this.cmbUserList.Name = "cmbUserList";
            this.cmbUserList.Size = new System.Drawing.Size(180, 22);
            this.cmbUserList.TabIndex = 67;
            this.cmbUserList.SelectedIndexChanged += new System.EventHandler(this.cmbUserList_SelectedIndexChanged);
            // 
            // btnDeleteRoles
            // 
            this.btnDeleteRoles.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteRoles.Location = new System.Drawing.Point(286, 15);
            this.btnDeleteRoles.Name = "btnDeleteRoles";
            this.btnDeleteRoles.Size = new System.Drawing.Size(121, 27);
            this.btnDeleteRoles.TabIndex = 68;
            this.btnDeleteRoles.Text = "Delete Roles";
            this.btnDeleteRoles.UseVisualStyleBackColor = true;
            this.btnDeleteRoles.Click += new System.EventHandler(this.btnDeleteRoles_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.groupBox2.Controls.Add(this.chkListPermission);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnSelectAll);
            this.groupBox2.Controls.Add(this.btnUnSelectAll);
            this.groupBox2.Location = new System.Drawing.Point(456, 58);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(281, 227);
            this.groupBox2.TabIndex = 69;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "User Rights";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(6, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Permissions";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkListPermission
            // 
            this.chkListPermission.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.chkListPermission.FormattingEnabled = true;
            this.chkListPermission.Items.AddRange(new object[] {
            "Add",
            "Modify",
            "View",
            "Delete",
            "Print",
            "Rights On Check Out"});
            this.chkListPermission.Location = new System.Drawing.Point(6, 44);
            this.chkListPermission.Name = "chkListPermission";
            this.chkListPermission.Size = new System.Drawing.Size(270, 140);
            this.chkListPermission.TabIndex = 5;
            // 
            // btnUnSelectAll
            // 
            this.btnUnSelectAll.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUnSelectAll.Location = new System.Drawing.Point(175, 190);
            this.btnUnSelectAll.Name = "btnUnSelectAll";
            this.btnUnSelectAll.Size = new System.Drawing.Size(101, 31);
            this.btnUnSelectAll.TabIndex = 4;
            this.btnUnSelectAll.Text = "Unselect All";
            this.btnUnSelectAll.UseVisualStyleBackColor = true;
            this.btnUnSelectAll.Click += new System.EventHandler(this.btnUnSelectAll_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(459, 297);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 28);
            this.label4.TabIndex = 3;
            this.label4.Text = "Copy Rights From:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbPreviousRole
            // 
            this.cmbPreviousRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPreviousRole.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbPreviousRole.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPreviousRole.FormattingEnabled = true;
            this.cmbPreviousRole.Location = new System.Drawing.Point(554, 301);
            this.cmbPreviousRole.Name = "cmbPreviousRole";
            this.cmbPreviousRole.Size = new System.Drawing.Size(183, 22);
            this.cmbPreviousRole.TabIndex = 67;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(513, 401);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(76, 31);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(594, 401);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 31);
            this.button2.TabIndex = 4;
            this.button2.Text = "&Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(684, 401);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 31);
            this.button1.TabIndex = 70;
            this.button1.Text = "&Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLoginDetails
            // 
            this.btnLoginDetails.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoginDetails.Location = new System.Drawing.Point(582, 355);
            this.btnLoginDetails.Name = "btnLoginDetails";
            this.btnLoginDetails.Size = new System.Drawing.Size(169, 31);
            this.btnLoginDetails.TabIndex = 4;
            this.btnLoginDetails.Text = "User Login Details";
            this.btnLoginDetails.UseVisualStyleBackColor = true;
            this.btnLoginDetails.Click += new System.EventHandler(this.btnLoginDetails_Click);
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectAll.Location = new System.Drawing.Point(68, 190);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(101, 31);
            this.btnSelectAll.TabIndex = 4;
            this.btnSelectAll.Text = "Select All";
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            // 
            // formid
            // 
            this.formid.HeaderText = "Forms ID";
            this.formid.Name = "formid";
            this.formid.ReadOnly = true;
            this.formid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.formid.Visible = false;
            // 
            // FormsName
            // 
            this.FormsName.HeaderText = "Forms Name";
            this.FormsName.Name = "FormsName";
            this.FormsName.ReadOnly = true;
            this.FormsName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // FrmUserPermission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(763, 441);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnLoginDetails);
            this.Controls.Add(this.btnRefersh);
            this.Controls.Add(this.btnDeleteRoles);
            this.Controls.Add(this.cmbPreviousRole);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbUserList);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmUserPermission";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User Permission Details";
            this.Load += new System.EventHandler(this.FrmUserPermission_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvformName)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnRefersh;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbUserList;
        private System.Windows.Forms.Button btnDeleteRoles;
        private System.Windows.Forms.DataGridView dgvformName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckedListBox chkListPermission;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUnSelectAll;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbPreviousRole;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSelectAll;
        private System.Windows.Forms.Button btnLoginDetails;
        private System.Windows.Forms.DataGridViewTextBoxColumn formid;
        private System.Windows.Forms.DataGridViewTextBoxColumn FormsName;
    }
}