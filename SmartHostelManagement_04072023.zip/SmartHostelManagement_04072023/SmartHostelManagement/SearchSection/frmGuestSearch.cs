﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Search
{
    public partial class frmGuestSearch : Form
    {
        GuestCaller objGuestData = new GuestCaller();
        MasterCaller objMasterData = new MasterCaller();

        public Type searchTypeObject { get; set; }
        public string guestName { get; set; }
        public int GuestNum { get; private set; }

        public frmGuestSearch()
        {
            InitializeComponent();
        }

        private void frmGuestSearch_Load(object sender, EventArgs e)
        {
            txtSearchName.Text = guestName;
            BindGridView(guestName);
        }

        private void BindGridView(string guestname)
        {
            try
            {
                if(searchTypeObject == typeof(EL.CompanyGuest))
                {
                    this.Text = "Guest Type Master Search";
                    IList<EL.CompanyGuest> companyGuestList = objGuestData.SearchCompanyGuest(txtSearchName.Text).OrderBy(x => x.CGUEST_CODE).ToList();
                    var dbdata = companyGuestList.Select((c, index) =>
                        new
                        {
                            c.CGuest_num,
                            SlNo = index + 1,
                            Guest_Code = c.CGUEST_CODE,
                            Guest_Type = c.CG_FNAME,
                            GST_Num = c.GST_NO,
                            PAN_Num = c.UID_NO,
                            PhoneNo = c.CG_PHONE1
                        });

                    datagrdiview.DataSource = dbdata.ToList();
                }
                else if (searchTypeObject == typeof(EL.Mast_guest)) 
                {
                    IList<EL.Mast_guest> guestList = objGuestData.SearchMastGuest(guestname).OrderBy(x => x.G_FNAME).ToList();
                    var dbdata = guestList.Select((c, index) =>
                        new
                        {
                            c.GUEST_NUM,
                            SlNo = index + 1,
                            GuestTitle = c.G_TITLE,
                            GuestName = c.G_FULLNAME,
                            Address = c.G_Street,
                            Country = c.G_COUNTRY,
                            PhoneNo = c.G_PHONE1
                        });

                    datagrdiview.DataSource = dbdata.ToList();
                }
                else if (searchTypeObject == typeof(EL.ROOM_TYPE))
                {
                    IList<EL.ROOM_TYPE> guestList = !string.IsNullOrEmpty(guestname) ? objMasterData.GetRoomType().Where(x => x.RM_TYPE_CODE.Contains(guestname)).ToList() 
                        : objMasterData.GetRoomType().ToList();
                    var dbdata = guestList.Select((c, index) =>
                        new
                        {
                            c.RM_TYPE_ID,
                            SlNo = index + 1,
                            RoomCode = c.RM_TYPE_CODE,
                            Description = c.RM_TYPE_DESC,
                            Room_Rate = c.Room_Type_rate,
                            NOP = c.NoPersons,
                            RoomType = string.Empty
                        });

                    datagrdiview.DataSource = dbdata.ToList();
                }
                else
                {
                    CustomMessageBox.ShowErrorMessage("Unable to find the search window", "Search Error");
                }

                datagrdiview.Columns[0].Visible = false;
                datagrdiview.Columns[1].Width = 45;
                datagrdiview.Columns[2].Width = 80;
                datagrdiview.Columns[3].Width = 170;
                datagrdiview.Columns[4].Width = 200;
                datagrdiview.Columns[5].Width = 80;
                datagrdiview.Columns[6].Width = 120;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Bind gridview Search frmGuestSearch Object");
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if(datagrdiview.SelectedRows.Count > 0)
                {
                    DataGridViewRow dr = datagrdiview.SelectedRows[0];
                    this.GuestNum = Convert.ToInt32(dr.Cells[0].Value);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in select data");
            }
        }

        private void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            BindGridView(txtSearchName.Text);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (datagrdiview.SelectedRows.Count > 0)
            {
                btnSelect_Click(sender, e);
            }
        }
    }
}
