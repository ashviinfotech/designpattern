﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Search
{
    public partial class frmHotelSearch : Form
    {
        HostelCaller objHostelData = new HostelCaller();

        public int hotelbillid { get; set; }
        public int roomDorm { get; set; }

        public frmHotelSearch()
        {
            InitializeComponent();
        }

        private void frmHotelSearch_Load(object sender, EventArgs e)
        {
            this.dtmReserFrom.Value = DateTime.Now;
            this.dtmResrvTo.Value = DateTime.Now.AddDays(30);
            LoadPageData();
        }

        private EL.FilterClass RefreshFilter()
        {
            return new EL.FilterClass
            {
                FinEnd = CommonVariables.dtmFinancialEnd.Year * 100 + CommonVariables.dtmFinancialEnd.Month,
                FinStart = CommonVariables.dtmFinancialStart.Year * 100 + CommonVariables.dtmFinancialStart.Month,
                FromDate = dtmReserFrom.Value,
                ToDate = dtmResrvTo.Value,
                BillNumber = 0,
                FolioNumber = 0,
                RecordCategory = 0,
                RecordNumber = 0,
                RoomCategory = roomDorm,
                SearchByText = string.Empty,
                tagChar = string.Empty,
                UniqueId = 0,
                Cancel = false
            }; ;
        }

        private void LoadPageData()
        {
            try
            {
                if (dtmReserFrom.Value < dtmResrvTo.Value)
                {
                    IList<EL.HotelBILL> lstHotel = objHostelData.GetHostelBillList(RefreshFilter());

                    var dbData = lstHotel.Select((x, index) => new
                    {
                        x.hotelBill_ID,
                        Slno = index + 1,
                        BillNo = x.Bill_No,
                        BillDate = x.Bdate.HasValue && x.Btime.HasValue ? x.Bdate.Value.Add(x.Btime.Value.TimeOfDay).ToString() : string.Empty,
                        Guest = x.Name_guest,
                        CheckIn = x.checkintime_date,
                        CheckOut = x.checkouttime_date,
                        NetAmount = x.totalamt
                    }).ToList();

                    dgvReservationDet.DataSource = dbData;
                    dgvReservationDet.Columns["hotelBill_ID"].Visible = false;
                    dgvReservationDet.Columns["Slno"].DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                    dgvReservationDet.Columns["BillDate"].DefaultCellStyle.Format = "dd/MMM/yyyy hh:mm:ss";
                    dgvReservationDet.Columns["CheckIn"].DefaultCellStyle.Format = "dd/MMM/yyyy hh:mm:ss";
                    dgvReservationDet.Columns["CheckOut"].DefaultCellStyle.Format = "dd/MMM/yyyy hh:mm:ss";
                    dgvReservationDet.Columns["NetAmount"].DefaultCellStyle.Format = "0.00";
                    dgvReservationDet.Columns["NetAmount"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                    dgvReservationDet.Columns["NetAmount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please check dates.", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in LoadPageData");
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadPageData();
        }

        private void dgvReservationDet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvReservationDet.SelectedRows.Count > 0)
            {
                DataGridViewRow grdRow = dgvReservationDet.SelectedRows[0];
                this.hotelbillid = Convert.ToInt32(grdRow.Cells["hotelBill_ID"].Value);
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            hotelbillid = 0;
            this.Close();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            dgvReservationDet_CellDoubleClick(sender, null);
        }
    }
}
