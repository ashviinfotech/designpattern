﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Search
{
    public partial class frmCancelReservation : Form
    {
        DBData.ISIPMEntities dbContext = null;
        public bool IsCancelForm { get; set; }
        private List<DBData.RESERVATION_DAYWISE_STATUS> lstdayWise = null;
        private List<DBData.RESERVATION_DAYWISE_CANCEL_STATUS> lstCanceldayWise = null;
        int rowDayIndex = -1;

        public int reservationId { get; set; }
        public int reservationnumber { get; set; }
        public string title { get; set; }
        public string cname { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
        public DateTime reservdate { get; set; }
        
        public frmCancelReservation()
        {
            InitializeComponent();
        }

        private void frmReservation_Load(object sender, EventArgs e)
        {
            BindComboBox();
            cmbTitle.Text = title;
            txtEntryNo.Text = reservationnumber.ToString();
            txtCustName.Text = cname;
            txtAddress.Text = address;
            txtAddress2.Text = address2;
            dtmReservTo.Value = reservdate;
            pageRefereshControl();
            frmReservation_Load();
        }

        void BindComboBox()
        {
            try
            {
                using (dbContext = new DBData.ISIPMEntities())
                {
                    List<DBData.MasterTitle> lstTitle = dbContext.MasterTitles.OrderBy(x => x.Titlename).ToList();
                    lstTitle.Insert(0, new DBData.MasterTitle { Titleid = 0, Titlename = string.Empty });

                    List<DBData.room_number> lstReservRoomNum = dbContext.room_number.Where(x => x.Dormatory == 1).OrderBy(x => x.room_number_number).ToList();
                    lstReservRoomNum.Insert(0, new DBData.room_number { room_number_ID = 0, room_number_number = string.Empty });

                    List<DBData.ROOM_TYPE> lstRoomTypeB = dbContext.ROOM_TYPE.Where(x => x.Room_dorm == 0).ToList();
                    lstRoomTypeB.Add(new DBData.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_DESC = string.Empty });

                    List<DBData.ROOM_TYPE> lstDormTypeB = dbContext.ROOM_TYPE.Where(x => x.Room_dorm == 1).ToList();
                    lstDormTypeB.Add(new DBData.ROOM_TYPE { RM_TYPE_ID = 0, RM_TYPE_DESC = string.Empty });

                    cmbTitle.DataSource = lstTitle;
                    cmbTitle.DisplayMember = "Titlename";
                    cmbTitle.ValueMember = "Titleid";

                    cmbDetDorm.DataSource = lstReservRoomNum;
                    cmbDetDorm.DisplayMember = "room_number_number";
                    cmbDetDorm.ValueMember = "room_number_ID";

                    cmbDetRoomType.DataSource = lstRoomTypeB.Select(x => new { roomdesc = (x.RM_TYPE_ID > 0 ? x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")" : string.Empty), x.RM_TYPE_ID }).ToList();
                    cmbDetRoomType.DisplayMember = "roomdesc";
                    cmbDetRoomType.ValueMember = "RM_TYPE_ID";

                    cmbDetDormType.DataSource = lstDormTypeB.Select(x => new { roomdesc = (x.RM_TYPE_ID > 0 ? x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")" : string.Empty), x.RM_TYPE_ID }).ToList();
                    cmbDetDormType.DisplayMember = "roomdesc";
                    cmbDetDormType.ValueMember = "RM_TYPE_ID";

                    if (IsCancelForm)
                        lstdayWise = dbContext.RESERVATION_DAYWISE_STATUS.Where(x => x.reservation_ID == reservationId).ToList();
                    else
                        lstCanceldayWise = dbContext.RESERVATION_DAYWISE_CANCEL_STATUS.Where(x => x.reservation_ID == reservationId).ToList();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindCombobox");
            }
        }

        void pageRefereshControl()
        {
            txtRoomQty.Text = string.Empty;
            txtRoomCancelQty.Text = string.Empty;
            txtBedQty.Text = string.Empty;
            txtBedCancelQty.Text = string.Empty;
            txtRoomTypeRate.Text = string.Empty;
            txtDormTypeRate.Text = string.Empty;
            txtDetRemarks.Text = string.Empty;
            dtmCancelledDate.Value = DateTime.Now;
            dtmDetUptoReserv.Value = DateTime.Now;
            cmbDetDorm.SelectedIndex = 0;
            cmbDetDormType.SelectedIndex = 0;
            cmbDetRoomType.SelectedIndex = 0;

            if (!IsCancelForm)
            {
                dtmCancelledDate.Enabled = false;
                txtRoomQty.Enabled = false;
                txtRoomCancelQty.Enabled = false;
                txtBedQty.Enabled = false;
                txtBedCancelQty.Enabled = false;
                txtRoomTypeRate.Enabled = false;
                txtDormTypeRate.Enabled = false;
                cmbDetDorm.Enabled = false;
                cmbDetRoomType.Enabled = false;
                txtDetRemarks.Enabled = false;
                dtmDetUptoReserv.Enabled = false;
                btnAddChange.Enabled = false;
                btnUndo.Enabled = false;
                btnExist.Enabled = false;
                button1.Enabled = false;
            }
        }

        void getReservationDetail()
        {
            try
            {
                using(dbContext = new DBData.ISIPMEntities())
                {
                    var objDayWiseReservtaion = dbContext.RESERVATION_DAYWISE_STATUS.FirstOrDefault(x => x.reservation_ID == reservationId);
                    if (objDayWiseReservtaion != null)
                    {
                        var objReserv = objDayWiseReservtaion.RESERVATION_CHECKIN_WALKIN;
                        cmbTitle.SelectedText = objReserv != null ? objReserv.reservation_PI_title : string.Empty;
                        txtEntryNo.Text = objReserv != null && objReserv.reservation_NUMBER.HasValue ? objReserv.reservation_NUMBER.Value.ToString() : string.Empty;
                        txtCustName.Text = objReserv != null ? objReserv.reservation_PI_frstname : string.Empty;
                        txtAddress.Text = objReserv!= null ? objReserv.reservation_PI_street : string.Empty;
                        txtAddress2.Text = objReserv != null ? objReserv.reservation_PI_organ : string.Empty;
                        dtmReservTo.Value = objReserv != null && objReserv.reservation_DATEofRESERV.HasValue ? objReserv.reservation_DATEofRESERV.Value : DateTime.Now;
                        dtmCancelledDate.Value = DateTime.Now;

                        dtmDetUptoReserv.Value = objDayWiseReservtaion.reservation_CHECKIN.HasValue ? objDayWiseReservtaion.reservation_CHECKIN.Value : DateTime.Now;
                        txtRoomQty.Text = objDayWiseReservtaion.reservation_Rooms.HasValue ? objDayWiseReservtaion.reservation_Rooms.Value.ToString() : string.Empty;
                        txtRoomCancelQty.Text = "0";
                        txtBedQty.Text = objDayWiseReservtaion.reservation_Dorm.HasValue ? objDayWiseReservtaion.reservation_Dorm.Value.ToString() : string.Empty;
                        txtBedCancelQty.Text = "0";
                        cmbDetDorm.SelectedValue = objDayWiseReservtaion.reservation_dormid.HasValue ? objDayWiseReservtaion.reservation_dormid.Value : 0;
                        cmbDetRoomType.SelectedValue = objDayWiseReservtaion.RM_TYPE_ID1.HasValue ? objDayWiseReservtaion.RM_TYPE_ID1.Value : 0;
                        cmbDetDormType.SelectedValue = objDayWiseReservtaion.RM_TYPE_ID2.HasValue ? objDayWiseReservtaion.RM_TYPE_ID2.Value : 0;
                        txtRoomTypeRate.Text = objDayWiseReservtaion.ROOMrate1.HasValue ? objDayWiseReservtaion.ROOMrate1.Value.ToString("0.00") : "0.00";
                        txtDormTypeRate.Text = objDayWiseReservtaion.ROOMrate2.HasValue ? objDayWiseReservtaion.ROOMrate2.Value.ToString("0.00") : "0.00"; 

                        lstCanceldayWise = objDayWiseReservtaion.RESERVATION_DAYWISE_CANCEL_STATUS.ToList();
                        frmReservation_Load();
                    }
                    else
                    {
                        CustomMessageBox.ShowErrorMessage("Unable to find Reservation Number!!", "Error");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Cancel Daywise getReservationDetail()");
            }
        }

        private void txtReceipt0_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void frmReservation_Load()
        {
            try
            {
                MasterCaller masterObj = new MasterCaller();
                IList<EL.room_number> lstRoom = masterObj.GetRoomNumber().ToList();
                IList<EL.ROOM_TYPE> lstRoomType = masterObj.GetRoomType().ToList();

                if (IsCancelForm)
                {
                    if (lstdayWise == null) new List<DBData.RESERVATION_DAYWISE_STATUS>();

                    var dbData = lstdayWise.Select((c, index) => new
                    {
                        SrNo = index + 1,
                        c.reservation_daywise_status_id,
                        ForDate = c.reservation_CHECKIN.HasValue ? c.reservation_CHECKIN.Value.ToString("dd-MMM-yyyy") : string.Empty,
                        Rooms = c.reservation_Rooms.HasValue ? c.reservation_Rooms.Value : 0,
                        Rooms_Cancel = string.Empty,
                        Rooms_Type = c.RM_TYPE_ID1.HasValue && lstRoomType.Any(x => x.RM_TYPE_ID == c.RM_TYPE_ID1.Value) ?
                            lstRoomType.FirstOrDefault(x => x.RM_TYPE_ID == c.RM_TYPE_ID1.Value).RM_TYPE_DESC : string.Empty,
                        Rooms_Rate = c.ROOMrate1.HasValue ? c.ROOMrate1.Value : 0,
                        Beds = c.reservation_Dorm.HasValue ? c.reservation_Dorm.Value : 0,
                        Beds_Cancel = string.Empty,
                        Dorm_Type = c.RM_TYPE_ID2.HasValue && lstRoomType.Any(x => x.RM_TYPE_ID == c.RM_TYPE_ID2.Value) ?
                            lstRoomType.FirstOrDefault(x => x.RM_TYPE_ID == c.RM_TYPE_ID2.Value).RM_TYPE_DESC : string.Empty,
                        Dorm_Rate = c.ROOMrate2.HasValue ? c.ROOMrate2.Value.ToString("0.00") : "0.00",
                        Remarks = c.reservation_remark
                    }).ToList();

                    dgvReservationDet.DataSource = dbData;
                    dgvReservationDet.Columns["reservation_daywise_status_id"].Visible = false;
                    dgvReservationDet.Columns["SlNo"].Frozen = true;
                }
                else
                {
                    if (lstCanceldayWise == null) new List<DBData.RESERVATION_DAYWISE_STATUS>();

                    var dbData = lstCanceldayWise.Select((c, index) =>
                    new
                    {
                        SrNo = index + 1,
                        c.reservation_daywise_status_id,
                        CancelDate = c.reservation_CancelDate.HasValue ? c.reservation_CancelDate.Value.ToString("dd-MMM-yyyy") : string.Empty,
                        ReservDate = c.reservation_CHECKIN.HasValue ? c.reservation_CHECKIN.Value.ToString("dd-MMM-yyyy") : string.Empty,
                        Rooms = c.reservation_Rooms.HasValue ? c.reservation_Rooms.Value : 0,
                        Rooms_Cancel = string.Empty,
                        Rooms_Type = c.RM_TYPE_ID1.HasValue && lstRoomType.Any(x => x.RM_TYPE_ID == c.RM_TYPE_ID1.Value) ?
                            lstRoomType.FirstOrDefault(x => x.RM_TYPE_ID == c.RM_TYPE_ID1.Value).RM_TYPE_DESC : string.Empty,
                        Rooms_Rate = c.ROOMrate1.HasValue ? c.ROOMrate1.Value : 0,
                        Beds = c.reservation_Dorm.HasValue ? c.reservation_Dorm.Value : 0,
                        Beds_Cancel = string.Empty,
                        Dorm_Type = c.RM_TYPE_ID2.HasValue && lstRoomType.Any(x => x.RM_TYPE_ID == c.RM_TYPE_ID2.Value) ?
                            lstRoomType.FirstOrDefault(x => x.RM_TYPE_ID == c.RM_TYPE_ID2.Value).RM_TYPE_DESC : string.Empty,
                        Dorm_Rate = c.ROOMrate2.HasValue ? c.ROOMrate2.Value.ToString("0.00") : "0.00",
                        Remarks = c.reservation_remark
                    }).ToList();

                    dgvReservationDet.DataSource = dbData.ToList();
                    dgvReservationDet.Columns["reservation_daywise_status_id"].Visible = false;
                    dgvReservationDet.Columns["SlNo"].Frozen = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex,"-->Error on page load.");
            }
        } 

        private void cmbDetRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox cmbBox = (ComboBox)sender;
                int rmTypeId = cmbBox.SelectedIndex > 0 ? (int)cmbBox.SelectedValue : 0;
                if (rmTypeId > 0)
                {
                    using (dbContext = new DBData.ISIPMEntities())
                    {
                        DBData.ROOM_TYPE_rates rmRate = dbContext.ROOM_TYPE_rates.OrderByDescending(x => x.RM_TYPE_rate_ID).FirstOrDefault(x => x.RM_TYPE_ID == rmTypeId);
                        
                        if (rmRate != null)
                        {
                            //txtMenuName.Text = cmbBox == cmbDetRoomType && rmRate.Room_Type_rate.HasValue ? rmRate.Room_Type_rate.Value.ToString("0.00") : string.Empty;
                            //txtBuffetTYpe.Text = cmbBox == cmbDetDormType && rmRate.Room_Type_rate.HasValue ? rmRate.Room_Type_rate.Value.ToString("0.00") : string.Empty;
                        }
                        else
                        {
                            //txtMenuName.Text = string.Empty;
                            //txtBuffetTYpe.Text = string.Empty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "cmbDetRoomType_SelectedIndexChanged");
            }
        }

        //Edit
        private void btnExist_Click(object sender, EventArgs e)
        {
            if (dgvReservationDet.SelectedRows.Count > 0)
            {
                rowDayIndex = dgvReservationDet.SelectedRows[0].Index;
                var currLst = lstdayWise[rowDayIndex];
                dtmDetUptoReserv.Value = currLst.reservation_realCHECKIN.HasValue ? currLst.reservation_realCHECKIN.Value : DateTime.Now;
                txtRoomQty.Text = currLst.reservation_Rooms.HasValue ? currLst.reservation_Rooms.Value.ToString() : string.Empty;
                txtRoomCancelQty.Text = "0";
                txtBedQty.Text = currLst.reservation_Dorm.HasValue ? currLst.reservation_Dorm.Value.ToString() : string.Empty;
                txtBedCancelQty.Text = "0";
                cmbDetDorm.SelectedValue = currLst.reservation_dormid.HasValue ? currLst.reservation_dormid.Value : 0;
                cmbDetRoomType.SelectedValue = currLst.RM_TYPE_ID1.HasValue ? currLst.RM_TYPE_ID1.Value : 0;
                cmbDetDormType.SelectedValue = currLst.RM_TYPE_ID2.HasValue ? currLst.RM_TYPE_ID2.Value : 0;
                txtRoomTypeRate.Text = currLst.ROOMrate1.HasValue ? currLst.ROOMrate1.Value.ToString("0.00") : "0.00";
                txtDormTypeRate.Text = currLst.ROOMrate2.HasValue ? currLst.ROOMrate2.Value.ToString("0.00") : "0.00"; 

                txtDetRemarks.Text = currLst.reservation_remark;
            }
        }

        //Add/Change
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                if (rowDayIndex > -1)
                {
                    if (lstCanceldayWise == null) lstCanceldayWise = new List<DBData.RESERVATION_DAYWISE_CANCEL_STATUS>();
                    int rmTypeId = cmbDetRoomType.SelectedIndex > 0 ? (int)cmbDetRoomType.SelectedValue : 0;
                    using (dbContext = new DBData.ISIPMEntities())
                    {
                        int noHrs = (int)(dtmDetUptoReserv.Value - dtmCancelledDate.Value).TotalHours;
                        DBData.Reservation_cancel_policy objCancelPolicy = dbContext.Reservation_cancel_policy
                            .FirstOrDefault(x => x.Type == "1" && x.from_hrs <= noHrs && x.to_hrs >= noHrs);
                        if (objCancelPolicy != null)
                        {
                            double noofFooms = !string.IsNullOrEmpty(txtRoomQty.Text) ? Convert.ToDouble(txtRoomQty.Text) : 0;
                            double noofRoomCancel = !string.IsNullOrEmpty(txtRoomCancelQty.Text) ? Convert.ToDouble(txtRoomCancelQty.Text) : 0;
                            double roomRent = !string.IsNullOrEmpty(txtRoomTypeRate.Text) ? Convert.ToDouble(txtRoomTypeRate.Text) : 0;
                            double noofDorm = !string.IsNullOrEmpty(txtBedQty.Text) ? Convert.ToDouble(txtBedQty.Text) : 0;
                            double noofDormCancel = !string.IsNullOrEmpty(txtBedCancelQty.Text) ? Convert.ToDouble(txtBedCancelQty.Text) : 0;
                            double dormRent = !string.IsNullOrEmpty(txtDormTypeRate.Text) ? Convert.ToDouble(txtDormTypeRate.Text) : 0;
                            double totalCharge = 0;

                            totalCharge = (noofFooms > 0) ? (noofRoomCancel * (objCancelPolicy.AmtPERC.HasValue ?
                                (objCancelPolicy.AmtPERC.Value * roomRent) / 100 : 0)) : (noofDormCancel * (objCancelPolicy.AmtPERC.HasValue ?
                                (objCancelPolicy.AmtPERC.Value * dormRent) / 100 : 0));
                            long maxId = dbContext.RESERVATION_DAYWISE_CANCEL_STATUS.Max(x => x.reservation_daywiseCANCEL_status_id) + 1;

                            DBData.RESERVATION_DAYWISE_CANCEL_STATUS objCancelDay = new DBData.RESERVATION_DAYWISE_CANCEL_STATUS
                            {
                                reservation_daywiseCANCEL_status_id = maxId,
                                reservation_daywise_status_id = lstdayWise[rowDayIndex].reservation_daywise_status_id,
                                reservation_ID = reservationId,
                                reservation_CHECKIN = dtmDetUptoReserv.Value,
                                reservation_CHKOUT = dtmDetUptoReserv.Value,
                                reservation_Rooms = (int)noofFooms,
                                reservation_Dorm = (int)noofDorm,
                                reservation_remark = txtDetRemarks.Text,
                                reservation_dormid = cmbDetDorm.SelectedIndex > 0 ? (int)cmbDetDorm.SelectedValue : 0,
                                RM_TYPE_ID1 = cmbDetRoomType.SelectedIndex > 0 ? (int)cmbDetRoomType.SelectedValue : 0,
                                ROOMrate1 = roomRent,
                                reservation_RoomsCancel = (int)noofRoomCancel,
                                reservation_DormCancel = (int)noofDormCancel,
                                reservation_CancelDate = dtmCancelledDate.Value,
                                cancel_hrs = noHrs,
                                Cancel_perc = objCancelPolicy.AmtPERC.HasValue ? objCancelPolicy.AmtPERC.Value : 0,
                                Cancel_charges = (noofFooms > 0) ? ((objCancelPolicy.AmtPERC.Value * roomRent) / 100) : ((objCancelPolicy.AmtPERC.Value * dormRent) / 100),
                                Cancel_charges_ttl = totalCharge,
                                reservation_RoomsORG = (int)noofFooms,
                                reservation_DormORG = (int)noofDorm
                            };
                            lstCanceldayWise.Add(objCancelDay);
                            lstdayWise[rowDayIndex].reservation_Rooms = (int)(noofFooms - noofRoomCancel);
                            lstdayWise[rowDayIndex].reservation_Dorm = (int)(noofDorm - noofDormCancel);
                            pageRefereshControl();
                            frmReservation_Load();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Btn Add Change");
            }
        }

        //Save
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (dbContext = new DBData.ISIPMEntities())
                {
                    dbContext.Configuration.LazyLoadingEnabled = false;

                    var resultData = dbContext.RESERVATION_DAYWISE_STATUS.Where(x => x.reservation_ID == reservationId);
                    foreach (var items in resultData)
                    {
                        var objDay = lstdayWise.FirstOrDefault(x => x.reservation_daywise_status_id == items.reservation_daywise_status_id);
                        if (objDay != null)
                        {
                            items.reservation_Rooms = objDay.reservation_Rooms;
                            items.reservation_Dorm = objDay.reservation_Dorm;
                        }
                    }

                    //var cancelData = dbContext.RESERVATION_DAYWISE_CANCEL_STATUS.Where(x => x.reservation_ID == reservationId);
                    //foreach (var item in lstCanceldayWise)
                    //{
                    //    var objDay = cancelData.FirstOrDefault(x => x.reservation_daywise_status_id == item.reservation_daywise_status_id);
                    //    if (objDay != null)
                    //    {
                    //        objDay.reservation_CHECKIN = item.reservation_CHECKIN;
                    //        objDay.reservation_CHKOUT = item.reservation_CHKOUT;
                    //        objDay.reservation_remark = item.reservation_remark;
                    //        objDay.reservation_dormid = item.reservation_dormid;
                    //        objDay.RM_TYPE_ID1 = item.RM_TYPE_ID2;
                    //        objDay.ROOMrate1 = item.ROOMrate2;
                    //        objDay.reservation_RoomsCancel = objDay.reservation_DormCancel.HasValue ? objDay.reservation_DormCancel.Value + item.reservation_DormCancel.Value : item.reservation_DormCancel.Value;
                    //        objDay.reservation_CancelDate = item.reservation_CancelDate;
                    //        objDay.cancel_hrs = item.cancel_hrs;
                    //        objDay.Cancel_perc = item.Cancel_perc;
                    //        objDay.Cancel_charges = item.Cancel_charges;
                    //        objDay.Cancel_charges_ttl = item.Cancel_charges_ttl;
                    //    }
                    //    else
                    //    {
                    //        dbContext.RESERVATION_DAYWISE_CANCEL_STATUS.Add(item);
                    //    }
                    //}
                    DBData.HotelBILL objHotelBill = dbContext.HotelBILLs.Where(x => x.reservation_ID == this.reservationId && x.activate_delete == false 
                        && x.HOTELBILLCANCEL == 0 && x.Room_Dormatory == (int)CommonVariables.RoomDormatory.Room).FirstOrDefault();
                    long maxId = dbContext.HotelBillCancelCharges.Any() ? dbContext.HotelBillCancelCharges.Max(x => x.HotelBillCancelCharges_id) + 1 : 1;
                    IList<DBData.ROOM_TYPE> lstRoomType = dbContext.ROOM_TYPE.ToList();
                    
                    foreach (var item in lstCanceldayWise)
                    {
                        dbContext.RESERVATION_DAYWISE_CANCEL_STATUS.Add(item);
                        if (objHotelBill != null)
                        {
                            DBData.HotelBillCancelCharge objChrg = new DBData.HotelBillCancelCharge
                            {
                                HotelBillCancelCharges_id = maxId,
                                hotelBill_ID = objHotelBill.hotelBill_ID,
                                reservation_daywiseCANCEL_status_id = item.reservation_daywiseCANCEL_status_id,
                                reservation_daywise_status_id = item.reservation_daywise_status_id,
                                reservation_ID = item.reservation_ID,
                                reservation_CHECKIN = item.reservation_CHECKIN,
                                reservation_CHKOUT = item.reservation_CHKOUT,
                                reservation_Rooms = item.reservation_Rooms,
                                reservation_Dorm = item.reservation_Dorm,
                                reservation_remark = item.reservation_remark,
                                Reserv_LodgingRequirement = item.Reserv_LodgingRequirement,
                                Reserv_SemConfChargesDetails = item.Reserv_SemConfChargesDetails,
                                Reserv_CateringRequirement = item.Reserv_CateringRequirement,
                                Reserv_OtherRequirement = item.Reserv_OtherRequirement,
                                reservation_dormid = item.reservation_dormid,
                                reservation_realCHECKIN = item.reservation_realCHECKIN,
                                reservation_realCHECKOUT = item.reservation_realCHECKOUT,
                                RM_TYPE_ID1 = item.RM_TYPE_ID1,
                                ROOMrate1 = item.ROOMrate1,
                                RM_TYPE_ID2 = item.RM_TYPE_ID2,
                                ROOMrate2 = item.ROOMrate2,
                                reservation_RoomsCancel = item.reservation_RoomsCancel,
                                reservation_DormCancel = item.reservation_DormCancel,
                                reservation_CancelDate = item.reservation_CancelDate,
                                cancel_hrs = item.cancel_hrs,
                                Cancel_perc = item.Cancel_perc,
                                Cancel_charges = item.Cancel_charges,
                                Cancel_charges_ttl = item.Cancel_charges_ttl,
                                reservation_RoomsORG = item.reservation_RoomsORG,
                                reservation_DormORG = item.reservation_DormORG
                            };

                            maxId++;
                            var rmTypeId = item.RM_TYPE_ID1.HasValue ? item.RM_TYPE_ID1.Value : item.RM_TYPE_ID2.HasValue ? item.RM_TYPE_ID1.Value : 0;
                            objChrg.RoomType = lstRoomType.Any(x => x.RM_TYPE_ID == rmTypeId) ? lstRoomType.FirstOrDefault(x => x.RM_TYPE_ID == rmTypeId).RM_TYPE_DESC : string.Empty;
                            objChrg.servrate = CommonVariables.RoomGST;
                            objChrg.servtax = CommonVariables.RoomGST * item.Cancel_charges_ttl.Value / 100;
                            dbContext.HotelBillCancelCharges.Add(objChrg);
                        }
                    }
                    if (dbContext.SaveChanges() > 0)
                    {
                        if (objHotelBill != null) CommonLogicFunction.BillCalculation(objHotelBill.hotelBill_ID);
                        CustomMessageBox.ShowInformationMessage("Record Save !", "DayWise Cancellation");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Save Cancel Daywise");
            }
        }

        //Undo
        private void btnUndo_Click(object sender, EventArgs e)
        {
            pageRefereshControl();
            rowDayIndex = -1;
        }

        private void dgvReservationDet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex > -1)
                {
                    rowDayIndex = e.RowIndex;
                    var currLst = lstdayWise[rowDayIndex];
                    dtmDetUptoReserv.Value = currLst.reservation_CHECKIN.HasValue ? currLst.reservation_CHECKIN.Value : DateTime.Now;
                    txtRoomQty.Text = currLst.reservation_Rooms.HasValue ? currLst.reservation_Rooms.Value.ToString() : string.Empty;
                    txtRoomCancelQty.Text = "0";
                    txtBedQty.Text = currLst.reservation_Dorm.HasValue ? currLst.reservation_Dorm.Value.ToString() : string.Empty;
                    txtBedCancelQty.Text = "0";
                    cmbDetDorm.SelectedValue = currLst.reservation_dormid.HasValue ? currLst.reservation_dormid.Value : 0;
                    cmbDetRoomType.SelectedValue = currLst.RM_TYPE_ID1.HasValue ? currLst.RM_TYPE_ID1.Value : 0;
                    cmbDetDormType.SelectedValue = currLst.RM_TYPE_ID2.HasValue ? currLst.RM_TYPE_ID2.Value : 0;
                    txtRoomTypeRate.Text = currLst.ROOMrate1.HasValue ? currLst.ROOMrate1.Value.ToString("0.00") : "0.00";
                    txtDormTypeRate.Text = currLst.ROOMrate2.HasValue ? currLst.ROOMrate2.Value.ToString("0.00") : "0.00";

                    txtDetRemarks.Text = currLst.reservation_remark;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "dgvReservationDet_CellDoubleClick");
            }
        }
    }
}
