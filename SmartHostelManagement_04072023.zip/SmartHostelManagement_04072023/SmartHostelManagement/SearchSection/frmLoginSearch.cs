﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Search
{
    public partial class frmLoginSearch : Form
    {
        LoginAuth objLoginAuth = new LoginAuth();
        public int loginid { get; set; }

        public frmLoginSearch()
        {
            InitializeComponent();
        }

        private void frmLoginSearch_Load(object sender, EventArgs e)
        {
            BindGridView();
        }

        private void BindGridView()
        {
            try
            {
                IList<EL.login> guestList = !string.IsNullOrEmpty(txtSearchName.Text) ? 
                    objLoginAuth.GetLoginUsersDetails().Where(x=>x.name.ToUpper().Contains(txtSearchName.Text.Trim().ToUpper())).OrderBy(x => x.name).ToList() :
                    objLoginAuth.GetLoginUsersDetails().OrderBy(x => x.name).ToList();

                var dbdata = guestList.Select((c, index) =>
                    new
                    {
                        c.log_id,
                        SlNo = index + 1,
                        Login_Id = c.loginID,
                        Name = c.name,
                        Activate = c.DeactivateAcc
                    });


                datagrdiview.DataSource = dbdata.ToList();
                datagrdiview.Columns["log_id"].Visible = false;
                datagrdiview.Columns["SlNo"].Width = 45;
                datagrdiview.Columns["Login_Id"].Width = 200;
                datagrdiview.Columns["Name"].Width = 200;
                datagrdiview.Columns["Activate"].Width = 145;

            }
            catch(Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Bind gridview");
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if(datagrdiview.SelectedRows.Count > 0)
                {
                    DataGridViewRow dr = datagrdiview.SelectedRows[0];
                    this.loginid = Convert.ToInt32(dr.Cells["log_id"].Value);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in select data");
            }
        }

        private void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            BindGridView();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (datagrdiview.SelectedRows.Count > 0)
            {
                btnSelect_Click(sender, e);
            }
        }

        
    }
}
