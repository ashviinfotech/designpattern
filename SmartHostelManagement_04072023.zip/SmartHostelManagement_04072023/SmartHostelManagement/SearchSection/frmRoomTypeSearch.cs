﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Search
{
    public partial class frmRoomTypeSearch : Form
    {
        MasterCaller objMasterData = new MasterCaller();
        public EL.room_number objSRoomNumb { get; set; }
        public EL.ROOM_TYPE objSRoomType { get; set; }
        public bool isRoomType { get; set; }

        public frmRoomTypeSearch()
        {
            InitializeComponent();
        }

        private void frmRoomTypeSearch_Load(object sender, EventArgs e)
        {
            BindGridView();
        }

        private void BindGridView()
        {
            try
            {
                if (!isRoomType)
                {
                    IList<EL.room_number> lstRoomnumb = !string.IsNullOrEmpty(txtSearchName.Text) ?
                    objMasterData.GetRoomNumber().Where(x => x.room_number_number.ToUpper().Contains(txtSearchName.Text.Trim().ToUpper()))
                    .OrderBy(x => x.room_number_number).ToList() :
                    objMasterData.GetRoomNumber().OrderBy(x => x.room_number_number).ToList();

                    var dbdata = lstRoomnumb.Select((c, index) =>
                        new
                        {
                            c.room_number_ID,
                            SlNo = index + 1,
                            Room_Numb = c.room_number_number,
                            Room_Desc = c.room_number_desc,
                            Exten = c.room_number_dataextn,
                            XtraRate = c.room_number_ConferenceRoom.HasValue ? c.room_number_ConferenceRoom.Value : 0,
                            Dorm = c.Dormatory.HasValue && c.Dormatory.Value == 1 ? "Room" : "Dorm"
                        });


                    datagrdiview.DataSource = dbdata.ToList();
                    datagrdiview.Columns["room_number_ID"].Visible = false;
                    datagrdiview.Columns["SlNo"].Width = 45;
                    datagrdiview.Columns["Room_Numb"].Width = 50;
                    datagrdiview.Columns["Room_Desc"].Width = 200;
                    datagrdiview.Columns["Exten"].Width = 100;
                    datagrdiview.Columns["XtraRate"].Width = 40;
                    datagrdiview.Columns["Dorm"].Width = 100;
                }
                else
                {
                    IList<EL.ROOM_TYPE> lstRoomType = !string.IsNullOrEmpty(txtSearchName.Text) ?
                    objMasterData.GetRoomType().Where(x => x.RM_TYPE_CODE.ToUpper().Contains(txtSearchName.Text.Trim().ToUpper()))
                    .OrderBy(x => x.RM_TYPE_DESC).ToList() :
                    objMasterData.GetRoomType().OrderBy(x => x.RM_TYPE_DESC).ToList();

                    var dbdata = lstRoomType.Select((c, index) =>
                        new
                        {
                            c.RM_TYPE_ID,
                            SlNo = index + 1,
                            Room_Code = c.RM_TYPE_CODE,
                            Room_Desc = c.RM_TYPE_DESC,
                            Rate = c.Room_Type_rate.HasValue ? c.Room_Type_rate.Value.ToString("0.00") : "0",
                            XtraRate = c.Room_Type_Xtrabedrate.HasValue ? c.Room_Type_Xtrabedrate.Value.ToString("0.00") : "0",
                            Type = c.Room_dorm.HasValue ? (c.Room_dorm.Value == 1 ? "Room" : "Dorm") : ""
                        });


                    datagrdiview.DataSource = dbdata.ToList();
                    datagrdiview.Columns["RM_TYPE_ID"].Visible = false;
                    datagrdiview.Columns["SlNo"].Width = 45;
                    datagrdiview.Columns["Room_Code"].Width = 50;
                    datagrdiview.Columns["Room_Desc"].Width = 200;
                    datagrdiview.Columns["Rate"].Width = 100;
                    datagrdiview.Columns["XtraRate"].Width = 100;
                    datagrdiview.Columns["Type"].Width = 100;

                    datagrdiview.Columns["Rate"].DefaultCellStyle.Format = "0.00";
                    datagrdiview.Columns["XtraRate"].DefaultCellStyle.Format = "0.00";
                }
            }
            catch(Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Bind gridview");
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if(datagrdiview.SelectedRows.Count > 0)
                {
                    DataGridViewRow dr = datagrdiview.SelectedRows[0];
                    int miscid = 0;
                    miscid = isRoomType ? Convert.ToInt32(dr.Cells["RM_TYPE_ID"].Value) : Convert.ToInt32(dr.Cells["room_number_ID"].Value);
                    if(!isRoomType)
                        objSRoomNumb = objMasterData.GetRoomNumber().FirstOrDefault(x => x.room_number_ID == miscid);
                    else
                        objSRoomType = objMasterData.GetRoomType().FirstOrDefault(x => x.RM_TYPE_ID == miscid);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in select data");
            }
        }

        private void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            BindGridView();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (datagrdiview.SelectedRows.Count > 0)
            {
                btnSelect_Click(sender, e);
            }
        }
    }
}
