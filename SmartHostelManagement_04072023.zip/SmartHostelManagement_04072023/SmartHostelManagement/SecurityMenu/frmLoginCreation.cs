﻿using System;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;

namespace SmartHostelManagement.Security
{
    public partial class frmLoginCreation : Form
    {
        LoginAuth objloginAuth = new LoginAuth();

        EL.login objLogin { get; set; }

        public frmLoginCreation()
        {
            InitializeComponent();
        }       

        private void frmLoginCreation_Load(object sender, EventArgs e)
        {
            pageResetControls();
            btnDelete.Enabled = false;
            txtLoginid.Focus();
        }

        private void SetValuesOfControls()
        {
            try
            {
                if (this.objLogin != null)
                {
                    txtLoginid.Text = objLogin.loginID;
                    txtLoginName.Text = objLogin.name;
                    txtPassword.Text = objLogin.password;
                    txtCnfrmPassword.Text = objLogin.password;
                    rdbAdminLevel.Checked = objLogin.level.Contains("Admin") ? true : false;
                    rdbUserLevel.Checked = objLogin.level.Contains("User") ? true : false;
                    chkDeactivate.Checked = objLogin.DeactivateAcc.HasValue ? objLogin.DeactivateAcc.Value : false;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "SetValuesOfControls");
            }
        }

        void pageResetControls()
        {
            txtLoginid.Text = string.Empty;
            txtLoginName.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtCnfrmPassword.Text = string.Empty;
            rdbAdminLevel.Checked = false;
            rdbUserLevel.Checked = true;
            chkDeactivate.Checked = false;
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            pageResetControls();
        }

        bool ValidateFormData()
        {
            if (string.IsNullOrEmpty(txtLoginid.Text.Trim()))
            {
                CustomMessageBox.ShowHandMessage("Please Enter Login ID !", this.Text);
                txtLoginid.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtLoginName.Text))
            {
                CustomMessageBox.ShowHandMessage("Please Enter Login Name !", this.Text);
                txtLoginName.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtPassword.Text))
            {
                CustomMessageBox.ShowHandMessage("Please Enter Password !", this.Text);
                txtPassword.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtCnfrmPassword.Text))
            {
                CustomMessageBox.ShowHandMessage("Please Enter Confirm Password !", this.Text);
                txtCnfrmPassword.Focus();
                return false;
            }
            else if (!string.Equals(txtPassword.Text.Trim(), txtCnfrmPassword.Text.Trim()))
            {
                CustomMessageBox.ShowHandMessage("Please Enter same password !", this.Text);                
                txtCnfrmPassword.Focus();
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateFormData())
                {
                    bool isNew = false;

                    if (this.objLogin == null)
                    {
                        isNew = true;
                        this.objLogin = new EL.login
                        {
                            name = txtLoginName.Text.Trim(),
                            loginID = txtLoginid.Text.Trim(),
                            password = txtPassword.Text.Trim(),
                            level = rdbAdminLevel.Checked ? "Admin" : "User",
                            POSSunddet_id = 1,
                            use_def_count = false,
                            use_def_accgrp = false,
                            perm_to_changedate = false,
                            perm_to_changeRPV = false,
                            perm_to_changeVchno = false,
                            req_admn_perm_inaccessamt = false,
                            DeactivateAcc = chkDeactivate.Checked
                        };
                    }
                    else
                    {
                        this.objLogin.name = txtLoginName.Text.Trim();
                        this.objLogin.loginID = txtLoginid.Text.Trim();
                        this.objLogin.password = txtPassword.Text.Trim();
                        this.objLogin.level = rdbAdminLevel.Checked ? "Admin" : "User";
                        this.objLogin.DeactivateAcc = chkDeactivate.Checked;
                    }

                    bool objNewLogin = isNew ? objloginAuth.CreateUserLogin(this.objLogin) : objloginAuth.UpdateUserLogin(this.objLogin);

                    pageResetControls();
                    if (objNewLogin)
                        CustomMessageBox.ShowInformationMessage("Login detail Saved !!!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!!", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Error on Save");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmLoginSearch objFrmLoginSearch = new frmLoginSearch())
                {
                    objFrmLoginSearch.ShowDialog();
                    if (objFrmLoginSearch.loginid > 0)
                    {
                        pageResetControls();
                        this.objLogin = objloginAuth.GetLoginDetails(new EL.login { log_id = objFrmLoginSearch.loginid });
                        SetValuesOfControls();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Search");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this User Login Details ?") == System.Windows.Forms.DialogResult.OK)
                {                    
                    pageResetControls();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtLoginid_KeyPress(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && sender.GetType() == typeof(TextBox))
            {
                if ((TextBox)sender == txtLoginid) txtLoginName.Focus();
                if ((TextBox)sender == txtLoginName) txtPassword.Focus();
                if ((TextBox)sender == txtPassword) txtCnfrmPassword.Focus();
                if ((TextBox)sender == txtCnfrmPassword) rdbUserLevel.Focus();
            }
        }
    }
}
