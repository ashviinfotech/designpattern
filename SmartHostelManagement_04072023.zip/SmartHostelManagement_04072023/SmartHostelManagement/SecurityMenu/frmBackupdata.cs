﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Security
{
    public partial class frmBackupdata : Form
    {   
        SqlConnection sqlConn = null;
        SqlCommand sqlCmd = null;

        public frmBackupdata()
        {   
            InitializeComponent();
        }

        private void frmBackupdata_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnectionStringBuilder sqlConnect = new SqlConnectionStringBuilder();
                sqlConnect.DataSource = CommonVariables.sqlServerName;
                sqlConnect.InitialCatalog = CommonVariables.sqlDatabaseName;
                sqlConnect.UserID = CommonVariables.sqlServerUserID;
                if (!string.IsNullOrEmpty(CommonVariables.sqlServerPwd))
                {
                    sqlConnect.Password = CommonVariables.sqlServerPwd;
                }
                else
                {
                    sqlConnect.IntegratedSecurity = true;
                }

                sqlConnect.Pooling = false;
                sqlConnect.MultipleActiveResultSets = false;
                sqlConn = new SqlConnection(sqlConnect.ConnectionString);
                if (sqlConn.State == ConnectionState.Open) sqlConn.Close();
                sqlConn.Open();
                CustomMessageBox.ShowInformationMessage("Connection made with Server sucessfull !!", this.Text);
                txtPathInfo.Text = Application.StartupPath;
            }
            catch (Exception ex)
            {
                CustomMessageBox.ShowErrorMessage(ex.Message, "DB Backup Start");
                ExceptionLogging.SendErrorToText(ex, "Db Backup Start");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog objFolderbrowser = new FolderBrowserDialog();
            objFolderbrowser.ShowNewFolderButton = true;
            DialogResult result = objFolderbrowser.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                txtPathInfo.Text = objFolderbrowser.SelectedPath;
                Environment.SpecialFolder root = objFolderbrowser.RootFolder;
            }
        }

        private void btnBackup_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtFileName.Text.Trim()))
                {
                    string filename = txtFileName.Text + ".bak";
                    string databasename = sqlConn.Database;
                    string filePath = txtPathInfo.Text.Trim() + "\\" + filename;

                    if (sqlConn.State == ConnectionState.Open) sqlConn.Close();
                    sqlConn.Open();
                    //sqlConn.ConnectionTimeout = 60 * 60;
                    sqlCmd = new SqlCommand();
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandTimeout = 60 * 60;
                    sqlCmd.CommandText = "Backup database " + databasename + " to disk = '" + filePath + "'";
                    sqlCmd.ExecuteNonQuery();
                    sqlCmd.Dispose();
                    sqlConn.Close();
                    sqlConn.Dispose();
                    CustomMessageBox.ShowInformationMessage("Database Backup Sucessfull !.", this.Text);
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please enter file Name.", this.Text);
                    txtFileName.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, this.Text);
            }
        }
    }
}
