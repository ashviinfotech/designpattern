﻿using System;
using System.Windows.Forms;
using SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SMH.BusinessLogic.Layer;
//using SmartHostel.TransReports;
using SmartHostelManagement.Master;
using SmartHostelManagement.Security;
using SmartHostelManagement.Windows;
using SmartHostelManagement.Transaction;
using SmartHostelManagement.Order;
using SmartHostelManagement.Kitchen;

namespace SmartHostelManagement
{
    public partial class MasterLayout : Form
    {
        LoginAuth objLoginAuth = new LoginAuth();
        CustomFormFunction objCustomForm = new CustomFormFunction();
        Timer timer1 = new Timer();        
                
        bool userClose = false;

        public MasterLayout()
        {
            InitializeComponent();
        }

        private void MasterLayout_Load(object sender, EventArgs e)
        {
            loadPageLayout();

            #region Code for Permission on form
            //try
            //{
            //    foreach (var menuItem in this.menuStrip.Items)
            //    {

            //    }
            //    foreach (login_perm_Hotel objPerm in MasterLayout.userLogin.login_perm_Hotels)
            //    {

            //    }
            //}
            //catch (Exception ex)
            //{
            //    CustomMessageBox.ShowErrorMessage(ex.Message, this.Text);
            //    ExceptionLogging.SendErrorToText(ex, this.Text);
            //}
            #endregion Code for Permission on form

            //gSTReturnToolStripMenuItem.Visible = false;
            accountTypeToolStripMenuItem.Visible = false;
        }

        public void loadPageLayout()
        {
            if (Frm_Login.UserLogin == null) Application.Exit();

            #region Code Need to work
            //dailyEntryFormCombinedToolStripMenuItem.Visible = false;
            //mergeCustomerToolStripMenuItem.Visible = false;
            //userPermissionToolStripMenuItem.Visible = false;
            #endregion Code Need to work

            #region No Need To Work
            //modifyCFormToolStripMenuItem.Visible = false;
            //cFormDateWiseToolStripMenuItem.Visible = false;
            //cFormToolStripMenuItem.Visible = false;
            //menuMasterToolStripMenuItem.Visible = false;
            #endregion No Need To Work


            toolStripStatusLabel.Text = "User: " + Frm_Login.UserLogin.name;
            toolStripStatusLabel1.Text = "Data From (" + CommonVariables.dtmFinancialStart.ToString("dd/MMM/yyyy") + " - " + CommonVariables.dtmFinancialEnd.ToString("dd/MMM/yyyy") + ")";
            toolStripStatusLabel2.Text = "Machine: " + Environment.MachineName;
            toolStripStatusLabel3.Text = "Date: " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt");
            timer1.Tick += timer1_Tick;
            this.timer1.Interval = 1000;
            this.timer1.Enabled = true;
        }

        private void mdiMasterLayout_FormClosing(object sender, FormClosingEventArgs e)
        {                                                                                                                                                                                                                                                                                                                                                                                                                                   
            if (userClose) return;
            if (CustomMessageBox.ShowDialogBoxMessage("Close this application") == System.Windows.Forms.DialogResult.Yes)
            {
                objLoginAuth.LogOutUser(Frm_Login.UserLogin);
                e.Cancel = false;
            }
            else
                e.Cancel = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "Date: " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt");
        }

        #region Master
        private void nationalityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmNationality)))
            {
                using (frmNationality objfrmNation = new frmNationality())
                    objfrmNation.ShowDialog();
            }
        }

        private void titleMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmTitleMaster)))
            {
                using (frmTitleMaster objfrmTitle = new frmTitleMaster())
                    objfrmTitle.ShowDialog();
            }
        }

        private void companyGuestMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmCompanyGuestMaster)))
            {
                using (frmCompanyGuestMaster objfrmTitle = new frmCompanyGuestMaster())
                    objfrmTitle.ShowDialog();
            }
        }

        private void guestTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmGuestType)))
            {
                using (frmGuestType objfrmGuestType = new frmGuestType())
                    objfrmGuestType.ShowDialog();
            }
        }

        private void guestMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmGuestMaster)))
            {
                using (frmGuestMaster objfrmGuest = new frmGuestMaster())
                    objfrmGuest.ShowDialog();
            }
        }

        private void roomTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmRoomType)))
            {
                using (frmRoomType frmroomtype = new frmRoomType())
                    frmroomtype.ShowDialog();
            }
        }

        private void roomNumberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmRoomNumber)))
            {
                using (frmRoomNumber frmroomnumber = new frmRoomNumber())
                    frmroomnumber.ShowDialog();
            }
        }
        
        //Company Details menu
        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmCompany)))
            {
                using (frmCompany objCompany = new frmCompany())
                    objCompany.ShowDialog();
            }
        }

        //Country Master
        private void roomNumberMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmRoomNumber)))
            //{
            //    using (frmRoomNumber objfrmroomnumber = new frmRoomNumber())
            //        objfrmroomnumber.ShowDialog();
            //}
        }

        private void accountTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(Hostel.frmHostelEstimateBill)))
            //    using (Hostel.frmHostelEstimateBill frmHostEstim = new Hostel.frmHostelEstimateBill())
            //        frmHostEstim.ShowDialog();
        }

        private void gSTReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmGstReport)))
            {
                Reports.frmGstReport frmCollReport = new Reports.frmGstReport();
                frmCollReport.WindowState = FormWindowState.Maximized;
                frmCollReport.MdiParent = this;
                frmCollReport.Show();
                frmCollReport.BringToFront();
            }
        }
        #endregion

        #region Transaction
        private void customerCardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmCustomer)))
            {
                using (frmCustomer objfrmcust = new frmCustomer())
                    objfrmcust.ShowDialog();
            }
        }

        private void roomBillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmRoomBill)))
            {
                using (frmRoomBill objfrmRoomBill = new frmRoomBill())
                    objfrmRoomBill.ShowDialog();
            }
        }

        private void dormatoryBillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmDormatoryBill)))
            //    using (frmDormatoryBill objfrmDormBill = new frmDormatoryBill())
            //        objfrmDormBill.ShowDialog();
        }

        private void dailyEntryFormCombinedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //CommanBaseFN.InformationMessage("Under Construction");
        }

        private void dailyEntryFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmOccupancy)))
            {
                frmOccupancy frmOccupancy = new frmOccupancy();
                frmOccupancy.WindowState = FormWindowState.Maximized;
                frmOccupancy.MdiParent = this;
                frmOccupancy.Show();
                frmOccupancy.BringToFront();
            }
        }

        private void receiptVoucherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmVoucher)))
                using (frmVoucher frmReceipt = new frmVoucher())
                {
                    frmReceipt.ShowDialog();
                }
        }

        private void roomUnbilledToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmUnbilledRoom)))
            //    using (frmUnbilledRoom frmunbilled = new frmUnbilledRoom())
            //    {
            //        frmunbilled.ShowDialog();
            //    }
        }

        private void dormatoryUnbilledToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmUnbilledDormatory)))
            //    using (frmUnbilledDormatory unbilldorm = new frmUnbilledDormatory())
            //    {
            //        unbilldorm.ShowDialog();
            //    }
        }

        private void paymentVoucherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmPayRefund)))
            {
                using (frmPayRefund frmpayref = new frmPayRefund())
                    frmpayref.ShowDialog();
            }
        }

        private void modifyCFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //CommanBaseFN.InformationMessage("Under Construction");
        }

        private void mergeCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //CommanBaseFN.InformationMessage("Under Construction");
        }

        private void membershipDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmMembership)))
            //{
            //    using (frmMembership frmMembShip = new frmMembership())
            //        frmMembShip.ShowDialog();
            //}
        }
        #endregion Transaction

        #region Hostel Booking
        private void hostelBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Hostel.frmHostelReserv)))
                using (Hostel.frmHostelReserv frmHostbook = new Hostel.frmHostelReserv())
                    frmHostbook.ShowDialog();
        }

        private void hostelBookingStatusChartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Hostel.frmHostelPlanerChart)))
            {
                Hostel.frmHostelPlanerChart frmHostelChart = new Hostel.frmHostelPlanerChart();
                frmHostelChart.WindowState = FormWindowState.Maximized;
                frmHostelChart.MdiParent = this;
                frmHostelChart.Show();
                frmHostelChart.BringToFront();
            }
        }
        #endregion Hostel Booking

        #region Seminar / Catreing
        private void menuMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void miscHeadMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmItemListMaster)))
            //    using (frmItemListMaster frmItemList = new frmItemListMaster())
            //        frmItemList.ShowDialog();
        }

        private void seminarBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Seminar.frmSeminarBookingEntry)))
                using (Seminar.frmSeminarBookingEntry frmSeminarbok = new Seminar.frmSeminarBookingEntry())
                    frmSeminarbok.ShowDialog();
        }

        private void seminarBookingStatusChartTimeBasisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //CommanBaseFN.InformationMessage("Under Construction");
        }

        private void seminarBookingStatusChartDayBasisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Seminar.frmSeminarChart)))
            {
                Seminar.frmSeminarChart frmSemChart = new Seminar.frmSeminarChart();
                frmSemChart.WindowState = FormWindowState.Maximized;
                frmSemChart.MdiParent = this;
                frmSemChart.Show();
                frmSemChart.BringToFront();
            }
        }

        private void seminarBillingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Seminar.frmSeminarBillpol)))
                using (Seminar.frmSeminarBillpol frmSemBill = new Seminar.frmSeminarBillpol())
                    frmSemBill.ShowDialog();
        }

        private void reservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //CommanBaseFN.InformationMessage("Under Construction");
        }

        private void cancelledReservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if(objCustomForm.CheckActiveForm(typeof(frmSemiReserCancel)))
            //    using (frmSemiReserCancel frmSemCancel = new frmSemiReserCancel())
            //        frmSemCancel.ShowDialog();
        }
        #endregion Seminar / Catreing

        #region Reports
        private void collectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmCollection)))
            //{
            //    frmCollection frmCollReport = new frmCollection();
            //    frmCollReport.WindowState = FormWindowState.Maximized;
            //    frmCollReport.MdiParent = this;
            //    frmCollReport.Show();
            //    frmCollReport.BringToFront();
            //}

        }

        private void revenueSummaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmRevenueSummary)))
            //{
            //    frmRevenueSummary frmRevenSum = new frmRevenueSummary();
            //    frmRevenSum.WindowState = FormWindowState.Maximized;
            //    frmRevenSum.MdiParent = this;
            //    frmRevenSum.Show();
            //    frmRevenSum.BringToFront();
            //}
        }

        private void revenueDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmRevenueDetails)))
            //{
            //    frmRevenueDetails frmrevenuedetail = new frmRevenueDetails();
            //    frmrevenuedetail.WindowState = FormWindowState.Maximized;
            //    frmrevenuedetail.MdiParent = this;
            //    frmrevenuedetail.Show();
            //    frmrevenuedetail.BringToFront();
            //}
        }

        private void unbilledCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmUnbilledCustomer)))
            //{
            //    frmUnbilledCustomer frmunbilledcust = new frmUnbilledCustomer();
            //    frmunbilledcust.WindowState = FormWindowState.Maximized;
            //    frmunbilledcust.MdiParent = this;
            //    frmunbilledcust.Show();
            //    frmunbilledcust.BringToFront();
            //}
        }

        private void statementOfNationalityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmStatementofNationality)))
            //{
            //    frmStatementofNationality frmstatnationality = new frmStatementofNationality();
            //    frmstatnationality.WindowState = FormWindowState.Maximized;
            //    frmstatnationality.MdiParent = this;
            //    frmstatnationality.Show();
            //    frmstatnationality.BringToFront();
            //}
        }

        private void salesSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSaleSummary)))
            //{
            //    frmSaleSummary frmSalesSummary = new frmSaleSummary();
            //    frmSalesSummary.WindowState = FormWindowState.Maximized;
            //    frmSalesSummary.MdiParent = this;
            //    frmSalesSummary.Show();
            //    frmSalesSummary.BringToFront();
            //}
        }

        private void advanceSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmAdvanceSummary)))
            //{
            //    frmAdvanceSummary frmAdvanceSumry = new frmAdvanceSummary();
            //    frmAdvanceSumry.WindowState = FormWindowState.Maximized;
            //    frmAdvanceSumry.MdiParent = this;
            //    frmAdvanceSumry.Show();
            //    frmAdvanceSumry.BringToFront();
            //}
        }

        private void statementOfCashRecieiptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmCashReceiptAgainst)))
            //{
            //    frmCashReceiptAgainst frmCashAgain = new frmCashReceiptAgainst();
            //    frmCashAgain.WindowState = FormWindowState.Maximized;
            //    frmCashAgain.MdiParent = this;
            //    frmCashAgain.Show();
            //    frmCashAgain.BringToFront();
            //}
        }

        private void billStatementToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmBillStatement)))
            //{
            //    frmBillStatement frmbillstatemnt = new frmBillStatement();
            //    frmbillstatemnt.WindowState = FormWindowState.Maximized;
            //    frmbillstatemnt.MdiParent = this;
            //    frmbillstatemnt.Show();
            //    frmbillstatemnt.BringToFront();
            //}
        }

        private void billStatementDateWiseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmBillStatementDateWise)))
            //{
            //    frmBillStatementDateWise frmbillstatedatewise = new frmBillStatementDateWise();
            //    frmbillstatedatewise.WindowState = FormWindowState.Maximized;
            //    frmbillstatedatewise.MdiParent = this;
            //    frmbillstatedatewise.Show();
            //    frmbillstatedatewise.BringToFront();
            //}
        }

        private void listOfRoomTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmListofRoom)))
            //{
            //    frmListofRoom frmListRoom = new frmListofRoom();
            //    frmListRoom.WindowState = FormWindowState.Maximized;
            //    frmListRoom.MdiParent = this;
            //    frmListRoom.Show();
            //    frmListRoom.BringToFront();
            //}
        }

        private void listOfCashReceiptTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmListofCashReceipt)))
            //{
            //    frmListofCashReceipt frmListofCashRecp = new frmListofCashReceipt();
            //    frmListofCashRecp.WindowState = FormWindowState.Maximized;
            //    frmListofCashRecp.MdiParent = this;
            //    frmListofCashRecp.Show();
            //    frmListofCashRecp.BringToFront();
            //}
        }

        private void listOfAdditionalGuestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmListOfAdditionalGuest)))
            //{
            //    frmListOfAdditionalGuest frmListAddGuest = new frmListOfAdditionalGuest();
            //    frmListAddGuest.WindowState = FormWindowState.Maximized;
            //    frmListAddGuest.MdiParent = this;
            //    frmListAddGuest.Show();
            //    frmListAddGuest.BringToFront();
            //}
        }

        private void partyWiseSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmPartyWiseSummary)))
            //{
            //    frmPartyWiseSummary frmpartywise = new frmPartyWiseSummary();
            //    frmpartywise.WindowState = FormWindowState.Maximized;
            //    frmpartywise.MdiParent = this;
            //    frmpartywise.Show();
            //    frmpartywise.BringToFront();
            //}
        }

        private void cFormDateWiseToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cFormToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void monthlyHostelOccupancyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmMonthlyOccupancy)))
            //{
            //    frmMonthlyOccupancy frmMonthlyOccup = new frmMonthlyOccupancy();
            //    frmMonthlyOccup.WindowState = FormWindowState.Maximized;
            //    frmMonthlyOccup.MdiParent = this;
            //    frmMonthlyOccup.Show();
            //    frmMonthlyOccup.BringToFront();
            //}
        }

        private void accountwiseAdvanceSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmAccountAdvanceSummary)))
            //{
            //    frmAccountAdvanceSummary frmAccountAdvSummary = new frmAccountAdvanceSummary();
            //    frmAccountAdvSummary.WindowState = FormWindowState.Maximized;
            //    frmAccountAdvSummary.MdiParent = this;
            //    frmAccountAdvSummary.Show();
            //    frmAccountAdvSummary.BringToFront();
            //}
        }
        #endregion Reports

        #region Seminar Report
        private void occupancyByNameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemOccupancy)))
            //{
            //    frmSemOccupancy frmOccupancy = new frmSemOccupancy();
            //    frmOccupancy.WindowState = FormWindowState.Maximized;
            //    frmOccupancy.MdiParent = this;
            //    frmOccupancy.Show();
            //    frmOccupancy.BringToFront();
            //}
        }

        private void collectionSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmBillStatement frmRevenSum = new Reports.frmBillStatement(CommonVariables.ReportSection.SeminarCollection);
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                //frmRevenSum._reportName = CommonVariables.ReportSection.SeminarCollection;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void collectionSummaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemCollection)))
            //{
            //    frmSemCollection frmsemcollection = new frmSemCollection();
            //    frmsemcollection.WindowState = FormWindowState.Maximized;
            //    frmsemcollection.MdiParent = this;
            //    frmsemcollection.Show();
            //    frmsemcollection.BringToFront();
            //}
        }

        private void occupancyRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemOccupancyRate)))
            //{
            //    frmSemOccupancyRate frmsemoccupancyrate = new frmSemOccupancyRate();
            //    frmsemoccupancyrate.WindowState = FormWindowState.Maximized;
            //    frmsemoccupancyrate.MdiParent = this;
            //    frmsemoccupancyrate.Show();
            //    frmsemoccupancyrate.BringToFront();
            //}
        }

        private void revenueSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemRevenueSum)))
            //{
            //    frmSemRevenueSum frmsemrevenuesum = new frmSemRevenueSum();
            //    frmsemrevenuesum.WindowState = FormWindowState.Maximized;
            //    frmsemrevenuesum.MdiParent = this;
            //    frmsemrevenuesum.Show();
            //    frmsemrevenuesum.BringToFront();
            //}
        }

        private void revenueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemRevenueDetail)))
            //{
            //    frmSemRevenueDetail frmsemrevenuedetail = new frmSemRevenueDetail();
            //    frmsemrevenuedetail.WindowState = FormWindowState.Maximized;
            //    frmsemrevenuedetail.MdiParent = this;
            //    frmsemrevenuedetail.Show();
            //    frmsemrevenuedetail.BringToFront();
            //}  
        }

        private void unbilledPartyListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemUnbilledBill)))
            //{
            //    frmSemUnbilledBill frmsemunbilledbill = new frmSemUnbilledBill();
            //    frmsemunbilledbill.WindowState = FormWindowState.Maximized;
            //    frmsemunbilledbill.MdiParent = this;
            //    frmsemunbilledbill.Show();
            //    frmsemunbilledbill.BringToFront();
            //}
        }

        private void itemWiseSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemItemSummary)))
            //{
            //    frmSemItemSummary frmsemitemsummary = new frmSemItemSummary();
            //    frmsemitemsummary.WindowState = FormWindowState.Maximized;
            //    frmsemitemsummary.MdiParent = this;
            //    frmsemitemsummary.Show();
            //    frmsemitemsummary.BringToFront();
            //}
        }

        private void conferenceHallCancellationToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void creditSaleRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemCrediSaleRegister)))
            //{
            //    frmSemCrediSaleRegister frmsemcredisaleregister = new frmSemCrediSaleRegister();
            //    frmsemcredisaleregister.WindowState = FormWindowState.Maximized;
            //    frmsemcredisaleregister.MdiParent = this;
            //    frmsemcredisaleregister.Show();
            //    frmsemcredisaleregister.BringToFront();
            //}
        }

        private void billStatementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemCateringStatementDatewise)))
            //{
            //    frmSemCateringStatementDatewise frmsemcateringstatementdatewise = new frmSemCateringStatementDatewise();
            //    frmsemcateringstatementdatewise.WindowState = FormWindowState.Maximized;
            //    frmsemcateringstatementdatewise.MdiParent = this;
            //    frmsemcateringstatementdatewise.Show();
            //    frmsemcateringstatementdatewise.BringToFront();
            //}
        }

        private void billStatementForSeminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (objCustomForm.CheckActiveForm(typeof(frmSemStatementDateWise)))
            //{
            //    frmSemStatementDateWise frmsemstatementdatewise = new frmSemStatementDateWise();
            //    frmsemstatementdatewise.WindowState = FormWindowState.Maximized;
            //    frmsemstatementdatewise.MdiParent = this;
            //    frmsemstatementdatewise.Show();
            //    frmsemstatementdatewise.BringToFront();
            //}
        }
        #endregion Seminar Report

        #region Security
        private void dataBackupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmBackupdata)))
                using (frmBackupdata frmBackup = new frmBackupdata())
                    frmBackup.ShowDialog();
        }

        private void loginToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmLoginCreation)))
                using (frmLoginCreation frmLoginCreate = new frmLoginCreation())
                    frmLoginCreate.ShowDialog();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmChangePassword)))
                using (frmChangePassword objfrmChngPwd = new frmChangePassword())
                    objfrmChngPwd.ShowDialog();
        }

        private void userPermissionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmChangePassword)))
                using (FrmUserPermission objfrmUserPerm = new FrmUserPermission())
                    objfrmUserPerm.ShowDialog();
        }
        #endregion Security

        #region Windows
        private void changeFinancialYearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmAboutUs)))
            {
                using (frmFinancialYear frmFinancial = new frmFinancialYear())
                {
                    frmFinancial.ShowDialog();
                    toolStripStatusLabel1.Text = "Data From (" + CommonVariables.dtmFinancialStart.ToString("dd/MMM/yyyy") + " - " + CommonVariables.dtmFinancialEnd.ToString("dd/MMM/yyyy") + ")";
                }
            }
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmAboutUs)))
            {
                using (frmAboutUs objAbout = new frmAboutUs())
                    objAbout.ShowDialog();
            }
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Frm_Login)))
            {
                Frm_Login objLogin = new Frm_Login();
                objLogin.ShowDialog();
                toolStripStatusLabel.Text = "User: " + Frm_Login.UserLogin.name;
            }
        }

        private void existToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            this.Close();
        }
        #endregion Windows

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Logout from this application?") == System.Windows.Forms.DialogResult.Yes)
            {
                if (objLoginAuth.LogOutUser(Frm_Login.UserLogin))
                {
                    Frm_Login.UserLogin = null;
                    userClose = true;
                    Frm_Login frmLogin = new Frm_Login();
                    frmLogin.ShowDialog();

                    if (Frm_Login.UserLogin != null)
                    {
                        userClose = false;
                        toolStripStatusLabel.Text = "User: " + Frm_Login.UserLogin.name;
                    }
                    else
                    {
                        this.Close();
                    }
                }
                else
                    CustomMessageBox.ShowErrorMessage("Unable to Logout Current User !!", this.Text);
            }
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void cateringOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmCateringOrder)))
                using (frmCateringOrder frmCatOrder = new frmCateringOrder())
                    frmCatOrder.ShowDialog();
        }

        private void prepareChannelBillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmAccountWiseSales)))
            { 
                frmAccountWiseSales frmAcctWise = new frmAccountWiseSales();
                frmAcctWise.WindowState = FormWindowState.Maximized;
                frmAcctWise.MdiParent = this;
                frmAcctWise.Show();
                frmAcctWise.BringToFront();
            }                     
        }

        private void channelBillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmChannelBill)))
                using (frmChannelBill frmChannelBill = new frmChannelBill())
                    frmChannelBill.ShowDialog();
        }

        private void menuGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmMenuGroupMaster)))
                using (frmMenuGroupMaster frmMenuItemMaster = new frmMenuGroupMaster())
            {
                frmMenuItemMaster.ShowDialog();
            }
        }

        private void buffetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(frmBuffetMaster)))
                using (frmBuffetMaster frmbuffetmaster = new frmBuffetMaster())
                {
                    frmbuffetmaster.ShowDialog();
                }
        }

        private void waiterMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(KitchenMenu.frmWaiter)))
                using (KitchenMenu.frmWaiter frmmenuitem = new KitchenMenu.frmWaiter())
                {
                    frmmenuitem.ShowDialog();
                }
        }

        private void menuMasterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!objCustomForm.CheckActiveForm(typeof(frmMenuItem))) return;
            MiscMaster.frmMiscHeadMaster frmMiscHead = new MiscMaster.frmMiscHeadMaster();
            frmMiscHead.ChannelId = 2;
            frmMiscHead.ShowDialog();
            frmMiscHead.Close();
            Kitchen.frmMenuItem frmMiscItem = new Kitchen.frmMenuItem();
            frmMiscItem.channelid = frmMiscHead.ChannelId;
            frmMiscItem.channelname = frmMiscHead.channelname;
            frmMiscItem.ShowDialog();
        }

        private void rawMaterialKitchenMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuReceiptBOMToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void kOTEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!objCustomForm.CheckActiveForm(typeof(frmKotBill))) return;
            MiscMaster.frmMiscHeadMaster frmMiscHead = new MiscMaster.frmMiscHeadMaster();
            frmMiscHead.ChannelId = 1;
            frmMiscHead.ShowDialog();
            frmMiscHead.Close();
            Kitchen.frmKotBill objKot = new Kitchen.frmKotBill();
            objKot.ChannelId = frmMiscHead.ChannelId;
            objKot.ShowDialog();
        }

        private void hostelEstimatetoolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!objCustomForm.CheckActiveForm(typeof(Hostel.frmRoomEstimate))) return;

            using (Hostel.frmRoomEstimate frmEstimeate = new Hostel.frmRoomEstimate())
            {
                frmEstimeate.ShowDialog();
            }
        }

        private void receiptSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmBillStatement frmRevenSum = new Reports.frmBillStatement(CommonVariables.ReportSection.ReceiptSummary);
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                //frmRevenSum._reportName = CommonVariables.ReportSection.ReceiptSummary;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void collectionSummaryToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmBillStatement frmRevenSum = new Reports.frmBillStatement(CommonVariables.ReportSection.HotelCollection);
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                //frmRevenSum._reportName = CommonVariables.ReportSection.HotelCollection;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Seminar.frmSeminarEstimate)))
            {
                using (Seminar.frmSeminarEstimate objfrmTitle = new Seminar.frmSeminarEstimate())
                    objfrmTitle.ShowDialog();
            }
        }

        private void occupancyChartDAILYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmBillStatement frmRevenSum = new Reports.frmBillStatement(CommonVariables.ReportSection.HostelDayOccupancy);
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                //frmRevenSum._reportName = CommonVariables.ReportSection.HostelDayOccupancy;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void occupancyChartMONTHLYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmBillStatement frmRevenSum = new Reports.frmBillStatement(CommonVariables.ReportSection.HostelMonOccupancy);
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                //frmRevenSum._reportName = CommonVariables.ReportSection.HostelMonOccupancy;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void cashCollectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmCollectionReport frmRevenSum = new Reports.frmCollectionReport();
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                frmRevenSum.ReceiptRightId = 2;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void occupancyChartDailyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmBillStatement frmRevenSum = new Reports.frmBillStatement(CommonVariables.ReportSection.SeminarDayOccupancy);
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                //frmRevenSum._reportName = CommonVariables.ReportSection.SeminarDayOccupancy;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void occupancyChartMONTHLYToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmBillStatement frmRevenSum = new Reports.frmBillStatement(CommonVariables.ReportSection.SeminarMonOccupancy);
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                //frmRevenSum._reportName = CommonVariables.ReportSection.SeminarMonOccupancy;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void cashCollectionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmCollectionReport frmRevenSum = new Reports.frmCollectionReport();
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                frmRevenSum.ReceiptRightId = 1;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }

        private void partyWiseSummaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Reports.frmBillStatement)))
            {
                Reports.frmPartyWiseSummary frmPartyReport = new Reports.frmPartyWiseSummary();
                frmPartyReport.WindowState = FormWindowState.Maximized;
                frmPartyReport.MdiParent = this;
                frmPartyReport.Show();
                frmPartyReport.BringToFront();
            }
        }

        private void miscHeadMasterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!objCustomForm.CheckActiveForm(typeof(frmMenuItem))) return;
            MiscMaster.frmMiscHeadMaster frmMiscHead = new MiscMaster.frmMiscHeadMaster();
            frmMiscHead.ChannelId = 0;
            frmMiscHead.ShowDialog();
            frmMiscHead.Close();
            MiscMaster.frmItemListMaster objMisc = new MiscMaster.frmItemListMaster();
            objMisc.channelId = frmMiscHead.ChannelId;
            objMisc.channelName = frmMiscHead.channelname;
            objMisc.ShowDialog();
        }

        private void miscEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(MIscMenu.frmMIscEntry)))
                using (MIscMenu.frmMIscEntry frmMiscMaster = new MIscMenu.frmMIscEntry())
                {
                    frmMiscMaster.ShowDialog();
                }
        }

        private void orderChartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objCustomForm.CheckActiveForm(typeof(Order.frmCategringOrderChart)))
            {
                Order.frmCategringOrderChart frmRevenSum = new Order.frmCategringOrderChart();
                frmRevenSum.WindowState = FormWindowState.Maximized;
                frmRevenSum.MdiParent = this;
                frmRevenSum.Show();
                frmRevenSum.BringToFront();
            }
        }
    }
}
