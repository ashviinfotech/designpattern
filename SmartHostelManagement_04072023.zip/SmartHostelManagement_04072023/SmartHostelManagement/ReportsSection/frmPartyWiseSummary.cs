﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;
using SMH.DataAccess.Layer;
using System.Drawing;
using System.Text;

namespace SmartHostelManagement.Reports
{
    public partial class frmPartyWiseSummary : Form
    {
        MasterCaller objReport = new MasterCaller();
        GuestCaller objGuestData = new GuestCaller();

        Dictionary<int, int> guestlstDic = new Dictionary<int, int>();

        public frmPartyWiseSummary()
        {
            InitializeComponent();
        }

        private void frmPartyWiseSummary_Load(object sender, EventArgs e)
        {
            var lstGuest = objGuestData.SearchMastGuest(string.Empty).Select(x => new { x.GUEST_NUM, x.G_FNAME }).Distinct().OrderBy(x=>x.G_FNAME).ToList();
            int count = 0;
            foreach (var item in lstGuest)
            {
                chkAccountList.Items.Add(item.G_FNAME, CheckState.Unchecked);
                guestlstDic.Add(count, item.GUEST_NUM);
                count++;
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {

                string guestString = GuestStringID()[0];

                if (!string.IsNullOrEmpty(guestString))
                {
                    DataTable dtReport = new DataTable();
                    decimal amount = 0m, billamount = 0;

                    string sqlQuery = @"DECLARE @StartDate Date = CAST('" + dtmReportFrom.Value.ToSystemDateString() + @"' AS DATE)
                            DECLARE @EndDate Date = CAST('" + dtmReportTo.Value.ToSystemDateString() + @"' AS DATE)

                            select (CASE WHEN R.[S.NO.]=0 THEN '' ELSE CAST(r.[S.NO.] AS VARCHAR(10)) END) [S.NO.],R.[Receipt No],R.[Recep Date],R.Amount,'' as [ ],
	                            (CASE WHEN H.[S.NO.]=0 THEN '' ELSE CAST(H.[S.NO.] AS VARCHAR(10)) END) [S.NO.],H.[Bill No],H.[Bill Date],H.Amount from  
                            (
	                            SELECT 0 [S.NO.],'Opening' [Receipt No],NULL [Recep Date],CAST(SUM(A.total_amt) AS DEC(10,2)) [Amount]
                                FROM receipt_payment A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Rdate AS DATE) < @STARTDATE
                                UNION
                                SELECT ROW_NUMBER() OVER(ORDER BY A.RECPT_PAY_ID) [S.NO.],CAST(A.receipt_No AS VARCHAR(20)) [Receipt No],
	                                REPLACE(CONVERT(NVARCHAR(20),A.Rdate,106),' ','/') [Recep Date],CAST(A.total_amt AS DEC(10,2)) [Amount]
                                FROM receipt_payment A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Rdate AS DATE) BETWEEN @STARTDATE AND @ENDDATE) R 
	                            Full outer join 
	                            (
		                            SELECT 0 [S.NO.],'Opening' [Bill No],NULL [Bill Date],CAST(SUM(A.totalamt) AS DEC(10,2)) [Amount]
                                    FROM HotelBILL A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Bdate AS DATE) < @STARTDATE
                                    UNION
                                    SELECT ROW_NUMBER() OVER(ORDER BY A.HotelBill_id) [S.NO.],CAST(A.Bill_No AS VARCHAR(20)) [Bill No],
	                                    REPLACE(CONVERT(NVARCHAR(20),A.Bdate,106),' ','/') [Bill Date],CAST(A.totalamt AS DEC(10,2)) [Amount]
                                    FROM HotelBILL A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Bdate AS DATE) BETWEEN @STARTDATE AND @ENDDATE) H 
                            ON R.[S.NO.]=H.[S.NO.]";

                    dtReport = objReport.GetDataTableData(sqlQuery, "PartySummary");

                    if (dtReport != null)
                    {
                        foreach (DataRow grdRow in dtReport.Rows)
                        {
                            amount += (!DBNull.Value.Equals(grdRow[3]) ? Convert.ToDecimal(grdRow[3]) : 0);
                            billamount += (!DBNull.Value.Equals(grdRow[8]) ? Convert.ToDecimal(grdRow[8]) : 0);
                        }

                        dtReport.Rows.Add(dtReport.NewRow());

                        DataRow drw = dtReport.NewRow();
                        drw[2] = "Total :";
                        drw[3] = amount.ToString("0.00");
                        drw[8] = billamount.ToString("0.00");
                        dtReport.Rows.Add(drw);
                    }

                    dgvReport.DataSource = dtReport;
                    foreach (DataGridViewColumn grdCol in dgvReport.Columns)
                    {
                        grdCol.SortMode = DataGridViewColumnSortMode.NotSortable;
                        if (grdCol.Index == 3 || grdCol.Index == 8)
                        {
                            grdCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            grdCol.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                        }
                    }

                    if (dtReport.Rows.Count > 2)
                    {
                        dgvReport.Rows[dtReport.Rows.Count - 1].DefaultCellStyle.BackColor = System.Drawing.Color.Yellow;
                        dgvReport.Rows[dtReport.Rows.Count - 1].DefaultCellStyle.Font = new Font("Verdana", 9, FontStyle.Bold);
                    }
                }
            }            
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error Get Report of Party Wise Summary");
            }
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chkAccountList.Items.Count; i++)
            {
                chkAccountList.SetItemChecked(i, true);
            }
        }

        private void btnUnselectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chkAccountList.Items.Count; i++)
            {
                chkAccountList.SetItemChecked(i, false);
            }
        }

        private string[] GuestStringID()
        {
            string[] customerDetails = new string[2];
            System.Text.StringBuilder guestid = new StringBuilder();
            System.Text.StringBuilder guestName = new StringBuilder();
            int guestNum = 0;

            foreach (int indexCheck in chkAccountList.CheckedIndices)
            {
                if (chkAccountList.GetItemCheckState(indexCheck) == CheckState.Checked)
                {
                    guestNum = guestlstDic.FirstOrDefault(x => x.Key == indexCheck).Value;
                    if (guestid.Length > 0)
                    {
                        guestid.Append(", ");
                    }

                    if (guestName.Length > 0)
                    {
                        guestName.Append(", ");
                    }

                    guestName.Append(chkAccountList.Items[indexCheck].ToString());

                    guestid.Append(guestNum.ToString());
                }
            }

            customerDetails[0] = guestid.ToString();
            customerDetails[1] = guestName.ToString();

            return customerDetails;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            return;
//            try
//            {
//                string guestString = GuestStringID()[0];
//                string guestName = GuestStringID()[1];
//                if (!string.IsNullOrEmpty(guestString))
//                {
//                    DataTable dtReport = new DataTable();
//                    string sqlQuery = @"
//                            DELETE FROM tempc
//                            DECLARE @StartDate Date = CAST('" + dtmReportFrom.Value.ToSystemDateString() + @"' AS DATE)
//                            DECLARE @EndDate Date = CAST('" + dtmReportTo.Value.ToSystemDateString() + @"' AS DATE)
//
//                            INSERT INTO tempc (sno,tempF_1,tempC_1,tempC_2,tempF_2,tempF_3,tempC_3,tempC_4,tempF_4)
//                            SELECT ISNULL(R.[S.NO.],H.[S.NO.]),r.[S.NO.],R.[Receipt No],R.[Recep Date],R.Amount,H.[S.NO.],H.[Bill No],H.[Bill Date],H.Amount
//                            from 
//                            (
//	                            SELECT 0 [S.NO.],'Opening' [Receipt No],NULL [Recep Date],CAST(SUM(A.total_amt) AS DEC(10,2)) [Amount]
//                                FROM receipt_payment A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Rdate AS DATE) < @STARTDATE
//                                UNION
//                                SELECT ROW_NUMBER() OVER(ORDER BY A.RECPT_PAY_ID) [S.NO.],CAST(A.receipt_No AS VARCHAR(20)) [Receipt No],
//                                    REPLACE(CONVERT(NVARCHAR(20),A.Rdate,106),' ','/') [Recep Date],CAST(A.total_amt AS DEC(10,2)) [Amount]
//                                FROM receipt_payment A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Rdate AS DATE) BETWEEN @STARTDATE AND @ENDDATE) R 
//	                            Full outer join 
//	                            (
//		                            SELECT 0 [S.NO.],'Opening' [Bill No],NULL [Bill Date],CAST(SUM(A.totalamt) AS DEC(10,2)) [Amount]
//                                    FROM HotelBILL A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Bdate AS DATE) < @STARTDATE
//                                    UNION
//                                    SELECT ROW_NUMBER() OVER(ORDER BY A.HotelBill_id) [S.NO.],CAST(A.Bill_No AS VARCHAR(20)) [Bill No],
//                                        REPLACE(CONVERT(NVARCHAR(20),A.Bdate,106),' ','/') [Bill Date],CAST(A.totalamt AS DEC(10,2)) [Amount]
//                                    FROM HotelBILL A WHERE GUEST_NUM in (" + guestString + @") AND CAST(Bdate AS DATE) BETWEEN @STARTDATE AND @ENDDATE) H 
//                            ON R.[S.NO.]=H.[S.NO.]";

//                    //objReport.ExecReportDataTable(sqlQuery);
//                    //frmbillreportview freport = new frmbillreportview();
//                    //freport.reportName = "rpt_ravi_PartyWiseSummaryVYK.rpt";
//                    //freport.reportCaption = "Party Wise Summary for (" + guestName + ") from " + dtmReportFrom.Value.ToString("dd/MM/yyyy") + " To " + dtmReportTo.Value.ToString("dd/MM/yyyy");
//                    //freport.Show();
//                }
//            }
//            catch (Exception ex)
//            {
//                ExceptionLogging.SendErrorToText(ex, "Error Print Report of Party Wise Summary");
//            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        string serchText = string.Empty;
        private void chkAccountList_KeyPress(object sender, KeyPressEventArgs e)
        {
            serchText += e.KeyChar.ToString();

            if (!string.IsNullOrEmpty(serchText))
            {
                int indexstr = chkAccountList.FindString(serchText);
                if (indexstr != -1)
                    chkAccountList.SetSelected(indexstr,true);
            }
        }

        private void chkAccountList_MouseMove(object sender, MouseEventArgs e)
        {
            serchText = string.Empty;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //serchText += e.KeyChar.ToString();

            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                int indexstr = chkAccountList.FindString(textBox1.Text);
                if (indexstr != -1)
                    chkAccountList.SetSelected(indexstr, true);
            }
        }
    }
}
