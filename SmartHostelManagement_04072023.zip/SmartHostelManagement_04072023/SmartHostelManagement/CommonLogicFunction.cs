﻿using System;
using System.Collections.Generic;
using System.Linq;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.DBData;

namespace SmartHostelManagement
{
    public static class CommonLogicFunction
    {
        public static void TransferAgainstReservation(int againstReservationId, int reservationId)
        {
            using (ISIPMEntities dbContext = new ISIPMEntities())
            {
                dbContext.Configuration.LazyLoadingEnabled = false;

            }
        }

        public static void BillCalculation(int hotelBillid)
        {
            using (DBData.ISIPMEntities dbContext = new DBData.ISIPMEntities())
            {
                dbContext.Configuration.LazyLoadingEnabled = false;
                try
                {
                    DBData.HotelBILL objHotelBill = dbContext.HotelBILLs.Where(x => x.hotelBill_ID == hotelBillid).FirstOrDefault();
                    if (objHotelBill != null)
                    {
                        objHotelBill.totalroomrent = dbContext.hotelbilldetails.Where(x => x.hotelBill_ID == hotelBillid).Sum(x=>x.roomrent_amt);
                        objHotelBill.totalroomrentAM = dbContext.hotelbilldetails.Where(x => x.hotelBill_ID == hotelBillid).Sum(x => x.ExtraHrsBeforeAmt);
                        objHotelBill.totalroomrentPM = dbContext.hotelbilldetails.Where(x => x.hotelBill_ID == hotelBillid).Sum(x => x.ExtraHrsAfterAmt);
                        objHotelBill.luxurytaxamt = dbContext.hotelbilldetails.Where(x => x.hotelBill_ID == hotelBillid).Sum(x => x.GSTAmt);
                        objHotelBill.CancelChargesAmountTotal = dbContext.HotelBillCancelCharges.Where(x => x.hotelBill_ID == hotelBillid).Sum(x => x.GSTAmt);
                        objHotelBill.CateringAmountTotal = dbContext.HotelBill_CATERING_DETAILS.Where(x => x.hotelBill_ID == hotelBillid)
                            .Join(dbContext.ChannelOrders.Where(y => y.activate_delete == false),x => x.ChannelOrder_Id, y => y.ChannelOrder_Id,
                            (x,y) => x).Sum(x => x.GSTAmt);
                        objHotelBill.CatCancelChargesAmountTotal = dbContext.HotelBillCatCancelDetails.Where(x => x.hotelBill_ID == hotelBillid)
                            .Join(dbContext.ChannelOrders.Where(y => y.activate_delete == false), x => x.ChannelOrder_Id, y => y.ChannelOrder_Id,
                            (x, y) => x).Sum(x => x.GSTAmt);
                        objHotelBill.DiningAmountTotal = dbContext.Hotel_DININGRoom_details.Where(x => x.hotelBill_ID == hotelBillid)
                            .Join(dbContext.KOTs.Where(y => y.activate_delete == false && y.KOTCANCEL == false), x => x.KOT_Id, y => y.KOT_ID,
                            (x, y) => x).Sum(x => x.GSTAmt);
                        objHotelBill.MiscAmountTotal = (dbContext.HotelBill_MISC_DETAILS.Where(x => x.hotelBill_ID == hotelBillid).Sum(x => x.AMOUNT + x.GSTAmt));


                        objHotelBill.totalamt = objHotelBill.totalroomrent + objHotelBill.totalroomrentAM + objHotelBill.totalroomrentPM + objHotelBill.luxurytaxamt;
                        objHotelBill.advancerecd = (objHotelBill.Room_Dormatory == (int)CommonVariables.RoomDormatory.Room ||
                            objHotelBill.Room_Dormatory == (int)CommonVariables.RoomDormatory.RoomEstimate) ?
                            dbContext.receipt_payment_Adjust_details.Where(x => x.hotelBill_ID == hotelBillid && x.AdjType == "Rooms").Sum(x => x.amount_Adj)
                            : dbContext.receipt_payment_Adjust_details.Where(x => x.hotelBill_ID == hotelBillid && x.AdjType == "Seminar").Sum(x => x.amount_Adj);

                        objHotelBill.grandtotalamt = (objHotelBill.totalamt + objHotelBill.CancelChargesAmountTotal + objHotelBill.CatCancelChargesAmountTotal
                            + objHotelBill.DiningAmountTotal + objHotelBill.MiscAmountTotal);
                        objHotelBill.netpayable = objHotelBill.advancerecd - objHotelBill.grandtotalamt;
                        objHotelBill.roundoff = (int)objHotelBill.netpayable - objHotelBill.netpayable;
                        objHotelBill.netpayable = (int)objHotelBill.netpayable;
                        dbContext.SaveChanges();
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogging.SendErrorToText(ex, "");
                }
            }
        }
    }
}
