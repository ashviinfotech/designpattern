﻿namespace SmartHostelManagement.Kitchen
{
    partial class frmKotBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.lblUserName = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtFoodDiscAmt = new System.Windows.Forms.TextBox();
            this.txtFoodDiscPer = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtFinalPrice = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtFoodName = new System.Windows.Forms.TextBox();
            this.dgvKotDetails = new System.Windows.Forms.DataGridView();
            this.btnFoodAddFood = new System.Windows.Forms.Button();
            this.btnFoodSearch = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnFoodRemove = new System.Windows.Forms.Button();
            this.btnFoodAdd = new System.Windows.Forms.Button();
            this.btnFoodNew = new System.Windows.Forms.Button();
            this.txtFoodGSTAmt = new System.Windows.Forms.TextBox();
            this.txtFoodAmt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtServAmt = new System.Windows.Forms.TextBox();
            this.txtFoodQty = new System.Windows.Forms.TextBox();
            this.txtFoodGSTPer = new System.Windows.Forms.TextBox();
            this.txtFoodServCharg = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtFoodPrice = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chklstCanceledBill = new System.Windows.Forms.CheckedListBox();
            this.txtKotNo = new System.Windows.Forms.TextBox();
            this.dtmKotTime = new System.Windows.Forms.DateTimePicker();
            this.btnGLSearch = new System.Windows.Forms.Button();
            this.dtmKotDate = new System.Windows.Forms.DateTimePicker();
            this.cmbModeOfPay = new System.Windows.Forms.ComboBox();
            this.cmbWaiter = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtGLName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtGLNo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSlNo = new System.Windows.Forms.TextBox();
            this.lblAccount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblGLAccount = new System.Windows.Forms.Label();
            this.txtGstPer = new System.Windows.Forms.TextBox();
            this.txtTotalAmt = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.txtDisAmount = new System.Windows.Forms.TextBox();
            this.txtTotalGST = new System.Windows.Forms.TextBox();
            this.txtNetAmout = new System.Windows.Forms.TextBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtTotalServAmt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnCancelBill = new System.Windows.Forms.Button();
            this.btnActivateBill = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.chkCancelled = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKotDetails)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnFirst);
            this.groupBox1.Controls.Add(this.btnPrevious);
            this.groupBox1.Controls.Add(this.btnNext);
            this.groupBox1.Controls.Add(this.btnLast);
            this.groupBox1.Controls.Add(this.lblUserName);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.txtGstPer);
            this.groupBox1.Controls.Add(this.txtTotalAmt);
            this.groupBox1.Controls.Add(this.textBox14);
            this.groupBox1.Controls.Add(this.txtDisAmount);
            this.groupBox1.Controls.Add(this.txtTotalGST);
            this.groupBox1.Controls.Add(this.txtNetAmout);
            this.groupBox1.Controls.Add(this.txtRemarks);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtTotalServAmt);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Location = new System.Drawing.Point(3, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(921, 500);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btnFirst
            // 
            this.btnFirst.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(114, 462);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(49, 26);
            this.btnFirst.TabIndex = 48;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.Location = new System.Drawing.Point(175, 462);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(49, 26);
            this.btnPrevious.TabIndex = 47;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(236, 462);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(49, 26);
            this.btnNext.TabIndex = 46;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnLast
            // 
            this.btnLast.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.Location = new System.Drawing.Point(294, 462);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(49, 26);
            this.btnLast.TabIndex = 45;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // lblUserName
            // 
            this.lblUserName.BackColor = System.Drawing.SystemColors.Info;
            this.lblUserName.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(423, 458);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(235, 32);
            this.lblUserName.TabIndex = 16;
            this.lblUserName.Text = "User : SUSHANT";
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(690, 476);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(84, 14);
            this.label19.TabIndex = 15;
            this.label19.Text = "Net Amount";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(686, 447);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(88, 14);
            this.label18.TabIndex = 15;
            this.label18.Text = "GST Amount";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(710, 419);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 14);
            this.label17.TabIndex = 15;
            this.label17.Text = "Discount";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(680, 392);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 14);
            this.label16.TabIndex = 15;
            this.label16.Text = "Total Amount";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtFoodDiscAmt);
            this.groupBox3.Controls.Add(this.txtFoodDiscPer);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.txtFinalPrice);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.txtFoodName);
            this.groupBox3.Controls.Add(this.dgvKotDetails);
            this.groupBox3.Controls.Add(this.btnFoodAddFood);
            this.groupBox3.Controls.Add(this.btnFoodSearch);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.btnFoodRemove);
            this.groupBox3.Controls.Add(this.btnFoodAdd);
            this.groupBox3.Controls.Add(this.btnFoodNew);
            this.groupBox3.Controls.Add(this.txtFoodGSTAmt);
            this.groupBox3.Controls.Add(this.txtFoodAmt);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txtServAmt);
            this.groupBox3.Controls.Add(this.txtFoodQty);
            this.groupBox3.Controls.Add(this.txtFoodGSTPer);
            this.groupBox3.Controls.Add(this.txtFoodServCharg);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtFoodPrice);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(6, 118);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(908, 265);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            // 
            // txtFoodDiscAmt
            // 
            this.txtFoodDiscAmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFoodDiscAmt.Location = new System.Drawing.Point(492, 45);
            this.txtFoodDiscAmt.Name = "txtFoodDiscAmt";
            this.txtFoodDiscAmt.ReadOnly = true;
            this.txtFoodDiscAmt.Size = new System.Drawing.Size(77, 22);
            this.txtFoodDiscAmt.TabIndex = 31;
            this.txtFoodDiscAmt.TabStop = false;
            this.txtFoodDiscAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodDiscAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtFoodDiscPer
            // 
            this.txtFoodDiscPer.Location = new System.Drawing.Point(342, 45);
            this.txtFoodDiscPer.Name = "txtFoodDiscPer";
            this.txtFoodDiscPer.Size = new System.Drawing.Size(76, 22);
            this.txtFoodDiscPer.TabIndex = 32;
            this.txtFoodDiscPer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodDiscPer.TextChanged += new System.EventHandler(this.txtFoodQty_TextChanged);
            this.txtFoodDiscPer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(424, 50);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 14);
            this.label25.TabIndex = 30;
            this.label25.Text = "Disc Amt";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(270, 50);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(68, 14);
            this.label26.TabIndex = 29;
            this.label26.Text = "Disc (%)";
            // 
            // txtFinalPrice
            // 
            this.txtFinalPrice.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFinalPrice.Location = new System.Drawing.Point(597, 15);
            this.txtFinalPrice.Name = "txtFinalPrice";
            this.txtFinalPrice.ReadOnly = true;
            this.txtFinalPrice.Size = new System.Drawing.Size(105, 22);
            this.txtFinalPrice.TabIndex = 28;
            this.txtFinalPrice.TabStop = false;
            this.txtFinalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(520, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 14);
            this.label21.TabIndex = 27;
            this.label21.Text = "Final Price";
            // 
            // txtFoodName
            // 
            this.txtFoodName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFoodName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFoodName.Location = new System.Drawing.Point(51, 16);
            this.txtFoodName.Name = "txtFoodName";
            this.txtFoodName.ReadOnly = true;
            this.txtFoodName.Size = new System.Drawing.Size(458, 22);
            this.txtFoodName.TabIndex = 26;
            this.txtFoodName.TabStop = false;
            // 
            // dgvKotDetails
            // 
            this.dgvKotDetails.AllowUserToAddRows = false;
            this.dgvKotDetails.AllowUserToDeleteRows = false;
            this.dgvKotDetails.AllowUserToResizeColumns = false;
            this.dgvKotDetails.AllowUserToResizeRows = false;
            this.dgvKotDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvKotDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKotDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvKotDetails.Location = new System.Drawing.Point(7, 108);
            this.dgvKotDetails.MultiSelect = false;
            this.dgvKotDetails.Name = "dgvKotDetails";
            this.dgvKotDetails.ReadOnly = true;
            this.dgvKotDetails.RowHeadersVisible = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvKotDetails.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvKotDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKotDetails.ShowCellErrors = false;
            this.dgvKotDetails.ShowEditingIcon = false;
            this.dgvKotDetails.ShowRowErrors = false;
            this.dgvKotDetails.Size = new System.Drawing.Size(895, 150);
            this.dgvKotDetails.TabIndex = 25;
            this.dgvKotDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKotDetails_CellDoubleClick);
            // 
            // btnFoodAddFood
            // 
            this.btnFoodAddFood.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoodAddFood.Location = new System.Drawing.Point(804, 13);
            this.btnFoodAddFood.Name = "btnFoodAddFood";
            this.btnFoodAddFood.Size = new System.Drawing.Size(98, 26);
            this.btnFoodAddFood.TabIndex = 14;
            this.btnFoodAddFood.Text = "Add Food";
            this.btnFoodAddFood.UseVisualStyleBackColor = true;
            this.btnFoodAddFood.Click += new System.EventHandler(this.btnFoodAddFood_Click);
            // 
            // btnFoodSearch
            // 
            this.btnFoodSearch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoodSearch.Location = new System.Drawing.Point(717, 13);
            this.btnFoodSearch.Name = "btnFoodSearch";
            this.btnFoodSearch.Size = new System.Drawing.Size(81, 26);
            this.btnFoodSearch.TabIndex = 13;
            this.btnFoodSearch.Text = "&Search";
            this.btnFoodSearch.UseVisualStyleBackColor = true;
            this.btnFoodSearch.Click += new System.EventHandler(this.btnFoodSearch_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(39, 14);
            this.label14.TabIndex = 21;
            this.label14.Text = "Food";
            // 
            // btnFoodRemove
            // 
            this.btnFoodRemove.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoodRemove.Location = new System.Drawing.Point(815, 79);
            this.btnFoodRemove.Name = "btnFoodRemove";
            this.btnFoodRemove.Size = new System.Drawing.Size(87, 23);
            this.btnFoodRemove.TabIndex = 19;
            this.btnFoodRemove.Text = "Remo&ve";
            this.btnFoodRemove.UseVisualStyleBackColor = true;
            this.btnFoodRemove.Click += new System.EventHandler(this.btnFoodRemove_Click);
            // 
            // btnFoodAdd
            // 
            this.btnFoodAdd.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoodAdd.Location = new System.Drawing.Point(686, 77);
            this.btnFoodAdd.Name = "btnFoodAdd";
            this.btnFoodAdd.Size = new System.Drawing.Size(120, 26);
            this.btnFoodAdd.TabIndex = 17;
            this.btnFoodAdd.Text = "&Add/Change";
            this.btnFoodAdd.UseVisualStyleBackColor = true;
            this.btnFoodAdd.Click += new System.EventHandler(this.btnFoodAdd_Click);
            // 
            // btnFoodNew
            // 
            this.btnFoodNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoodNew.Location = new System.Drawing.Point(605, 77);
            this.btnFoodNew.Name = "btnFoodNew";
            this.btnFoodNew.Size = new System.Drawing.Size(75, 26);
            this.btnFoodNew.TabIndex = 18;
            this.btnFoodNew.Text = "&New";
            this.btnFoodNew.UseVisualStyleBackColor = true;
            this.btnFoodNew.Click += new System.EventHandler(this.btnFoodNew_Click);
            // 
            // txtFoodGSTAmt
            // 
            this.txtFoodGSTAmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFoodGSTAmt.Location = new System.Drawing.Point(235, 76);
            this.txtFoodGSTAmt.Name = "txtFoodGSTAmt";
            this.txtFoodGSTAmt.ReadOnly = true;
            this.txtFoodGSTAmt.Size = new System.Drawing.Size(100, 22);
            this.txtFoodGSTAmt.TabIndex = 17;
            this.txtFoodGSTAmt.TabStop = false;
            this.txtFoodGSTAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodGSTAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtFoodAmt
            // 
            this.txtFoodAmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFoodAmt.Location = new System.Drawing.Point(405, 76);
            this.txtFoodAmt.Name = "txtFoodAmt";
            this.txtFoodAmt.ReadOnly = true;
            this.txtFoodAmt.Size = new System.Drawing.Size(105, 22);
            this.txtFoodAmt.TabIndex = 16;
            this.txtFoodAmt.TabStop = false;
            this.txtFoodAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(346, 81);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 14);
            this.label13.TabIndex = 15;
            this.label13.Text = "Amount";
            // 
            // txtServAmt
            // 
            this.txtServAmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtServAmt.Location = new System.Drawing.Point(822, 45);
            this.txtServAmt.Name = "txtServAmt";
            this.txtServAmt.ReadOnly = true;
            this.txtServAmt.Size = new System.Drawing.Size(77, 22);
            this.txtServAmt.TabIndex = 14;
            this.txtServAmt.TabStop = false;
            this.txtServAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtServAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtFoodQty
            // 
            this.txtFoodQty.Location = new System.Drawing.Point(205, 45);
            this.txtFoodQty.Name = "txtFoodQty";
            this.txtFoodQty.Size = new System.Drawing.Size(61, 22);
            this.txtFoodQty.TabIndex = 15;
            this.txtFoodQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodQty.TextChanged += new System.EventHandler(this.txtFoodQty_TextChanged);
            this.txtFoodQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFoodQty_KeyDown);
            this.txtFoodQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtFoodGSTPer
            // 
            this.txtFoodGSTPer.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFoodGSTPer.Location = new System.Drawing.Point(78, 75);
            this.txtFoodGSTPer.Name = "txtFoodGSTPer";
            this.txtFoodGSTPer.ReadOnly = true;
            this.txtFoodGSTPer.Size = new System.Drawing.Size(61, 22);
            this.txtFoodGSTPer.TabIndex = 12;
            this.txtFoodGSTPer.TabStop = false;
            this.txtFoodGSTPer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodGSTPer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtFoodServCharg
            // 
            this.txtFoodServCharg.Location = new System.Drawing.Point(674, 45);
            this.txtFoodServCharg.Name = "txtFoodServCharg";
            this.txtFoodServCharg.Size = new System.Drawing.Size(76, 22);
            this.txtFoodServCharg.TabIndex = 16;
            this.txtFoodServCharg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodServCharg.TextChanged += new System.EventHandler(this.txtFoodQty_TextChanged);
            this.txtFoodServCharg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(145, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 14);
            this.label7.TabIndex = 6;
            this.label7.Text = "GST Amount";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 79);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 14);
            this.label8.TabIndex = 5;
            this.label8.Text = "GST (%)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(753, 50);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 14);
            this.label9.TabIndex = 4;
            this.label9.Text = "Serv Amt";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(571, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 14);
            this.label10.TabIndex = 3;
            this.label10.Text = "Serv Char(%)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(138, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 14);
            this.label11.TabIndex = 2;
            this.label11.Text = "Quantity";
            // 
            // txtFoodPrice
            // 
            this.txtFoodPrice.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFoodPrice.Location = new System.Drawing.Point(51, 45);
            this.txtFoodPrice.Name = "txtFoodPrice";
            this.txtFoodPrice.ReadOnly = true;
            this.txtFoodPrice.Size = new System.Drawing.Size(82, 22);
            this.txtFoodPrice.TabIndex = 1;
            this.txtFoodPrice.TabStop = false;
            this.txtFoodPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFoodPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 14);
            this.label12.TabIndex = 0;
            this.label12.Text = "Price";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chklstCanceledBill);
            this.groupBox2.Controls.Add(this.txtKotNo);
            this.groupBox2.Controls.Add(this.dtmKotTime);
            this.groupBox2.Controls.Add(this.btnGLSearch);
            this.groupBox2.Controls.Add(this.dtmKotDate);
            this.groupBox2.Controls.Add(this.cmbModeOfPay);
            this.groupBox2.Controls.Add(this.cmbWaiter);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtGLName);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtGLNo);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtSlNo);
            this.groupBox2.Controls.Add(this.lblAccount);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblGLAccount);
            this.groupBox2.Location = new System.Drawing.Point(7, 8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(907, 111);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // chklstCanceledBill
            // 
            this.chklstCanceledBill.FormattingEnabled = true;
            this.chklstCanceledBill.Location = new System.Drawing.Point(623, 35);
            this.chklstCanceledBill.Name = "chklstCanceledBill";
            this.chklstCanceledBill.Size = new System.Drawing.Size(278, 72);
            this.chklstCanceledBill.TabIndex = 24;
            this.chklstCanceledBill.TabStop = false;
            // 
            // txtKotNo
            // 
            this.txtKotNo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtKotNo.Location = new System.Drawing.Point(528, 13);
            this.txtKotNo.Name = "txtKotNo";
            this.txtKotNo.ReadOnly = true;
            this.txtKotNo.Size = new System.Drawing.Size(87, 22);
            this.txtKotNo.TabIndex = 11;
            this.txtKotNo.TabStop = false;
            this.txtKotNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtKotNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // dtmKotTime
            // 
            this.dtmKotTime.CustomFormat = "hh:mm tt";
            this.dtmKotTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmKotTime.Location = new System.Drawing.Point(367, 13);
            this.dtmKotTime.Name = "dtmKotTime";
            this.dtmKotTime.ShowUpDown = true;
            this.dtmKotTime.Size = new System.Drawing.Size(94, 22);
            this.dtmKotTime.TabIndex = 8;
            this.dtmKotTime.TabStop = false;
            // 
            // btnGLSearch
            // 
            this.btnGLSearch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGLSearch.Location = new System.Drawing.Point(184, 79);
            this.btnGLSearch.Name = "btnGLSearch";
            this.btnGLSearch.Size = new System.Drawing.Size(80, 26);
            this.btnGLSearch.TabIndex = 12;
            this.btnGLSearch.Text = "&Search";
            this.btnGLSearch.UseVisualStyleBackColor = true;
            this.btnGLSearch.Click += new System.EventHandler(this.btnGLSearch_Click);
            // 
            // dtmKotDate
            // 
            this.dtmKotDate.CustomFormat = "dd/MMM/yyyy";
            this.dtmKotDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmKotDate.Location = new System.Drawing.Point(206, 13);
            this.dtmKotDate.Name = "dtmKotDate";
            this.dtmKotDate.Size = new System.Drawing.Size(110, 22);
            this.dtmKotDate.TabIndex = 7;
            this.dtmKotDate.TabStop = false;
            // 
            // cmbModeOfPay
            // 
            this.cmbModeOfPay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbModeOfPay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbModeOfPay.Location = new System.Drawing.Point(133, 43);
            this.cmbModeOfPay.Name = "cmbModeOfPay";
            this.cmbModeOfPay.Size = new System.Drawing.Size(184, 22);
            this.cmbModeOfPay.TabIndex = 11;
            this.cmbModeOfPay.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // cmbWaiter
            // 
            this.cmbWaiter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbWaiter.FormattingEnabled = true;
            this.cmbWaiter.Location = new System.Drawing.Point(404, 43);
            this.cmbWaiter.Name = "cmbWaiter";
            this.cmbWaiter.Size = new System.Drawing.Size(116, 22);
            this.cmbWaiter.TabIndex = 12;
            this.cmbWaiter.Visible = false;
            this.cmbWaiter.SelectedIndexChanged += new System.EventHandler(this.cmbWaiter_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(620, 18);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 14);
            this.label24.TabIndex = 6;
            this.label24.Text = "Cancel Bills";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(324, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 14);
            this.label6.TabIndex = 6;
            this.label6.Text = "Waiter No";
            this.label6.Visible = false;
            // 
            // txtGLName
            // 
            this.txtGLName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtGLName.Location = new System.Drawing.Point(331, 82);
            this.txtGLName.Name = "txtGLName";
            this.txtGLName.ReadOnly = true;
            this.txtGLName.Size = new System.Drawing.Size(284, 22);
            this.txtGLName.TabIndex = 17;
            this.txtGLName.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 14);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mode Of Payment";
            // 
            // txtGLNo
            // 
            this.txtGLNo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtGLNo.Location = new System.Drawing.Point(97, 82);
            this.txtGLNo.Name = "txtGLNo";
            this.txtGLNo.ReadOnly = true;
            this.txtGLNo.Size = new System.Drawing.Size(83, 22);
            this.txtGLNo.TabIndex = 17;
            this.txtGLNo.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(467, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 14);
            this.label4.TabIndex = 4;
            this.label4.Text = "KOT No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(322, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 14);
            this.label3.TabIndex = 3;
            this.label3.Text = "Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(134, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "KOT Date";
            // 
            // txtSlNo
            // 
            this.txtSlNo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtSlNo.Location = new System.Drawing.Point(46, 13);
            this.txtSlNo.Name = "txtSlNo";
            this.txtSlNo.ReadOnly = true;
            this.txtSlNo.Size = new System.Drawing.Size(82, 22);
            this.txtSlNo.TabIndex = 1;
            this.txtSlNo.TabStop = false;
            this.txtSlNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSlNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // lblAccount
            // 
            this.lblAccount.AutoSize = true;
            this.lblAccount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccount.Location = new System.Drawing.Point(271, 85);
            this.lblAccount.Name = "lblAccount";
            this.lblAccount.Size = new System.Drawing.Size(59, 14);
            this.lblAccount.TabIndex = 6;
            this.lblAccount.Text = "Account";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "S No";
            // 
            // lblGLAccount
            // 
            this.lblGLAccount.AutoSize = true;
            this.lblGLAccount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGLAccount.Location = new System.Drawing.Point(6, 85);
            this.lblGLAccount.Name = "lblGLAccount";
            this.lblGLAccount.Size = new System.Drawing.Size(89, 14);
            this.lblGLAccount.TabIndex = 6;
            this.lblGLAccount.Text = "G/L Account";
            // 
            // txtGstPer
            // 
            this.txtGstPer.Location = new System.Drawing.Point(611, 416);
            this.txtGstPer.Name = "txtGstPer";
            this.txtGstPer.Size = new System.Drawing.Size(43, 22);
            this.txtGstPer.TabIndex = 24;
            this.txtGstPer.Text = "0";
            this.txtGstPer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGstPer.Visible = false;
            this.txtGstPer.TextChanged += new System.EventHandler(this.txtDisPer_TextChanged);
            this.txtGstPer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtTotalAmt
            // 
            this.txtTotalAmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTotalAmt.Location = new System.Drawing.Point(778, 388);
            this.txtTotalAmt.Name = "txtTotalAmt";
            this.txtTotalAmt.ReadOnly = true;
            this.txtTotalAmt.Size = new System.Drawing.Size(136, 22);
            this.txtTotalAmt.TabIndex = 14;
            this.txtTotalAmt.TabStop = false;
            this.txtTotalAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(1025, 503);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(89, 22);
            this.textBox14.TabIndex = 14;
            // 
            // txtDisAmount
            // 
            this.txtDisAmount.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtDisAmount.Location = new System.Drawing.Point(778, 415);
            this.txtDisAmount.Name = "txtDisAmount";
            this.txtDisAmount.ReadOnly = true;
            this.txtDisAmount.Size = new System.Drawing.Size(136, 22);
            this.txtDisAmount.TabIndex = 14;
            this.txtDisAmount.TabStop = false;
            this.txtDisAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDisAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtTotalGST
            // 
            this.txtTotalGST.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTotalGST.Location = new System.Drawing.Point(778, 443);
            this.txtTotalGST.Name = "txtTotalGST";
            this.txtTotalGST.ReadOnly = true;
            this.txtTotalGST.Size = new System.Drawing.Size(136, 22);
            this.txtTotalGST.TabIndex = 14;
            this.txtTotalGST.TabStop = false;
            this.txtTotalGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalGST.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtNetAmout
            // 
            this.txtNetAmout.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtNetAmout.Location = new System.Drawing.Point(778, 471);
            this.txtNetAmout.Name = "txtNetAmout";
            this.txtNetAmout.ReadOnly = true;
            this.txtNetAmout.Size = new System.Drawing.Size(136, 22);
            this.txtNetAmout.TabIndex = 14;
            this.txtNetAmout.TabStop = false;
            this.txtNetAmout.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNetAmout.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Location = new System.Drawing.Point(75, 389);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(339, 56);
            this.txtRemarks.TabIndex = 22;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(7, 393);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 14);
            this.label20.TabIndex = 4;
            this.label20.Text = "Remarks";
            // 
            // txtTotalServAmt
            // 
            this.txtTotalServAmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTotalServAmt.Location = new System.Drawing.Point(523, 388);
            this.txtTotalServAmt.Name = "txtTotalServAmt";
            this.txtTotalServAmt.ReadOnly = true;
            this.txtTotalServAmt.Size = new System.Drawing.Size(116, 22);
            this.txtTotalServAmt.TabIndex = 14;
            this.txtTotalServAmt.TabStop = false;
            this.txtTotalServAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalServAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(420, 392);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 14);
            this.label15.TabIndex = 4;
            this.label15.Text = "Serv. Charges";
            // 
            // btnCancelBill
            // 
            this.btnCancelBill.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelBill.Location = new System.Drawing.Point(10, 507);
            this.btnCancelBill.Name = "btnCancelBill";
            this.btnCancelBill.Size = new System.Drawing.Size(75, 41);
            this.btnCancelBill.TabIndex = 25;
            this.btnCancelBill.Text = "Cancel Bill";
            this.btnCancelBill.UseVisualStyleBackColor = true;
            this.btnCancelBill.Click += new System.EventHandler(this.btnCancelBill_Click);
            // 
            // btnActivateBill
            // 
            this.btnActivateBill.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActivateBill.Location = new System.Drawing.Point(94, 507);
            this.btnActivateBill.Name = "btnActivateBill";
            this.btnActivateBill.Size = new System.Drawing.Size(93, 41);
            this.btnActivateBill.TabIndex = 26;
            this.btnActivateBill.Text = "Activate Bill";
            this.btnActivateBill.UseVisualStyleBackColor = true;
            this.btnActivateBill.Click += new System.EventHandler(this.btnActivateBill_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(434, 507);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(95, 41);
            this.btnRefresh.TabIndex = 29;
            this.btnRefresh.Text = "&Referesh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(546, 507);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 41);
            this.btnSave.TabIndex = 30;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(647, 507);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(90, 41);
            this.btnSearch.TabIndex = 31;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(753, 507);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 41);
            this.btnDelete.TabIndex = 32;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(842, 507);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 41);
            this.btnExit.TabIndex = 33;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(323, 507);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(93, 41);
            this.btnPrint.TabIndex = 28;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // chkCancelled
            // 
            this.chkCancelled.AutoSize = true;
            this.chkCancelled.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCancelled.Location = new System.Drawing.Point(198, 519);
            this.chkCancelled.Name = "chkCancelled";
            this.chkCancelled.Size = new System.Drawing.Size(115, 18);
            this.chkCancelled.TabIndex = 27;
            this.chkCancelled.Text = "Cancelled Bill";
            this.chkCancelled.UseVisualStyleBackColor = true;
            // 
            // frmKotBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 554);
            this.Controls.Add(this.chkCancelled);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnActivateBill);
            this.Controls.Add(this.btnCancelBill);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmKotBill";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bill For Dining Hall (Dining Hall)";
            this.Load += new System.EventHandler(this.frmKotBill_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKotDetails)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSlNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbWaiter;
        private System.Windows.Forms.ComboBox cmbModeOfPay;
        private System.Windows.Forms.DateTimePicker dtmKotDate;
        private System.Windows.Forms.DateTimePicker dtmKotTime;
        private System.Windows.Forms.TextBox txtKotNo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtFoodServCharg;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtFoodPrice;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtFoodGSTPer;
        private System.Windows.Forms.TextBox txtFoodQty;
        private System.Windows.Forms.TextBox txtFoodAmt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtServAmt;
        private System.Windows.Forms.TextBox txtFoodGSTAmt;
        private System.Windows.Forms.Button btnFoodNew;
        private System.Windows.Forms.Button btnFoodAdd;
        private System.Windows.Forms.Button btnFoodRemove;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnFoodAddFood;
        private System.Windows.Forms.Button btnFoodSearch;
        private System.Windows.Forms.DataGridView dgvKotDetails;
        private System.Windows.Forms.TextBox txtFoodName;
        private System.Windows.Forms.TextBox txtTotalServAmt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtGstPer;
        private System.Windows.Forms.TextBox txtTotalAmt;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox txtDisAmount;
        private System.Windows.Forms.TextBox txtTotalGST;
        private System.Windows.Forms.TextBox txtNetAmout;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Button btnCancelBill;
        private System.Windows.Forms.Button btnActivateBill;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.CheckBox chkCancelled;
        private System.Windows.Forms.TextBox txtGLNo;
        private System.Windows.Forms.Label lblGLAccount;
        private System.Windows.Forms.Button btnGLSearch;
        private System.Windows.Forms.TextBox txtGLName;
        private System.Windows.Forms.Label lblAccount;
        private System.Windows.Forms.CheckedListBox chklstCanceledBill;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.TextBox txtFinalPrice;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtFoodDiscAmt;
        private System.Windows.Forms.TextBox txtFoodDiscPer;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
    }
}