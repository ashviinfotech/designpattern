﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using DB = SmartHostelManagement.DBData;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.KitchenMenu
{
    public partial class frmWaiter : Form
    {
        DB.ISIPMEntities dbContext = new DB.ISIPMEntities();
        DB.waiter_master objWaier = null;
        int waierId = 0;

        public frmWaiter()
        {
            InitializeComponent();
        }

        private void txtServiceChrg_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmWaiter_Load(object sender, EventArgs e)
        {
            ResetPageData();
        }

        void ResetPageData()
        {
            txtWaiterCode.Text = string.Empty;
            txtWaiterName.Text = string.Empty;
        }

        private void populatePageData(DBData.waiter_master objMenu)
        {
            if (objMenu != null)
            {
                waierId = objMenu.waiter_id;
                txtWaiterCode.Text = objMenu.waiterno;
                txtWaiterName.Text = objMenu.waitername;
            }
            else
            {
                ResetPageData();
            }
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            ResetPageData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtWaiterCode.Text.Trim()))
                {
                    if (!string.IsNullOrEmpty(txtWaiterName.Text.Trim()))
                    {
                        DBData.waiter_master objMenu = dbContext.waiter_master.FirstOrDefault(x => x.waiter_id == this.waierId);
                        bool newEntry = false;

                        if (objMenu != null)
                        {
                            objMenu.id1 = Frm_Login.UserLogin.log_id;
                            objMenu.date_of_mod = DateTime.Now;
                        }
                        else
                        {
                            objMenu = new DBData.waiter_master();
                            newEntry = true;
                            objMenu.waiter_id = dbContext.waiter_master.Any() ? dbContext.waiter_master.Max(x => x.waiter_id) + 1 : 1; 
                            objMenu.id = Frm_Login.UserLogin.log_id;
                            objMenu.date_of_add = DateTime.Now;
                        }

                        objMenu.waiterno = txtWaiterCode.Text;
                        objMenu.waitername = txtWaiterName.Text;

                        if (newEntry) dbContext.waiter_master.Add(objMenu);

                        dbContext.SaveChanges();

                        CustomMessageBox.ShowInformationMessage("Recorded Save !!!", "");
                        btnReferesh_Click(null, null);
                    }
                    else
                    {
                        CustomMessageBox.ShowInformationMessage("Please Enter Waiter Name", "");
                        txtWaiterName.Focus();
                    }
                }
                else
                {
                    CustomMessageBox.ShowHandMessage("Please Enter Waiter Code", "");
                    txtWaiterCode.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnSave_Click");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (frmSearchKitch objMenuS = new frmSearchKitch())
            {
                objMenuS.objForm = CommonVariables.SearchFormType.Waiter;
                objMenuS.Text = "Waiter Search";
                objMenuS.ShowDialog();
                if (objMenuS.searchId > 0)
                {
                    this.waierId = objMenuS.searchId;

                    dbContext = new DB.ISIPMEntities();
                    objWaier = dbContext.waiter_master.FirstOrDefault(x => x.waiter_id == this.waierId);
                    populatePageData(objWaier);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DBData.waiter_master objMenu = dbContext.waiter_master.FirstOrDefault(x => x.waiter_id == waierId);
                if (objMenu != null)
                {
                    dbContext.waiter_master.Remove(objMenu);
                    dbContext.SaveChanges();
                    dbContext = new DB.ISIPMEntities();
                    CustomMessageBox.ShowInformationMessage("Recorded Delete !!", "");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
            btnReferesh_Click(null, null);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
