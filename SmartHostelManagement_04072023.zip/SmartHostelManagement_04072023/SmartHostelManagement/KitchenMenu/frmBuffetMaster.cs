﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmBuffetMaster : Form
    {
        ISIPMEntities dbContext = new ISIPMEntities();
        int menugroupid { get; set; }

        IList<MENUGROUPMASTER> lstMenuMstr { get; set; }
        List<MENUGROUPMASTER> lstNewMenuMstr { get; set; }
        BuffetMaster objbuffetMaster { get; set; }

        public frmBuffetMaster()
        {
            InitializeComponent();
        }

        private void frmBuffetMaster_Load(object sender, EventArgs e)
        {
            dbContext.Configuration.LazyLoadingEnabled = true;
            BindFirstChecklist();
        }

        private void BindFirstChecklist()
        {
            try
            {
                lstMenuMstr = dbContext.MENUGROUPMASTERs.OrderBy(x=>x.MENUGROUPno).ToList();
                foreach (MENUGROUPMASTER objMenu in lstMenuMstr)
                    checkedListBox1.Items.Add(objMenu.MENUGROUPno + " -- " + objMenu.MENUGROUPname);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnForward_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstNewMenuMstr == null) lstNewMenuMstr = new List<MENUGROUPMASTER>();
                checkedListBox2.Items.Clear();

                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {
                    if (checkedListBox1.GetItemChecked(i))
                    {
                        lstNewMenuMstr.Add(lstMenuMstr[i]);
                        checkedListBox1.SetItemChecked(i, false);
                    }
                }

                foreach (MENUGROUPMASTER objMenu in lstNewMenuMstr)
                    checkedListBox2.Items.Add(objMenu.MENUGROUPno + " -- " + objMenu.MENUGROUPname);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnForward_Click");
            }
        }

        private void btnBackward_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < checkedListBox2.Items.Count; i++)
                {
                    if (checkedListBox2.GetItemChecked(i))
                    {
                        lstNewMenuMstr.RemoveAt(i);
                    }
                }
                checkedListBox2.Items.Clear();

                foreach (MENUGROUPMASTER objMenu in lstNewMenuMstr)
                    checkedListBox2.Items.Add(objMenu.MENUGROUPno + " -- " + objMenu.MENUGROUPname);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnBackward_Click");
            }
        }

        private void txtGroupCode_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFoodCode.Text.Trim()))
            {
                if (dbContext.BuffetMasters.Any(x => x.Buffetno.ToUpper() == txtFoodCode.Text.Trim()))
                {
                    CustomMessageBox.ShowInformationMessage("Code Already exists !!", "");
                    txtFoodCode.Text = string.Empty;
                    txtFoodCode.Focus();
                }
            }
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                checkedListBox1.SetItemChecked(i, false);
            this.menugroupid = 0;
            objbuffetMaster = null;
            txtFoodCode.Text = string.Empty;
            txtFoodName.Text = string.Empty;
            lstNewMenuMstr = new List<MENUGROUPMASTER>();
            checkedListBox2.Items.Clear();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidatePageData())
                {
                    if (objbuffetMaster != null)
                    {
                        objbuffetMaster.Buffetno = txtFoodCode.Text;
                        objbuffetMaster.Buffetname = txtFoodName.Text;
                        objbuffetMaster.id1 = Frm_Login.UserLogin.log_id;
                        objbuffetMaster.date_of_mod = DateTime.Now;
                    }
                    else
                    {
                        menugroupid = dbContext.BuffetMasters.Any() ? dbContext.BuffetMasters.Max(x => x.Buffet_id) + 1 : 1;

                        objbuffetMaster = new BuffetMaster
                        {
                            Buffet_id = menugroupid,
                            Buffetno = txtFoodCode.Text,
                            Buffetname = txtFoodName.Text,
                            id = Frm_Login.UserLogin.log_id,
                            date_of_add = DateTime.Now
                        };
                        dbContext.BuffetMasters.Add(objbuffetMaster);
                    }
                    if (lstNewMenuMstr == null) lstNewMenuMstr = new List<MENUGROUPMASTER>();
                    List<BuffetMasterDetail> lstMenuDet = objbuffetMaster.BuffetMasterDetails.ToList();
                    foreach (BuffetMasterDetail objMenuDet in lstMenuDet)
                    {
                        if (!lstNewMenuMstr.Any(x => x.MENUGROUP_id == objMenuDet.MENUGROUP_id))
                            dbContext.BuffetMasterDetails.Remove(objMenuDet);
                    }

                    int menudroupdetid = dbContext.BuffetMasterDetails.Any() ? dbContext.BuffetMasterDetails.Max(x => x.BuffetDet_id) : 0;

                    foreach (MENUGROUPMASTER objMenu in lstNewMenuMstr)
                    {
                        if (!this.objbuffetMaster.BuffetMasterDetails.Any(x => x.MENUGROUP_id == objMenu.MENUGROUP_id))
                        {
                            menudroupdetid++;
                            dbContext.BuffetMasterDetails.Add(new BuffetMasterDetail
                            {
                                BuffetDet_id = menudroupdetid,
                                Buffet_id = menugroupid,
                                MENUGROUP_id = objMenu.MENUGROUP_id
                            });
                        }
                    }

                    if (dbContext.SaveChanges() > 0)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Saved", "");
                    }
                    else
                        CustomMessageBox.ShowInformationMessage("Record not Saved", "");

                    btnReferesh_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private bool ValidatePageData()
        {
            if (string.IsNullOrEmpty(txtFoodCode.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please enter Menu group code", "");
                txtFoodCode.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtFoodName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please enter Menu group code", "");
                txtFoodName.Focus();
                return false;
            }
            //else if (lstNewMenuMstr == null || lstNewMenuMstr.Count == 0)
            //{
            //    CustomMessageBox.ShowInformationMessage("Please Add items in menu items.", "");
            //    return false;
            //}
            else
                return true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (frmSearchMenuGroup objMenuS = new frmSearchMenuGroup())
            {
                objMenuS.menumaster = false;
                objMenuS.ShowDialog();
                if (objMenuS.menugroupid > 0)
                {
                    btnReferesh_Click(sender, e);
                    this.menugroupid = objMenuS.menugroupid;
                    objbuffetMaster = dbContext.BuffetMasters.FirstOrDefault(x => x.Buffet_id == this.menugroupid);
                    populatePageData();
                }
            }
        }

        private void populatePageData()
        {
            try
            {
                if (this.objbuffetMaster != null)
                {
                    txtFoodCode.Text = objbuffetMaster.Buffetno;
                    txtFoodName.Text = objbuffetMaster.Buffetname;

                    IList<BuffetMasterDetail> lstMenuGrpDetail = objbuffetMaster.BuffetMasterDetails.ToList();
                    foreach (BuffetMasterDetail objMgd in lstMenuGrpDetail)
                    {
                        if (lstMenuMstr.Any(x => x.MENUGROUP_id == objMgd.MENUGROUP_id))
                        {
                            var localMen = lstMenuMstr.FirstOrDefault(x => x.MENUGROUP_id == objMgd.MENUGROUP_id);

                            lstNewMenuMstr.Add(localMen);
                            checkedListBox2.Items.Add(localMen.MENUGROUPno + " -- " + localMen.MENUGROUPname);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (menugroupid > 0 && CustomMessageBox.ShowDialogBoxMessage("Delete this Menu Group item ?")
                    == System.Windows.Forms.DialogResult.Yes)
                {
                    foreach (BuffetMasterDetail objMenDet in dbContext.BuffetMasterDetails.Where(x => x.Buffet_id == menugroupid))
                        dbContext.BuffetMasterDetails.Remove(objMenDet);

                    dbContext.BuffetMasters.Remove(dbContext.BuffetMasters.FirstOrDefault(x => x.Buffet_id == menugroupid));

                    if (dbContext.SaveChanges() > 0)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Deleted !!!", "");
                        dbContext = new ISIPMEntities();
                        btnReferesh_Click(null, null);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
