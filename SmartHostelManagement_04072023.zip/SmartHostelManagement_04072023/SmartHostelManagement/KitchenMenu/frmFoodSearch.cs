﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using DB = SmartHostelManagement.DBData;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmFoodSearch : Form
    {
        public bool itemWised { get; set; }
        public bool glAccount { get; set; }
        IList<DB.Menu> lstMenu { get; set; }
        public int foodid { get; set; }

        public frmFoodSearch()
        {
            InitializeComponent();
        }

        private void frmFoodSearch_Load(object sender, EventArgs e)
        {
            using (DB.ISIPMEntities dbContext = new DB.ISIPMEntities())
                this.lstMenu = dbContext.Menus.ToList();
            textBox1_TextChanged(sender, e);
            textBox1.Focus();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {   
            try
            {
                if (!string.IsNullOrEmpty(textBox1.Text))
                {
                    var dbMenu = !itemWised ? lstMenu.Where(x => x.Food_code.StartsWith(textBox1.Text))
                        .Select(x => new { x.Food_Id, FName = x.Food_code + " -- " + x.Food_Name,x.Price }).ToList() :
                        lstMenu.Where(x => x.Food_Name.ToUpper().Contains(textBox1.Text))
                        .Select(x => new { x.Food_Id, FName = x.Food_code + " -- " + x.Food_Name,x.Price }).ToList();
                    dataGridView1.DataSource = dbMenu;
                }
                else 
                {
                    var dbMenu = lstMenu.Select(x => new { x.Food_Id, FName = x.Food_code + " -- " + x.Food_Name, x.Price }).ToList();
                    dataGridView1.DataSource = dbMenu;
                }

                dataGridView1.Columns["Food_Id"].Visible = false;
                dataGridView1.Columns["Price"].Width = 100;
                dataGridView1.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dataGridView1.Columns["Price"].DefaultCellStyle.Format = "0.00";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (dataGridView1.SelectedRows.Count > 0)
                    foodid = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Food_Id"].Value);                
                this.Close();    
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && !string.IsNullOrEmpty(textBox1.Text))
            {
                dataGridView1_KeyDown(sender, e);
            }
            else if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void frmFoodSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }
    }
}
