﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SmartHostelManagement.DBData;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmMenuSearch : Form
    {
        public int foodid = 0;
        public int channelId = 0;

        public frmMenuSearch()
        {
            InitializeComponent();
        }

        private void frmMenuSearch_Load(object sender, EventArgs e)
        {
            loadPageData();
        }

        private void loadPageData()
        {
            try
            {
                string sqlQuery = @"SELECT ROW_NUMBER() OVER (ORDER BY Food_code) SLNo,Food_Id,Food_code,Food_Name,
                        isnull(Price,0) Price,isnull(Tax,0) Tax,isnull(Unit,0) Unit,isnull(vatpercent,0) vatpercent,
                        isnull(Deactivate,0) Deactivate,isnull(OrderBased,0) OrderBased,isnull(DisplayinKOT,0) DisplayinKOT from Menu
                        where channelid=" + channelId.ToString();

                if (!string.IsNullOrEmpty(txtFoodCode.Text.Trim()))
                    sqlQuery += " where Food_Name like '%" + txtFoodCode.Text.Trim() + "%' or Food_code like '%" + txtFoodCode.Text.Trim() + "%'";

                DataTable dt = new SMH.BusinessLogic.Layer.MasterCaller().GetDataTableData(sqlQuery, "Menus");

                dgSearch.DataSource = dt;

                foreach (DataGridViewRow grdRow in dgSearch.Rows)
                {
                    if (grdRow.Cells["DisplayinKOT"].Value.ToString() == "1")
                        grdRow.DefaultCellStyle.BackColor = System.Drawing.Color.Yellow;
                    if (grdRow.Cells["OrderBased"].Value.ToString() == "1")
                        grdRow.DefaultCellStyle.BackColor = System.Drawing.Color.Green;
                    if (grdRow.Cells["Deactivate"].Value.ToString() == "1")
                        grdRow.DefaultCellStyle.BackColor = System.Drawing.Color.Red;
                }

                dgSearch.Columns["Food_Id"].Visible = false;
                dgSearch.Columns["Deactivate"].Visible = false;
                dgSearch.Columns["OrderBased"].Visible = false;
                dgSearch.Columns["DisplayinKOT"].Visible = false;

                dgSearch.Columns["SLNo"].Width = 50;
                dgSearch.Columns["Food_code"].Width = 160;
                dgSearch.Columns["Food_Name"].Width = 240;
                dgSearch.Columns["Price"].Width = 90;
                dgSearch.Columns["Tax"].Width = 70;
                dgSearch.Columns["Unit"].Width = 70;
                dgSearch.Columns["vatpercent"].Width = 70;

                dgSearch.Columns["Price"].DefaultCellStyle.Format = "0.00";
                dgSearch.Columns["Tax"].DefaultCellStyle.Format = "0.00";
                dgSearch.Columns["Unit"].DefaultCellStyle.Format = "0.00";
                dgSearch.Columns["vatpercent"].DefaultCellStyle.Format = "0.00";

                dgSearch.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgSearch.Columns["Tax"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgSearch.Columns["Unit"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgSearch.Columns["vatpercent"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgSearch.Columns["SLNo"].HeaderText = "Sl.No.";
                dgSearch.Columns["Food_code"].HeaderText = "Food Code";
                dgSearch.Columns["Food_Name"].HeaderText = "Food Name";
                dgSearch.Columns["vatpercent"].HeaderText = "VAT";

                dgSearch.ClearSelection();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in loadPageData");
            }
        }

        private void txtFoodCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtFoodCode_KeyUp(object sender, KeyEventArgs e)
        {
            loadPageData();
        }

        private void dgSearch_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {   
                if (int.TryParse(dgSearch.Rows[e.RowIndex].Cells["Food_Id"].Value.ToString(),out foodid))
                {
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in dgSearch_CellDoubleClick");
            }
        }
    }
}
