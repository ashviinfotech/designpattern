﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmKotBill : Form
    {
        ISIPMEntities dbContext = new ISIPMEntities();
        MasterCaller mastcaller = new MasterCaller();
        SMH.Entities.Layer.login objLogin = Frm_Login.UserLogin;
        public int ChannelId = 0;
        int kotRowIndex = -1;
        bool itemBased = default(bool);
        KOT objKotM { get; set; }        
        List<KOT_details> lstKotDetails { get; set; }
        DataTable canceledKOt = null;
        DBData.Menu FoodM { get; set; }
        int hotellbillId = 0;

        public frmKotBill()
        {
            InitializeComponent();
        }

        private void frmKotBill_Load(object sender, EventArgs e)
        {
            lblUserName.Text = "User : " + Frm_Login.UserLogin.loginID;
            BindModeOfPay();
            ResetPageValue();
            btnFoodSearch.Focus();
            itemBased = (CustomMessageBox.ShowDialogBoxMessage("List KOT Items code based") == System.Windows.Forms.DialogResult.OK) ? true : itemBased = false;
        }

        private void BindModeOfPay()
        {
            Dictionary<int, string> ModeOfPayData = new Dictionary<int, string>();
            ModeOfPayData.Add(0, "Cash Bills");
            ModeOfPayData.Add(1, "Room Service");
            ModeOfPayData.Add(2, "GL Account");
            ModeOfPayData.Add(3, "Business Promotions");
            ModeOfPayData.Add(4, "Credit Crad");
            ModeOfPayData.Add(5, "Conference");

            cmbModeOfPay.DataSource = ModeOfPayData.ToList();
            cmbModeOfPay.ValueMember = "Key";
            cmbModeOfPay.DisplayMember = "Value";
 
        }

        private void ResetPageValue()
        {
            this.objKotM = new KOT();
            this.lstKotDetails = null;

            txtSlNo.Text = string.Empty;
            txtKotNo.Text = string.Empty;
            txtGLNo.Text = string.Empty;
            txtGLName.Text = string.Empty;

            txtTotalServAmt.Text = "0.00";
            txtTotalAmt.Text = "0.00";
            txtGstPer.Text = string.Empty;
            txtDisAmount.Text = "0.00";
            txtTotalGST.Text = "0.00";
            txtNetAmout.Text = "0.00";
            txtRemarks.Text = string.Empty;

            chkCancelled.Checked = false;
            chklstCanceledBill.Items.Clear();

            dtmKotDate.Value = DateTime.Today;
            dtmKotTime.Value = DateTime.Now;

            cmbModeOfPay.SelectedIndex = 0;

            BindKotbillDetails();
            BindCanceledKot();

            btnFoodSearch.Focus();

            btnGLSearch.Enabled = true;
            btnFoodSearch.Enabled = true;
            btnFoodAddFood.Enabled = true;
            btnFoodNew.Enabled = true;
            btnFoodAdd.Enabled = true;
            btnFoodRemove.Enabled = true;
            btnSave.Enabled = true;
        }

        private void SetControlsValue()
        {
            try
            {
                if (objKotM != null)
                {
                    //chkSeperate.Checked = objKotM.seperate_bill.HasValue ? objKotM.seperate_bill.Value : false;
                    //chkBusinessPromotion.Checked = objKotM.seperate_bill.HasValue ? objKotM.seperate_bill.Value : false;

                    txtSlNo.Text = Convert.ToString(objKotM.Kot_No.Value);
                    txtKotNo.Text = Convert.ToString(objKotM.KOTBOOKno);
                    dtmKotDate.Value = objKotM.Kdate.HasValue ? objKotM.Kdate.Value : DateTime.Today;
                    dtmKotTime.Value = objKotM.Ktime.HasValue ? objKotM.Ktime.Value : DateTime.Today;
                    cmbModeOfPay.SelectedValue = objKotM.mod_of_bill.HasValue ? objKotM.mod_of_bill.Value : 0;

                    comboBox2_SelectedIndexChanged(null, null);

                    if (objKotM.mod_of_bill.HasValue && objKotM.mod_of_bill.Value == 1)
                    {
                        var reserv = dbContext.RESERVATION_CHECKIN_WALKIN.FirstOrDefault(x => x.reservation_ID == objKotM.reservation_ID);
                        if (reserv != null)
                        {
                            txtGLNo.Text = reserv.reservation_NUMBER.HasValue ? reserv.reservation_NUMBER.Value.ToString() : string.Empty;
                            txtGLName.Text = reserv.reservation_PI_frstname;
                        }                            
                    }
                    else if (objKotM.mod_of_bill.HasValue && objKotM.mod_of_bill.Value == 2)
                    {
                        var ordCust = dbContext.ORDERs.FirstOrDefault(x => x.ORDNO == objKotM.OrdNo);
                        if (ordCust != null)
                        {
                            txtGLNo.Text = ordCust.ORDNO;
                            txtGLName.Text = ordCust.PARNAM;
                        }
                    }                    

                    txtTotalServAmt.Text = objKotM.taxed_Amount.HasValue ? objKotM.taxed_Amount.Value.ToString("0.00") : "0.00";
                    txtTotalAmt.Text = objKotM.Amount.HasValue ? objKotM.Amount.Value.ToString("0.00") : "0.00";
                    txtGstPer.Text = objKotM.Disc_Per.HasValue ? objKotM.Disc_Per.Value.ToString("0.00") : "0.00";
                    txtDisAmount.Text = objKotM.Disc_amt.HasValue ? objKotM.Disc_amt.Value.ToString("0.00") : "0.00";
                    txtTotalGST.Text = objKotM.delivery_status.HasValue && objKotM.delivery_status.Value && objKotM.ServTaxAmt.HasValue ? objKotM.ServTaxAmt.Value.ToString("0.00") : "0.00";
                    txtNetAmout.Text = objKotM.NetTotal.HasValue ? objKotM.NetTotal.Value.ToString("0.00") : "0.00";
                    txtRemarks.Text = objKotM.RemarksDesc;
                    
                    chkCancelled.Checked = objKotM.KOTCANCEL.HasValue ? objKotM.KOTCANCEL.Value : false;
                    
                    this.lstKotDetails = objKotM.KOT_details.ToList();
                    BindKotbillDetails();

                    if (this.objKotM.KOT_ID > 0)
                    {
                        btnGLSearch.Enabled = false;
                        btnFoodSearch.Enabled = false;
                        btnFoodAddFood.Enabled = false;
                        btnFoodNew.Enabled = false;
                        btnFoodAdd.Enabled = false;
                        btnFoodRemove.Enabled = false;
                        btnSave.Enabled = Frm_Login.UserLogin.level == "Admin" ? true : false;
                        btnDelete.Enabled = false;
                    }
                    else
                    {
                        btnGLSearch.Enabled = true;
                        btnFoodSearch.Enabled = true;
                        btnFoodAddFood.Enabled = true;
                        btnFoodNew.Enabled = true;
                        btnFoodAdd.Enabled = true;
                        btnFoodRemove.Enabled = true;
                        btnSave.Enabled = true;
                        btnDelete.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbModeOfPay.SelectedValue.GetType() == typeof(int))
            {
                if (Convert.ToInt32(cmbModeOfPay.SelectedValue) == 1 || Convert.ToInt32(cmbModeOfPay.SelectedValue) == 2)
                {
                    lblGLAccount.Text = Convert.ToInt32(cmbModeOfPay.SelectedValue) == 1 || Convert.ToInt32(cmbModeOfPay.SelectedValue) == 5 ? "Card No." : "G/L Account";
                    lblAccount.Text = Convert.ToInt32(cmbModeOfPay.SelectedValue) == 1 || Convert.ToInt32(cmbModeOfPay.SelectedValue) == 5 ? "Name" : "Account";

                    lblGLAccount.Visible = true;
                    lblAccount.Visible = true;
                    txtGLNo.Visible = true;
                    btnGLSearch.Visible = true;
                    txtGLName.Visible = true;
                    txtGLName.Text = string.Empty;
                }
                else
                {
                    lblGLAccount.Visible = false;
                    lblAccount.Visible = false;
                    txtGLNo.Visible = false;
                    btnGLSearch.Visible = false;
                    txtGLName.Visible = false;
                    txtGLName.Text = "STACO3";
                }   
            }
        }
        
        private void btnGLSearch_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cmbModeOfPay.SelectedValue) == 1)
            {
                using (Search.frmHotelSearch frmAcc = new Search.frmHotelSearch())
                {
                    frmAcc.roomDorm = (int)CommonVariables.RoomDormatory.Room;
                    frmAcc.ShowDialog();
                    var ordrAcc = dbContext.HotelBILLs.FirstOrDefault(x => x.hotelBill_ID == frmAcc.hotelbillid);
                    if (ordrAcc != null)
                    {
                        objKotM.reservation_ID = ordrAcc.reservation_ID;
                        objKotM.GUEST_NUM = ordrAcc.GUEST_NUM;
                        txtGLNo.Text = ordrAcc.reservation_Number;
                        txtGLName.Text = ordrAcc.Name_guest;
                        hotellbillId = ordrAcc.hotelBill_ID;
                    }

                    btnFoodSearch.Focus();
                }
            }
            else if (Convert.ToInt32(cmbModeOfPay.SelectedValue) == 2)
            {
                using (frmGLAccount frmAcc = new frmGLAccount())
                {
                    frmAcc.ShowDialog();
                    var ordrAcc = dbContext.ORDERs.FirstOrDefault(x => x.ORDID == frmAcc.ORDID);
                    if (ordrAcc != null)
                    {
                        objKotM.OrdNo = ordrAcc.ORDNO;
                        txtGLNo.Text = ordrAcc.ORDNO;
                        txtGLName.Text = ordrAcc.PARNAM;
                    }

                    btnFoodSearch.Focus();
                }
            }
            else if (Convert.ToInt32(cmbModeOfPay.SelectedValue) == 5)
            {
                using (Search.frmHotelSearch frmAcc = new Search.frmHotelSearch())
                {
                    frmAcc.roomDorm = (int)CommonVariables.RoomDormatory.Seminar;
                    frmAcc.ShowDialog();
                    var ordrAcc = dbContext.HotelBILLs.FirstOrDefault(x => x.hotelBill_ID == frmAcc.hotelbillid);
                    if (ordrAcc != null)
                    {
                        objKotM.reservation_ID = ordrAcc.reservation_ID;
                        objKotM.GUEST_NUM = ordrAcc.GUEST_NUM;
                        txtGLNo.Text = ordrAcc.reservation_Number;
                        txtGLName.Text = ordrAcc.Name_guest;
                        hotellbillId = ordrAcc.hotelBill_ID;
                    }

                    btnFoodSearch.Focus();
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void BindCanceledKot()
        {
            try
            {
                if (chklstCanceledBill.Items.Count > 0) chklstCanceledBill.Items.Clear();
                canceledKOt = mastcaller.GetDataTableData(@"select a.Kot_No,a.KOT_ID from KOt a join KOTCancelAttached B 
                        on a.KOT_ID=b.CancelKOT_ID where a.KOTCANCEL=1 and b.KOT_ID is null", "CancelKOT");
                if (canceledKOt != null)
                {
                    foreach (DataRow drRow in canceledKOt.Rows)
                    {
                        chklstCanceledBill.Items.Add(Convert.ToString(drRow["KOT_No"]));
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }
        
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvKotDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex > -1)
                {
                    kotRowIndex = e.RowIndex;
                    int foodid = lstKotDetails[kotRowIndex].Food_Id.HasValue ? lstKotDetails[kotRowIndex].Food_Id.Value : 0;
                    txtFoodName.Text = dbContext.Menus.FirstOrDefault(x => x.Food_Id == foodid).Food_Name;
                    txtFoodPrice.Text = lstKotDetails[kotRowIndex].Price.Value.ToString("0.00");
                    txtFoodQty.Text = lstKotDetails[kotRowIndex].Quantity.Value.ToString();
                    txtFoodServCharg.Text = lstKotDetails[kotRowIndex].tax_rate.Value.ToString();
                    txtServAmt.Text = lstKotDetails[kotRowIndex].tax_amt.Value.ToString("0.00");
                    txtFoodDiscPer.Text = lstKotDetails[kotRowIndex].DiscPerc.Value.ToString("0.00");
                    txtFoodDiscAmt.Text = lstKotDetails[kotRowIndex].DiscPerc.Value.ToString("0.00");

                    if (lstKotDetails[kotRowIndex].comp_itm.HasValue && lstKotDetails[kotRowIndex].comp_itm.Value == true)
                    {
                        txtFoodGSTPer.Text = lstKotDetails[kotRowIndex].vatpercent.Value.ToString();
                        txtFoodGSTAmt.Text = lstKotDetails[kotRowIndex].vatamount.Value.ToString("0.00");
                    }
                    else
                    {
                        txtFoodGSTPer.Text = "5";
                        txtFoodGSTAmt.Text = "0";
                    }
                    
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void txtDisPer_TextChanged(object sender, EventArgs e)
        {
            if (this.objKotM != null)
            {
                decimal didcPer = !string.IsNullOrEmpty(txtGstPer.Text) ? Convert.ToDecimal(txtGstPer.Text) : 0;
                this.objKotM.Disc_Per = Convert.ToDouble(didcPer);
                txtDisAmount.Text = objKotM.Amount.HasValue ? (this.objKotM.Amount.Value * (didcPer / 100)).ToString("0.00") : "0.00";
                BillCalculation();
            }
        }

        #region Bill details
        private void ReserKotDetailPage()
        {
            this.kotRowIndex = -1;
            FoodM = null;
            txtFoodName.Text = string.Empty;
            txtFoodPrice.Text = string.Empty;
            txtFoodQty.Text = string.Empty;
            txtServAmt.Text = string.Empty;
            txtFoodServCharg.Text = string.Empty;
            txtFoodAmt.Text = string.Empty;
            txtFoodGSTPer.Text = string.Empty;
            txtFoodGSTAmt.Text = string.Empty;
            txtFinalPrice.Text = string.Empty;
            txtFoodDiscPer.Text = string.Empty;
            txtFoodDiscAmt.Text = string.Empty;
        }

        private void BindKotbillDetails()
        {
            try
            {
                if (lstKotDetails == null) lstKotDetails = new List<KOT_details>();
                int index = 1;
                var dbData = (from c in lstKotDetails
                              join d in dbContext.Menus on c.Food_Id equals d.Food_Id
                              select new
                              {
                                  SNo = index++,
                                  c.KOT_ID_det,
                                  FoodCode = d.Food_code,
                                  FoodName = d.Food_Name,
                                  Price = c.Price,
                                  Quantity = c.Quantity,
                                  ServChrg = c.tax_rate,
                                  ServAmt = c.tax_amt,
                                  Amount = c.Amount,
                                  GST = c.comp_itm.HasValue && c.comp_itm.Value ? c.vatpercent : 0,
                                  GSTAmt = c.comp_itm.HasValue && c.comp_itm.Value ? c.vatamount : 0,
                                  Desc = c.DiscPerc.HasValue ? c.DiscPerc.Value : 0,
                                  ActualPrice = c.ActPrice
                              }).ToList();

                dgvKotDetails.DataSource = dbData;
                foreach (DataGridViewColumn grdcol in dgvKotDetails.Columns)
                {
                    if (grdcol.Name != "SNo" && grdcol.Name != "FoodName")
                        grdcol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    if (grdcol.Name != "SNo" && grdcol.Name != "SNo" && grdcol.Name != "Quantity" && grdcol.Name != "GST")
                        grdcol.DefaultCellStyle.Format = "0.00";
                    grdcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                }

                dgvKotDetails.Columns["SNo"].Frozen = true;
                dgvKotDetails.Columns["KOT_ID_det"].Visible = false;
                dgvKotDetails.ClearSelection();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void BillCalculation()
        {
            try
            {
                if (lstKotDetails != null && lstKotDetails.Count > 0)
                {
                    double discPer = 0;
                    this.objKotM.delivery_status = true;
                    this.objKotM.Amount = Convert.ToDecimal(lstKotDetails.Sum(x => x.Amount).Value);
                    this.objKotM.taxed_Amount = Convert.ToDecimal(lstKotDetails.Sum(x => x.tax_amt).Value);
                    this.objKotM.Disc_amt = !string.IsNullOrEmpty(txtDisAmount.Text) ? Convert.ToDouble(txtDisAmount.Text) : 0;
                    this.objKotM.ServTaxPerc = CommonVariables.FoodGST;
                    this.objKotM.ServTaxAmt = Convert.ToDouble(lstKotDetails.Sum(x => x.vatamount).Value);
                    discPer = this.objKotM.Disc_amt.HasValue && this.objKotM.Disc_amt.Value > 0 ? this.objKotM.Disc_amt.Value * (CommonVariables.FoodGST / 100) : 0;
                    this.objKotM.ServTaxAmt = this.objKotM.ServTaxAmt - discPer;
                    this.objKotM.NetTotal = (Convert.ToDouble(this.objKotM.Amount.Value) - this.objKotM.Disc_amt.Value) + this.objKotM.ServTaxAmt;

                    txtTotalAmt.Text = this.objKotM.Amount.Value.ToString("0.00");
                    txtTotalServAmt.Text = this.objKotM.taxed_Amount.Value.ToString("0.00");
                    txtDisAmount.Text = this.objKotM.Disc_amt.Value.ToString("0.00");
                    txtTotalGST.Text = this.objKotM.ServTaxAmt.Value.ToString("0.00");
                    txtNetAmout.Text = this.objKotM.NetTotal.Value.ToString("0.00");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnFoodSearch_Click(object sender, EventArgs e)
        {
            dtmKotTime.Value = DateTime.Now;
            using (frmFoodSearch frmFood = new frmFoodSearch())
            {
                frmFood.itemWised = this.itemBased;
                //frmFood.glAccount = cmbModeOfPay.se
                frmFood.ShowDialog();
                FoodM = dbContext.Menus.FirstOrDefault(x => x.Food_Id == frmFood.foodid);
                if (FoodM != null)
                {
                    txtFoodName.Text = FoodM.Food_Name;
                    txtFoodPrice.Text = FoodM.Price.HasValue ? FoodM.Price.Value.ToString("0.00") : "0.00";
                    txtFoodQty.Text = FoodM.Unit.HasValue ? FoodM.Unit.Value.ToString() : "1";
                    txtFoodServCharg.Text = "0.00";
                    txtServAmt.Text = "0.00";
                    txtFoodGSTPer.Text = CommonVariables.FoodGST.ToString();
                    txtFoodDiscPer.Text = "0.00";
                    txtFoodDiscAmt.Text = "0.00";
                    txtFinalPrice.Text = FoodM.Price.HasValue ? FoodM.Price.Value.ToString("0.00") : "0.00";

                    if (cmbModeOfPay.SelectedIndex > -1 && Convert.ToInt32(cmbModeOfPay.SelectedValue) == 2)
                    {
                        if (!string.IsNullOrEmpty(txtGLNo.Text))
                        {
                            ORDER objCust = dbContext.ORDERs.FirstOrDefault(x => x.ORDNO.Contains(txtGLNo.Text.Trim()));
                            if (objCust != null && objCust.AccStaff.HasValue && objCust.AccStaff.Value == true)
                            {
                                txtFoodPrice.Text = "0.00";
                            }
                            else if (objCust != null && objCust.CHRGST.HasValue && objCust.CHRGST.Value == true)
                            {

                            }
                        }
                    }

                    txtFoodGSTAmt.Text = ((Convert.ToDouble(txtFoodPrice.Text) * Convert.ToDouble(txtFoodQty.Text)) * (CommonVariables.FoodGST / 100)).ToString("0.00");
                    txtFoodAmt.Text = ((Convert.ToDouble(txtFoodPrice.Text) * Convert.ToDouble(txtFoodQty.Text))).ToString("0.00");
                    txtFoodQty.Focus();
                }
                else
                {
                    ReserKotDetailPage();
                }
            }
        }

        private void btnFoodAddFood_Click(object sender, EventArgs e)
        {
            frmMenuItem frmMenu = new frmMenuItem();
            frmMenu.channelid = ChannelId;
            frmMenu.channelname = ChannelId == 5 ? "Kitchen" : "Annuixure";
            frmMenu.ShowDialog();
        }

        private void btnFoodNew_Click(object sender, EventArgs e)
        {
            ReserKotDetailPage();
        }

        private void btnFoodAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtFoodName.Text)) return;
                if (string.IsNullOrEmpty(txtFoodAmt.Text)) return;
                if (string.IsNullOrEmpty(txtFoodQty.Text)) return;

                if (kotRowIndex > -1 && lstKotDetails.Count > 0)
                {
                    lstKotDetails[kotRowIndex].Quantity = Convert.ToInt32(txtFoodQty.Text);
                    lstKotDetails[kotRowIndex].Amount = Convert.ToDouble(txtFoodAmt.Text);
                    lstKotDetails[kotRowIndex].tax_rate = Convert.ToDouble(txtFoodServCharg.Text);
                    lstKotDetails[kotRowIndex].tax_amt = Convert.ToDouble(txtServAmt.Text);
                    lstKotDetails[kotRowIndex].AmountDisc = Convert.ToDouble(txtFoodAmt.Text);
                    lstKotDetails[kotRowIndex].tax_amtDisc = Convert.ToDouble(txtServAmt.Text);
                    lstKotDetails[kotRowIndex].vatamount = Convert.ToDouble(txtFoodGSTAmt.Text);
                    lstKotDetails[kotRowIndex].DiscAmt = Convert.ToDouble(txtFoodDiscAmt.Text);
                    lstKotDetails[kotRowIndex].DiscPerc = Convert.ToDouble(txtFoodDiscPer.Text);
                    lstKotDetails[kotRowIndex].ActPrice = FoodM.Price.HasValue ? Convert.ToDouble(FoodM.Price.Value) : 0;
                }
                else
                {
                    lstKotDetails.Add(new KOT_details
                    {
                        Food_Id = FoodM.Food_Id,
                        Price = Convert.ToDouble(txtFoodPrice.Text),
                        Quantity = Convert.ToInt32(txtFoodQty.Text),
                        Amount = Convert.ToDouble(txtFoodAmt.Text),
                        comp_itm = true,
                        tax_rate = Convert.ToDouble(txtFoodServCharg.Text),
                        tax_amt = Convert.ToDouble(txtServAmt.Text),
                        discount = 0,
                        priceDisc = Convert.ToDouble(txtFoodPrice.Text),
                        AmountDisc = Convert.ToDouble(txtFoodAmt.Text),
                        tax_amtDisc = Convert.ToDouble(txtServAmt.Text),
                        vatamount = Convert.ToDouble(txtFoodGSTAmt.Text),
                        vatpercent = Convert.ToDouble(txtFoodGSTPer.Text),
                        ChannelOrderdet_id = 0,
                        listmenuid = string.Empty,
                        Buffet_id = FoodM.OrderBased,
                        OrderBased = FoodM.OrderBased,
                        DiscAmt = Convert.ToDouble(txtFoodDiscAmt.Text),
                        DiscPerc = Convert.ToDouble(txtFoodDiscPer.Text),
                        ActPrice = FoodM.Price.HasValue ? Convert.ToDouble(FoodM.Price.Value) : 0
                    });

                }
                ReserKotDetailPage();
                BindKotbillDetails();
                BillCalculation();
                btnFoodSearch.Focus();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnFoodRemove_Click(object sender, EventArgs e)
        {
            if (kotRowIndex > -1 && this.lstKotDetails.Count > 0)
            {
                this.lstKotDetails.RemoveAt(kotRowIndex);
                ReserKotDetailPage();
                BindKotbillDetails();
                BillCalculation();
            }
        }

        private void txtFoodQty_TextChanged(object sender, EventArgs e)
        {
            double qty = !string.IsNullOrEmpty(txtFoodQty.Text) ?  Convert.ToDouble(txtFoodQty.Text) : 0;
            double price = !string.IsNullOrEmpty(txtFoodPrice.Text) ? Convert.ToDouble(txtFoodPrice.Text) : 0;
            double servPer = !string.IsNullOrEmpty(txtFoodServCharg.Text) ? Convert.ToDouble(txtFoodServCharg.Text) : 0;
            double gstPer = !string.IsNullOrEmpty(txtFoodGSTPer.Text) ? Convert.ToDouble(txtFoodGSTPer.Text) : 0;
            double disPer = !string.IsNullOrEmpty(txtFoodDiscPer.Text) ? Convert.ToDouble(txtFoodDiscPer.Text) : 0;

            txtServAmt.Text = ((price * qty) * (servPer / 100)).ToString("0.00");
            txtFoodAmt.Text = (price * qty).ToString("0.00");
            txtFoodGSTAmt.Text = ((price * qty) * (gstPer / 100)).ToString("0.00");
            txtFoodDiscAmt.Text = ((price * qty) * disPer / 100).ToString("0.00");
        }
        #endregion Bill details

        private void btnCancelBill_Click(object sender, EventArgs e)
        {
            if (this.objKotM != null && chkCancelled.Checked)
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Cancel this KOT") == System.Windows.Forms.DialogResult.Yes)
                {
                    this.objKotM.KOTCANCEL = true;
                    this.objKotM.CancelledBY = Frm_Login.UserLogin.loginID;
                    this.objKotM.date_of_CANCEL = DateTime.Now;
                    this.objKotM.idCANCEL = Frm_Login.UserLogin.log_id;
                    btnSave_Click(null, null);
                }
            }
        }

        private void btnActivateBill_Click(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (objKotM != null && objKotM.KOT_ID > 0)
            {
                PrintKot();
            }
            else
                CustomMessageBox.ShowInformationMessage("Not Able to print data", "");
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ResetPageValue();
        }

        bool ValidatePage()
        {
            if (lstKotDetails == null || lstKotDetails.Count == 0)
            {
                CustomMessageBox.ShowInformationMessage("Please add items !!", "");
                btnFoodSearch.Focus();
                return false;
            }
            else if (txtGLName.Visible && string.IsNullOrEmpty(txtGLName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please select GL Account Party items !!", "");
                btnGLSearch.Focus();
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidatePage() && this.objKotM != null)
                {   
                    this.objKotM.Kdate= dtmKotDate.Value;
                    this.objKotM.Ktime = dtmKotTime.MinDate.Add(dtmKotTime.Value.TimeOfDay);
                    this.objKotM.Kdatetime = dtmKotTime.Value;
                                        
                    this.objKotM.complementary_item = false;
                    this.objKotM.activate_delete = this.objKotM.activate_delete.HasValue ? this.objKotM.activate_delete.Value : false;
                    this.objKotM.mod_of_bill= Convert.ToInt32(cmbModeOfPay.SelectedValue);
                    this.objKotM.mod_of_bill_desc= cmbModeOfPay.Text;                    
                    this.objKotM.OrdNo = !string.IsNullOrEmpty(this.objKotM.OrdNo) ? this.objKotM.OrdNo : 
                        (this.objKotM.mod_of_bill.Value == 0) ? "STACO3" : default(string);
                    this.objKotM.RemarksDesc=txtRemarks.Text;
                    this.objKotM.vatamount = this.objKotM.vatamount.HasValue ? this.objKotM.vatamount.Value : 0;
                    this.objKotM.channelid = ChannelId;
                    this.objKotM.MachineName=Environment.MachineName;                    
                    
                    this.objKotM.KOTCANCEL = this.objKotM.KOTCANCEL.HasValue ? this.objKotM.KOTCANCEL.Value : false;                    
                    this.objKotM.ServTaxPerc= this.objKotM.ServTaxPerc.HasValue ? this.objKotM.ServTaxPerc.Value:0;
                    this.objKotM.ServTaxAmt=this.objKotM.ServTaxAmt.HasValue ? this.objKotM.ServTaxAmt.Value:0;
                    this.objKotM.RoundOff = this.objKotM.RoundOff.HasValue ? this.objKotM.RoundOff.Value : 0;

                    this.objKotM.delivery_status = false;
                    this.objKotM.seperate_bill = false;
                    this.objKotM.stexempted = false;
                    this.objKotM.ReceiptRightId = 0;
                    this.objKotM.ReceiptRightDesc = string.Empty;
                    this.objKotM.BundledServ = false;
                    this.objKotM.GuestGSTstateID = 0;
                    this.objKotM.GuestGSTstateCODE = string.Empty;
                    this.objKotM.PrefixInv = objKotM.mod_of_bill.HasValue && objKotM.mod_of_bill.Value == 0 ? "RK" : "RA";
                                        

                    if (objKotM.KOT_ID > 0)
                    {
                        #region Edit
                        this.objKotM.id1=Frm_Login.UserLogin.log_id;
                        this.objKotM.date_of_mod=DateTime.Now;
                        this.objKotM.modifiedby = Frm_Login.UserLogin.loginID;
                        #endregion Edit                        
                    }
                    else
                    {
                        #region Add
                        objKotM.KOT_ID = dbContext.KOTs.Max(x => x.KOT_ID) + 1;

                        dbContext.Configuration.LazyLoadingEnabled = false;
                        if ((dtmKotDate.Value.Year * 100 + dtmKotDate.Value.Month) > (DateTime.Today.Year * 100 + 3))
                        {
                            objKotM.Kot_No = dbContext.KOTs.Where(x => (x.channelid == ChannelId) && (x.Kdate.Value.Year * 100 + x.Kdate.Value.Month) > (DateTime.Today.Year * 100 + 3)
                                && (x.Kdate.Value.Year * 100 + x.Kdate.Value.Month) < ((DateTime.Today.Year + 1) * 100 + 04)).Max(t => t.Kot_No);
                        }
                        else
                        {
                            objKotM.Kot_No = dbContext.KOTs.Where(x => (x.channelid == ChannelId) && (x.Kdate.Value.Year * 100 + x.Kdate.Value.Month) > ((DateTime.Today.Year - 1) * 100 + 3)
                                && (x.Kdate.Value.Year * 100 + x.Kdate.Value.Month) < (DateTime.Today.Year * 100 + 04)).Max(t => t.Kot_No);
                        }
                        dbContext.Configuration.LazyLoadingEnabled = true;
                        objKotM.Kot_No = objKotM.Kot_No.HasValue ? objKotM.Kot_No.Value + 1 : 1;

                        this.objKotM.KOTBOOKno = objKotM.Kot_No.ToString();
                        this.objKotM.id = Frm_Login.UserLogin.log_id;
                        this.objKotM.date_of_add = DateTime.Now;
                        this.objKotM.createdby = Frm_Login.UserLogin.loginID;
                        #endregion Add

                        dbContext.KOTs.Add(objKotM);                        
                    }

                    if (dbContext.SaveChanges() > 0)
                    {
                        int count = 0;
                        foreach (KOT_details objKotDet in lstKotDetails)
                        {
                            objKotDet.sno = count++;
                            if (!objKotDet.KOT_ID.HasValue)
                            {
                                objKotDet.KOT_ID = objKotM.KOT_ID;
                                dbContext.KOT_details.Add(objKotDet);
                            }
                        }

                        if(objKotM.KOTCANCEL.HasValue && objKotM.KOTCANCEL.Value == true)
                        {
                            if(!dbContext.KOTCancelAttacheds.Any(x=>x.CancelKOT_ID == objKotM.KOT_ID))
                            {
                                dbContext.KOTCancelAttacheds.Add(new KOTCancelAttached
                                {
                                    CancelKOT_ID = objKotM.KOT_ID
                                });
                            }
                        }

                        for(int i=0;i<chklstCanceledBill.Items.Count;i++)
                        {
                            if(chklstCanceledBill.GetItemChecked(i) && canceledKOt !=null)
                            {
                                int kotid = Convert.ToInt32(canceledKOt.Rows[i]["KOT_ID"]);
                                KOTCancelAttached objCancel = dbContext.KOTCancelAttacheds.FirstOrDefault(x=>x.CancelKOT_ID == kotid);
                                if(objCancel != null)
                                {
                                    objCancel.KOT_ID = this.objKotM.KOT_ID;
                                }
                            }       
                        }

                        if (this.objKotM.reservation_ID.HasValue && this.objKotM.reservation_ID.Value > 0)
                        {
                            long reserHoId = dbContext.Hotel_DININGRoom_details.Max(x => x.Hotel_DININGRoom_id) + 1; 
                            dbContext.Hotel_DININGRoom_details.Add(new Hotel_DININGRoom_details
                            {
                                Hotel_DININGRoom_id = reserHoId,
                                reservation_ID = objKotM.reservation_ID,
                                hotelBill_ID = hotellbillId,
                                KOT_Id = objKotM.KOT_ID,
                                AMOUNT = objKotM.NetTotal,
                                KOTTime = objKotM.Ktime,
                                KOTDate = objKotM.Kdate,
                                KOTno = objKotM.Kot_No.HasValue ? objKotM.Kot_No.Value.ToString() : string.Empty,
                                ServTaxPerc = objKotM.ServTaxPerc,
                                ServTaxAmt = objKotM.ServTaxAmt
                            });
                        }


                        dbContext.SaveChanges();
                        btnPrint_Click(sender, e);
                    }
                    else
                    {
                        CustomMessageBox.ShowErrorMessage("Unable to save data", "");
                    }
                    ResetPageValue();
                }
                
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Save Data");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmKotSearch frmSearch = new frmKotSearch())
                {
                    frmSearch.ShowDialog();
                    ResetPageValue();
                    if (frmSearch.kotID > 0)
                    {
                        this.objKotM = dbContext.KOTs.FirstOrDefault(x => x.KOT_ID == frmSearch.kotID);
                        SetControlsValue();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                CustomMessageBox.ShowInformationMessage("This action not available", "");
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        void PrintKot()
        {
            try
            {
                if (this.objKotM != null && this.objKotM.KOT_ID > 0)
                {
                    string strQuery = @"DECLARE @Kot_Id int="+objKotM.KOT_ID+@";

                    DELETE FROM tempc; DELETE FROM tempc1;

                    INSERT INTO tempc (sno,tempC_1,tempC_2,tempC_3,tempC_4,tempC_5,tempC_6,tempC_7,tempC_8,tempC_10,tempF_1,tempF_3,tempF_4,tempF_5,tempF_6,tempF_7,
                    tempF_8,tempF_9, tempF_12)
                    select 1, Kot_No, KOTBOOKno, Waiter, REPLACE(CONVERT(VARCHAR(20),KDATE,106),' ','-'),STUFF(RIGHT(CONVERT(VarChar(19), Ktime, 0), 7), 6, 0, ' '),
                    '', R.reservation_NUMBER, M.G_FNAME, C.ChannelName, Amount, Disc_amt,'0.00','0.00','0.00',NetTotal,ServTaxAmt,'0.00',ServTaxAmt
                    from KOT K LEFT JOIN ChannelMaster C ON K.Channelid = C.Channelid LEFT JOIN RESERVATION_CHECKIN_WALKIN R JOIN Mast_guest M ON R.GUEST_NUM=M.GUEST_NUM
                    ON K.reservation_ID=R.reservation_ID where KOT_ID=@Kot_Id;

                    INSERT INTO tempc1 (sno1,sno,tempC_1,tempC_2,tempC_3,tempC_5,tempC_6)
                    SELECT k.sno,1,m.Food_Name,CAST(k.Price AS DECIMAL(10,2)) Price,k.Quantity,'0.00',CAST(Amount AS DECIMAL(10,2)) Amount
                    FROM KOT_details k LEFT JOIN Menu M on k.Food_Id=m.Food_Id WHERE KOT_ID=@Kot_Id";

                    if (dbContext.Database.ExecuteSqlCommand(strQuery) > 0)
                    {
                        Report.frmbillreportview freport = new Report.frmbillreportview();
                        freport.reportName = "KOTBILLt.rpt";
                        freport.amttowaords = "Rupees " + CommonBaseFN.NumberToWords(Convert.ToInt32(objKotM.NetTotal.Value)) + " Only ";
                        freport.Createdby = objKotM.createdby + " / " +
                            (objKotM.date_of_add.HasValue ? objKotM.date_of_add.Value.ToString("dd-MMM-yyyy / HH:mm") : string.Empty) +
                            "   P/ON : " + DateTime.Now.ToString("dd-MMM-yyyy / HH:mm");
                        freport.Show();
                    }
                }
                else
                    CustomMessageBox.ShowHandMessage("Please select Order form", "");
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        //private void printlastformate()
        //{
        //    LPrinter MyPrinter = new LPrinter();
        //    MyPrinter.ChoosePrinter();
        //    if (!MyPrinter.Open("Test Page")) return;

        //    string glAccount = txtGLName.Text.Trim();
        //    MyPrinter.Print("\x0F");
        //    MyPrinter.Print("\n\t\t\t\t\tDINING HALL\r\n");
        //    if (objKotM.KOTCANCEL.HasValue && objKotM.KOTCANCEL.Value)
        //        MyPrinter.Print("\t\t\t\t\tCANCELED\r\n");
        //    MyPrinter.Print("\t\t------------------------------------------------------------------\r\n");
        //    MyPrinter.Print("\t\tKOT NO: " + objKotM.Kot_No + " \t PAYMENT TYPE: " + objKotM.mod_of_bill_desc + "\r\n");
        //    MyPrinter.Print("\t\tDATE: " + objKotM.Kdate.Value.ToString("dd/MMM/yyyy") + " " + objKotM.Ktime.Value.ToString("hh:mm tt") + "\r\n");
        //    if (!string.IsNullOrEmpty(glAccount) && txtGLName.Visible) 
        //    {
        //        if (glAccount.Length > 100) glAccount = glAccount.Substring(0, 99);
        //        MyPrinter.Print("\t\tName: " + glAccount + "\r\n"); 
        //    }
        //    MyPrinter.Print("\t\t------------------------------------------------------------------\r\n");
        //    MyPrinter.Print(string.Format("\t\t{0,-5}{1,-20}{2,9}{3,6}{4,8}{5,8}{6,10}\r\n", "CODE", "ITEMS", "PRICE", "QTY", "S.TAX", "GST", "AMOUNT"));
        //    MyPrinter.Print("\t\t------------------------------------------------------------------\r\n");
        //    foreach (KOT_details objdetails in lstKotDetails)
        //    {
        //        string strval1 = "", strval2 = "";
        //        try
        //        {
        //            if (objdetails.Menu.Food_Name.Length > 20)
        //            {
        //                strval1 = objdetails.Menu.Food_Name.Remove(20);
        //                strval2 = objdetails.Menu.Food_Name.Remove(0, 20);
        //            }
        //            else
        //                strval1 = objdetails.Menu.Food_Name;
        //        }
        //        catch { }
        //        MyPrinter.Print(string.Format("\t\t{0,-5}{1,-20}{2,9}{3,6}{4,8}{5,8}{6,10}\r\n", objdetails.Menu.Food_code, strval1, objdetails.Price.Value.ToString("0.00"), objdetails.Quantity.Value.ToString(), objdetails.tax_amt.Value.ToString("0.00"), objdetails.vatamount.Value.ToString("0.00"), (objdetails.Amount.Value + objdetails.tax_amt.Value + objdetails.vatamount.Value).ToString("0.00")));
        //        try
        //        {
        //            if (strval2.Length > 0)
        //                MyPrinter.Print(string.Format("\t\t{0,-5}{1,-20}\r\n", "", strval2));
        //        }
        //        catch { }
        //    }
        //    string cancelk = "\t\t", canKn = "\t\t";
        //    if (objKotM.KOTCancelAttacheds.Any())
        //    {
        //        int? CkotId = objKotM.KOTCancelAttacheds.FirstOrDefault().CancelKOT_ID;
        //        int? CkotNo = dbContext.KOTs.FirstOrDefault(x => x.KOT_ID == (CkotId.HasValue ? CkotId.Value : 0)).Kot_No;
        //        cancelk = (CkotNo.HasValue ? CkotNo.Value.ToString() : "") + "\t\t";
        //        canKn = "Against KOT No.\t";
        //    }


        //    MyPrinter.Print("\t\t------------------------------------------------------------------\r\n");
        //    MyPrinter.Print(string.Format("\t\t\t\t\t\t\t     Total: {0,12}\r\n", (objKotM.Amount.Value).ToString("0.00")));
        //    //MyPrinter.Print(string.Format("\t\t\t\t\t\t\t       VAT: {0,12}\r\n", (objKotM.vatamount.Value).ToString("0.00")));
        //    MyPrinter.Print(string.Format("\t\t\t\t\t\t\t     Disc : {0,12}\r\n", (objKotM.Disc_amt.Value).ToString("0.00")));
        //    MyPrinter.Print(string.Format("\t\t" + canKn + "\t\t\tCGST(2.5%): {0,12}\r\n", (objKotM.ServTaxAmt.HasValue ? (objKotM.ServTaxAmt.Value / 2).ToString("0.00") : "0.00")));
        //    MyPrinter.Print(string.Format("\t\t" + cancelk + "\t\t\tSGST(2.5%): {0,12}\r\n", (objKotM.ServTaxAmt.HasValue ? (objKotM.ServTaxAmt.Value / 2).ToString("0.00") : "0.00")));
        //    MyPrinter.Print(string.Format("\t\t\t\t\t\t\tNet Total : {0,12}\r\n", (objKotM.NetTotal.Value).ToString("0.00")));
        //    MyPrinter.Print("\t\tRemarks:  " + objKotM.RemarksDesc + "\r\n");
        //    MyPrinter.Print("\t\tCreated By:  " + objKotM.createdby + "\r\n");
        //    MyPrinter.Print("\t\tGuest Singnature  \t\t           Bill Clerk\r\n");
        //    MyPrinter.Print("\t\t\t\t      HAVE A NICE DAY\r\n\n\n\n\n\n\n\n\n");
        //    MyPrinter.Print("\t\t\t\t     VISHWA YUVAK KENDRA\r\n");
        //    MyPrinter.Print("\t\t\t     (A Unit of Indian Youth Centres Trust)\r\n");
        //    MyPrinter.Print("\t\t\t  Circular Road, Chanakya Puri, New Delhi-110021\r\n");
        //    MyPrinter.Print("\t\t\t\t\tPh: 23013631-35, Email: vyk@vykonline.org\r\n");
        //    MyPrinter.Print("\t\t\t\t\tPAN NO: AAAT10141C, GSTIN: 07AAATI0141C2ZE\r\n");
        //    //MyPrinter.Print("\t\t\t\t\tPAN NO: AAAT10141C,    GSTIN : 07470025773\r\n");
        //    //MyPrinter.Print("\t\t\t\t\t\t   SERVICE TAX NO: AAATI0141CSD001\r\n");
        //    MyPrinter.Print("\x12");
        //    MyPrinter.Close();
        //}

        private void txtFoodQty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnFoodAdd.Focus();
            }
        }

        private void cmbWaiter_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        #region First, Previous, Next, Last
        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 Kot_Id from KOT WHERE ISNULL(activate_delete,0) = 0 and ISNULL(KOTCANCEL,0) = 0 order by Kot_Id asc";
                int hotelID = mastcaller.GetIdentityID(sqlQuery);

                if (this.objKotM != null && this.objKotM.KOT_ID == hotelID)
                    CustomMessageBox.ShowInformationMessage("This is Last record", "");
                else
                {
                    ResetPageValue();
                    this.objKotM = dbContext.KOTs.FirstOrDefault(x => x.KOT_ID == hotelID);
                    SetControlsValue();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in First Selection Data");
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 Kot_Id from KOT WHERE ISNULL(activate_delete,0) = 0 and ISNULL(KOTCANCEL,0) = 0 " +
                        (this.objKotM != null && objKotM.KOT_ID > 0 ? " and KOT_ID < " + this.objKotM.KOT_ID : string.Empty) +
                        " order by Kot_Id desc";

                int hotelID = mastcaller.GetIdentityID(sqlQuery);

                if (this.objKotM != null && this.objKotM.KOT_ID == hotelID)
                    CustomMessageBox.ShowInformationMessage("This is Last record", "");
                else
                {
                    ResetPageValue();
                    this.objKotM = dbContext.KOTs.FirstOrDefault(x => x.KOT_ID == hotelID);
                    SetControlsValue();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in First Selection Data");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 Kot_Id from KOT WHERE ISNULL(activate_delete,0) = 0 and ISNULL(KOTCANCEL,0) = 0 " +
                        (this.objKotM != null && objKotM.KOT_ID > 0 ? " and KOT_ID > " + this.objKotM.KOT_ID : string.Empty) +
                        " order by Kot_Id asc";    
                int hotelID = mastcaller.GetIdentityID(sqlQuery);

                if (this.objKotM != null && this.objKotM.KOT_ID == hotelID)
                    CustomMessageBox.ShowInformationMessage("This is Last record", "");
                else
                {
                    ResetPageValue();
                    this.objKotM = dbContext.KOTs.FirstOrDefault(x => x.KOT_ID == hotelID);
                    SetControlsValue();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in First Selection Data");
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 Kot_Id from KOT WHERE ISNULL(activate_delete,0) = 0 and ISNULL(KOTCANCEL,0) = 0 order by Kot_Id desc";
                int hotelID = mastcaller.GetIdentityID(sqlQuery);

                if (this.objKotM != null && this.objKotM.KOT_ID == hotelID)
                    CustomMessageBox.ShowInformationMessage("This is Last record", "");
                else
                {
                    ResetPageValue();
                    this.objKotM = dbContext.KOTs.FirstOrDefault(x => x.KOT_ID == hotelID);
                    SetControlsValue();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in First Selection Data");
            }
        }
        #endregion First, Previous, Next, Last
    }
}
