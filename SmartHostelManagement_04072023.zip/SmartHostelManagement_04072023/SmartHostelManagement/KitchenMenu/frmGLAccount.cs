﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmGLAccount : Form
    {
        ISIPMEntities dbContext = new ISIPMEntities();

        public int ORDID { get; set; }

        public frmGLAccount()
        {
            InitializeComponent();
        }

        private void frmGLAccount_Load(object sender, EventArgs e)
        {
            LoadAccountData();
            txtAccountName.Focus();
        }

        private void LoadAccountData()
        {
            try
            {
                IList<ORDER> lstOrders = !string.IsNullOrEmpty(txtAccountName.Text) ?
                    dbContext.ORDERs.Where(x => x.GCODE.Contains("C6") && x.PARNAM.ToUpper().Contains(txtAccountName.Text)).OrderBy(x => x.PARNAM).ToList() :
                    dbContext.ORDERs.Where(x => x.GCODE.Contains("C6")).OrderBy(x=>x.PARNAM).ToList();
                int index = 1;

                var dbAccount = (from c in lstOrders
                                 join d in dbContext.ACGROUPs on c.GCODE equals d.GCODE
                                 select
                                     new
                                     {
                                         SlNO = index++,
                                         c.ORDID,
                                         AccountName = c.PARNAM,
                                         GroupName = d.PARNAM
                                     }).ToList();

                dgvAccountDetails.DataSource = dbAccount;
                dgvAccountDetails.Columns["ORDID"].Visible = false;

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void txtAccountName_TextChanged(object sender, EventArgs e)
        {
            LoadAccountData();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadAccountData();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (dgvAccountDetails.SelectedRows.Count > 0)
            {
                this.ORDID = Convert.ToInt32(dgvAccountDetails.SelectedRows[0].Cells["ORDID"].Value);
                this.Close();
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            using (frmGLCreateAcc objCreateGL = new frmGLCreateAcc())
            {
                objCreateGL.ShowDialog();
                LoadAccountData();
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            if (dgvAccountDetails.SelectedRows.Count > 0)
            {
                int ordorid = Convert.ToInt32(dgvAccountDetails.SelectedRows[0].Cells["ORDID"].Value);
                using (frmGLCreateAcc objGLAcc = new frmGLCreateAcc())
                {
                    objGLAcc.orderNo = ordorid;
                    objGLAcc.ShowDialog();
                }
            }
            else
            {
                CustomMessageBox.ShowInformationMessage("Please select GL Account user to edit", "");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
