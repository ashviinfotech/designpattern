﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Collections.Generic;
using SMH.CommonLogic.Layer;
using DB = SmartHostelManagement.DBData;
using SMH.BusinessLogic.Layer;

namespace SmartHostelManagement.KitchenMenu
{
    public partial class frmSearchKitch : Form
    {
        MasterCaller objMaster = new MasterCaller();
        public CommonVariables.SearchFormType objForm;
        DataTable searchData = null;
        public int searchId;

        public frmSearchKitch()
        {
            InitializeComponent();
        }

        private void frmSearchKitch_Load(object sender, EventArgs e)
        {
            GetDataFromDatabase(); BindGridView();
        }

        void BindGridView()
        {
            try
            {
                dataGridView1.DataSource = searchData;
                if (searchData != null)
                {
                    dataGridView1.Rows[0].Frozen = true;
                    dataGridView1.ClearSelection();
                    dataGridView1.Columns[1].Visible = false;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        void GetDataFromDatabase()
        {
            try
            {
                string sqlQuery = string.Empty;
                searchData = new DataTable();
                if (objForm == CommonVariables.SearchFormType.Waiter)
                { 
                    sqlQuery =@"select (ROW_NUMBER() over (order by waiter_id)) [Sr.No.], waiter_id,waiterno [Waiter No], 
                        waitername [Waiter Name] from waiter_master";
                    searchData = objMaster.GetDataTableData(sqlQuery, "DBReport");

                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");      
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                { 
                    if (int.TryParse(dataGridView1.SelectedRows[0].Cells[1].Value.ToString(), out searchId))
                    {
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (int.TryParse(dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString(), out searchId))
                {
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in dgSearch_CellDoubleClick");
            }
        }
    }
}
