﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Kitchen
{
    public partial class frmKotSearch : Form
    {
        string sqlConString { get; set; }
        public int kotID { get; private set; }

        public frmKotSearch()
        {
            InitializeComponent();
        }

        private void frmKotSearch_Load(object sender, EventArgs e)
        {
            using (ISIPMEntities dbContext = new ISIPMEntities())
                this.sqlConString = dbContext.Database.Connection.ConnectionString;
            dtmFromDate.Value = DateTime.Today;
            dtmToDate.Value = DateTime.Today;
            LoadKotsData();
        }

        private void LoadKotsData()
        {
            try
            {
                string frmDate = dtmFromDate.Value.Date.ToString("MM/dd/yyyy");
                string toDate = dtmToDate.Value.Date.ToString("MM/dd/yyyy");

                MasterCaller objMaster = new MasterCaller();

                string sqlQuery = @"SELECT ROW_NUMBER() OVER (ORDER BY KOT_ID ASC) Slno,KOT_ID,Kot_No AS [KOT No],mod_of_bill_desc [Mode Of Pay],(SELECT TOP 1 PARNAM FROM [ORDER] WHERE ORDNO=KOT.OrdNo) [Guest Name], 
                        cHANNELbILLNO [Order No],CONVERT(VARCHAR,KDATE,103) [KOT Date],CONVERT(VARCHAR,KTIME,108) [KOT Time],taxed_Amount [Serv Chrg],Disc_Per [Disc Per],Disc_amt [Disc Amt], 
                        (CASE WHEN delivery_status=1 THEN ServTaxPerc ELSE 0 END) [GST(%)],(CASE WHEN delivery_status=1 THEN ServTaxAmt ELSE 0 END) [GST AMT],Amount,NetTotal,(CASE WHEN isnull(KOTCANCEL,0) = 0 THEN 'FALSE' ELSE 'TRUE' END) [Cancel],RemarksDesc [Remarks] 
                        FROM KOT WHERE CAST(Kdate AS DATE) BETWEEN CAST('" + frmDate + "' AS DATE) AND CAST('" + toDate + "' AS DATE) AND isnull(activate_delete,0)=0 and isnull(KOTCANCEL,0)=0 ORDER BY KOT_ID ASC";

                DataTable dtKot = objMaster.GetDataTableData(sqlQuery, "KOT");

                dgvKotDetails.DataSource = dtKot;
                dgvKotDetails.Columns["Slno"].Frozen = true;
                dgvKotDetails.Columns["KOT_ID"].Visible = false;
                dgvKotDetails.Columns["Serv Chrg"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvKotDetails.Columns["Disc Amt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvKotDetails.Columns["Disc Per"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvKotDetails.Columns["GST(%)"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvKotDetails.Columns["GST AMT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvKotDetails.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvKotDetails.Columns["NetTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvKotDetails.Columns["Serv Chrg"].DefaultCellStyle.Format = "0.00";
                dgvKotDetails.Columns["Disc Amt"].DefaultCellStyle.Format = "0.00";
                dgvKotDetails.Columns["Disc Per"].DefaultCellStyle.Format = "0.00";
                dgvKotDetails.Columns["GST(%)"].DefaultCellStyle.Format = "0.00";
                dgvKotDetails.Columns["GST AMT"].DefaultCellStyle.Format = "0.00";
                dgvKotDetails.Columns["Amount"].DefaultCellStyle.Format = "0.00";
                dgvKotDetails.Columns["NetTotal"].DefaultCellStyle.Format = "0.00";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadKotsData();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvKotDetails.SelectedRows.Count > 0)
                {
                    this.kotID = Convert.ToInt32(dgvKotDetails.SelectedRows[0].Cells["KOT_ID"].Value);
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please select record !", "");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvKotDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvKotDetails.SelectedRows.Count > 0)
                {
                    this.kotID = Convert.ToInt32(dgvKotDetails.SelectedRows[0].Cells["KOT_ID"].Value);
                    this.Close();
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please select record !", "");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }
    }
}
