﻿namespace SmartHostelManagement.Hostel
{
    partial class frmHostelReserv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label23 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.label47 = new System.Windows.Forms.Label();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.label44 = new System.Windows.Forms.Label();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnUndo = new System.Windows.Forms.Button();
            this.txtEntryNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnMemo = new System.Windows.Forms.Button();
            this.btnReceipt = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnOpenByEntryNo = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnRefersh = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnEstimate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.lblRecepDesc3 = new System.Windows.Forms.Label();
            this.lblRecepDesc2 = new System.Windows.Forms.Label();
            this.lblRecepDesc1 = new System.Windows.Forms.Label();
            this.lblRecepDesc0 = new System.Windows.Forms.Label();
            this.lblReceiptNo3 = new System.Windows.Forms.Label();
            this.txtReceipt3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dtmTodate = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.dtmFromDate = new System.Windows.Forms.DateTimePicker();
            this.lblReceiptNo2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chkServiceBundle = new System.Windows.Forms.CheckBox();
            this.chkServiceExmpt = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmbDetDormType = new System.Windows.Forms.ComboBox();
            this.grdReservDetails = new System.Windows.Forms.DataGridView();
            this.cmbDetRoomType = new System.Windows.Forms.ComboBox();
            this.btnDetNew = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnDetAdd = new System.Windows.Forms.Button();
            this.txtDetDormTypeAmt = new System.Windows.Forms.TextBox();
            this.btnDetRemove = new System.Windows.Forms.Button();
            this.txtDetRoomTypeAmt = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDetRemarks = new System.Windows.Forms.TextBox();
            this.cmbDetDorm = new System.Windows.Forms.ComboBox();
            this.txtNoOfBeds = new System.Windows.Forms.TextBox();
            this.txtNoOfRooms = new System.Windows.Forms.TextBox();
            this.dtmDetUptoReserv = new System.Windows.Forms.DateTimePicker();
            this.dtmDetFromReserv = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbDormType = new System.Windows.Forms.ComboBox();
            this.cmbRoomType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtDormTypeRent = new System.Windows.Forms.TextBox();
            this.txtRoomTypeRent = new System.Windows.Forms.TextBox();
            this.btnRoomFolio = new System.Windows.Forms.Button();
            this.lblResrvStatus = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtRoomFolioNo = new System.Windows.Forms.TextBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtUpto = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtNoBeds = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNoRoom = new System.Windows.Forms.TextBox();
            this.cmbDorm = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.lblTotalReceipt = new System.Windows.Forms.Label();
            this.lblCustStatus = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnCancellation = new System.Windows.Forms.Button();
            this.BtnCancelHistory = new System.Windows.Forms.Button();
            this.txtReceipt2 = new System.Windows.Forms.TextBox();
            this.lblReceiptNo1 = new System.Windows.Forms.Label();
            this.txtReceipt1 = new System.Windows.Forms.TextBox();
            this.lblReceiptAmt0 = new System.Windows.Forms.Label();
            this.txtReceipt0 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAddress3 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtmReservTo = new System.Windows.Forms.DateTimePicker();
            this.btnSelectGuest = new System.Windows.Forms.Button();
            this.btnAddGuest = new System.Windows.Forms.Button();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdReservDetails)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 5);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(98, 14);
            this.label23.TabIndex = 58;
            this.label23.Text = "Entry Number";
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(7, 44);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(865, 460);
            this.dataGridView4.TabIndex = 73;
            this.dataGridView4.TabStop = false;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(204, 20);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(28, 14);
            this.label47.TabIndex = 72;
            this.label47.Text = "To:";
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker7.CustomFormat = "dd/MMM/yyyy";
            this.dateTimePicker7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker7.Location = new System.Drawing.Point(236, 16);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker7.TabIndex = 51;
            this.dateTimePicker7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(12, 20);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(46, 14);
            this.label44.TabIndex = 70;
            this.label44.Text = "From:";
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker6.CustomFormat = "dd/MMM/yyyy";
            this.dateTimePicker6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker6.Location = new System.Drawing.Point(59, 16);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker6.TabIndex = 50;
            this.dateTimePicker6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.dataGridView4);
            this.tabPage3.Controls.Add(this.label47);
            this.tabPage3.Controls.Add(this.dateTimePicker7);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.dateTimePicker6);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(878, 512);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Reservation Chart";
            // 
            // btnUndo
            // 
            this.btnUndo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUndo.Location = new System.Drawing.Point(7, 35);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(89, 26);
            this.btnUndo.TabIndex = 37;
            this.btnUndo.Text = "Undo";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            this.btnUndo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtEntryNo
            // 
            this.txtEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryNo.Location = new System.Drawing.Point(105, 2);
            this.txtEntryNo.MaxLength = 10;
            this.txtEntryNo.Name = "txtEntryNo";
            this.txtEntryNo.Size = new System.Drawing.Size(114, 22);
            this.txtEntryNo.TabIndex = 1;
            this.txtEntryNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEntryNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtEntryNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 14);
            this.label1.TabIndex = 58;
            this.label1.Text = "Title";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(455, 7);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(81, 27);
            this.btnSearch.TabIndex = 44;
            this.btnSearch.Text = "Serach";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            this.btnSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnMemo
            // 
            this.btnMemo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemo.Location = new System.Drawing.Point(353, 6);
            this.btnMemo.Name = "btnMemo";
            this.btnMemo.Size = new System.Drawing.Size(95, 27);
            this.btnMemo.TabIndex = 42;
            this.btnMemo.Text = "Memo";
            this.btnMemo.UseVisualStyleBackColor = true;
            this.btnMemo.Click += new System.EventHandler(this.btnMemo_Click);
            this.btnMemo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnReceipt
            // 
            this.btnReceipt.AutoSize = true;
            this.btnReceipt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReceipt.Location = new System.Drawing.Point(214, 35);
            this.btnReceipt.Name = "btnReceipt";
            this.btnReceipt.Size = new System.Drawing.Size(130, 27);
            this.btnReceipt.TabIndex = 41;
            this.btnReceipt.Text = "Receipts";
            this.btnReceipt.UseVisualStyleBackColor = true;
            this.btnReceipt.Click += new System.EventHandler(this.btnReceipt_Click);
            this.btnReceipt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(455, 34);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(81, 27);
            this.btnDelete.TabIndex = 45;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            this.btnDelete.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnOpenByEntryNo
            // 
            this.btnOpenByEntryNo.AutoSize = true;
            this.btnOpenByEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenByEntryNo.Location = new System.Drawing.Point(570, 35);
            this.btnOpenByEntryNo.Name = "btnOpenByEntryNo";
            this.btnOpenByEntryNo.Size = new System.Drawing.Size(153, 27);
            this.btnOpenByEntryNo.TabIndex = 50;
            this.btnOpenByEntryNo.Text = "Open By Entry No";
            this.btnOpenByEntryNo.UseVisualStyleBackColor = true;
            this.btnOpenByEntryNo.Click += new System.EventHandler(this.btnOpenByEntryNo_Click);
            this.btnOpenByEntryNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnExit
            // 
            this.btnExit.AutoSize = true;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(786, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(92, 46);
            this.btnExit.TabIndex = 51;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            this.btnExit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnFirst
            // 
            this.btnFirst.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(548, 6);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(56, 27);
            this.btnFirst.TabIndex = 46;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            this.btnFirst.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnRefersh
            // 
            this.btnRefersh.AutoSize = true;
            this.btnRefersh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefersh.Location = new System.Drawing.Point(214, 7);
            this.btnRefersh.Name = "btnRefersh";
            this.btnRefersh.Size = new System.Drawing.Size(130, 27);
            this.btnRefersh.TabIndex = 40;
            this.btnRefersh.Text = "Refresh Chart";
            this.btnRefersh.UseVisualStyleBackColor = true;
            this.btnRefersh.Click += new System.EventHandler(this.btnRefersh_Click);
            this.btnRefersh.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnLast
            // 
            this.btnLast.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.Location = new System.Drawing.Point(725, 7);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(54, 27);
            this.btnLast.TabIndex = 49;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            this.btnLast.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(666, 7);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(56, 27);
            this.btnNext.TabIndex = 48;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            this.btnNext.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnPrev
            // 
            this.btnPrev.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrev.Location = new System.Drawing.Point(607, 7);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(56, 27);
            this.btnPrev.TabIndex = 47;
            this.btnPrev.Text = "<";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            this.btnPrev.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnEstimate
            // 
            this.btnEstimate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEstimate.Location = new System.Drawing.Point(353, 34);
            this.btnEstimate.Name = "btnEstimate";
            this.btnEstimate.Size = new System.Drawing.Size(95, 27);
            this.btnEstimate.TabIndex = 43;
            this.btnEstimate.Text = "Estimate";
            this.btnEstimate.UseVisualStyleBackColor = true;
            this.btnEstimate.Click += new System.EventHandler(this.btnPrint_Click);
            this.btnEstimate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(113, 34);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 27);
            this.btnSave.TabIndex = 39;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            this.btnSave.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(113, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(81, 27);
            this.btnEdit.TabIndex = 38;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            this.btnEdit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNew.Location = new System.Drawing.Point(7, 7);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(89, 27);
            this.btnAddNew.TabIndex = 36;
            this.btnAddNew.Text = "Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            this.btnAddNew.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // lblRecepDesc3
            // 
            this.lblRecepDesc3.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc3.Location = new System.Drawing.Point(123, 172);
            this.lblRecepDesc3.Name = "lblRecepDesc3";
            this.lblRecepDesc3.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc3.TabIndex = 122;
            this.lblRecepDesc3.Text = "Amount";
            // 
            // lblRecepDesc2
            // 
            this.lblRecepDesc2.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc2.Location = new System.Drawing.Point(123, 122);
            this.lblRecepDesc2.Name = "lblRecepDesc2";
            this.lblRecepDesc2.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc2.TabIndex = 121;
            this.lblRecepDesc2.Text = "Amount";
            // 
            // lblRecepDesc1
            // 
            this.lblRecepDesc1.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc1.Location = new System.Drawing.Point(123, 72);
            this.lblRecepDesc1.Name = "lblRecepDesc1";
            this.lblRecepDesc1.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc1.TabIndex = 120;
            this.lblRecepDesc1.Text = "Amount";
            // 
            // lblRecepDesc0
            // 
            this.lblRecepDesc0.BackColor = System.Drawing.Color.Pink;
            this.lblRecepDesc0.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecepDesc0.Location = new System.Drawing.Point(123, 20);
            this.lblRecepDesc0.Name = "lblRecepDesc0";
            this.lblRecepDesc0.Size = new System.Drawing.Size(272, 46);
            this.lblRecepDesc0.TabIndex = 119;
            this.lblRecepDesc0.Text = "Amount";
            // 
            // lblReceiptNo3
            // 
            this.lblReceiptNo3.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo3.Location = new System.Drawing.Point(6, 196);
            this.lblReceiptNo3.Name = "lblReceiptNo3";
            this.lblReceiptNo3.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo3.TabIndex = 118;
            this.lblReceiptNo3.Text = "Amount";
            this.lblReceiptNo3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt3
            // 
            this.txtReceipt3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt3.Location = new System.Drawing.Point(6, 172);
            this.txtReceipt3.MaxLength = 10;
            this.txtReceipt3.Name = "txtReceipt3";
            this.txtReceipt3.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt3.TabIndex = 24;
            this.txtReceipt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt3.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(221, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 14);
            this.label8.TabIndex = 102;
            this.label8.Text = "Upto Days";
            // 
            // dtmTodate
            // 
            this.dtmTodate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmTodate.CustomFormat = "dd/MMM/yyyy";
            this.dtmTodate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmTodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmTodate.Location = new System.Drawing.Point(343, 65);
            this.dtmTodate.Name = "dtmTodate";
            this.dtmTodate.Size = new System.Drawing.Size(121, 22);
            this.dtmTodate.TabIndex = 14;
            this.dtmTodate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 14);
            this.label7.TabIndex = 100;
            this.label7.Text = "Reserv From";
            // 
            // dtmFromDate
            // 
            this.dtmFromDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFromDate.CustomFormat = "dd/MMM/yyyy";
            this.dtmFromDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmFromDate.Location = new System.Drawing.Point(97, 65);
            this.dtmFromDate.Name = "dtmFromDate";
            this.dtmFromDate.Size = new System.Drawing.Size(121, 22);
            this.dtmFromDate.TabIndex = 12;
            this.dtmFromDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // lblReceiptNo2
            // 
            this.lblReceiptNo2.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo2.Location = new System.Drawing.Point(6, 146);
            this.lblReceiptNo2.Name = "lblReceiptNo2";
            this.lblReceiptNo2.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo2.TabIndex = 116;
            this.lblReceiptNo2.Text = "Amount";
            this.lblReceiptNo2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(886, 541);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.chkServiceBundle);
            this.tabPage1.Controls.Add(this.chkServiceExmpt);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.lblTotalReceipt);
            this.tabPage1.Controls.Add(this.lblCustStatus);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(878, 512);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Reservation Information";
            // 
            // chkServiceBundle
            // 
            this.chkServiceBundle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.chkServiceBundle.Enabled = false;
            this.chkServiceBundle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkServiceBundle.Location = new System.Drawing.Point(689, 40);
            this.chkServiceBundle.Name = "chkServiceBundle";
            this.chkServiceBundle.Size = new System.Drawing.Size(145, 18);
            this.chkServiceBundle.TabIndex = 129;
            this.chkServiceBundle.Text = "Bypass Tax Verify";
            this.chkServiceBundle.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkServiceBundle.UseCompatibleTextRendering = true;
            this.chkServiceBundle.UseVisualStyleBackColor = false;
            // 
            // chkServiceExmpt
            // 
            this.chkServiceExmpt.BackColor = System.Drawing.Color.Red;
            this.chkServiceExmpt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkServiceExmpt.Location = new System.Drawing.Point(505, 39);
            this.chkServiceExmpt.Name = "chkServiceExmpt";
            this.chkServiceExmpt.Size = new System.Drawing.Size(153, 20);
            this.chkServiceExmpt.TabIndex = 128;
            this.chkServiceExmpt.Text = "GST Exempted";
            this.chkServiceExmpt.UseCompatibleTextRendering = true;
            this.chkServiceExmpt.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cmbDetDormType);
            this.panel2.Controls.Add(this.grdReservDetails);
            this.panel2.Controls.Add(this.cmbDetRoomType);
            this.panel2.Controls.Add(this.btnDetNew);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.btnDetAdd);
            this.panel2.Controls.Add(this.txtDetDormTypeAmt);
            this.panel2.Controls.Add(this.btnDetRemove);
            this.panel2.Controls.Add(this.txtDetRoomTypeAmt);
            this.panel2.Controls.Add(this.label55);
            this.panel2.Controls.Add(this.label54);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.txtDetRemarks);
            this.panel2.Controls.Add(this.cmbDetDorm);
            this.panel2.Controls.Add(this.txtNoOfBeds);
            this.panel2.Controls.Add(this.txtNoOfRooms);
            this.panel2.Controls.Add(this.dtmDetUptoReserv);
            this.panel2.Controls.Add(this.dtmDetFromReserv);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(3, 335);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(871, 175);
            this.panel2.TabIndex = 127;
            // 
            // cmbDetDormType
            // 
            this.cmbDetDormType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDetDormType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDetDormType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDetDormType.FormattingEnabled = true;
            this.cmbDetDormType.Location = new System.Drawing.Point(349, 44);
            this.cmbDetDormType.Name = "cmbDetDormType";
            this.cmbDetDormType.Size = new System.Drawing.Size(138, 22);
            this.cmbDetDormType.TabIndex = 129;
            this.cmbDetDormType.SelectedIndexChanged += new System.EventHandler(this.cmbDormType_SelectedIndexChanged);
            // 
            // grdReservDetails
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdReservDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grdReservDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdReservDetails.DefaultCellStyle = dataGridViewCellStyle2;
            this.grdReservDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdReservDetails.Location = new System.Drawing.Point(4, 71);
            this.grdReservDetails.Name = "grdReservDetails";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdReservDetails.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grdReservDetails.RowHeadersVisible = false;
            this.grdReservDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdReservDetails.ShowCellErrors = false;
            this.grdReservDetails.ShowCellToolTips = false;
            this.grdReservDetails.ShowEditingIcon = false;
            this.grdReservDetails.ShowRowErrors = false;
            this.grdReservDetails.Size = new System.Drawing.Size(864, 102);
            this.grdReservDetails.TabIndex = 128;
            this.grdReservDetails.TabStop = false;
            this.grdReservDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdReservDetails_CellDoubleClick);
            // 
            // cmbDetRoomType
            // 
            this.cmbDetRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDetRoomType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDetRoomType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDetRoomType.FormattingEnabled = true;
            this.cmbDetRoomType.Location = new System.Drawing.Point(55, 44);
            this.cmbDetRoomType.Name = "cmbDetRoomType";
            this.cmbDetRoomType.Size = new System.Drawing.Size(151, 22);
            this.cmbDetRoomType.TabIndex = 128;
            this.cmbDetRoomType.SelectedIndexChanged += new System.EventHandler(this.cmbRoomType_SelectedIndexChanged);
            // 
            // btnDetNew
            // 
            this.btnDetNew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetNew.Location = new System.Drawing.Point(586, 43);
            this.btnDetNew.Name = "btnDetNew";
            this.btnDetNew.Size = new System.Drawing.Size(84, 24);
            this.btnDetNew.TabIndex = 32;
            this.btnDetNew.Text = "&New";
            this.btnDetNew.UseVisualStyleBackColor = true;
            this.btnDetNew.Click += new System.EventHandler(this.btnDetNew_Click);
            this.btnDetNew.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 32);
            this.label6.TabIndex = 127;
            this.label6.Text = "Room Type";
            // 
            // btnDetAdd
            // 
            this.btnDetAdd.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetAdd.Location = new System.Drawing.Point(672, 43);
            this.btnDetAdd.Name = "btnDetAdd";
            this.btnDetAdd.Size = new System.Drawing.Size(103, 24);
            this.btnDetAdd.TabIndex = 33;
            this.btnDetAdd.Text = "&Add/Change";
            this.btnDetAdd.UseVisualStyleBackColor = true;
            this.btnDetAdd.Click += new System.EventHandler(this.btnDetAdd_Click);
            this.btnDetAdd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtDetDormTypeAmt
            // 
            this.txtDetDormTypeAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDetDormTypeAmt.Location = new System.Drawing.Point(490, 44);
            this.txtDetDormTypeAmt.MaxLength = 10;
            this.txtDetDormTypeAmt.Name = "txtDetDormTypeAmt";
            this.txtDetDormTypeAmt.Size = new System.Drawing.Size(84, 22);
            this.txtDetDormTypeAmt.TabIndex = 125;
            this.txtDetDormTypeAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnDetRemove
            // 
            this.btnDetRemove.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetRemove.Location = new System.Drawing.Point(778, 43);
            this.btnDetRemove.Name = "btnDetRemove";
            this.btnDetRemove.Size = new System.Drawing.Size(84, 24);
            this.btnDetRemove.TabIndex = 34;
            this.btnDetRemove.Text = "Remo&ve";
            this.btnDetRemove.UseVisualStyleBackColor = true;
            this.btnDetRemove.Click += new System.EventHandler(this.btnDetRemove_Click);
            this.btnDetRemove.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtDetRoomTypeAmt
            // 
            this.txtDetRoomTypeAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDetRoomTypeAmt.Location = new System.Drawing.Point(210, 43);
            this.txtDetRoomTypeAmt.MaxLength = 10;
            this.txtDetRoomTypeAmt.Name = "txtDetRoomTypeAmt";
            this.txtDetRoomTypeAmt.Size = new System.Drawing.Size(87, 22);
            this.txtDetRoomTypeAmt.TabIndex = 124;
            this.txtDetRoomTypeAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(129, 2);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(88, 14);
            this.label55.TabIndex = 124;
            this.label55.Text = "Reserv Upto";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(4, 2);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(91, 14);
            this.label54.TabIndex = 123;
            this.label54.Text = "Reserv From";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(576, 2);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 14);
            this.label30.TabIndex = 122;
            this.label30.Text = "Remarks";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(458, 2);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(85, 14);
            this.label29.TabIndex = 121;
            this.label29.Text = "Dorm Name";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(355, 2);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(82, 14);
            this.label28.TabIndex = 120;
            this.label28.Text = "No. of Beds";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(253, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 14);
            this.label10.TabIndex = 119;
            this.label10.Text = "No. of Rooms";
            // 
            // txtDetRemarks
            // 
            this.txtDetRemarks.BackColor = System.Drawing.Color.White;
            this.txtDetRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDetRemarks.Location = new System.Drawing.Point(579, 17);
            this.txtDetRemarks.MaxLength = 40000;
            this.txtDetRemarks.Name = "txtDetRemarks";
            this.txtDetRemarks.Size = new System.Drawing.Size(287, 22);
            this.txtDetRemarks.TabIndex = 31;
            this.txtDetRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtDetRemarks.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // cmbDetDorm
            // 
            this.cmbDetDorm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDetDorm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDetDorm.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDetDorm.FormattingEnabled = true;
            this.cmbDetDorm.Location = new System.Drawing.Point(461, 17);
            this.cmbDetDorm.Name = "cmbDetDorm";
            this.cmbDetDorm.Size = new System.Drawing.Size(113, 22);
            this.cmbDetDorm.TabIndex = 30;
            this.cmbDetDorm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // txtNoOfBeds
            // 
            this.txtNoOfBeds.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoOfBeds.Location = new System.Drawing.Point(358, 17);
            this.txtNoOfBeds.MaxLength = 10;
            this.txtNoOfBeds.Name = "txtNoOfBeds";
            this.txtNoOfBeds.Size = new System.Drawing.Size(98, 22);
            this.txtNoOfBeds.TabIndex = 29;
            this.txtNoOfBeds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNoOfBeds.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtNoOfBeds.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // txtNoOfRooms
            // 
            this.txtNoOfRooms.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoOfRooms.Location = new System.Drawing.Point(256, 17);
            this.txtNoOfRooms.MaxLength = 10;
            this.txtNoOfRooms.Name = "txtNoOfRooms";
            this.txtNoOfRooms.Size = new System.Drawing.Size(98, 22);
            this.txtNoOfRooms.TabIndex = 28;
            this.txtNoOfRooms.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNoOfRooms.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtNoOfRooms.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // dtmDetUptoReserv
            // 
            this.dtmDetUptoReserv.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetUptoReserv.CustomFormat = "dd/MMM/yyyy";
            this.dtmDetUptoReserv.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetUptoReserv.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmDetUptoReserv.Location = new System.Drawing.Point(132, 17);
            this.dtmDetUptoReserv.Name = "dtmDetUptoReserv";
            this.dtmDetUptoReserv.Size = new System.Drawing.Size(120, 22);
            this.dtmDetUptoReserv.TabIndex = 27;
            this.dtmDetUptoReserv.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // dtmDetFromReserv
            // 
            this.dtmDetFromReserv.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetFromReserv.CustomFormat = "dd/MMM/yyyy";
            this.dtmDetFromReserv.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetFromReserv.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmDetFromReserv.Location = new System.Drawing.Point(7, 17);
            this.dtmDetFromReserv.Name = "dtmDetFromReserv";
            this.dtmDetFromReserv.Size = new System.Drawing.Size(121, 22);
            this.dtmDetFromReserv.TabIndex = 26;
            this.dtmDetFromReserv.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(299, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 30);
            this.label9.TabIndex = 126;
            this.label9.Text = "Dorm Type";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cmbDormType);
            this.panel1.Controls.Add(this.cmbRoomType);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txtDormTypeRent);
            this.panel1.Controls.Add(this.txtRoomTypeRent);
            this.panel1.Controls.Add(this.btnRoomFolio);
            this.panel1.Controls.Add(this.lblResrvStatus);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtRoomFolioNo);
            this.panel1.Controls.Add(this.txtRemarks);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.txtUpto);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.txtNoBeds);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtNoRoom);
            this.panel1.Controls.Add(this.cmbDorm);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.dtmTodate);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.dtmFromDate);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(3, 152);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(470, 184);
            this.panel1.TabIndex = 126;
            // 
            // cmbDormType
            // 
            this.cmbDormType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDormType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDormType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDormType.FormattingEnabled = true;
            this.cmbDormType.Location = new System.Drawing.Point(289, 37);
            this.cmbDormType.Name = "cmbDormType";
            this.cmbDormType.Size = new System.Drawing.Size(110, 22);
            this.cmbDormType.TabIndex = 123;
            this.cmbDormType.SelectedIndexChanged += new System.EventHandler(this.cmbDormType_SelectedIndexChanged);
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoomType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbRoomType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Location = new System.Drawing.Point(55, 37);
            this.cmbRoomType.Name = "cmbRoomType";
            this.cmbRoomType.Size = new System.Drawing.Size(113, 22);
            this.cmbRoomType.TabIndex = 122;
            this.cmbRoomType.SelectedIndexChanged += new System.EventHandler(this.cmbRoomType_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(5, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 32);
            this.label12.TabIndex = 121;
            this.label12.Text = "Room Type";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(241, 34);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 30);
            this.label11.TabIndex = 120;
            this.label11.Text = "Dorm Type";
            // 
            // txtDormTypeRent
            // 
            this.txtDormTypeRent.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDormTypeRent.Location = new System.Drawing.Point(402, 37);
            this.txtDormTypeRent.MaxLength = 10;
            this.txtDormTypeRent.Name = "txtDormTypeRent";
            this.txtDormTypeRent.Size = new System.Drawing.Size(61, 22);
            this.txtDormTypeRent.TabIndex = 119;
            this.txtDormTypeRent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtRoomTypeRent
            // 
            this.txtRoomTypeRent.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoomTypeRent.Location = new System.Drawing.Point(172, 36);
            this.txtRoomTypeRent.MaxLength = 10;
            this.txtRoomTypeRent.Name = "txtRoomTypeRent";
            this.txtRoomTypeRent.Size = new System.Drawing.Size(66, 22);
            this.txtRoomTypeRent.TabIndex = 117;
            this.txtRoomTypeRent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnRoomFolio
            // 
            this.btnRoomFolio.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoomFolio.Location = new System.Drawing.Point(189, 135);
            this.btnRoomFolio.Name = "btnRoomFolio";
            this.btnRoomFolio.Size = new System.Drawing.Size(42, 24);
            this.btnRoomFolio.TabIndex = 19;
            this.btnRoomFolio.Text = "RF";
            this.btnRoomFolio.UseVisualStyleBackColor = true;
            this.btnRoomFolio.Click += new System.EventHandler(this.btnRoomFolio_Click);
            this.btnRoomFolio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // lblResrvStatus
            // 
            this.lblResrvStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblResrvStatus.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResrvStatus.Location = new System.Drawing.Point(235, 136);
            this.lblResrvStatus.Name = "lblResrvStatus";
            this.lblResrvStatus.Size = new System.Drawing.Size(229, 43);
            this.lblResrvStatus.TabIndex = 115;
            this.lblResrvStatus.Text = "Existing-Entry";
            this.lblResrvStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 14);
            this.label4.TabIndex = 113;
            this.label4.Text = "Room Folio";
            // 
            // txtRoomFolioNo
            // 
            this.txtRoomFolioNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoomFolioNo.Location = new System.Drawing.Point(88, 137);
            this.txtRoomFolioNo.MaxLength = 10;
            this.txtRoomFolioNo.Name = "txtRoomFolioNo";
            this.txtRoomFolioNo.Size = new System.Drawing.Size(98, 22);
            this.txtRoomFolioNo.TabIndex = 17;
            this.txtRoomFolioNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRoomFolioNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtRoomFolioNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // txtRemarks
            // 
            this.txtRemarks.BackColor = System.Drawing.Color.White;
            this.txtRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(72, 89);
            this.txtRemarks.MaxLength = 40000;
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(391, 44);
            this.txtRemarks.TabIndex = 15;
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtRemarks.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(4, 89);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 14);
            this.label25.TabIndex = 110;
            this.label25.Text = "Remarks";
            // 
            // txtUpto
            // 
            this.txtUpto.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpto.Location = new System.Drawing.Point(297, 65);
            this.txtUpto.MaxLength = 10;
            this.txtUpto.Name = "txtUpto";
            this.txtUpto.Size = new System.Drawing.Size(43, 22);
            this.txtUpto.TabIndex = 13;
            this.txtUpto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUpto.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtUpto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(165, 12);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(82, 14);
            this.label27.TabIndex = 103;
            this.label27.Text = "No. of Beds";
            // 
            // txtNoBeds
            // 
            this.txtNoBeds.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoBeds.Location = new System.Drawing.Point(250, 9);
            this.txtNoBeds.MaxLength = 10;
            this.txtNoBeds.Name = "txtNoBeds";
            this.txtNoBeds.Size = new System.Drawing.Size(59, 22);
            this.txtNoBeds.TabIndex = 10;
            this.txtNoBeds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNoBeds.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtNoBeds.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 14);
            this.label3.TabIndex = 101;
            this.label3.Text = "No. of Rooms";
            // 
            // txtNoRoom
            // 
            this.txtNoRoom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoRoom.Location = new System.Drawing.Point(101, 9);
            this.txtNoRoom.MaxLength = 10;
            this.txtNoRoom.Name = "txtNoRoom";
            this.txtNoRoom.Size = new System.Drawing.Size(61, 22);
            this.txtNoRoom.TabIndex = 9;
            this.txtNoRoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNoRoom.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtNoRoom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            // 
            // cmbDorm
            // 
            this.cmbDorm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDorm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDorm.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDorm.FormattingEnabled = true;
            this.cmbDorm.Location = new System.Drawing.Point(361, 9);
            this.cmbDorm.Name = "cmbDorm";
            this.cmbDorm.Size = new System.Drawing.Size(104, 22);
            this.cmbDorm.TabIndex = 11;
            this.cmbDorm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(310, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 34);
            this.label13.TabIndex = 100;
            this.label13.Text = "Dorm Name";
            // 
            // lblTotalReceipt
            // 
            this.lblTotalReceipt.BackColor = System.Drawing.Color.LightYellow;
            this.lblTotalReceipt.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalReceipt.Location = new System.Drawing.Point(664, 9);
            this.lblTotalReceipt.Name = "lblTotalReceipt";
            this.lblTotalReceipt.Size = new System.Drawing.Size(210, 28);
            this.lblTotalReceipt.TabIndex = 125;
            this.lblTotalReceipt.Text = "Adv Recpt. : 1234567.00";
            this.lblTotalReceipt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustStatus
            // 
            this.lblCustStatus.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lblCustStatus.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustStatus.Location = new System.Drawing.Point(478, 9);
            this.lblCustStatus.Name = "lblCustStatus";
            this.lblCustStatus.Size = new System.Drawing.Size(183, 27);
            this.lblCustStatus.TabIndex = 113;
            this.lblCustStatus.Text = "Existing-Entry";
            this.lblCustStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnCancellation);
            this.groupBox4.Controls.Add(this.lblRecepDesc3);
            this.groupBox4.Controls.Add(this.BtnCancelHistory);
            this.groupBox4.Controls.Add(this.lblRecepDesc2);
            this.groupBox4.Controls.Add(this.lblRecepDesc1);
            this.groupBox4.Controls.Add(this.lblRecepDesc0);
            this.groupBox4.Controls.Add(this.lblReceiptNo3);
            this.groupBox4.Controls.Add(this.txtReceipt3);
            this.groupBox4.Controls.Add(this.lblReceiptNo2);
            this.groupBox4.Controls.Add(this.txtReceipt2);
            this.groupBox4.Controls.Add(this.lblReceiptNo1);
            this.groupBox4.Controls.Add(this.txtReceipt1);
            this.groupBox4.Controls.Add(this.lblReceiptAmt0);
            this.groupBox4.Controls.Add(this.txtReceipt0);
            this.groupBox4.Location = new System.Drawing.Point(475, 61);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(399, 274);
            this.groupBox4.TabIndex = 112;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Receipt Entry Number";
            // 
            // btnCancellation
            // 
            this.btnCancellation.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancellation.Location = new System.Drawing.Point(56, 232);
            this.btnCancellation.Name = "btnCancellation";
            this.btnCancellation.Size = new System.Drawing.Size(128, 31);
            this.btnCancellation.TabIndex = 130;
            this.btnCancellation.Text = "&Cancellation";
            this.btnCancellation.UseVisualStyleBackColor = true;
            this.btnCancellation.Click += new System.EventHandler(this.btnCancellation_Click);
            // 
            // BtnCancelHistory
            // 
            this.BtnCancelHistory.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancelHistory.Location = new System.Drawing.Point(194, 232);
            this.BtnCancelHistory.Name = "BtnCancelHistory";
            this.BtnCancelHistory.Size = new System.Drawing.Size(132, 31);
            this.BtnCancelHistory.TabIndex = 131;
            this.BtnCancelHistory.Text = "&Cancel &History";
            this.BtnCancelHistory.UseVisualStyleBackColor = true;
            this.BtnCancelHistory.Click += new System.EventHandler(this.BtnCancelHistory_Click);
            // 
            // txtReceipt2
            // 
            this.txtReceipt2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt2.Location = new System.Drawing.Point(6, 122);
            this.txtReceipt2.MaxLength = 10;
            this.txtReceipt2.Name = "txtReceipt2";
            this.txtReceipt2.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt2.TabIndex = 23;
            this.txtReceipt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt2.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblReceiptNo1
            // 
            this.lblReceiptNo1.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptNo1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptNo1.Location = new System.Drawing.Point(6, 96);
            this.lblReceiptNo1.Name = "lblReceiptNo1";
            this.lblReceiptNo1.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptNo1.TabIndex = 114;
            this.lblReceiptNo1.Text = "Amount";
            this.lblReceiptNo1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt1
            // 
            this.txtReceipt1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt1.Location = new System.Drawing.Point(6, 72);
            this.txtReceipt1.MaxLength = 10;
            this.txtReceipt1.Name = "txtReceipt1";
            this.txtReceipt1.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt1.TabIndex = 22;
            this.txtReceipt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt1.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // lblReceiptAmt0
            // 
            this.lblReceiptAmt0.BackColor = System.Drawing.Color.Pink;
            this.lblReceiptAmt0.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceiptAmt0.Location = new System.Drawing.Point(6, 44);
            this.lblReceiptAmt0.Name = "lblReceiptAmt0";
            this.lblReceiptAmt0.Size = new System.Drawing.Size(114, 22);
            this.lblReceiptAmt0.TabIndex = 112;
            this.lblReceiptAmt0.Text = "Amount";
            this.lblReceiptAmt0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtReceipt0
            // 
            this.txtReceipt0.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceipt0.Location = new System.Drawing.Point(6, 20);
            this.txtReceipt0.MaxLength = 10;
            this.txtReceipt0.Name = "txtReceipt0";
            this.txtReceipt0.Size = new System.Drawing.Size(114, 22);
            this.txtReceipt0.TabIndex = 21;
            this.txtReceipt0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceipt0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtReceipt0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceipt0_KeyPress);
            this.txtReceipt0.Leave += new System.EventHandler(this.txtReceipt0_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtAddress3);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.txtAddress2);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dtmReservTo);
            this.groupBox1.Controls.Add(this.btnSelectGuest);
            this.groupBox1.Controls.Add(this.btnAddGuest);
            this.groupBox1.Controls.Add(this.txtCustName);
            this.groupBox1.Controls.Add(this.cmbTitle);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtEntryNo);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(472, 149);
            this.groupBox1.TabIndex = 59;
            this.groupBox1.TabStop = false;
            // 
            // txtAddress3
            // 
            this.txtAddress3.BackColor = System.Drawing.Color.White;
            this.txtAddress3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress3.Location = new System.Drawing.Point(8, 124);
            this.txtAddress3.MaxLength = 40000;
            this.txtAddress3.Name = "txtAddress3";
            this.txtAddress3.Size = new System.Drawing.Size(459, 22);
            this.txtAddress3.TabIndex = 70;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(71, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(45, 14);
            this.label26.TabIndex = 69;
            this.label26.Text = "Name";
            // 
            // txtAddress2
            // 
            this.txtAddress2.BackColor = System.Drawing.Color.White;
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(9, 100);
            this.txtAddress2.MaxLength = 40000;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(457, 22);
            this.txtAddress2.TabIndex = 8;
            this.txtAddress2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtAddress2.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.White;
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(40, 76);
            this.txtAddress.MaxLength = 40000;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(426, 22);
            this.txtAddress.TabIndex = 7;
            this.txtAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtAddress.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(236, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 14);
            this.label5.TabIndex = 64;
            this.label5.Text = "Date of Reser";
            // 
            // dtmReservTo
            // 
            this.dtmReservTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmReservTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmReservTo.Location = new System.Drawing.Point(339, 2);
            this.dtmReservTo.Name = "dtmReservTo";
            this.dtmReservTo.Size = new System.Drawing.Size(127, 22);
            this.dtmReservTo.TabIndex = 2;
            this.dtmReservTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // btnSelectGuest
            // 
            this.btnSelectGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectGuest.Location = new System.Drawing.Point(371, 25);
            this.btnSelectGuest.Name = "btnSelectGuest";
            this.btnSelectGuest.Size = new System.Drawing.Size(96, 24);
            this.btnSelectGuest.TabIndex = 6;
            this.btnSelectGuest.Text = "Select Guest";
            this.btnSelectGuest.UseVisualStyleBackColor = true;
            this.btnSelectGuest.Click += new System.EventHandler(this.btnSelectGuest_Click);
            // 
            // btnAddGuest
            // 
            this.btnAddGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddGuest.Location = new System.Drawing.Point(273, 25);
            this.btnAddGuest.Name = "btnAddGuest";
            this.btnAddGuest.Size = new System.Drawing.Size(96, 24);
            this.btnAddGuest.TabIndex = 5;
            this.btnAddGuest.Text = "Add Guest";
            this.btnAddGuest.UseVisualStyleBackColor = true;
            this.btnAddGuest.Click += new System.EventHandler(this.btnAddGuest_Click);
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.Color.White;
            this.txtCustName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.Location = new System.Drawing.Point(72, 51);
            this.txtCustName.MaxLength = 40000;
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(394, 22);
            this.txtCustName.TabIndex = 4;
            this.txtCustName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            this.txtCustName.Leave += new System.EventHandler(this.txtCustName_Leave);
            // 
            // cmbTitle
            // 
            this.cmbTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTitle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Location = new System.Drawing.Point(9, 51);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(59, 22);
            this.cmbTitle.TabIndex = 3;
            this.cmbTitle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntryNo_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 14);
            this.label2.TabIndex = 58;
            this.label2.Text = "Add";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnSearch);
            this.splitContainer1.Panel2.Controls.Add(this.btnMemo);
            this.splitContainer1.Panel2.Controls.Add(this.btnReceipt);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpenByEntryNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnExit);
            this.splitContainer1.Panel2.Controls.Add(this.btnFirst);
            this.splitContainer1.Panel2.Controls.Add(this.btnRefersh);
            this.splitContainer1.Panel2.Controls.Add(this.btnLast);
            this.splitContainer1.Panel2.Controls.Add(this.btnNext);
            this.splitContainer1.Panel2.Controls.Add(this.btnPrev);
            this.splitContainer1.Panel2.Controls.Add(this.btnEstimate);
            this.splitContainer1.Panel2.Controls.Add(this.btnSave);
            this.splitContainer1.Panel2.Controls.Add(this.btnEdit);
            this.splitContainer1.Panel2.Controls.Add(this.btnUndo);
            this.splitContainer1.Panel2.Controls.Add(this.btnAddNew);
            this.splitContainer1.Size = new System.Drawing.Size(886, 616);
            this.splitContainer1.SplitterDistance = 541;
            this.splitContainer1.TabIndex = 1;
            // 
            // frmHostelReserv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 616);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmHostelReserv";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmHostelReserv";
            this.Load += new System.EventHandler(this.frmHostelReserv_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdReservDetails)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.TextBox txtEntryNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnMemo;
        private System.Windows.Forms.Button btnReceipt;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnOpenByEntryNo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnRefersh;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnEstimate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Label lblRecepDesc3;
        private System.Windows.Forms.Label lblRecepDesc2;
        private System.Windows.Forms.Label lblRecepDesc1;
        private System.Windows.Forms.Label lblRecepDesc0;
        private System.Windows.Forms.Label lblReceiptNo3;
        private System.Windows.Forms.TextBox txtReceipt3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtmTodate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtmFromDate;
        private System.Windows.Forms.Label lblReceiptNo2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblTotalReceipt;
        private System.Windows.Forms.Label lblCustStatus;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtReceipt2;
        private System.Windows.Forms.Label lblReceiptNo1;
        private System.Windows.Forms.TextBox txtReceipt1;
        private System.Windows.Forms.Label lblReceiptAmt0;
        private System.Windows.Forms.TextBox txtReceipt0;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtmReservTo;
        private System.Windows.Forms.Button btnSelectGuest;
        private System.Windows.Forms.Button btnAddGuest;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.ComboBox cmbTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtNoRoom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbDorm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtNoBeds;
        private System.Windows.Forms.TextBox txtUpto;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtRoomFolioNo;
        private System.Windows.Forms.Label lblResrvStatus;
        private System.Windows.Forms.Button btnRoomFolio;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtmDetUptoReserv;
        private System.Windows.Forms.DateTimePicker dtmDetFromReserv;
        private System.Windows.Forms.TextBox txtNoOfRooms;
        private System.Windows.Forms.ComboBox cmbDetDorm;
        private System.Windows.Forms.TextBox txtNoOfBeds;
        private System.Windows.Forms.TextBox txtDetRemarks;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Button btnDetRemove;
        private System.Windows.Forms.Button btnDetNew;
        private System.Windows.Forms.Button btnDetAdd;
        private System.Windows.Forms.DataGridView grdReservDetails;
        private System.Windows.Forms.TextBox txtAddress3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtDormTypeRent;
        private System.Windows.Forms.TextBox txtRoomTypeRent;
        private System.Windows.Forms.CheckBox chkServiceExmpt;
        private System.Windows.Forms.CheckBox chkServiceBundle;
        private System.Windows.Forms.ComboBox cmbRoomType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmbDormType;
        private System.Windows.Forms.ComboBox cmbDetDormType;
        private System.Windows.Forms.ComboBox cmbDetRoomType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDetDormTypeAmt;
        private System.Windows.Forms.TextBox txtDetRoomTypeAmt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCancellation;
        private System.Windows.Forms.Button BtnCancelHistory;
    }
}