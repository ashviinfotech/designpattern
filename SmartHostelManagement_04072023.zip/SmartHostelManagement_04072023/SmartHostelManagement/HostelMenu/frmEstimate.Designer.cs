﻿namespace SmartHostelManagement.Hostel
{
    partial class frmRoomEstimate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvAdvancePayementRece = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTotalCancelChrg = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.txtTotalCatering = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvCateringDetails = new System.Windows.Forms.DataGridView();
            this.label26 = new System.Windows.Forms.Label();
            this.txtCatAmount = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtCatBillNo = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.dtmCatDate = new System.Windows.Forms.DateTimePicker();
            this.btnCatRemove = new System.Windows.Forms.Button();
            this.btnCatAddChange = new System.Windows.Forms.Button();
            this.btnCatNew = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dgvCancellationCharge = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dgvCateringCancellation = new System.Windows.Forms.DataGridView();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dgvSeminarDetails = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNetAdvRece = new System.Windows.Forms.TextBox();
            this.txtTotalCatCancel = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtGstPerc = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtLuxuryTax = new System.Windows.Forms.TextBox();
            this.txtExtraHrs = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btnSRemove = new System.Windows.Forms.Button();
            this.txtPax = new System.Windows.Forms.TextBox();
            this.btnSAddChange = new System.Windows.Forms.Button();
            this.btnSNew = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dtmReservTo = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSemnRent = new System.Windows.Forms.TextBox();
            this.txtSCharge = new System.Windows.Forms.TextBox();
            this.txtTotalAmt = new System.Windows.Forms.TextBox();
            this.cmbSeminarType = new System.Windows.Forms.ComboBox();
            this.cmbSeminar = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkServiceExmpt = new System.Windows.Forms.CheckBox();
            this.btnSelectGuest = new System.Windows.Forms.Button();
            this.btnAddGuest = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.lblRoomStatus = new System.Windows.Forms.Label();
            this.txtOrderFormNo = new System.Windows.Forms.TextBox();
            this.txtEntryNo = new System.Windows.Forms.TextBox();
            this.dtmUpTo = new System.Windows.Forms.DateTimePicker();
            this.label27 = new System.Windows.Forms.Label();
            this.dtmFrom = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.txtDrawnOn = new System.Windows.Forms.TextBox();
            this.txtFolio = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.chkBillTo = new System.Windows.Forms.CheckBox();
            this.lblGuestStatus = new System.Windows.Forms.Label();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBillTo = new System.Windows.Forms.TextBox();
            this.dtmDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRoundOff = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAmountDue = new System.Windows.Forms.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnPrintTax = new System.Windows.Forms.Button();
            this.btnReceipt = new System.Windows.Forms.Button();
            this.btnOpenByReservNo = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnOpnByBillNo = new System.Windows.Forms.Button();
            this.btnOpenByEntryNo = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtNoPrint = new System.Windows.Forms.TextBox();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnSearchByBillNo = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.chkPrintPrv = new System.Windows.Forms.CheckBox();
            this.btnSetCatOrder = new System.Windows.Forms.Button();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdvancePayementRece)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCateringDetails)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCancellationCharge)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCateringCancellation)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeminarDetails)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(624, 468);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 14);
            this.label8.TabIndex = 47;
            this.label8.Text = "Catering Can.";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(608, 180);
            this.tabPage1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvAdvancePayementRece);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(602, 174);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Details of Advance/Payments/Receipts";
            // 
            // dgvAdvancePayementRece
            // 
            this.dgvAdvancePayementRece.AllowUserToAddRows = false;
            this.dgvAdvancePayementRece.AllowUserToDeleteRows = false;
            this.dgvAdvancePayementRece.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAdvancePayementRece.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvAdvancePayementRece.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdvancePayementRece.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAdvancePayementRece.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvAdvancePayementRece.Location = new System.Drawing.Point(3, 16);
            this.dgvAdvancePayementRece.MultiSelect = false;
            this.dgvAdvancePayementRece.Name = "dgvAdvancePayementRece";
            this.dgvAdvancePayementRece.ReadOnly = true;
            this.dgvAdvancePayementRece.RowHeadersVisible = false;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAdvancePayementRece.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAdvancePayementRece.ShowCellErrors = false;
            this.dgvAdvancePayementRece.ShowCellToolTips = false;
            this.dgvAdvancePayementRece.ShowEditingIcon = false;
            this.dgvAdvancePayementRece.ShowRowErrors = false;
            this.dgvAdvancePayementRece.Size = new System.Drawing.Size(596, 155);
            this.dgvAdvancePayementRece.StandardTab = true;
            this.dgvAdvancePayementRece.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(2, 366);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 37);
            this.button1.TabIndex = 82;
            this.button1.Text = "Advance /\r\nPayment /\r\nReceipt";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(628, 443);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 14);
            this.label12.TabIndex = 46;
            this.label12.Text = " Total Cancel";
            // 
            // txtTotalCancelChrg
            // 
            this.txtTotalCancelChrg.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalCancelChrg.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalCancelChrg.Location = new System.Drawing.Point(720, 439);
            this.txtTotalCancelChrg.MaxLength = 10;
            this.txtTotalCancelChrg.Name = "txtTotalCancelChrg";
            this.txtTotalCancelChrg.ReadOnly = true;
            this.txtTotalCancelChrg.Size = new System.Drawing.Size(124, 22);
            this.txtTotalCancelChrg.TabIndex = 45;
            this.txtTotalCancelChrg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalCancelChrg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(652, 492);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 14);
            this.label6.TabIndex = 43;
            this.label6.Text = " Discount";
            // 
            // txtDiscount
            // 
            this.txtDiscount.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtDiscount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.Location = new System.Drawing.Point(720, 488);
            this.txtDiscount.MaxLength = 10;
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(124, 22);
            this.txtDiscount.TabIndex = 42;
            this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            this.txtDiscount.Leave += new System.EventHandler(this.txtDiscount_Leave);
            // 
            // txtTotalCatering
            // 
            this.txtTotalCatering.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalCatering.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalCatering.Location = new System.Drawing.Point(720, 415);
            this.txtTotalCatering.MaxLength = 10;
            this.txtTotalCatering.Name = "txtTotalCatering";
            this.txtTotalCatering.ReadOnly = true;
            this.txtTotalCatering.Size = new System.Drawing.Size(124, 22);
            this.txtTotalCatering.TabIndex = 39;
            this.txtTotalCatering.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalCatering.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(608, 180);
            this.tabPage2.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSetCatOrder);
            this.groupBox2.Controls.Add(this.dgvCateringDetails);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.txtCatAmount);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.txtCatBillNo);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.dtmCatDate);
            this.groupBox2.Controls.Add(this.btnCatRemove);
            this.groupBox2.Controls.Add(this.btnCatAddChange);
            this.groupBox2.Controls.Add(this.btnCatNew);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(602, 174);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Catering Details";
            // 
            // dgvCateringDetails
            // 
            this.dgvCateringDetails.AllowUserToAddRows = false;
            this.dgvCateringDetails.AllowUserToDeleteRows = false;
            this.dgvCateringDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCateringDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvCateringDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCateringDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCateringDetails.Location = new System.Drawing.Point(1, 44);
            this.dgvCateringDetails.MultiSelect = false;
            this.dgvCateringDetails.Name = "dgvCateringDetails";
            this.dgvCateringDetails.ReadOnly = true;
            this.dgvCateringDetails.RowHeadersVisible = false;
            this.dgvCateringDetails.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCateringDetails.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvCateringDetails.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvCateringDetails.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvCateringDetails.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCateringDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCateringDetails.ShowCellErrors = false;
            this.dgvCateringDetails.ShowCellToolTips = false;
            this.dgvCateringDetails.ShowEditingIcon = false;
            this.dgvCateringDetails.ShowRowErrors = false;
            this.dgvCateringDetails.Size = new System.Drawing.Size(518, 129);
            this.dgvCateringDetails.StandardTab = true;
            this.dgvCateringDetails.TabIndex = 81;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(3, 22);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(38, 14);
            this.label26.TabIndex = 78;
            this.label26.Text = "Date";
            // 
            // txtCatAmount
            // 
            this.txtCatAmount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCatAmount.Location = new System.Drawing.Point(417, 17);
            this.txtCatAmount.MaxLength = 10;
            this.txtCatAmount.Name = "txtCatAmount";
            this.txtCatAmount.Size = new System.Drawing.Size(99, 22);
            this.txtCatAmount.TabIndex = 79;
            this.txtCatAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCatAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(355, 21);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(57, 14);
            this.label32.TabIndex = 80;
            this.label32.Text = "Amount";
            // 
            // txtCatBillNo
            // 
            this.txtCatBillNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCatBillNo.Location = new System.Drawing.Point(246, 16);
            this.txtCatBillNo.MaxLength = 10;
            this.txtCatBillNo.Name = "txtCatBillNo";
            this.txtCatBillNo.Size = new System.Drawing.Size(77, 22);
            this.txtCatBillNo.TabIndex = 79;
            this.txtCatBillNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCatBillNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(188, 20);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(54, 14);
            this.label29.TabIndex = 80;
            this.label29.Text = "Bill No.";
            // 
            // dtmCatDate
            // 
            this.dtmCatDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmCatDate.CustomFormat = "dd/MMM/yyyy";
            this.dtmCatDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmCatDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmCatDate.Location = new System.Drawing.Point(45, 17);
            this.dtmCatDate.Name = "dtmCatDate";
            this.dtmCatDate.Size = new System.Drawing.Size(106, 22);
            this.dtmCatDate.TabIndex = 77;
            // 
            // btnCatRemove
            // 
            this.btnCatRemove.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatRemove.Location = new System.Drawing.Point(524, 139);
            this.btnCatRemove.Name = "btnCatRemove";
            this.btnCatRemove.Size = new System.Drawing.Size(72, 27);
            this.btnCatRemove.TabIndex = 75;
            this.btnCatRemove.Text = "&Remove";
            this.btnCatRemove.UseVisualStyleBackColor = true;
            this.btnCatRemove.Click += new System.EventHandler(this.btnCatRemove_Click);
            // 
            // btnCatAddChange
            // 
            this.btnCatAddChange.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatAddChange.Location = new System.Drawing.Point(524, 96);
            this.btnCatAddChange.Name = "btnCatAddChange";
            this.btnCatAddChange.Size = new System.Drawing.Size(73, 37);
            this.btnCatAddChange.TabIndex = 75;
            this.btnCatAddChange.Text = "&Add/\r\nChange";
            this.btnCatAddChange.UseVisualStyleBackColor = true;
            this.btnCatAddChange.Click += new System.EventHandler(this.btnCatAddChange_Click);
            // 
            // btnCatNew
            // 
            this.btnCatNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatNew.Location = new System.Drawing.Point(524, 64);
            this.btnCatNew.Name = "btnCatNew";
            this.btnCatNew.Size = new System.Drawing.Size(73, 26);
            this.btnCatNew.TabIndex = 75;
            this.btnCatNew.Text = "&New";
            this.btnCatNew.UseVisualStyleBackColor = true;
            this.btnCatNew.Click += new System.EventHandler(this.btnCatNew_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(616, 419);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(104, 14);
            this.label24.TabIndex = 40;
            this.label24.Text = " Catering Total";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(101, 20);
            this.tabControl1.Location = new System.Drawing.Point(2, 379);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(616, 208);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 36;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(608, 180);
            this.tabPage3.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(602, 174);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Miscelleneous Details";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.Controls.Add(this.checkedListBox1);
            this.tabPage4.Controls.Add(this.listView1);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(608, 180);
            this.tabPage4.TabIndex = 3;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkedListBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(3, 3);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(602, 174);
            this.checkedListBox1.TabIndex = 1;
            // 
            // listView1
            // 
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.Location = new System.Drawing.Point(3, 3);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(602, 174);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dgvCancellationCharge);
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(608, 180);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dgvCancellationCharge
            // 
            this.dgvCancellationCharge.AllowUserToAddRows = false;
            this.dgvCancellationCharge.AllowUserToDeleteRows = false;
            this.dgvCancellationCharge.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCancellationCharge.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvCancellationCharge.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCancellationCharge.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCancellationCharge.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCancellationCharge.Location = new System.Drawing.Point(0, 0);
            this.dgvCancellationCharge.MultiSelect = false;
            this.dgvCancellationCharge.Name = "dgvCancellationCharge";
            this.dgvCancellationCharge.ReadOnly = true;
            this.dgvCancellationCharge.RowHeadersVisible = false;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCancellationCharge.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCancellationCharge.ShowCellErrors = false;
            this.dgvCancellationCharge.ShowCellToolTips = false;
            this.dgvCancellationCharge.ShowEditingIcon = false;
            this.dgvCancellationCharge.ShowRowErrors = false;
            this.dgvCancellationCharge.Size = new System.Drawing.Size(608, 180);
            this.dgvCancellationCharge.StandardTab = true;
            this.dgvCancellationCharge.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dgvCateringCancellation);
            this.tabPage6.Location = new System.Drawing.Point(4, 24);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(608, 180);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dgvCateringCancellation
            // 
            this.dgvCateringCancellation.AllowUserToAddRows = false;
            this.dgvCateringCancellation.AllowUserToDeleteRows = false;
            this.dgvCateringCancellation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCateringCancellation.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvCateringCancellation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCateringCancellation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCateringCancellation.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCateringCancellation.Location = new System.Drawing.Point(0, 0);
            this.dgvCateringCancellation.MultiSelect = false;
            this.dgvCateringCancellation.Name = "dgvCateringCancellation";
            this.dgvCateringCancellation.ReadOnly = true;
            this.dgvCateringCancellation.RowHeadersVisible = false;
            this.dgvCateringCancellation.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCateringCancellation.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvCateringCancellation.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvCateringCancellation.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvCateringCancellation.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCateringCancellation.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCateringCancellation.ShowCellErrors = false;
            this.dgvCateringCancellation.ShowCellToolTips = false;
            this.dgvCateringCancellation.ShowEditingIcon = false;
            this.dgvCateringCancellation.ShowRowErrors = false;
            this.dgvCateringCancellation.Size = new System.Drawing.Size(608, 180);
            this.dgvCateringCancellation.StandardTab = true;
            this.dgvCateringCancellation.TabIndex = 1;
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(720, 370);
            this.txtTotal.MaxLength = 10;
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(124, 22);
            this.txtTotal.TabIndex = 30;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.txtTotalCancelChrg);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtDiscount);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.txtTotalCatering);
            this.panel1.Controls.Add(this.dgvSeminarDetails);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtNetAdvRece);
            this.panel1.Controls.Add(this.txtTotalCatCancel);
            this.panel1.Controls.Add(this.txtTotal);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtRoundOff);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtAmountDue);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 589);
            this.panel1.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.AutoSize = true;
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button6.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(507, 366);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(109, 37);
            this.button6.TabIndex = 87;
            this.button6.Text = "Catering\r\nCancellation";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.AutoSize = true;
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button5.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(405, 366);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(104, 37);
            this.button5.TabIndex = 86;
            this.button5.Text = "Cancellation\r\nCharges";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(303, 366);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 37);
            this.button4.TabIndex = 85;
            this.button4.Text = "Cancelled\r\nBill";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(104, 366);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 37);
            this.button2.TabIndex = 83;
            this.button2.Text = "Catering \r\nDetails";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(202, 366);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 37);
            this.button3.TabIndex = 84;
            this.button3.Text = "Miscelleneous\r\nDetails";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvSeminarDetails
            // 
            this.dgvSeminarDetails.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.ControlDark;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSeminarDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvSeminarDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSeminarDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvSeminarDetails.Location = new System.Drawing.Point(1, 190);
            this.dgvSeminarDetails.MultiSelect = false;
            this.dgvSeminarDetails.Name = "dgvSeminarDetails";
            this.dgvSeminarDetails.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSeminarDetails.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvSeminarDetails.RowHeadersVisible = false;
            this.dgvSeminarDetails.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvSeminarDetails.RowTemplate.ReadOnly = true;
            this.dgvSeminarDetails.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSeminarDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSeminarDetails.ShowCellErrors = false;
            this.dgvSeminarDetails.ShowCellToolTips = false;
            this.dgvSeminarDetails.ShowEditingIcon = false;
            this.dgvSeminarDetails.ShowRowErrors = false;
            this.dgvSeminarDetails.Size = new System.Drawing.Size(845, 173);
            this.dgvSeminarDetails.TabIndex = 37;
            this.dgvSeminarDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSeminarDetails_CellDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(643, 540);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 14);
            this.label4.TabIndex = 35;
            this.label4.Text = " Round Off";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(616, 516);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 14);
            this.label3.TabIndex = 34;
            this.label3.Text = " Net Adv. recd.";
            // 
            // txtNetAdvRece
            // 
            this.txtNetAdvRece.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtNetAdvRece.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNetAdvRece.Location = new System.Drawing.Point(720, 512);
            this.txtNetAdvRece.MaxLength = 10;
            this.txtNetAdvRece.Name = "txtNetAdvRece";
            this.txtNetAdvRece.ReadOnly = true;
            this.txtNetAdvRece.Size = new System.Drawing.Size(124, 22);
            this.txtNetAdvRece.TabIndex = 33;
            this.txtNetAdvRece.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNetAdvRece.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // txtTotalCatCancel
            // 
            this.txtTotalCatCancel.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalCatCancel.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalCatCancel.Location = new System.Drawing.Point(720, 463);
            this.txtTotalCatCancel.MaxLength = 10;
            this.txtTotalCatCancel.Name = "txtTotalCatCancel";
            this.txtTotalCatCancel.ReadOnly = true;
            this.txtTotalCatCancel.Size = new System.Drawing.Size(124, 22);
            this.txtTotalCatCancel.TabIndex = 32;
            this.txtTotalCatCancel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalCatCancel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.txtGstPerc);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.txtLuxuryTax);
            this.panel3.Controls.Add(this.txtExtraHrs);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.btnSRemove);
            this.panel3.Controls.Add(this.txtPax);
            this.panel3.Controls.Add(this.btnSAddChange);
            this.panel3.Controls.Add(this.btnSNew);
            this.panel3.Controls.Add(this.label31);
            this.panel3.Controls.Add(this.label30);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.dtmReservTo);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.txtSemnRent);
            this.panel3.Controls.Add(this.txtSCharge);
            this.panel3.Controls.Add(this.txtTotalAmt);
            this.panel3.Controls.Add(this.cmbSeminarType);
            this.panel3.Controls.Add(this.cmbSeminar);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Location = new System.Drawing.Point(1, 112);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(845, 79);
            this.panel3.TabIndex = 29;
            // 
            // txtGstPerc
            // 
            this.txtGstPerc.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGstPerc.Location = new System.Drawing.Point(229, 51);
            this.txtGstPerc.MaxLength = 10;
            this.txtGstPerc.Name = "txtGstPerc";
            this.txtGstPerc.Size = new System.Drawing.Size(88, 22);
            this.txtGstPerc.TabIndex = 81;
            this.txtGstPerc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGstPerc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(162, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 14);
            this.label11.TabIndex = 82;
            this.label11.Text = "GST (%)";
            // 
            // txtLuxuryTax
            // 
            this.txtLuxuryTax.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuxuryTax.Location = new System.Drawing.Point(485, 24);
            this.txtLuxuryTax.MaxLength = 10;
            this.txtLuxuryTax.Name = "txtLuxuryTax";
            this.txtLuxuryTax.Size = new System.Drawing.Size(86, 22);
            this.txtLuxuryTax.TabIndex = 79;
            this.txtLuxuryTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLuxuryTax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // txtExtraHrs
            // 
            this.txtExtraHrs.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtraHrs.Location = new System.Drawing.Point(483, 51);
            this.txtExtraHrs.MaxLength = 10;
            this.txtExtraHrs.Name = "txtExtraHrs";
            this.txtExtraHrs.Size = new System.Drawing.Size(88, 22);
            this.txtExtraHrs.TabIndex = 79;
            this.txtExtraHrs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtExtraHrs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(414, 55);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 14);
            this.label20.TabIndex = 80;
            this.label20.Text = "Extra Hrs";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(482, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 14);
            this.label19.TabIndex = 80;
            this.label19.Text = "Luxuary Tax";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(782, 5);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 14);
            this.label18.TabIndex = 78;
            this.label18.Text = "PAX";
            // 
            // btnSRemove
            // 
            this.btnSRemove.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSRemove.Location = new System.Drawing.Point(764, 51);
            this.btnSRemove.Name = "btnSRemove";
            this.btnSRemove.Size = new System.Drawing.Size(77, 22);
            this.btnSRemove.TabIndex = 76;
            this.btnSRemove.Text = "&Remove";
            this.btnSRemove.UseVisualStyleBackColor = true;
            this.btnSRemove.Click += new System.EventHandler(this.btnSRemove_Click);
            // 
            // txtPax
            // 
            this.txtPax.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPax.Location = new System.Drawing.Point(779, 24);
            this.txtPax.MaxLength = 10;
            this.txtPax.Name = "txtPax";
            this.txtPax.Size = new System.Drawing.Size(61, 22);
            this.txtPax.TabIndex = 77;
            this.txtPax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // btnSAddChange
            // 
            this.btnSAddChange.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSAddChange.Location = new System.Drawing.Point(658, 51);
            this.btnSAddChange.Name = "btnSAddChange";
            this.btnSAddChange.Size = new System.Drawing.Size(104, 22);
            this.btnSAddChange.TabIndex = 75;
            this.btnSAddChange.Text = "&Add/Change";
            this.btnSAddChange.UseVisualStyleBackColor = true;
            this.btnSAddChange.Click += new System.EventHandler(this.btnSAddChange_Click);
            // 
            // btnSNew
            // 
            this.btnSNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSNew.Location = new System.Drawing.Point(581, 51);
            this.btnSNew.Name = "btnSNew";
            this.btnSNew.Size = new System.Drawing.Size(75, 22);
            this.btnSNew.TabIndex = 74;
            this.btnSNew.Text = "&New";
            this.btnSNew.UseVisualStyleBackColor = true;
            this.btnSNew.Click += new System.EventHandler(this.btnSNew_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(707, 5);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(70, 14);
            this.label31.TabIndex = 73;
            this.label31.Text = "Total Amt";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(108, 3);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(80, 14);
            this.label30.TabIndex = 72;
            this.label30.Text = "Room Type";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 14);
            this.label5.TabIndex = 19;
            this.label5.Text = "Date";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(383, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 14);
            this.label15.TabIndex = 68;
            this.label15.Text = "Room Rent";
            // 
            // dtmReservTo
            // 
            this.dtmReservTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmReservTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmReservTo.Location = new System.Drawing.Point(50, 49);
            this.dtmReservTo.Name = "dtmReservTo";
            this.dtmReservTo.Size = new System.Drawing.Size(106, 22);
            this.dtmReservTo.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(572, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 14);
            this.label9.TabIndex = 65;
            this.label9.Text = "GST";
            // 
            // txtSemnRent
            // 
            this.txtSemnRent.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSemnRent.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSemnRent.Location = new System.Drawing.Point(382, 24);
            this.txtSemnRent.MaxLength = 10;
            this.txtSemnRent.Name = "txtSemnRent";
            this.txtSemnRent.Size = new System.Drawing.Size(101, 22);
            this.txtSemnRent.TabIndex = 61;
            this.txtSemnRent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSemnRent.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // txtSCharge
            // 
            this.txtSCharge.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSCharge.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSCharge.Location = new System.Drawing.Point(573, 24);
            this.txtSCharge.MaxLength = 10;
            this.txtSCharge.Name = "txtSCharge";
            this.txtSCharge.ReadOnly = true;
            this.txtSCharge.Size = new System.Drawing.Size(102, 22);
            this.txtSCharge.TabIndex = 58;
            this.txtSCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // txtTotalAmt
            // 
            this.txtTotalAmt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalAmt.Location = new System.Drawing.Point(677, 24);
            this.txtTotalAmt.MaxLength = 10;
            this.txtTotalAmt.Name = "txtTotalAmt";
            this.txtTotalAmt.ReadOnly = true;
            this.txtTotalAmt.Size = new System.Drawing.Size(100, 22);
            this.txtTotalAmt.TabIndex = 57;
            this.txtTotalAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // cmbSeminarType
            // 
            this.cmbSeminarType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSeminarType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSeminarType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSeminarType.FormattingEnabled = true;
            this.cmbSeminarType.Location = new System.Drawing.Point(105, 24);
            this.cmbSeminarType.Name = "cmbSeminarType";
            this.cmbSeminarType.Size = new System.Drawing.Size(274, 22);
            this.cmbSeminarType.TabIndex = 37;
            this.cmbSeminarType.SelectedIndexChanged += new System.EventHandler(this.cmbSeminarType_SelectedIndexChanged);
            // 
            // cmbSeminar
            // 
            this.cmbSeminar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSeminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSeminar.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSeminar.FormattingEnabled = true;
            this.cmbSeminar.Location = new System.Drawing.Point(4, 24);
            this.cmbSeminar.Name = "cmbSeminar";
            this.cmbSeminar.Size = new System.Drawing.Size(97, 22);
            this.cmbSeminar.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1, 5);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 14);
            this.label17.TabIndex = 29;
            this.label17.Text = "Room";
            // 
            // panel2
            // 
            this.panel2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.chkServiceExmpt);
            this.panel2.Controls.Add(this.btnSelectGuest);
            this.panel2.Controls.Add(this.btnAddGuest);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.lblRoomStatus);
            this.panel2.Controls.Add(this.txtOrderFormNo);
            this.panel2.Controls.Add(this.txtEntryNo);
            this.panel2.Controls.Add(this.dtmUpTo);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.dtmFrom);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.txtRemarks);
            this.panel2.Controls.Add(this.txtDrawnOn);
            this.panel2.Controls.Add(this.txtFolio);
            this.panel2.Controls.Add(this.txtAddress2);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.txtAddress);
            this.panel2.Controls.Add(this.chkBillTo);
            this.panel2.Controls.Add(this.lblGuestStatus);
            this.panel2.Controls.Add(this.txtCustName);
            this.panel2.Controls.Add(this.cmbTitle);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtBillTo);
            this.panel2.Controls.Add(this.dtmDate);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Location = new System.Drawing.Point(1, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(845, 112);
            this.panel2.TabIndex = 28;
            // 
            // chkServiceExmpt
            // 
            this.chkServiceExmpt.BackColor = System.Drawing.Color.Red;
            this.chkServiceExmpt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkServiceExmpt.Location = new System.Drawing.Point(388, 82);
            this.chkServiceExmpt.Name = "chkServiceExmpt";
            this.chkServiceExmpt.Size = new System.Drawing.Size(123, 21);
            this.chkServiceExmpt.TabIndex = 129;
            this.chkServiceExmpt.Text = "GST Exempted";
            this.chkServiceExmpt.UseCompatibleTextRendering = true;
            this.chkServiceExmpt.UseVisualStyleBackColor = false;
            // 
            // btnSelectGuest
            // 
            this.btnSelectGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectGuest.Location = new System.Drawing.Point(288, 80);
            this.btnSelectGuest.Name = "btnSelectGuest";
            this.btnSelectGuest.Size = new System.Drawing.Size(96, 24);
            this.btnSelectGuest.TabIndex = 59;
            this.btnSelectGuest.Text = "Select Guest";
            this.btnSelectGuest.UseVisualStyleBackColor = true;
            this.btnSelectGuest.Click += new System.EventHandler(this.btnSelectGuest_Click);
            // 
            // btnAddGuest
            // 
            this.btnAddGuest.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddGuest.Location = new System.Drawing.Point(288, 55);
            this.btnAddGuest.Name = "btnAddGuest";
            this.btnAddGuest.Size = new System.Drawing.Size(96, 24);
            this.btnAddGuest.TabIndex = 58;
            this.btnAddGuest.Text = "Add Guest";
            this.btnAddGuest.UseVisualStyleBackColor = true;
            this.btnAddGuest.Click += new System.EventHandler(this.btnAddGuest_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(735, 69);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 14);
            this.label28.TabIndex = 57;
            this.label28.Text = "Order Frm No.";
            // 
            // lblRoomStatus
            // 
            this.lblRoomStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblRoomStatus.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomStatus.Location = new System.Drawing.Point(609, 79);
            this.lblRoomStatus.Name = "lblRoomStatus";
            this.lblRoomStatus.Size = new System.Drawing.Size(116, 27);
            this.lblRoomStatus.TabIndex = 38;
            this.lblRoomStatus.Text = "Check-Out";
            this.lblRoomStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrderFormNo
            // 
            this.txtOrderFormNo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtOrderFormNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderFormNo.Location = new System.Drawing.Point(729, 83);
            this.txtOrderFormNo.MaxLength = 10;
            this.txtOrderFormNo.Name = "txtOrderFormNo";
            this.txtOrderFormNo.ReadOnly = true;
            this.txtOrderFormNo.Size = new System.Drawing.Size(109, 22);
            this.txtOrderFormNo.TabIndex = 56;
            this.txtOrderFormNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrderFormNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // txtEntryNo
            // 
            this.txtEntryNo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryNo.Location = new System.Drawing.Point(729, 44);
            this.txtEntryNo.MaxLength = 10;
            this.txtEntryNo.Name = "txtEntryNo";
            this.txtEntryNo.ReadOnly = true;
            this.txtEntryNo.Size = new System.Drawing.Size(109, 22);
            this.txtEntryNo.TabIndex = 55;
            this.txtEntryNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEntryNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // dtmUpTo
            // 
            this.dtmUpTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmUpTo.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmUpTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmUpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmUpTo.Location = new System.Drawing.Point(517, 55);
            this.dtmUpTo.Name = "dtmUpTo";
            this.dtmUpTo.ShowCheckBox = true;
            this.dtmUpTo.Size = new System.Drawing.Size(201, 22);
            this.dtmUpTo.TabIndex = 54;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(476, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(38, 14);
            this.label27.TabIndex = 53;
            this.label27.Text = "Upto";
            // 
            // dtmFrom
            // 
            this.dtmFrom.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFrom.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmFrom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmFrom.Location = new System.Drawing.Point(517, 29);
            this.dtmFrom.Name = "dtmFrom";
            this.dtmFrom.ShowCheckBox = true;
            this.dtmFrom.Size = new System.Drawing.Size(201, 22);
            this.dtmFrom.TabIndex = 52;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(473, 34);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 14);
            this.label22.TabIndex = 51;
            this.label22.Text = "From";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(1, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 14);
            this.label21.TabIndex = 50;
            this.label21.Text = "Remarks";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(68, 30);
            this.txtRemarks.MaxLength = 40000;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(400, 22);
            this.txtRemarks.TabIndex = 49;
            // 
            // txtDrawnOn
            // 
            this.txtDrawnOn.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDrawnOn.Location = new System.Drawing.Point(68, 30);
            this.txtDrawnOn.MaxLength = 40000;
            this.txtDrawnOn.Name = "txtDrawnOn";
            this.txtDrawnOn.Size = new System.Drawing.Size(389, 22);
            this.txtDrawnOn.TabIndex = 49;
            // 
            // txtFolio
            // 
            this.txtFolio.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtFolio.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFolio.Location = new System.Drawing.Point(517, 4);
            this.txtFolio.MaxLength = 10;
            this.txtFolio.Name = "txtFolio";
            this.txtFolio.ReadOnly = true;
            this.txtFolio.Size = new System.Drawing.Size(95, 22);
            this.txtFolio.TabIndex = 47;
            this.txtFolio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(4, 80);
            this.txtAddress2.MaxLength = 40000;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(283, 22);
            this.txtAddress2.TabIndex = 46;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1, 59);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 14);
            this.label16.TabIndex = 43;
            this.label16.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(67, 55);
            this.txtAddress.MaxLength = 40000;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ReadOnly = true;
            this.txtAddress.Size = new System.Drawing.Size(220, 22);
            this.txtAddress.TabIndex = 42;
            // 
            // chkBillTo
            // 
            this.chkBillTo.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chkBillTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBillTo.Location = new System.Drawing.Point(270, 4);
            this.chkBillTo.Name = "chkBillTo";
            this.chkBillTo.Size = new System.Drawing.Size(65, 19);
            this.chkBillTo.TabIndex = 39;
            this.chkBillTo.Text = "Bill To";
            this.chkBillTo.UseCompatibleTextRendering = true;
            this.chkBillTo.UseVisualStyleBackColor = true;
            // 
            // lblGuestStatus
            // 
            this.lblGuestStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblGuestStatus.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuestStatus.Location = new System.Drawing.Point(521, 80);
            this.lblGuestStatus.Name = "lblGuestStatus";
            this.lblGuestStatus.Size = new System.Drawing.Size(82, 26);
            this.lblGuestStatus.TabIndex = 34;
            this.lblGuestStatus.Text = "Regular";
            this.lblGuestStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCustName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.Location = new System.Drawing.Point(68, 4);
            this.txtCustName.MaxLength = 40000;
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.ReadOnly = true;
            this.txtCustName.Size = new System.Drawing.Size(195, 22);
            this.txtCustName.TabIndex = 33;
            // 
            // cmbTitle
            // 
            this.cmbTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTitle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Location = new System.Drawing.Point(4, 4);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(59, 22);
            this.cmbTitle.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(751, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 14);
            this.label7.TabIndex = 29;
            this.label7.Text = "Entry No.";
            // 
            // txtBillTo
            // 
            this.txtBillTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillTo.Location = new System.Drawing.Point(335, 4);
            this.txtBillTo.MaxLength = 300;
            this.txtBillTo.Name = "txtBillTo";
            this.txtBillTo.Size = new System.Drawing.Size(117, 22);
            this.txtBillTo.TabIndex = 28;
            // 
            // dtmDate
            // 
            this.dtmDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDate.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmDate.Location = new System.Drawing.Point(655, 4);
            this.dtmDate.Name = "dtmDate";
            this.dtmDate.Size = new System.Drawing.Size(185, 22);
            this.dtmDate.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(614, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 14);
            this.label10.TabIndex = 16;
            this.label10.Text = "Date";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(453, 7);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 14);
            this.label23.TabIndex = 48;
            this.label23.Text = "ESTM No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(665, 374);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 14);
            this.label2.TabIndex = 12;
            this.label2.Text = " TOTAL";
            // 
            // txtRoundOff
            // 
            this.txtRoundOff.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtRoundOff.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoundOff.Location = new System.Drawing.Point(720, 536);
            this.txtRoundOff.MaxLength = 10;
            this.txtRoundOff.Name = "txtRoundOff";
            this.txtRoundOff.ReadOnly = true;
            this.txtRoundOff.Size = new System.Drawing.Size(124, 22);
            this.txtRoundOff.TabIndex = 11;
            this.txtRoundOff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRoundOff.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(629, 565);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 14);
            this.label1.TabIndex = 10;
            this.label1.Text = " Amount Due";
            // 
            // txtAmountDue
            // 
            this.txtAmountDue.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAmountDue.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmountDue.Location = new System.Drawing.Point(720, 560);
            this.txtAmountDue.MaxLength = 10;
            this.txtAmountDue.Name = "txtAmountDue";
            this.txtAmountDue.ReadOnly = true;
            this.txtAmountDue.Size = new System.Drawing.Size(124, 22);
            this.txtAmountDue.TabIndex = 9;
            this.txtAmountDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAmountDue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIsDigit_KeyPress);
            // 
            // splitContainer1
            // 
            this.splitContainer1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.splitContainer1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.splitContainer1.Panel2.Controls.Add(this.btnPrintTax);
            this.splitContainer1.Panel2.Controls.Add(this.btnReceipt);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpenByReservNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpnByBillNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpenByEntryNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnExit);
            this.splitContainer1.Panel2.Controls.Add(this.txtNoPrint);
            this.splitContainer1.Panel2.Controls.Add(this.btnFirst);
            this.splitContainer1.Panel2.Controls.Add(this.btnSearchByBillNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnLast);
            this.splitContainer1.Panel2.Controls.Add(this.btnNext);
            this.splitContainer1.Panel2.Controls.Add(this.btnPrev);
            this.splitContainer1.Panel2.Controls.Add(this.btnPrint);
            this.splitContainer1.Panel2.Controls.Add(this.btnSave);
            this.splitContainer1.Panel2.Controls.Add(this.btnEdit);
            this.splitContainer1.Panel2.Controls.Add(this.btnUndo);
            this.splitContainer1.Panel2.Controls.Add(this.btnAddNew);
            this.splitContainer1.Panel2.Controls.Add(this.chkPrintPrv);
            this.splitContainer1.Size = new System.Drawing.Size(849, 658);
            this.splitContainer1.SplitterDistance = 589;
            this.splitContainer1.TabIndex = 3;
            // 
            // btnPrintTax
            // 
            this.btnPrintTax.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintTax.Location = new System.Drawing.Point(401, 33);
            this.btnPrintTax.Name = "btnPrintTax";
            this.btnPrintTax.Size = new System.Drawing.Size(81, 27);
            this.btnPrintTax.TabIndex = 80;
            this.btnPrintTax.Text = "History";
            this.btnPrintTax.UseVisualStyleBackColor = true;
            this.btnPrintTax.Click += new System.EventHandler(this.btnPrintTax_Click);
            // 
            // btnReceipt
            // 
            this.btnReceipt.AutoSize = true;
            this.btnReceipt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReceipt.Location = new System.Drawing.Point(770, 5);
            this.btnReceipt.Name = "btnReceipt";
            this.btnReceipt.Size = new System.Drawing.Size(77, 27);
            this.btnReceipt.TabIndex = 19;
            this.btnReceipt.Text = "Receipts";
            this.btnReceipt.UseVisualStyleBackColor = true;
            this.btnReceipt.Click += new System.EventHandler(this.btnReceipt_Click);
            // 
            // btnOpenByReservNo
            // 
            this.btnOpenByReservNo.AutoSize = true;
            this.btnOpenByReservNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenByReservNo.Location = new System.Drawing.Point(620, 34);
            this.btnOpenByReservNo.Name = "btnOpenByReservNo";
            this.btnOpenByReservNo.Size = new System.Drawing.Size(145, 27);
            this.btnOpenByReservNo.TabIndex = 18;
            this.btnOpenByReservNo.Text = "Open By Reserv No";
            this.btnOpenByReservNo.UseVisualStyleBackColor = true;
            this.btnOpenByReservNo.Click += new System.EventHandler(this.btnOpenByReservNo_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(320, 5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(81, 27);
            this.btnDelete.TabIndex = 16;
            this.btnDelete.Text = "Cancel";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnOpnByBillNo
            // 
            this.btnOpnByBillNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpnByBillNo.Location = new System.Drawing.Point(484, 34);
            this.btnOpnByBillNo.Name = "btnOpnByBillNo";
            this.btnOpnByBillNo.Size = new System.Drawing.Size(134, 27);
            this.btnOpnByBillNo.TabIndex = 13;
            this.btnOpnByBillNo.Text = "Open By Bill No";
            this.btnOpnByBillNo.UseVisualStyleBackColor = true;
            this.btnOpnByBillNo.Click += new System.EventHandler(this.btnOpnByBillNo_Click);
            // 
            // btnOpenByEntryNo
            // 
            this.btnOpenByEntryNo.AutoSize = true;
            this.btnOpenByEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenByEntryNo.Location = new System.Drawing.Point(401, 5);
            this.btnOpenByEntryNo.Name = "btnOpenByEntryNo";
            this.btnOpenByEntryNo.Size = new System.Drawing.Size(134, 27);
            this.btnOpenByEntryNo.TabIndex = 17;
            this.btnOpenByEntryNo.Text = "Open By Entry No";
            this.btnOpenByEntryNo.UseVisualStyleBackColor = true;
            this.btnOpenByEntryNo.Click += new System.EventHandler(this.btnOpenByEntryNo_Click);
            // 
            // btnExit
            // 
            this.btnExit.AutoSize = true;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(769, 34);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(78, 27);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtNoPrint
            // 
            this.txtNoPrint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoPrint.Location = new System.Drawing.Point(175, 35);
            this.txtNoPrint.MaxLength = 10;
            this.txtNoPrint.Name = "txtNoPrint";
            this.txtNoPrint.Size = new System.Drawing.Size(35, 22);
            this.txtNoPrint.TabIndex = 79;
            this.txtNoPrint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnFirst
            // 
            this.btnFirst.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(536, 5);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(56, 27);
            this.btnFirst.TabIndex = 12;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnSearchByBillNo
            // 
            this.btnSearchByBillNo.AutoSize = true;
            this.btnSearchByBillNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchByBillNo.Location = new System.Drawing.Point(174, 6);
            this.btnSearchByBillNo.Name = "btnSearchByBillNo";
            this.btnSearchByBillNo.Size = new System.Drawing.Size(144, 27);
            this.btnSearchByBillNo.TabIndex = 14;
            this.btnSearchByBillNo.Text = "Search By Bill No";
            this.btnSearchByBillNo.UseVisualStyleBackColor = true;
            this.btnSearchByBillNo.Click += new System.EventHandler(this.btnSearchByBillNo_Click);
            // 
            // btnLast
            // 
            this.btnLast.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.Location = new System.Drawing.Point(713, 6);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(54, 27);
            this.btnLast.TabIndex = 11;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(654, 6);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(56, 27);
            this.btnNext.TabIndex = 10;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrev.Location = new System.Drawing.Point(595, 6);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(56, 27);
            this.btnPrev.TabIndex = 9;
            this.btnPrev.Text = "<";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(320, 33);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(81, 27);
            this.btnPrint.TabIndex = 5;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(91, 33);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 27);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(91, 5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(81, 27);
            this.btnEdit.TabIndex = 3;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnUndo
            // 
            this.btnUndo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUndo.Location = new System.Drawing.Point(3, 34);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(89, 26);
            this.btnUndo.TabIndex = 2;
            this.btnUndo.Text = "Undo";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNew.Location = new System.Drawing.Point(3, 6);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(89, 27);
            this.btnAddNew.TabIndex = 1;
            this.btnAddNew.Text = "Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // chkPrintPrv
            // 
            this.chkPrintPrv.AutoSize = true;
            this.chkPrintPrv.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chkPrintPrv.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPrintPrv.Location = new System.Drawing.Point(213, 37);
            this.chkPrintPrv.Name = "chkPrintPrv";
            this.chkPrintPrv.Size = new System.Drawing.Size(119, 19);
            this.chkPrintPrv.TabIndex = 7;
            this.chkPrintPrv.Text = "Print Priview";
            this.chkPrintPrv.UseCompatibleTextRendering = true;
            this.chkPrintPrv.UseVisualStyleBackColor = true;
            // 
            // btnSetCatOrder
            // 
            this.btnSetCatOrder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetCatOrder.Location = new System.Drawing.Point(524, 14);
            this.btnSetCatOrder.Name = "btnSetCatOrder";
            this.btnSetCatOrder.Size = new System.Drawing.Size(73, 26);
            this.btnSetCatOrder.TabIndex = 82;
            this.btnSetCatOrder.Text = "&New";
            this.btnSetCatOrder.UseVisualStyleBackColor = true;
            this.btnSetCatOrder.Click += new System.EventHandler(this.btnSetCatOrder_Click);
            // 
            // frmRoomEstimate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 658);
            this.Controls.Add(this.splitContainer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRoomEstimate";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmSeminarEstimate";
            this.Load += new System.EventHandler(this.frmSeminarEstimate_Load);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdvancePayementRece)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCateringDetails)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCancellationCharge)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCateringCancellation)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeminarDetails)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvAdvancePayementRece;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtTotalCancelChrg;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.TextBox txtTotalCatering;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtCatAmount;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtCatBillNo;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DateTimePicker dtmCatDate;
        private System.Windows.Forms.Button btnCatRemove;
        private System.Windows.Forms.Button btnCatAddChange;
        private System.Windows.Forms.Button btnCatNew;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvSeminarDetails;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNetAdvRece;
        private System.Windows.Forms.TextBox txtTotalCatCancel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtGstPerc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtLuxuryTax;
        private System.Windows.Forms.TextBox txtExtraHrs;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnSRemove;
        private System.Windows.Forms.TextBox txtPax;
        private System.Windows.Forms.Button btnSAddChange;
        private System.Windows.Forms.Button btnSNew;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtmReservTo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSemnRent;
        private System.Windows.Forms.TextBox txtSCharge;
        private System.Windows.Forms.TextBox txtTotalAmt;
        private System.Windows.Forms.ComboBox cmbSeminarType;
        private System.Windows.Forms.ComboBox cmbSeminar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkServiceExmpt;
        private System.Windows.Forms.Button btnSelectGuest;
        private System.Windows.Forms.Button btnAddGuest;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblRoomStatus;
        private System.Windows.Forms.TextBox txtOrderFormNo;
        private System.Windows.Forms.TextBox txtEntryNo;
        private System.Windows.Forms.DateTimePicker dtmUpTo;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DateTimePicker dtmFrom;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.TextBox txtDrawnOn;
        private System.Windows.Forms.TextBox txtFolio;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.CheckBox chkBillTo;
        private System.Windows.Forms.Label lblGuestStatus;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.ComboBox cmbTitle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBillTo;
        private System.Windows.Forms.DateTimePicker dtmDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRoundOff;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAmountDue;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnPrintTax;
        private System.Windows.Forms.Button btnReceipt;
        private System.Windows.Forms.Button btnOpenByReservNo;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnOpnByBillNo;
        private System.Windows.Forms.Button btnOpenByEntryNo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtNoPrint;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnSearchByBillNo;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.CheckBox chkPrintPrv;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dgvCateringDetails;
        private System.Windows.Forms.DataGridView dgvCancellationCharge;
        private System.Windows.Forms.DataGridView dgvCateringCancellation;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Button btnSetCatOrder;
    }
}