﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Master
{
    public partial class frmNationality : Form
    {
        MasterCaller objMaster = new MasterCaller();
        EL.Masternationality objMasterNational { get; set; }

        public frmNationality()
        {
            InitializeComponent();
        }

        private void frmNationality_Load(object sender, EventArgs e)
        {
            BindGridview();
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (datagrdiview.SelectedRows.Count > 0)
                {
                    DataGridViewRow dr = datagrdiview.SelectedRows[0];
                    int miscid = Convert.ToInt32(dr.Cells["Nationalityid"].Value);
                    this.objMasterNational = objMaster.GetNationalityMaster().FirstOrDefault(x => x.Nationalityid == miscid);
                    txtNationality.Text = objMasterNational.Nationality;
                    chkForeginNationality.Checked = objMasterNational.Foreigner.HasValue ? objMasterNational.Foreigner.Value : false; 
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in select data");
            }
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            objMasterNational = null;
            txtNationality.Text = string.Empty;
            chkForeginNationality.Checked = false;
            BindGridview();
        }
        
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtNationality.Text.Trim()))
                {
                    bool isNew = false;

                    if (objMasterNational != null)
                        isNew = false;
                    else
                    {
                        isNew = true;
                        objMasterNational = new EL.Masternationality();
                        objMasterNational.noofvisitors = 0;
                    }

                    objMasterNational.Nationality = txtNationality.Text.Trim();
                    objMasterNational.Foreigner = chkForeginNationality.Checked;

                    if (objMaster.SaveUpdateDeleteNationalityMaster(objMasterNational, isNew, false))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        void BindGridview()
        {
            try
            {
                IList<EL.Masternationality> lstNational = !string.IsNullOrEmpty(txtNationality.Text) ? objMaster.GetNationalityMaster()
                    .Where(x => x.Nationality.ToUpper().Contains(txtNationality.Text.ToUpper())).ToList() :
                    objMaster.GetNationalityMaster().ToList();

                var dbdata = lstNational.Select((c, index) =>
                new
                {
                    c.Nationalityid,
                    SlNo = index + 1,
                    c.Nationality,
                    Foreigner_Nationality = c.Foreigner.HasValue && c.Foreigner.Value ? "Foreigner" : string.Empty
                }).OrderBy(x => x.Nationality);

                datagrdiview.DataSource = dbdata.ToList();
                datagrdiview.Columns["Nationalityid"].Visible = false;
                datagrdiview.Columns["SlNo"].Width = 100;
                datagrdiview.Columns["Nationality"].Width = 150;
                datagrdiview.Columns["Foreigner_Nationality"].Width = 250;
                
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "BindGridview");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            BindGridview();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Nationality ?") == System.Windows.Forms.DialogResult.Yes)
                {
                    if (objMaster.SaveUpdateDeleteNationalityMaster(objMasterNational, false, true))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnExit_Click(object sender, FormClosingEventArgs e)
        {
        }
    }
}
