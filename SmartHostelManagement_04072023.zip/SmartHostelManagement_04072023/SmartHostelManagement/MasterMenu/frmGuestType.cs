﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Master
{
    public partial class frmGuestType : Form
    {
        MasterCaller objMaster = new MasterCaller();
        EL.MastGuestType objGuestType { get; set; }

        public frmGuestType()
        {
            InitializeComponent();
        }

        private void frmTitleMaster_Load(object sender, EventArgs e)
        {
            BindGridview();
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            txtGuestType.Text = string.Empty;
            txtGuestTypeCode.Text = string.Empty;
            BindGridview();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtGuestTypeCode.Text.Trim()))
                {
                    bool isNew = objGuestType != null ? false : true;
                    if (objGuestType != null)
                    {
                        objGuestType.id1 = SmartHostelManagement.Windows.Frm_Login.UserLogin.log_id;
                        objGuestType.date_of_mod = DateTime.Now;
                    }
                    else
                    {
                        objGuestType = new EL.MastGuestType();
                        objGuestType.id = SmartHostelManagement.Windows.Frm_Login.UserLogin.log_id;
                        objGuestType.date_of_add = DateTime.Now;
                    }
                    objGuestType.GT_CODE = txtGuestTypeCode.Text.Trim();
                    objGuestType.GT_TYPE = txtGuestType.Text.Trim();

                    if (objMaster.SaveUpdateDeleteMastGuestType(objGuestType, isNew, false))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please enter guest type code.", this.Text);
                    txtGuestTypeCode.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Guest Type ?") == System.Windows.Forms.DialogResult.Yes)
                {
                    if (objMaster.SaveUpdateDeleteMastGuestType(objGuestType, false, true))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        void BindGridview()
        {
            try
            {
                IList<EL.MastGuestType> lstTitle = objMaster.GetMastGuestType().ToList();

                var dbdata = lstTitle.Select((c, index) =>
                new
                {
                    c.GT_NO,
                    SlNo = index + 1,
                    Guest_Code = c.GT_CODE,
                    GUest_Type = c.GT_TYPE
                });

                datagrdiview.DataSource = dbdata.ToList();
                datagrdiview.Columns[0].Visible = false;
                datagrdiview.Columns[1].Width = 100;
                datagrdiview.Columns[2].Width = 150;
                datagrdiview.Columns[3].Width = 250;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "BindGridview");
            }
        }

        private void txtGuestTypeCode_Leave(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(txtGuestTypeCode.Text))
            {
                if(objMaster.GetMastGuestType().Any(x => x.GT_CODE == txtGuestTypeCode.Text.Trim()))
                {
                    CustomMessageBox.ShowExclamationMessage("Guest Type Code Exists !!", "Guest Type Code");
                    txtGuestTypeCode.Focus();
                }
            }
        }

        private void datagrdiview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (datagrdiview.SelectedRows.Count > 0)
                {
                    DataGridViewRow dr = datagrdiview.SelectedRows[0];
                    int miscid = Convert.ToInt32(dr.Cells[0].Value);
                    this.objGuestType = objMaster.GetMastGuestType().FirstOrDefault(x => x.GT_NO == miscid);
                    txtGuestTypeCode.Text = objGuestType.GT_CODE;
                    txtGuestType.Text = objGuestType.GT_TYPE;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in select data");
            }
        }    
    }
}
