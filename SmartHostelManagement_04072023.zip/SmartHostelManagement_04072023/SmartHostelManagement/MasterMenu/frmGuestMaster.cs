﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SmartHostelManagement.Search;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SMH.BusinessLogic.Layer;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Master
{
    public partial class frmGuestMaster : Form
    {
        GuestCaller guestCaller = new GuestCaller();
        MasterCaller objMasterData = new MasterCaller();
        public int guestnum { get; set; }

        public frmGuestMaster()
        {
            InitializeComponent();
        }

        private void frmGuestMaster_Load(object sender, EventArgs e)
        {
            Bind_Title();
            
        }
        
        private void Bind_Title()
        {
            IList<EL.MasterTitle> lstTitle = objMasterData.GetTitleMaster().ToList();
            lstTitle.Insert(0, new EL.MasterTitle {Titleid = 0, Titlename = "" });
            cmbTitle.DataSource = lstTitle.ToList();
            cmbTitle.DisplayMember = "Titlename";
            cmbTitle.ValueMember = "Titleid";

            IList<EL.CompanyGuest> lstCompGuest = guestCaller.SearchCompanyGuest(string.Empty).ToList();
            lstCompGuest.Insert(0, new EL.CompanyGuest { CGuest_num = 0, CGUEST_CODE = "" });
            cmbCompany.DataSource = lstCompGuest.ToList();
            cmbCompany.DisplayMember = "CGUEST_CODE";
            cmbCompany.ValueMember = "CGuest_num";

            IList<EL.MastGuestType> lstGuestType = objMasterData.GetMastGuestType().ToList();
            lstGuestType.Insert(0, new EL.MastGuestType { GT_NO = 0, GT_TYPE = "" });
            cmbGuestType.DataSource = lstGuestType.Select(c => 
                new { 
                    c.GT_NO,
                    GType = !string.IsNullOrEmpty(c.GT_CODE) ? (c.GT_CODE + "--" + c.GT_TYPE) : ""
                }).ToList();
            cmbGuestType.DisplayMember = "GType";
            cmbGuestType.ValueMember = "GT_NO";
        }

        private void SetControlsValue(EL.Mast_guest mastguest)
        {
            if (mastguest != null)
            {
                #region Tab 1
                cmbTitle.Text = mastguest.G_TITLE;
                txtFirstName.Text = mastguest.G_FNAME;
                txtLastName.Text = mastguest.G_LNAME;
                txtAddress1.Text = mastguest.G_Street;
                txtAddress2.Text = mastguest.G_CITY;
                txtPhone.Text = mastguest.G_PHONE1;
                txtFAX.Text = mastguest.G_PHONE2;
                txtEmail.Text = mastguest.G_EMAIL;
                cmbCompany.Text = (!string.IsNullOrEmpty(mastguest.G_COMPANY) ? mastguest.G_COMPANY : string.Empty);
                txtContactPerson.Text = mastguest.G_ContPerson;
                cmbGuestType.SelectedValue = mastguest.GT_NO.HasValue ? mastguest.GT_NO.Value : 0; 
                #endregion Tab 1

                #region Tab 2
                txtLanguage.Text = mastguest.G_Language;
                txtRefrence.Text = mastguest.G_Reference;
                txtSpouse.Text = mastguest.G_Spouse.ToString();
                txtFavoriteroom.Text = mastguest.G_favourite_room;
                txtGender.Text = mastguest.G_Gender;
                dtmBirthday.Value = Convert.ToDateTime(mastguest.G_Birthday);
                dtmAnniversary.Value = Convert.ToDateTime(mastguest.G_Anniversary);
                txtJobTitle.Text = mastguest.G_Jobtitle;
                #endregion Tab 2

                #region Tab 3
                txtHoldType.Text = mastguest.G_HoldTYPE;
                txtNumberType.Text = mastguest.G_NUM_TYP;
                dtmExpiryDate.Value = Convert.ToDateTime(mastguest.G_CARD_EXP);
                txtNameOnCard.Text = mastguest.G_Name_on_card;
                txtDirectBill.Text = mastguest.G_Direct_bill;
                txtComapany.Text = mastguest.G_COMPANY;
                txtTravel.Text = mastguest.G_Travel_agent;
                txtRoomType.Text = mastguest.G_Room_type;
                txtWeekDays.Text = mastguest.G_Weekdays;
                chkOverrideRate.Checked = Convert.ToBoolean(mastguest.G_override_rate);
                txtRateCode.Text = mastguest.G_Rate_code;
                txtWeekend.Text = mastguest.G_Weedend;
                chkTaxIncidentals.Checked = Convert.ToBoolean(mastguest.G_tax_incidencials);
                drpAdults.Text = Convert.ToString(mastguest.G_Adults);
                txtDiscount.Text =  Convert.ToString(mastguest.G_Discounts);
                cmbDiscount.Text = mastguest.G_Type_ofDISCOUNT;
                drpChildren.Text = Convert.ToString(mastguest.G_Childrens);
                #endregion Tab 3
            }
            
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.guestnum = 0;
            chkOverrideRate.Checked = false;
            chkTaxIncidentals.Checked = false;
            if (cmbDiscount.Items.Count > 0) cmbDiscount.SelectedIndex = 0;
            cmbTitle.SelectedIndex = 0;
            drpAdults.Text = "0";
            drpChildren.Text = "0";
            dtmAnniversary.Value = DateTime.MinValue.AddYears(1900);
            dtmBirthday.Value = DateTime.MinValue.AddYears(1900);
            dtmExpiryDate.Value = DateTime.Now;
            txtAddress1.Text = string.Empty;
            txtAddress2.Text = string.Empty;
            txtComapany.Text = string.Empty;
            txtDirectBill.Text = string.Empty;
            txtDiscount.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtFavoriteroom.Text = string.Empty;
            txtFAX.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtGender.Text = string.Empty;
            txtHoldType.Text = string.Empty;
            txtJobTitle.Text = string.Empty;
            txtLanguage.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtNameOnCard.Text = string.Empty;
            txtNumberType.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtRateCode.Text = string.Empty;
            txtRefrence.Text = string.Empty;
            txtRoomType.Text = string.Empty;
            txtSpouse.Text = string.Empty;
            txtTravel.Text = string.Empty;
            txtWeekDays.Text = string.Empty;
            txtWeekend.Text = string.Empty;

            cmbCompany.SelectedValue =0;
            txtContactPerson.Text = string.Empty;
            cmbGuestType.SelectedIndex = 0;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidatePageData())
                {
                    EL.Mast_guest objmasguest = guestCaller.GuestDetailByID(new EL.Mast_guest { GUEST_NUM = this.guestnum });
                    
                    #region Edit Guest Data
                    if (objmasguest != null)
                    {
                        objmasguest.G_TITLE = cmbTitle.Text;
                        objmasguest.G_FNAME = txtFirstName.Text;
                        objmasguest.G_LNAME = txtLastName.Text;
                        objmasguest.G_Street = txtAddress1.Text;
                        objmasguest.G_CITY = txtAddress2.Text;
                        objmasguest.G_PHONE1 = txtPhone.Text;
                        objmasguest.G_PHONE2 = txtFAX.Text;
                        objmasguest.G_EMAIL = txtEmail.Text;
                        objmasguest.G_Language = txtLanguage.Text;
                        objmasguest.G_Reference = txtRefrence.Text;
                        objmasguest.G_Spouse = Convert.ToInt32(txtSpouse.Text);
                        objmasguest.G_favourite_room = txtFavoriteroom.Text;
                        objmasguest.G_Gender = txtGender.Text;
                        objmasguest.G_Birthday = dtmBirthday.Value;
                        objmasguest.G_Anniversary = dtmAnniversary.Value;
                        objmasguest.G_Jobtitle = txtJobTitle.Text;
                        objmasguest.G_HoldTYPE = txtHoldType.Text;
                        objmasguest.G_NUM_TYP = txtNumberType.Text;
                        objmasguest.G_CARD_EXP = dtmExpiryDate.Value;
                        objmasguest.G_Name_on_card = txtNameOnCard.Text;
                        objmasguest.G_Direct_bill = txtDirectBill.Text;
                        objmasguest.G_COMPANY = txtComapany.Text;
                        objmasguest.G_Travel_agent = txtTravel.Text;
                        objmasguest.G_Room_type = txtRoomType.Text;
                        objmasguest.G_Weekdays = txtWeekDays.Text;
                        objmasguest.G_override_rate = chkOverrideRate.Checked;
                        objmasguest.G_Rate_code = txtRateCode.Text;
                        objmasguest.G_Weedend = txtWeekend.Text;
                        objmasguest.G_tax_incidencials = chkTaxIncidentals.Checked;
                        objmasguest.G_Adults = Convert.ToInt32(drpAdults.Text);
                        objmasguest.G_Discounts = Convert.ToInt32(txtDiscount.Text);
                        objmasguest.G_Type_ofDISCOUNT = cmbDiscount.Text;
                        objmasguest.G_Childrens = Convert.ToInt32(drpChildren.Text);
                        objmasguest.id1 = Frm_Login.UserLogin.log_id;
                        objmasguest.date_of_mod = DateTime.Now;
                        objmasguest.G_FULLNAME = txtFirstName.Text.Trim() + " " + txtLastName.Text.Trim();
                        objmasguest.G_LICENSE = string.Empty;
                        objmasguest.G_Followup = string.Empty;
                        objmasguest.G_COMPANY = cmbCompany.Text;
                        objmasguest.G_ContPerson = txtContactPerson.Text;
                        objmasguest.GT_NO = cmbGuestType.SelectedIndex > 0 ? (int)cmbGuestType.SelectedValue : default(int);
                    }
                    #endregion Edit Guest Data

                    #region Add Guest Data
                    else
                    {
                        objmasguest = new EL.Mast_guest
                        {
                            G_LNAME = txtLastName.Text,
                            G_FNAME = txtFirstName.Text,
                            G_TITLE = cmbTitle.Text,
                            G_Street = txtAddress1.Text,
                            G_ADDRESS2 = string.Empty,
                            G_CITY = txtAddress2.Text,
                            G_STATE = string.Empty,
                            G_COUNTRY = string.Empty,
                            G_ZIP = string.Empty,
                            G_PHONE1 = txtPhone.Text,
                            G_PHONE2 = txtFAX.Text,
                            G_EMAIL = txtEmail.Text,
                            G_Language = txtLanguage.Text,
                            G_Reference = txtRefrence.Text,
                            G_Spouse = !string.IsNullOrEmpty(txtSpouse.Text) && txtSpouse.Text.GetType() == typeof(int) ? Convert.ToInt32(txtSpouse.Text) : 0,
                            G_favourite_room = txtFavoriteroom.Text,
                            G_Gender = txtGender.Text,
                            G_Birthday = dtmBirthday.Value,
                            G_Anniversary = dtmAnniversary.Value,
                            G_Jobtitle = txtJobTitle.Text,
                            G_HoldTYPE = txtHoldType.Text,
                            G_NUM_TYP = txtNumberType.Text,
                            G_CARD_EXP = dtmExpiryDate.Value,
                            G_Name_on_card = txtNameOnCard.Text,
                            G_Direct_bill = txtDirectBill.Text,
                            //G_COMPANY = txtComapany.Text,
                            G_Travel_agent = txtTravel.Text,
                            G_Room_type = txtRoomType.Text,
                            G_Weekdays = txtWeekDays.Text,
                            G_override_rate = chkOverrideRate.Checked,
                            G_Rate_code = txtRateCode.Text,
                            G_Weedend = txtWeekend.Text,
                            G_tax_incidencials = chkTaxIncidentals.Checked,
                            G_Adults = !string.IsNullOrEmpty(drpAdults.Text) && drpAdults.Text.GetType() == typeof(int) ? Convert.ToInt32(drpAdults.Text) : 0,
                            G_Discounts = !string.IsNullOrEmpty(txtDiscount.Text) && txtDiscount.Text.GetType() == typeof(int) ? Convert.ToInt32(txtDiscount.Text) : 0,
                            G_Type_ofDISCOUNT = cmbDiscount.Text,
                            G_Childrens = !string.IsNullOrEmpty(drpChildren.Text) && drpChildren.Text.GetType() == typeof(int) ? Convert.ToInt32(drpChildren.Text) : 0,
                            id = Frm_Login.UserLogin.log_id,
                            date_of_add = DateTime.Now,
                            G_FULLNAME = txtFirstName.Text + " " + txtLastName.Text,
                            G_LICENSE = string.Empty,
                            G_Followup = string.Empty,
                            G_COMPANY = cmbCompany.Text,
                            G_ContPerson = txtContactPerson.Text,
                            GT_NO = cmbGuestType.SelectedIndex > 0 ? (int)cmbGuestType.SelectedValue : default(int)
                        };
                    }
                    #endregion Add Guest Data

                    this.guestnum = guestCaller.SaveUpdateMastGuestDetails(objmasguest);

                    if (this.guestnum > 0)
                        CustomMessageBox.ShowInformationMessage("Record Saved", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record not Saved", this.Text);
                    
                    btnRefresh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        private bool ValidatePageData()
        {
            if (string.IsNullOrEmpty(txtFirstName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please Enter name of Guest", this.Text);
                return false;
            }
            else
                return true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (frmGuestSearch guestsearch = new frmGuestSearch())
            {
                guestsearch.searchTypeObject = typeof(EL.Mast_guest);
                guestsearch.guestName = txtFirstName.Text;
                guestsearch.ShowDialog();
                this.guestnum = guestsearch.GuestNum;
                SetControlsValue(guestCaller.GuestDetailByID(new EL.Mast_guest { GUEST_NUM = this.guestnum }));
            } 
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void cmbTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender.GetType() == typeof(ComboBox))
                {
                    if (((ComboBox)sender) == cmbTitle)
                        txtFirstName.Focus();
                    else if (((ComboBox)sender) == cmbDiscount)
                        btnSave.Focus();
                    //else if (((ComboBox)sender) == cmbCompany)
                        //txtMembshipno.Focus();

                }
                else if (sender.GetType() == typeof(TextBox))
                {
                    if (((TextBox)sender) == txtFirstName)
                        txtLastName.Focus();
                    else if (((TextBox)sender) == txtLastName)
                        txtAddress1.Focus();
                    else if (((TextBox)sender) == txtAddress1)
                        txtAddress2.Focus();
                    else if (((TextBox)sender) == txtAddress2)
                        cmbCompany.Focus();
                    else if (((TextBox)sender) == txtFAX)
                        txtEmail.Focus();
                    else if (((TextBox)sender) == txtPhone)
                        txtFAX.Focus();
                    else if (((TextBox)sender) == txtEmail)
                        txtContactPerson.Focus();
                    else if (((TextBox)sender) == txtGender)
                        dtmBirthday.Focus();
                    else if (((TextBox)sender) == txtSpouse)
                        txtFavoriteroom.Focus();
                    else if (((TextBox)sender) == txtLanguage)
                        txtRefrence.Focus();
                    else if (((TextBox)sender) == txtJobTitle)
                        txtHoldType.Focus();
                    else if (((TextBox)sender) == txtRefrence)
                        txtSpouse.Focus();
                    else if (((TextBox)sender) == txtFavoriteroom)
                        txtGender.Focus();
                    else if (((TextBox)sender) == txtHoldType)
                        txtNumberType.Focus();
                    else if (((TextBox)sender) == txtNumberType)
                        dtmExpiryDate.Focus();
                    else if (((TextBox)sender) == txtNameOnCard)
                        txtDirectBill.Focus();
                    else if (((TextBox)sender) == txtTravel)
                        txtRoomType.Focus();
                    else if (((TextBox)sender) == txtComapany)
                        txtTravel.Focus();
                    else if (((TextBox)sender) == txtDirectBill)
                        txtComapany.Focus();
                    else if (((TextBox)sender) == txtRoomType)
                        txtWeekDays.Focus();
                    else if (((TextBox)sender) == txtWeekDays)
                        chkOverrideRate.Focus();
                    else if (((TextBox)sender) == txtWeekend)
                        chkTaxIncidentals.Focus();
                    else if (((TextBox)sender) == txtRateCode)
                        txtWeekend.Focus();
                    else if (((TextBox)sender) == txtDiscount)
                        drpChildren.Focus();
                    //else if (((TextBox)sender) == txtGSTNo)
                    //    txtPANNo.Focus();
                    //else if (((TextBox)sender) == txtPANNo)
                    //    txtLanguage.Focus();
                    //else if (((TextBox)sender) == txtMembshipno)
                    //    txtPhone.Focus();
                }
                else if(sender.GetType() == typeof(DateTimePicker))
                {

                    if (((DateTimePicker)sender) == dtmBirthday)
                        dtmAnniversary.Focus();
                    else if (((DateTimePicker)sender) == dtmAnniversary)
                        txtJobTitle.Focus();
                    else if (((DateTimePicker)sender) == dtmExpiryDate)
                        txtNameOnCard.Focus();

                }
                else if (sender.GetType() == typeof(CheckBox))
                { 
                    if (((CheckBox)sender) == chkTaxIncidentals)
                        drpAdults.Focus();
                    else if (((CheckBox)sender) == chkOverrideRate)
                        txtRateCode.Focus();                    
                }                
                else if (sender.GetType() == typeof(DomainUpDown))
                {
                    if (((DomainUpDown)sender) == drpAdults)
                        txtDiscount.Focus();
                    else if (((DomainUpDown)sender) == drpChildren)
                        cmbDiscount.Focus();
                }
            }
        }

        private void txtFirstName_Leave(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(TextBox))
            {
                TextBox txtText = (TextBox)sender;
                txtText.Text = CommonBaseFN.ConvertFirstLetterToCapital(txtText.Text);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            EL.Mast_guest objGuest = guestCaller.GuestDetailByID(new EL.Mast_guest { GUEST_NUM = this.guestnum });
            if (objGuest != null && CustomMessageBox.ShowDialogBoxMessage("Delete this Guest details.") == System.Windows.Forms.DialogResult.Yes)
            {
                if (guestCaller.DeleteGuestDeatils(objGuest))
                    CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                else
                    CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                btnRefresh_Click(null, null);
            }
        }

        private void btnAddCompany_Click(object sender, EventArgs e)
        {
            using (frmCompanyGuestMaster frmCompGuest = new frmCompanyGuestMaster())
            {
                frmCompGuest.ShowDialog();
                IList<EL.CompanyGuest> lstCompGuest = guestCaller.SearchCompanyGuest(string.Empty).ToList();
                lstCompGuest.Insert(0, new EL.CompanyGuest { CGuest_num = 0, CGUEST_CODE = "" });
                cmbCompany.DataSource = lstCompGuest.ToList();
                cmbCompany.DisplayMember = "CGUEST_CODE";
                cmbCompany.ValueMember = "CGuest_num";
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
    }
}