﻿namespace SmartHostelManagement.Master
{
    partial class frmGuestMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cmbGuestType = new System.Windows.Forms.ComboBox();
            this.btnAddCompany = new System.Windows.Forms.Button();
            this.cmbCompany = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtContactPerson = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFAX = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dtmAnniversary = new System.Windows.Forms.DateTimePicker();
            this.dtmBirthday = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.txtFavoriteroom = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtRefrence = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtJobTitle = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSpouse = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLanguage = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbDiscount = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.drpChildren = new System.Windows.Forms.DomainUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.drpAdults = new System.Windows.Forms.DomainUpDown();
            this.chkTaxIncidentals = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtWeekend = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtRateCode = new System.Windows.Forms.TextBox();
            this.chkOverrideRate = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtWeekDays = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtRoomType = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtmExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtTravel = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtComapany = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtDirectBill = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtNameOnCard = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtNumberType = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtHoldType = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel2.Controls.Add(this.btnRefresh);
            this.splitContainer1.Panel2.Controls.Add(this.btnSearch);
            this.splitContainer1.Panel2.Controls.Add(this.btnExit);
            this.splitContainer1.Panel2.Controls.Add(this.btnSave);
            this.splitContainer1.Size = new System.Drawing.Size(667, 426);
            this.splitContainer1.SplitterDistance = 371;
            this.splitContainer1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(220, 20);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(667, 371);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.cmbGuestType);
            this.tabPage1.Controls.Add(this.btnAddCompany);
            this.tabPage1.Controls.Add(this.cmbCompany);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.txtContactPerson);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtEmail);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtFAX);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtPhone);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtAddress2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtAddress1);
            this.tabPage1.Controls.Add(this.txtLastName);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.cmbTitle);
            this.tabPage1.Controls.Add(this.txtFirstName);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(659, 343);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Genral Address";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // cmbGuestType
            // 
            this.cmbGuestType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGuestType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbGuestType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGuestType.FormattingEnabled = true;
            this.cmbGuestType.Location = new System.Drawing.Point(116, 262);
            this.cmbGuestType.Name = "cmbGuestType";
            this.cmbGuestType.Size = new System.Drawing.Size(341, 21);
            this.cmbGuestType.TabIndex = 118;
            // 
            // btnAddCompany
            // 
            this.btnAddCompany.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCompany.Location = new System.Drawing.Point(480, 184);
            this.btnAddCompany.Name = "btnAddCompany";
            this.btnAddCompany.Size = new System.Drawing.Size(165, 22);
            this.btnAddCompany.TabIndex = 117;
            this.btnAddCompany.Text = "Add Company Details";
            this.btnAddCompany.UseVisualStyleBackColor = true;
            this.btnAddCompany.Click += new System.EventHandler(this.btnAddCompany_Click);
            // 
            // cmbCompany
            // 
            this.cmbCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCompany.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCompany.FormattingEnabled = true;
            this.cmbCompany.Location = new System.Drawing.Point(117, 184);
            this.cmbCompany.Name = "cmbCompany";
            this.cmbCompany.Size = new System.Drawing.Size(341, 21);
            this.cmbCompany.TabIndex = 116;
            this.cmbCompany.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(41, 190);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(68, 14);
            this.label31.TabIndex = 115;
            this.label31.Text = "Company";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(28, 265);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(81, 14);
            this.label30.TabIndex = 113;
            this.label30.Text = "Guest Type";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(2, 238);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(107, 14);
            this.label29.TabIndex = 111;
            this.label29.Text = "Contact Person";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtContactPerson.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactPerson.Location = new System.Drawing.Point(116, 234);
            this.txtContactPerson.MaxLength = 500;
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(342, 22);
            this.txtContactPerson.TabIndex = 110;
            this.txtContactPerson.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtContactPerson.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(61, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 14);
            this.label5.TabIndex = 109;
            this.label5.Text = "E-Mail";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(117, 156);
            this.txtEmail.MaxLength = 500;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(341, 22);
            this.txtEmail.TabIndex = 108;
            this.txtEmail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtEmail.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(76, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 14);
            this.label4.TabIndex = 107;
            this.label4.Text = "FAX";
            // 
            // txtFAX
            // 
            this.txtFAX.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFAX.Location = new System.Drawing.Point(117, 128);
            this.txtFAX.MaxLength = 500;
            this.txtFAX.Name = "txtFAX";
            this.txtFAX.Size = new System.Drawing.Size(341, 22);
            this.txtFAX.TabIndex = 106;
            this.txtFAX.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtFAX.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(61, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 14);
            this.label3.TabIndex = 105;
            this.label3.Text = "Phone";
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone.Location = new System.Drawing.Point(117, 100);
            this.txtPhone.MaxLength = 500;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(341, 22);
            this.txtPhone.TabIndex = 104;
            this.txtPhone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtPhone.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 14);
            this.label2.TabIndex = 103;
            this.label2.Text = "Address 2";
            // 
            // txtAddress2
            // 
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(117, 72);
            this.txtAddress2.MaxLength = 10000;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(528, 22);
            this.txtAddress2.TabIndex = 102;
            this.txtAddress2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtAddress2.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 14);
            this.label1.TabIndex = 101;
            this.label1.Text = "Address 1";
            // 
            // txtAddress1
            // 
            this.txtAddress1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress1.Location = new System.Drawing.Point(117, 44);
            this.txtAddress1.MaxLength = 10000;
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(528, 22);
            this.txtAddress1.TabIndex = 100;
            this.txtAddress1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtAddress1.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastName.Location = new System.Drawing.Point(412, 16);
            this.txtLastName.MaxLength = 10000;
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(233, 22);
            this.txtLastName.TabIndex = 99;
            this.txtLastName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtLastName.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(21, 20);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 14);
            this.label24.TabIndex = 98;
            this.label24.Text = "Title - Name";
            // 
            // cmbTitle
            // 
            this.cmbTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Location = new System.Drawing.Point(117, 16);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(73, 21);
            this.cmbTitle.TabIndex = 57;
            this.cmbTitle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstName.Location = new System.Drawing.Point(194, 16);
            this.txtFirstName.MaxLength = 10000;
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(216, 22);
            this.txtFirstName.TabIndex = 56;
            this.txtFirstName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtFirstName.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.dtmAnniversary);
            this.tabPage2.Controls.Add(this.dtmBirthday);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.txtFavoriteroom);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtRefrence);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.txtJobTitle);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtGender);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtSpouse);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtLanguage);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(659, 343);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Personal Information";
            // 
            // dtmAnniversary
            // 
            this.dtmAnniversary.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmAnniversary.CustomFormat = "dd/MMM/yyyy";
            this.dtmAnniversary.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmAnniversary.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmAnniversary.Location = new System.Drawing.Point(111, 173);
            this.dtmAnniversary.Name = "dtmAnniversary";
            this.dtmAnniversary.Size = new System.Drawing.Size(106, 22);
            this.dtmAnniversary.TabIndex = 125;
            this.dtmAnniversary.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // dtmBirthday
            // 
            this.dtmBirthday.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmBirthday.CustomFormat = "dd/MMM/yyyy";
            this.dtmBirthday.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmBirthday.Location = new System.Drawing.Point(111, 146);
            this.dtmBirthday.Name = "dtmBirthday";
            this.dtmBirthday.Size = new System.Drawing.Size(106, 22);
            this.dtmBirthday.TabIndex = 124;
            this.dtmBirthday.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(306, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 14);
            this.label13.TabIndex = 123;
            this.label13.Text = "Favourite Room";
            // 
            // txtFavoriteroom
            // 
            this.txtFavoriteroom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFavoriteroom.Location = new System.Drawing.Point(421, 91);
            this.txtFavoriteroom.MaxLength = 10000;
            this.txtFavoriteroom.Name = "txtFavoriteroom";
            this.txtFavoriteroom.Size = new System.Drawing.Size(227, 22);
            this.txtFavoriteroom.TabIndex = 122;
            this.txtFavoriteroom.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtFavoriteroom.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(351, 68);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 14);
            this.label12.TabIndex = 121;
            this.label12.Text = "Refrence";
            // 
            // txtRefrence
            // 
            this.txtRefrence.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRefrence.Location = new System.Drawing.Point(421, 64);
            this.txtRefrence.MaxLength = 10000;
            this.txtRefrence.Name = "txtRefrence";
            this.txtRefrence.Size = new System.Drawing.Size(227, 22);
            this.txtRefrence.TabIndex = 120;
            this.txtRefrence.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtRefrence.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(42, 203);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 14);
            this.label11.TabIndex = 119;
            this.label11.Text = "Job Title";
            // 
            // txtJobTitle
            // 
            this.txtJobTitle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobTitle.Location = new System.Drawing.Point(111, 199);
            this.txtJobTitle.MaxLength = 10000;
            this.txtJobTitle.Name = "txtJobTitle";
            this.txtJobTitle.Size = new System.Drawing.Size(227, 22);
            this.txtJobTitle.TabIndex = 118;
            this.txtJobTitle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtJobTitle.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(18, 176);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 14);
            this.label10.TabIndex = 117;
            this.label10.Text = "Anniversary";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(42, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 14);
            this.label9.TabIndex = 115;
            this.label9.Text = "Birthday";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(50, 122);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 14);
            this.label8.TabIndex = 113;
            this.label8.Text = "Gender";
            // 
            // txtGender
            // 
            this.txtGender.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGender.Location = new System.Drawing.Point(111, 118);
            this.txtGender.MaxLength = 10000;
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(34, 22);
            this.txtGender.TabIndex = 112;
            this.txtGender.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtGender.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(50, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 14);
            this.label7.TabIndex = 111;
            this.label7.Text = "Spouse";
            // 
            // txtSpouse
            // 
            this.txtSpouse.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpouse.Location = new System.Drawing.Point(111, 91);
            this.txtSpouse.MaxLength = 10000;
            this.txtSpouse.Name = "txtSpouse";
            this.txtSpouse.Size = new System.Drawing.Size(34, 22);
            this.txtSpouse.TabIndex = 110;
            this.txtSpouse.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtSpouse.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 14);
            this.label6.TabIndex = 109;
            this.label6.Text = "Language";
            // 
            // txtLanguage
            // 
            this.txtLanguage.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLanguage.Location = new System.Drawing.Point(111, 64);
            this.txtLanguage.MaxLength = 10000;
            this.txtLanguage.Name = "txtLanguage";
            this.txtLanguage.Size = new System.Drawing.Size(227, 22);
            this.txtLanguage.TabIndex = 108;
            this.txtLanguage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtLanguage.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(659, 343);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Stay Information";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbDiscount);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.txtDiscount);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.drpChildren);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.drpAdults);
            this.groupBox2.Controls.Add(this.chkTaxIncidentals);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.txtWeekend);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.txtRateCode);
            this.groupBox2.Controls.Add(this.chkOverrideRate);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.txtWeekDays);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.txtRoomType);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(5, 203);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(648, 140);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Stay Information";
            // 
            // cmbDiscount
            // 
            this.cmbDiscount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDiscount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDiscount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDiscount.FormattingEnabled = true;
            this.cmbDiscount.Location = new System.Drawing.Point(452, 92);
            this.cmbDiscount.Name = "cmbDiscount";
            this.cmbDiscount.Size = new System.Drawing.Size(156, 22);
            this.cmbDiscount.TabIndex = 148;
            this.cmbDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(254, 95);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(64, 14);
            this.label28.TabIndex = 147;
            this.label28.Text = "Discount";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiscount
            // 
            this.txtDiscount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.Location = new System.Drawing.Point(339, 91);
            this.txtDiscount.MaxLength = 10000;
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(88, 22);
            this.txtDiscount.TabIndex = 146;
            this.txtDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtDiscount.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(9, 120);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(62, 14);
            this.label27.TabIndex = 145;
            this.label27.Text = "Children";
            // 
            // drpChildren
            // 
            this.drpChildren.Location = new System.Drawing.Point(116, 117);
            this.drpChildren.Name = "drpChildren";
            this.drpChildren.Size = new System.Drawing.Size(58, 21);
            this.drpChildren.TabIndex = 144;
            this.drpChildren.Text = "domainUpDown2";
            this.drpChildren.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(9, 95);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 14);
            this.label26.TabIndex = 143;
            this.label26.Text = "Adults";
            // 
            // drpAdults
            // 
            this.drpAdults.Location = new System.Drawing.Point(116, 92);
            this.drpAdults.Name = "drpAdults";
            this.drpAdults.Size = new System.Drawing.Size(58, 21);
            this.drpAdults.TabIndex = 142;
            this.drpAdults.Text = "domainUpDown1";
            this.drpAdults.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // chkTaxIncidentals
            // 
            this.chkTaxIncidentals.AutoSize = true;
            this.chkTaxIncidentals.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTaxIncidentals.Location = new System.Drawing.Point(452, 66);
            this.chkTaxIncidentals.Name = "chkTaxIncidentals";
            this.chkTaxIncidentals.Size = new System.Drawing.Size(127, 18);
            this.chkTaxIncidentals.TabIndex = 141;
            this.chkTaxIncidentals.Text = "Tax Incidentals";
            this.chkTaxIncidentals.UseVisualStyleBackColor = true;
            this.chkTaxIncidentals.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(254, 69);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(73, 14);
            this.label23.TabIndex = 140;
            this.label23.Text = "Week End";
            // 
            // txtWeekend
            // 
            this.txtWeekend.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeekend.Location = new System.Drawing.Point(339, 65);
            this.txtWeekend.MaxLength = 10000;
            this.txtWeekend.Name = "txtWeekend";
            this.txtWeekend.Size = new System.Drawing.Size(88, 22);
            this.txtWeekend.TabIndex = 139;
            this.txtWeekend.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtWeekend.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(9, 69);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(74, 14);
            this.label25.TabIndex = 138;
            this.label25.Text = "Rate Code";
            // 
            // txtRateCode
            // 
            this.txtRateCode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRateCode.Location = new System.Drawing.Point(116, 65);
            this.txtRateCode.MaxLength = 10000;
            this.txtRateCode.Name = "txtRateCode";
            this.txtRateCode.Size = new System.Drawing.Size(121, 22);
            this.txtRateCode.TabIndex = 137;
            this.txtRateCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtRateCode.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // chkOverrideRate
            // 
            this.chkOverrideRate.AutoSize = true;
            this.chkOverrideRate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOverrideRate.Location = new System.Drawing.Point(452, 40);
            this.chkOverrideRate.Name = "chkOverrideRate";
            this.chkOverrideRate.Size = new System.Drawing.Size(119, 18);
            this.chkOverrideRate.TabIndex = 136;
            this.chkOverrideRate.Text = "Override Rate";
            this.chkOverrideRate.UseVisualStyleBackColor = true;
            this.chkOverrideRate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(254, 43);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 14);
            this.label22.TabIndex = 135;
            this.label22.Text = "Week Days";
            // 
            // txtWeekDays
            // 
            this.txtWeekDays.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeekDays.Location = new System.Drawing.Point(339, 39);
            this.txtWeekDays.MaxLength = 10000;
            this.txtWeekDays.Name = "txtWeekDays";
            this.txtWeekDays.Size = new System.Drawing.Size(88, 22);
            this.txtWeekDays.TabIndex = 134;
            this.txtWeekDays.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtWeekDays.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(9, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 14);
            this.label21.TabIndex = 133;
            this.label21.Text = "Room Type";
            // 
            // txtRoomType
            // 
            this.txtRoomType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoomType.Location = new System.Drawing.Point(116, 39);
            this.txtRoomType.MaxLength = 10000;
            this.txtRoomType.Name = "txtRoomType";
            this.txtRoomType.Size = new System.Drawing.Size(121, 22);
            this.txtRoomType.TabIndex = 132;
            this.txtRoomType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtRoomType.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtmExpiryDate);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtTravel);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtComapany);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtDirectBill);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtNameOnCard);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtNumberType);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtHoldType);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(5, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(649, 193);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Guarantee Information";
            // 
            // dtmExpiryDate
            // 
            this.dtmExpiryDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmExpiryDate.CustomFormat = "dd/MMM/yyyy";
            this.dtmExpiryDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmExpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmExpiryDate.Location = new System.Drawing.Point(502, 58);
            this.dtmExpiryDate.Name = "dtmExpiryDate";
            this.dtmExpiryDate.Size = new System.Drawing.Size(106, 22);
            this.dtmExpiryDate.TabIndex = 133;
            this.dtmExpiryDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(414, 62);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 14);
            this.label20.TabIndex = 132;
            this.label20.Text = "Expiry Date";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(9, 169);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(91, 14);
            this.label17.TabIndex = 131;
            this.label17.Text = "Travel Agent";
            // 
            // txtTravel
            // 
            this.txtTravel.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTravel.Location = new System.Drawing.Point(116, 165);
            this.txtTravel.MaxLength = 10000;
            this.txtTravel.Name = "txtTravel";
            this.txtTravel.Size = new System.Drawing.Size(227, 22);
            this.txtTravel.TabIndex = 130;
            this.txtTravel.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtTravel.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(9, 142);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 14);
            this.label18.TabIndex = 129;
            this.label18.Text = "Company";
            // 
            // txtComapany
            // 
            this.txtComapany.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComapany.Location = new System.Drawing.Point(116, 138);
            this.txtComapany.MaxLength = 10000;
            this.txtComapany.Name = "txtComapany";
            this.txtComapany.Size = new System.Drawing.Size(227, 22);
            this.txtComapany.TabIndex = 128;
            this.txtComapany.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtComapany.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(9, 115);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 14);
            this.label19.TabIndex = 127;
            this.label19.Text = "Direct Bill";
            // 
            // txtDirectBill
            // 
            this.txtDirectBill.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirectBill.Location = new System.Drawing.Point(116, 111);
            this.txtDirectBill.MaxLength = 10000;
            this.txtDirectBill.Name = "txtDirectBill";
            this.txtDirectBill.Size = new System.Drawing.Size(227, 22);
            this.txtDirectBill.TabIndex = 126;
            this.txtDirectBill.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtDirectBill.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(9, 89);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 14);
            this.label16.TabIndex = 125;
            this.label16.Text = "Name On Card";
            // 
            // txtNameOnCard
            // 
            this.txtNameOnCard.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameOnCard.Location = new System.Drawing.Point(116, 85);
            this.txtNameOnCard.MaxLength = 10000;
            this.txtNameOnCard.Name = "txtNameOnCard";
            this.txtNameOnCard.Size = new System.Drawing.Size(227, 22);
            this.txtNameOnCard.TabIndex = 124;
            this.txtNameOnCard.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtNameOnCard.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(9, 62);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 14);
            this.label15.TabIndex = 123;
            this.label15.Text = "Number Type";
            // 
            // txtNumberType
            // 
            this.txtNumberType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumberType.Location = new System.Drawing.Point(116, 58);
            this.txtNumberType.MaxLength = 10000;
            this.txtNumberType.Name = "txtNumberType";
            this.txtNumberType.Size = new System.Drawing.Size(227, 22);
            this.txtNumberType.TabIndex = 122;
            this.txtNumberType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtNumberType.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(9, 35);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 14);
            this.label14.TabIndex = 121;
            this.label14.Text = "Hold Type";
            // 
            // txtHoldType
            // 
            this.txtHoldType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoldType.Location = new System.Drawing.Point(116, 31);
            this.txtHoldType.MaxLength = 10000;
            this.txtHoldType.Name = "txtHoldType";
            this.txtHoldType.Size = new System.Drawing.Size(227, 22);
            this.txtHoldType.TabIndex = 120;
            this.txtHoldType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtHoldType.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // btnDelete
            // 
            this.btnDelete.AutoSize = true;
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(461, 10);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(78, 27);
            this.btnDelete.TabIndex = 20;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(160, 10);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(81, 27);
            this.btnRefresh.TabIndex = 19;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(356, 10);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(86, 27);
            this.btnSearch.TabIndex = 17;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnExit
            // 
            this.btnExit.AutoSize = true;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(558, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(78, 27);
            this.btnExit.TabIndex = 18;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(257, 10);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 27);
            this.btnSave.TabIndex = 16;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmGuestMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 426);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmGuestMaster";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guest Master";
            this.Load += new System.EventHandler(this.frmGuestMaster_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox cmbTitle;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFAX;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGender;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSpouse;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLanguage;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtJobTitle;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtRefrence;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtFavoriteroom;
        private System.Windows.Forms.DateTimePicker dtmBirthday;
        private System.Windows.Forms.DateTimePicker dtmAnniversary;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtHoldType;
        private System.Windows.Forms.TextBox txtNumberType;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtNameOnCard;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtTravel;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtComapany;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtDirectBill;
        private System.Windows.Forms.DateTimePicker dtmExpiryDate;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtRoomType;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtWeekDays;
        private System.Windows.Forms.CheckBox chkTaxIncidentals;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtWeekend;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtRateCode;
        private System.Windows.Forms.CheckBox chkOverrideRate;
        private System.Windows.Forms.DomainUpDown drpAdults;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DomainUpDown drpChildren;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbDiscount;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtContactPerson;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cmbCompany;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAddCompany;
        private System.Windows.Forms.ComboBox cmbGuestType;

    }
}