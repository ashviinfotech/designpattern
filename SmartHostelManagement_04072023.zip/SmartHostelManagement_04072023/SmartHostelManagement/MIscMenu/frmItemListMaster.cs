﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.MiscMaster
{
    public partial class frmItemListMaster : Form
    {
        MasterCaller objMaster = new MasterCaller();
        EL.Misc_items objMiscItems { get; set; }
        public int channelId = 0;
        public string channelName = string.Empty;

        public frmItemListMaster()
        {
            InitializeComponent();
            
        }

        private void txtLoginid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && sender.GetType() == typeof(TextBox))
            {
                if ((TextBox)sender == txtChannel) txtItemCode.Focus();
                if ((TextBox)sender == txtItemCode) txtItemName.Focus();
                if ((TextBox)sender == txtItemName) txtPrice.Focus();
                if ((TextBox)sender == txtPrice) txtUnit.Focus();
                if ((TextBox)sender == txtUnit) btnReferesh.Focus();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            objMiscItems = null;
            txtItemCode.Text = string.Empty;
            txtItemName.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtUnit.Text = string.Empty;
        }
        
        private void txtItemCode_Leave(object sender, EventArgs e)
        {
            try
            {
                if(!string.IsNullOrEmpty(txtItemCode.Text.Trim()))
                {
                    IList<EL.Misc_items> lstMiscItems = objMaster.GetMiscItems().ToList();
                    if(lstMiscItems.Any(x=>x.Misc_items_code.ToUpper().Equals(txtItemCode.Text.Trim().ToUpper())))
                    {
                        CustomMessageBox.ShowInformationMessage("Item Code alredy exists !!!", this.Text);
                        txtItemCode.Text = string.Empty;
                        txtItemCode.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "txtItemCode_Leave");
            }
        }

        bool validatePageData()
        {
            if (string.IsNullOrEmpty(txtItemCode.Text))
            {
                CustomMessageBox.ShowStopMessage("Please Enter Item Code.", this.Text);
                txtItemCode.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtItemName.Text))
            {
                CustomMessageBox.ShowStopMessage("Please Enter Item Name.", this.Text);
                txtItemName.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtPrice.Text))
            {
                CustomMessageBox.ShowStopMessage("Please Enter Price.", this.Text);
                txtPrice.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtUnit.Text))
            {
                CustomMessageBox.ShowStopMessage("Please Enter Units.", this.Text);
                txtUnit.Focus();
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (validatePageData())
                {
                    bool isNew = false;

                    if (objMiscItems != null)
                    {
                        objMiscItems.id1 = Frm_Login.UserLogin.log_id;
                        objMiscItems.date_of_mod = DateTime.Now;
                    }
                    else
                    {
                        isNew = true;
                        objMiscItems = new EL.Misc_items 
                        { 
                            id = Frm_Login.UserLogin.log_id,
                            date_of_add = DateTime.Now,
                            channelid = channelId,
                            Tax=0
                        };
                    }

                    objMiscItems.Misc_items_code = txtItemCode.Text.Trim();
                    objMiscItems.Misc_items_Name = txtItemName.Text.Trim();
                    objMiscItems.Price = !string.IsNullOrEmpty(txtPrice.Text) ? Convert.ToDecimal(txtPrice.Text) : 0;
                    objMiscItems.Unit = !string.IsNullOrEmpty(txtUnit.Text) ? Convert.ToDouble(txtUnit.Text) : 0;

                    if (objMaster.SaveUpdateDeleteMistItem(objMiscItems, isNew, false))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "btnSave_Click");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (Search.frmMiscItemSearch objfrmsearch = new Search.frmMiscItemSearch())
                {
                    objfrmsearch.channelid = this.channelId;
                    objfrmsearch.ShowDialog();
                    if (objfrmsearch.objSMiscItems != null)
                    {
                        this.objMiscItems = objfrmsearch.objSMiscItems;
                        txtItemCode.Text = objfrmsearch.objSMiscItems.Misc_items_code;
                        txtItemName.Text = objfrmsearch.objSMiscItems.Misc_items_Name;
                        txtPrice.Text = objfrmsearch.objSMiscItems.Price.HasValue ? objfrmsearch.objSMiscItems.Price.Value.ToString("0.00") : "0";
                        txtUnit.Text = objfrmsearch.objSMiscItems.Unit.HasValue ? objfrmsearch.objSMiscItems.Unit.Value.ToString("0") : "0";
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in search");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Hostel Booking ?") == System.Windows.Forms.DialogResult.Yes)
                {
                    if (objMaster.SaveUpdateDeleteMistItem(objMiscItems, false, true))
                        CustomMessageBox.ShowInformationMessage("Record Saved !!", this.Text);
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!", this.Text);

                    btnReferesh_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmItemListMaster_Load(object sender, EventArgs e)
        {
            txtChannel.Text = channelName;
        }
    }
}
