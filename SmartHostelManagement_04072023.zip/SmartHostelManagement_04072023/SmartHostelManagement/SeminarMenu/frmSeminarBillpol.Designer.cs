﻿namespace SmartHostelManagement.Seminar
{
    partial class frmSeminarBillpol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkStExcempted = new System.Windows.Forms.CheckBox();
            this.btnSelectGuest = new System.Windows.Forms.Button();
            this.btnAddGuest = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.lblRoomStatus = new System.Windows.Forms.Label();
            this.txtOrderFormNo = new System.Windows.Forms.TextBox();
            this.txtFinalBill = new System.Windows.Forms.TextBox();
            this.txtEntryNo = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dtmUpTo = new System.Windows.Forms.DateTimePicker();
            this.label27 = new System.Windows.Forms.Label();
            this.dtmFrom = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.txtDrawnOn = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.chkBillTo = new System.Windows.Forms.CheckBox();
            this.lblGuestStatus = new System.Windows.Forms.Label();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBillTo = new System.Windows.Forms.TextBox();
            this.dtmDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.txtGstPerc = new System.Windows.Forms.TextBox();
            this.txtTotalAmt = new System.Windows.Forms.TextBox();
            this.cmbSeminarType = new System.Windows.Forms.ComboBox();
            this.cmbSeminar = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRoundOff = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAmountDue = new System.Windows.Forms.TextBox();
            this.btnReceipt = new System.Windows.Forms.Button();
            this.txtSCharge = new System.Windows.Forms.TextBox();
            this.btnOpenByReservNo = new System.Windows.Forms.Button();
            this.btnOpenByEntryNo = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnOpnByBillNo = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnSearchByBillNo = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.chkPrintPrv = new System.Windows.Forms.CheckBox();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnSRemove = new System.Windows.Forms.Button();
            this.btnSAddChange = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.txtTotalMiscAmt = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtExtraHrscharg = new System.Windows.Forms.TextBox();
            this.txtLuxuryTax = new System.Windows.Forms.TextBox();
            this.txtExtraHrs = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPax = new System.Windows.Forms.TextBox();
            this.btnSNew = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dtmReservTo = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSemnRent = new System.Windows.Forms.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txtTotalDiningAmt = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtTotalLogistiesAmt = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtTotalCancelChargeAmt = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtTotalCatCanAmt = new System.Windows.Forms.TextBox();
            this.dgvSeminarDetails = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNetAdvRece = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvAdvancePayementRece = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtMiscAmount = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtMiscHrs = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtMiscQty = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtMiscRate = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.dtmMiscDate = new System.Windows.Forms.DateTimePicker();
            this.dgvMiscDetails = new System.Windows.Forms.DataGridView();
            this.btnMiscRemove = new System.Windows.Forms.Button();
            this.btnMiscAddChange = new System.Windows.Forms.Button();
            this.btnMiscAdd = new System.Windows.Forms.Button();
            this.cmbMiscItem = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvCancellationCharge = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.label24 = new System.Windows.Forms.Label();
            this.txtNoPrint = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeminarDetails)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdvancePayementRece)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMiscDetails)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCancellationCharge)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.chkStExcempted);
            this.panel2.Controls.Add(this.btnSelectGuest);
            this.panel2.Controls.Add(this.btnAddGuest);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.lblRoomStatus);
            this.panel2.Controls.Add(this.txtOrderFormNo);
            this.panel2.Controls.Add(this.txtFinalBill);
            this.panel2.Controls.Add(this.txtEntryNo);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.dtmUpTo);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.dtmFrom);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.txtRemarks);
            this.panel2.Controls.Add(this.txtDrawnOn);
            this.panel2.Controls.Add(this.txtAddress2);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.txtAddress);
            this.panel2.Controls.Add(this.chkBillTo);
            this.panel2.Controls.Add(this.lblGuestStatus);
            this.panel2.Controls.Add(this.txtCustName);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmbTitle);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.txtBillTo);
            this.panel2.Controls.Add(this.dtmDate);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Location = new System.Drawing.Point(1, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(845, 112);
            this.panel2.TabIndex = 28;
            // 
            // chkStExcempted
            // 
            this.chkStExcempted.BackColor = System.Drawing.Color.Red;
            this.chkStExcempted.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkStExcempted.Location = new System.Drawing.Point(390, 83);
            this.chkStExcempted.Name = "chkStExcempted";
            this.chkStExcempted.Size = new System.Drawing.Size(124, 21);
            this.chkStExcempted.TabIndex = 60;
            this.chkStExcempted.Text = "ST Exempted";
            this.chkStExcempted.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.chkStExcempted.UseCompatibleTextRendering = true;
            this.chkStExcempted.UseVisualStyleBackColor = false;
            // 
            // btnSelectGuest
            // 
            this.btnSelectGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectGuest.Location = new System.Drawing.Point(288, 80);
            this.btnSelectGuest.Name = "btnSelectGuest";
            this.btnSelectGuest.Size = new System.Drawing.Size(96, 24);
            this.btnSelectGuest.TabIndex = 59;
            this.btnSelectGuest.Text = "Select Guest";
            this.btnSelectGuest.UseVisualStyleBackColor = true;
            this.btnSelectGuest.Click += new System.EventHandler(this.btnSelectGuest_Click);
            // 
            // btnAddGuest
            // 
            this.btnAddGuest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddGuest.Location = new System.Drawing.Point(288, 55);
            this.btnAddGuest.Name = "btnAddGuest";
            this.btnAddGuest.Size = new System.Drawing.Size(96, 24);
            this.btnAddGuest.TabIndex = 58;
            this.btnAddGuest.Text = "Add Guest";
            this.btnAddGuest.UseVisualStyleBackColor = true;
            this.btnAddGuest.Click += new System.EventHandler(this.btnAddGuest_Click);
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(660, 78);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(66, 30);
            this.label28.TabIndex = 57;
            this.label28.Text = "Order Frm No.";
            // 
            // lblRoomStatus
            // 
            this.lblRoomStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblRoomStatus.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomStatus.Location = new System.Drawing.Point(519, 81);
            this.lblRoomStatus.Name = "lblRoomStatus";
            this.lblRoomStatus.Size = new System.Drawing.Size(139, 26);
            this.lblRoomStatus.TabIndex = 38;
            this.lblRoomStatus.Text = "regular";
            this.lblRoomStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrderFormNo
            // 
            this.txtOrderFormNo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtOrderFormNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderFormNo.Location = new System.Drawing.Point(726, 80);
            this.txtOrderFormNo.MaxLength = 10;
            this.txtOrderFormNo.Name = "txtOrderFormNo";
            this.txtOrderFormNo.ReadOnly = true;
            this.txtOrderFormNo.Size = new System.Drawing.Size(114, 22);
            this.txtOrderFormNo.TabIndex = 56;
            this.txtOrderFormNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrderFormNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtOrderFormNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // txtFinalBill
            // 
            this.txtFinalBill.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtFinalBill.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFinalBill.Location = new System.Drawing.Point(526, 2);
            this.txtFinalBill.MaxLength = 10;
            this.txtFinalBill.Name = "txtFinalBill";
            this.txtFinalBill.ReadOnly = true;
            this.txtFinalBill.Size = new System.Drawing.Size(91, 22);
            this.txtFinalBill.TabIndex = 55;
            this.txtFinalBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFinalBill.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtFinalBill.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // txtEntryNo
            // 
            this.txtEntryNo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryNo.Location = new System.Drawing.Point(726, 55);
            this.txtEntryNo.MaxLength = 10;
            this.txtEntryNo.Name = "txtEntryNo";
            this.txtEntryNo.ReadOnly = true;
            this.txtEntryNo.Size = new System.Drawing.Size(114, 22);
            this.txtEntryNo.TabIndex = 55;
            this.txtEntryNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEntryNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(726, 55);
            this.textBox1.MaxLength = 10;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(114, 22);
            this.textBox1.TabIndex = 55;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dtmUpTo
            // 
            this.dtmUpTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmUpTo.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmUpTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmUpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmUpTo.Location = new System.Drawing.Point(517, 55);
            this.dtmUpTo.Name = "dtmUpTo";
            this.dtmUpTo.ShowCheckBox = true;
            this.dtmUpTo.Size = new System.Drawing.Size(201, 22);
            this.dtmUpTo.TabIndex = 54;
            this.dtmUpTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(476, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(38, 14);
            this.label27.TabIndex = 53;
            this.label27.Text = "Upto";
            // 
            // dtmFrom
            // 
            this.dtmFrom.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFrom.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmFrom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmFrom.Location = new System.Drawing.Point(517, 29);
            this.dtmFrom.Name = "dtmFrom";
            this.dtmFrom.ShowCheckBox = true;
            this.dtmFrom.Size = new System.Drawing.Size(201, 22);
            this.dtmFrom.TabIndex = 52;
            this.dtmFrom.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(473, 34);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 14);
            this.label22.TabIndex = 51;
            this.label22.Text = "From";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(1, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 14);
            this.label21.TabIndex = 50;
            this.label21.Text = "Remarks";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(68, 30);
            this.txtRemarks.MaxLength = 40000;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(400, 22);
            this.txtRemarks.TabIndex = 49;
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // txtDrawnOn
            // 
            this.txtDrawnOn.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDrawnOn.Location = new System.Drawing.Point(68, 30);
            this.txtDrawnOn.MaxLength = 40000;
            this.txtDrawnOn.Name = "txtDrawnOn";
            this.txtDrawnOn.Size = new System.Drawing.Size(389, 22);
            this.txtDrawnOn.TabIndex = 49;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(4, 80);
            this.txtAddress2.MaxLength = 40000;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(283, 22);
            this.txtAddress2.TabIndex = 46;
            this.txtAddress2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1, 59);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 14);
            this.label16.TabIndex = 43;
            this.label16.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(67, 55);
            this.txtAddress.MaxLength = 40000;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ReadOnly = true;
            this.txtAddress.Size = new System.Drawing.Size(220, 22);
            this.txtAddress.TabIndex = 42;
            this.txtAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // chkBillTo
            // 
            this.chkBillTo.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chkBillTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBillTo.Location = new System.Drawing.Point(270, 4);
            this.chkBillTo.Name = "chkBillTo";
            this.chkBillTo.Size = new System.Drawing.Size(59, 19);
            this.chkBillTo.TabIndex = 39;
            this.chkBillTo.Text = "Bill To";
            this.chkBillTo.UseCompatibleTextRendering = true;
            this.chkBillTo.UseVisualStyleBackColor = true;
            this.chkBillTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // lblGuestStatus
            // 
            this.lblGuestStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblGuestStatus.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuestStatus.Location = new System.Drawing.Point(390, 56);
            this.lblGuestStatus.Name = "lblGuestStatus";
            this.lblGuestStatus.Size = new System.Drawing.Size(85, 23);
            this.lblGuestStatus.TabIndex = 34;
            this.lblGuestStatus.Text = "Regular";
            this.lblGuestStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCustName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.Location = new System.Drawing.Point(68, 4);
            this.txtCustName.MaxLength = 40000;
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.ReadOnly = true;
            this.txtCustName.Size = new System.Drawing.Size(195, 22);
            this.txtCustName.TabIndex = 33;
            this.txtCustName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(443, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 14);
            this.label8.TabIndex = 29;
            this.label8.Text = "FINAL BILL";
            // 
            // cmbTitle
            // 
            this.cmbTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTitle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Location = new System.Drawing.Point(4, 4);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(59, 22);
            this.cmbTitle.TabIndex = 32;
            this.cmbTitle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(748, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 14);
            this.label11.TabIndex = 29;
            this.label11.Text = "Entry No.";
            // 
            // txtBillTo
            // 
            this.txtBillTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillTo.Location = new System.Drawing.Point(332, 4);
            this.txtBillTo.MaxLength = 300;
            this.txtBillTo.Name = "txtBillTo";
            this.txtBillTo.Size = new System.Drawing.Size(109, 22);
            this.txtBillTo.TabIndex = 28;
            this.txtBillTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // dtmDate
            // 
            this.dtmDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDate.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmDate.Location = new System.Drawing.Point(658, 4);
            this.dtmDate.Name = "dtmDate";
            this.dtmDate.Size = new System.Drawing.Size(182, 22);
            this.dtmDate.TabIndex = 17;
            this.dtmDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(619, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 14);
            this.label10.TabIndex = 16;
            this.label10.Text = "Date";
            // 
            // txtGstPerc
            // 
            this.txtGstPerc.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGstPerc.Location = new System.Drawing.Point(228, 50);
            this.txtGstPerc.MaxLength = 10;
            this.txtGstPerc.Name = "txtGstPerc";
            this.txtGstPerc.Size = new System.Drawing.Size(59, 22);
            this.txtGstPerc.TabIndex = 59;
            this.txtGstPerc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGstPerc.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtGstPerc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // txtTotalAmt
            // 
            this.txtTotalAmt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalAmt.Location = new System.Drawing.Point(677, 24);
            this.txtTotalAmt.MaxLength = 10;
            this.txtTotalAmt.Name = "txtTotalAmt";
            this.txtTotalAmt.ReadOnly = true;
            this.txtTotalAmt.Size = new System.Drawing.Size(100, 22);
            this.txtTotalAmt.TabIndex = 57;
            this.txtTotalAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalAmt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtTotalAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // cmbSeminarType
            // 
            this.cmbSeminarType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSeminarType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSeminarType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSeminarType.FormattingEnabled = true;
            this.cmbSeminarType.Location = new System.Drawing.Point(105, 24);
            this.cmbSeminarType.Name = "cmbSeminarType";
            this.cmbSeminarType.Size = new System.Drawing.Size(246, 22);
            this.cmbSeminarType.TabIndex = 37;
            this.cmbSeminarType.SelectedIndexChanged += new System.EventHandler(this.cmbSeminarType_SelectedIndexChanged);
            this.cmbSeminarType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // cmbSeminar
            // 
            this.cmbSeminar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSeminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSeminar.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSeminar.FormattingEnabled = true;
            this.cmbSeminar.Location = new System.Drawing.Point(4, 24);
            this.cmbSeminar.Name = "cmbSeminar";
            this.cmbSeminar.Size = new System.Drawing.Size(97, 22);
            this.cmbSeminar.TabIndex = 34;
            this.cmbSeminar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(7, 5);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 14);
            this.label17.TabIndex = 29;
            this.label17.Text = "Seminar";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(665, 478);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 14);
            this.label2.TabIndex = 12;
            this.label2.Text = " TOTAL";
            // 
            // txtRoundOff
            // 
            this.txtRoundOff.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtRoundOff.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoundOff.Location = new System.Drawing.Point(720, 522);
            this.txtRoundOff.MaxLength = 10;
            this.txtRoundOff.Name = "txtRoundOff";
            this.txtRoundOff.ReadOnly = true;
            this.txtRoundOff.Size = new System.Drawing.Size(124, 22);
            this.txtRoundOff.TabIndex = 11;
            this.txtRoundOff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRoundOff.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtRoundOff.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(629, 575);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 14);
            this.label1.TabIndex = 10;
            this.label1.Text = " Amount Due";
            // 
            // txtAmountDue
            // 
            this.txtAmountDue.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAmountDue.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmountDue.Location = new System.Drawing.Point(720, 570);
            this.txtAmountDue.MaxLength = 10;
            this.txtAmountDue.Name = "txtAmountDue";
            this.txtAmountDue.ReadOnly = true;
            this.txtAmountDue.Size = new System.Drawing.Size(124, 22);
            this.txtAmountDue.TabIndex = 9;
            this.txtAmountDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAmountDue.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtAmountDue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // btnReceipt
            // 
            this.btnReceipt.AutoSize = true;
            this.btnReceipt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReceipt.Location = new System.Drawing.Point(770, 4);
            this.btnReceipt.Name = "btnReceipt";
            this.btnReceipt.Size = new System.Drawing.Size(77, 27);
            this.btnReceipt.TabIndex = 19;
            this.btnReceipt.Text = "Receipts";
            this.btnReceipt.UseVisualStyleBackColor = true;
            this.btnReceipt.Click += new System.EventHandler(this.btnReceipt_Click);
            // 
            // txtSCharge
            // 
            this.txtSCharge.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSCharge.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSCharge.Location = new System.Drawing.Point(573, 24);
            this.txtSCharge.MaxLength = 10;
            this.txtSCharge.Name = "txtSCharge";
            this.txtSCharge.ReadOnly = true;
            this.txtSCharge.Size = new System.Drawing.Size(102, 22);
            this.txtSCharge.TabIndex = 58;
            this.txtSCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSCharge.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtSCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // btnOpenByReservNo
            // 
            this.btnOpenByReservNo.AutoSize = true;
            this.btnOpenByReservNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenByReservNo.Location = new System.Drawing.Point(591, 33);
            this.btnOpenByReservNo.Name = "btnOpenByReservNo";
            this.btnOpenByReservNo.Size = new System.Drawing.Size(171, 27);
            this.btnOpenByReservNo.TabIndex = 18;
            this.btnOpenByReservNo.Text = "Open By Reserv No";
            this.btnOpenByReservNo.UseVisualStyleBackColor = true;
            this.btnOpenByReservNo.Click += new System.EventHandler(this.btnOpenByReservNo_Click);
            // 
            // btnOpenByEntryNo
            // 
            this.btnOpenByEntryNo.AutoSize = true;
            this.btnOpenByEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenByEntryNo.Location = new System.Drawing.Point(401, 4);
            this.btnOpenByEntryNo.Name = "btnOpenByEntryNo";
            this.btnOpenByEntryNo.Size = new System.Drawing.Size(134, 27);
            this.btnOpenByEntryNo.TabIndex = 17;
            this.btnOpenByEntryNo.Text = "Open By Entry No";
            this.btnOpenByEntryNo.UseVisualStyleBackColor = true;
            this.btnOpenByEntryNo.Click += new System.EventHandler(this.btnOpenByEntryNo_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(320, 4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(81, 27);
            this.btnDelete.TabIndex = 16;
            this.btnDelete.Text = "Cancel";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnOpnByBillNo
            // 
            this.btnOpnByBillNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpnByBillNo.Location = new System.Drawing.Point(402, 33);
            this.btnOpnByBillNo.Name = "btnOpnByBillNo";
            this.btnOpnByBillNo.Size = new System.Drawing.Size(181, 27);
            this.btnOpnByBillNo.TabIndex = 13;
            this.btnOpnByBillNo.Text = "Open By Bill No";
            this.btnOpnByBillNo.UseVisualStyleBackColor = true;
            this.btnOpnByBillNo.Click += new System.EventHandler(this.btnOpnByBillNo_Click);
            // 
            // btnExit
            // 
            this.btnExit.AutoSize = true;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(769, 33);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(78, 27);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(536, 4);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(56, 27);
            this.btnFirst.TabIndex = 12;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnSearchByBillNo
            // 
            this.btnSearchByBillNo.AutoSize = true;
            this.btnSearchByBillNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchByBillNo.Location = new System.Drawing.Point(174, 5);
            this.btnSearchByBillNo.Name = "btnSearchByBillNo";
            this.btnSearchByBillNo.Size = new System.Drawing.Size(144, 27);
            this.btnSearchByBillNo.TabIndex = 14;
            this.btnSearchByBillNo.Text = "Search By Bill No";
            this.btnSearchByBillNo.UseVisualStyleBackColor = true;
            this.btnSearchByBillNo.Click += new System.EventHandler(this.btnSearchByBillNo_Click);
            // 
            // btnLast
            // 
            this.btnLast.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.Location = new System.Drawing.Point(713, 5);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(54, 27);
            this.btnLast.TabIndex = 11;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(654, 5);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(56, 27);
            this.btnNext.TabIndex = 10;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrev.Location = new System.Drawing.Point(595, 5);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(56, 27);
            this.btnPrev.TabIndex = 9;
            this.btnPrev.Text = "<";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // chkPrintPrv
            // 
            this.chkPrintPrv.AutoSize = true;
            this.chkPrintPrv.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chkPrintPrv.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPrintPrv.Location = new System.Drawing.Point(213, 36);
            this.chkPrintPrv.Name = "chkPrintPrv";
            this.chkPrintPrv.Size = new System.Drawing.Size(119, 19);
            this.chkPrintPrv.TabIndex = 7;
            this.chkPrintPrv.Text = "Print Priview";
            this.chkPrintPrv.UseCompatibleTextRendering = true;
            this.chkPrintPrv.UseVisualStyleBackColor = true;
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(320, 32);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(81, 27);
            this.btnPrint.TabIndex = 5;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(91, 32);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 27);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(91, 4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(81, 27);
            this.btnEdit.TabIndex = 3;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnUndo
            // 
            this.btnUndo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUndo.Location = new System.Drawing.Point(3, 33);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(89, 26);
            this.btnUndo.TabIndex = 2;
            this.btnUndo.Text = "Undo";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNew.Location = new System.Drawing.Point(3, 5);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(89, 27);
            this.btnAddNew.TabIndex = 1;
            this.btnAddNew.Text = "Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnSRemove
            // 
            this.btnSRemove.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSRemove.Location = new System.Drawing.Point(764, 51);
            this.btnSRemove.Name = "btnSRemove";
            this.btnSRemove.Size = new System.Drawing.Size(77, 22);
            this.btnSRemove.TabIndex = 76;
            this.btnSRemove.Text = "&Remove";
            this.btnSRemove.UseVisualStyleBackColor = true;
            this.btnSRemove.Click += new System.EventHandler(this.btnSRemove_Click);
            // 
            // btnSAddChange
            // 
            this.btnSAddChange.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSAddChange.Location = new System.Drawing.Point(658, 51);
            this.btnSAddChange.Name = "btnSAddChange";
            this.btnSAddChange.Size = new System.Drawing.Size(104, 22);
            this.btnSAddChange.TabIndex = 75;
            this.btnSAddChange.Text = "&Add/Change";
            this.btnSAddChange.UseVisualStyleBackColor = true;
            this.btnSAddChange.Click += new System.EventHandler(this.btnSAddChange_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(108, 3);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 14);
            this.label30.TabIndex = 72;
            this.label30.Text = "Seminar Type";
            // 
            // txtTotalMiscAmt
            // 
            this.txtTotalMiscAmt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalMiscAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalMiscAmt.Location = new System.Drawing.Point(720, 378);
            this.txtTotalMiscAmt.MaxLength = 10;
            this.txtTotalMiscAmt.Name = "txtTotalMiscAmt";
            this.txtTotalMiscAmt.ReadOnly = true;
            this.txtTotalMiscAmt.Size = new System.Drawing.Size(124, 22);
            this.txtTotalMiscAmt.TabIndex = 32;
            this.txtTotalMiscAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalMiscAmt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtTotalMiscAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(720, 474);
            this.txtTotal.MaxLength = 10;
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(124, 22);
            this.txtTotal.TabIndex = 30;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.txtExtraHrscharg);
            this.panel3.Controls.Add(this.txtLuxuryTax);
            this.panel3.Controls.Add(this.txtExtraHrs);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.btnSRemove);
            this.panel3.Controls.Add(this.txtPax);
            this.panel3.Controls.Add(this.btnSAddChange);
            this.panel3.Controls.Add(this.btnSNew);
            this.panel3.Controls.Add(this.label31);
            this.panel3.Controls.Add(this.label30);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.dtmReservTo);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.txtSemnRent);
            this.panel3.Controls.Add(this.txtGstPerc);
            this.panel3.Controls.Add(this.txtSCharge);
            this.panel3.Controls.Add(this.txtTotalAmt);
            this.panel3.Controls.Add(this.cmbSeminarType);
            this.panel3.Controls.Add(this.cmbSeminar);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Location = new System.Drawing.Point(1, 112);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(845, 79);
            this.panel3.TabIndex = 29;
            // 
            // txtExtraHrscharg
            // 
            this.txtExtraHrscharg.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtraHrscharg.Location = new System.Drawing.Point(463, 50);
            this.txtExtraHrscharg.MaxLength = 10;
            this.txtExtraHrscharg.Name = "txtExtraHrscharg";
            this.txtExtraHrscharg.Size = new System.Drawing.Size(108, 22);
            this.txtExtraHrscharg.TabIndex = 81;
            this.txtExtraHrscharg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtLuxuryTax
            // 
            this.txtLuxuryTax.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuxuryTax.Location = new System.Drawing.Point(463, 24);
            this.txtLuxuryTax.MaxLength = 10;
            this.txtLuxuryTax.Name = "txtLuxuryTax";
            this.txtLuxuryTax.Size = new System.Drawing.Size(107, 22);
            this.txtLuxuryTax.TabIndex = 79;
            this.txtLuxuryTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLuxuryTax.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtLuxuryTax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // txtExtraHrs
            // 
            this.txtExtraHrs.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtraHrs.Location = new System.Drawing.Point(398, 50);
            this.txtExtraHrs.MaxLength = 10;
            this.txtExtraHrs.Name = "txtExtraHrs";
            this.txtExtraHrs.Size = new System.Drawing.Size(63, 22);
            this.txtExtraHrs.TabIndex = 79;
            this.txtExtraHrs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtExtraHrs.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtExtraHrs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(325, 54);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 14);
            this.label20.TabIndex = 80;
            this.label20.Text = "Extra Hrs";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(460, 7);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 14);
            this.label19.TabIndex = 80;
            this.label19.Text = "Luxuary Tax";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(782, 5);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 14);
            this.label18.TabIndex = 78;
            this.label18.Text = "PAX";
            // 
            // txtPax
            // 
            this.txtPax.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPax.Location = new System.Drawing.Point(779, 24);
            this.txtPax.MaxLength = 10;
            this.txtPax.Name = "txtPax";
            this.txtPax.Size = new System.Drawing.Size(61, 22);
            this.txtPax.TabIndex = 77;
            this.txtPax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPax.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtPax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // btnSNew
            // 
            this.btnSNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSNew.Location = new System.Drawing.Point(581, 51);
            this.btnSNew.Name = "btnSNew";
            this.btnSNew.Size = new System.Drawing.Size(75, 22);
            this.btnSNew.TabIndex = 74;
            this.btnSNew.Text = "&New";
            this.btnSNew.UseVisualStyleBackColor = true;
            this.btnSNew.Click += new System.EventHandler(this.btnSNew_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(707, 5);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(70, 14);
            this.label31.TabIndex = 73;
            this.label31.Text = "Total Amt";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 14);
            this.label5.TabIndex = 19;
            this.label5.Text = "Date";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(358, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 14);
            this.label15.TabIndex = 68;
            this.label15.Text = "Semn Rent";
            // 
            // dtmReservTo
            // 
            this.dtmReservTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmReservTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmReservTo.Location = new System.Drawing.Point(50, 49);
            this.dtmReservTo.Name = "dtmReservTo";
            this.dtmReservTo.Size = new System.Drawing.Size(106, 22);
            this.dtmReservTo.TabIndex = 18;
            this.dtmReservTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(161, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 14);
            this.label12.TabIndex = 66;
            this.label12.Text = "GST (%)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(576, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 14);
            this.label9.TabIndex = 65;
            this.label9.Text = "GST";
            // 
            // txtSemnRent
            // 
            this.txtSemnRent.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSemnRent.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSemnRent.Location = new System.Drawing.Point(354, 24);
            this.txtSemnRent.MaxLength = 10;
            this.txtSemnRent.Name = "txtSemnRent";
            this.txtSemnRent.Size = new System.Drawing.Size(107, 22);
            this.txtSemnRent.TabIndex = 61;
            this.txtSemnRent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSemnRent.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtSemnRent.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            this.txtSemnRent.Leave += new System.EventHandler(this.txtSemnRent_Leave);
            // 
            // splitContainer1
            // 
            this.splitContainer1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.splitContainer1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnReceipt);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpenByReservNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpnByBillNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnOpenByEntryNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnExit);
            this.splitContainer1.Panel2.Controls.Add(this.txtNoPrint);
            this.splitContainer1.Panel2.Controls.Add(this.btnFirst);
            this.splitContainer1.Panel2.Controls.Add(this.btnSearchByBillNo);
            this.splitContainer1.Panel2.Controls.Add(this.btnLast);
            this.splitContainer1.Panel2.Controls.Add(this.btnNext);
            this.splitContainer1.Panel2.Controls.Add(this.btnPrev);
            this.splitContainer1.Panel2.Controls.Add(this.btnPrint);
            this.splitContainer1.Panel2.Controls.Add(this.btnSave);
            this.splitContainer1.Panel2.Controls.Add(this.btnEdit);
            this.splitContainer1.Panel2.Controls.Add(this.btnUndo);
            this.splitContainer1.Panel2.Controls.Add(this.btnAddNew);
            this.splitContainer1.Panel2.Controls.Add(this.chkPrintPrv);
            this.splitContainer1.Size = new System.Drawing.Size(849, 663);
            this.splitContainer1.SplitterDistance = 596;
            this.splitContainer1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.txtTotalDiningAmt);
            this.panel1.Controls.Add(this.txtDiscount);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.txtTotalLogistiesAmt);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.txtTotalCancelChargeAmt);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.txtTotalCatCanAmt);
            this.panel1.Controls.Add(this.dgvSeminarDetails);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtNetAdvRece);
            this.panel1.Controls.Add(this.txtTotalMiscAmt);
            this.panel1.Controls.Add(this.txtTotal);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtRoundOff);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtAmountDue);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 596);
            this.panel1.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.Font = new System.Drawing.Font("Verdana", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(533, 356);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(76, 39);
            this.button8.TabIndex = 61;
            this.button8.Text = "Misc.\r\nDetails";
            this.button8.UseCompatibleTextRendering = true;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button1_Click);
            // 
            // button7
            // 
            this.button7.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.Font = new System.Drawing.Font("Verdana", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(456, 356);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(80, 39);
            this.button7.TabIndex = 60;
            this.button7.Text = "Dining\r\nDetails";
            this.button7.UseCompatibleTextRendering = true;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button1_Click);
            // 
            // button6
            // 
            this.button6.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.Font = new System.Drawing.Font("Verdana", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(379, 356);
            this.button6.Margin = new System.Windows.Forms.Padding(0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(80, 39);
            this.button6.TabIndex = 59;
            this.button6.Text = "Catering\r\nCancellation";
            this.button6.UseCompatibleTextRendering = true;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.Font = new System.Drawing.Font("Verdana", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(304, 356);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(80, 39);
            this.button5.TabIndex = 58;
            this.button5.Text = "Cancellation\r\nCharges";
            this.button5.UseCompatibleTextRendering = true;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.Font = new System.Drawing.Font("Verdana", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(228, 356);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(80, 39);
            this.button4.TabIndex = 57;
            this.button4.Text = "Cancelled\r\nBill";
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.Font = new System.Drawing.Font("Verdana", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(153, 356);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 39);
            this.button3.TabIndex = 56;
            this.button3.Text = "Logisties\r\nDetails";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.Font = new System.Drawing.Font("Verdana", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(79, 356);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 39);
            this.button2.TabIndex = 55;
            this.button2.Text = "Catering\r\nDetails";
            this.button2.UseCompatibleTextRendering = true;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button1_Click);
            // 
            // button1
            // 
            this.button1.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(3, 356);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 39);
            this.button1.TabIndex = 54;
            this.button1.Text = "Advance /\r\nPayment /\r\nReceipt";
            this.button1.UseCompatibleTextRendering = true;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(634, 359);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 14);
            this.label6.TabIndex = 53;
            this.label6.Text = "Total Dining";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(621, 430);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 14);
            this.label39.TabIndex = 50;
            this.label39.Text = " Logistic Total";
            // 
            // txtTotalDiningAmt
            // 
            this.txtTotalDiningAmt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalDiningAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalDiningAmt.Location = new System.Drawing.Point(720, 354);
            this.txtTotalDiningAmt.MaxLength = 10;
            this.txtTotalDiningAmt.Name = "txtTotalDiningAmt";
            this.txtTotalDiningAmt.ReadOnly = true;
            this.txtTotalDiningAmt.Size = new System.Drawing.Size(124, 22);
            this.txtTotalDiningAmt.TabIndex = 47;
            this.txtTotalDiningAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDiscount
            // 
            this.txtDiscount.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtDiscount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.Location = new System.Drawing.Point(720, 498);
            this.txtDiscount.MaxLength = 10;
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.ReadOnly = true;
            this.txtDiscount.Size = new System.Drawing.Size(124, 22);
            this.txtDiscount.TabIndex = 46;
            this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDiscount.TextChanged += new System.EventHandler(this.txtDiscount_TextChanged);
            this.txtDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(652, 502);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(68, 14);
            this.label41.TabIndex = 45;
            this.label41.Text = " Discount";
            // 
            // txtTotalLogistiesAmt
            // 
            this.txtTotalLogistiesAmt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalLogistiesAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalLogistiesAmt.Location = new System.Drawing.Point(720, 426);
            this.txtTotalLogistiesAmt.MaxLength = 10;
            this.txtTotalLogistiesAmt.Name = "txtTotalLogistiesAmt";
            this.txtTotalLogistiesAmt.ReadOnly = true;
            this.txtTotalLogistiesAmt.Size = new System.Drawing.Size(124, 22);
            this.txtTotalLogistiesAmt.TabIndex = 44;
            this.txtTotalLogistiesAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(613, 455);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(107, 14);
            this.label42.TabIndex = 43;
            this.label42.Text = "Ttl Cancel Chrg";
            // 
            // txtTotalCancelChargeAmt
            // 
            this.txtTotalCancelChargeAmt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalCancelChargeAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalCancelChargeAmt.Location = new System.Drawing.Point(720, 450);
            this.txtTotalCancelChargeAmt.MaxLength = 10;
            this.txtTotalCancelChargeAmt.Name = "txtTotalCancelChargeAmt";
            this.txtTotalCancelChargeAmt.ReadOnly = true;
            this.txtTotalCancelChargeAmt.Size = new System.Drawing.Size(124, 22);
            this.txtTotalCancelChargeAmt.TabIndex = 42;
            this.txtTotalCancelChargeAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(639, 383);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(81, 14);
            this.label25.TabIndex = 41;
            this.label25.Text = " Total Misc.";
            // 
            // txtTotalCatCanAmt
            // 
            this.txtTotalCatCanAmt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTotalCatCanAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalCatCanAmt.Location = new System.Drawing.Point(720, 402);
            this.txtTotalCatCanAmt.MaxLength = 10;
            this.txtTotalCatCanAmt.Name = "txtTotalCatCanAmt";
            this.txtTotalCatCanAmt.ReadOnly = true;
            this.txtTotalCatCanAmt.Size = new System.Drawing.Size(124, 22);
            this.txtTotalCatCanAmt.TabIndex = 39;
            this.txtTotalCatCanAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalCatCanAmt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtTotalCatCanAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // dgvSeminarDetails
            // 
            this.dgvSeminarDetails.AllowUserToAddRows = false;
            this.dgvSeminarDetails.AllowUserToDeleteRows = false;
            this.dgvSeminarDetails.AllowUserToOrderColumns = true;
            this.dgvSeminarDetails.AllowUserToResizeColumns = false;
            this.dgvSeminarDetails.AllowUserToResizeRows = false;
            this.dgvSeminarDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSeminarDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvSeminarDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSeminarDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvSeminarDetails.Location = new System.Drawing.Point(1, 190);
            this.dgvSeminarDetails.MultiSelect = false;
            this.dgvSeminarDetails.Name = "dgvSeminarDetails";
            this.dgvSeminarDetails.ReadOnly = true;
            this.dgvSeminarDetails.RowHeadersVisible = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvSeminarDetails.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSeminarDetails.RowTemplate.ReadOnly = true;
            this.dgvSeminarDetails.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSeminarDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSeminarDetails.ShowCellErrors = false;
            this.dgvSeminarDetails.ShowCellToolTips = false;
            this.dgvSeminarDetails.ShowEditingIcon = false;
            this.dgvSeminarDetails.ShowRowErrors = false;
            this.dgvSeminarDetails.Size = new System.Drawing.Size(845, 161);
            this.dgvSeminarDetails.TabIndex = 37;
            this.dgvSeminarDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSeminarDetails_CellDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(643, 526);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 14);
            this.label4.TabIndex = 35;
            this.label4.Text = " Round Off";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(620, 550);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 14);
            this.label3.TabIndex = 34;
            this.label3.Text = " Net Adv recd.";
            // 
            // txtNetAdvRece
            // 
            this.txtNetAdvRece.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtNetAdvRece.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNetAdvRece.Location = new System.Drawing.Point(720, 546);
            this.txtNetAdvRece.MaxLength = 10;
            this.txtNetAdvRece.Name = "txtNetAdvRece";
            this.txtNetAdvRece.ReadOnly = true;
            this.txtNetAdvRece.Size = new System.Drawing.Size(124, 22);
            this.txtNetAdvRece.TabIndex = 33;
            this.txtNetAdvRece.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNetAdvRece.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtNetAdvRece.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(75, 1);
            this.tabControl1.Location = new System.Drawing.Point(3, 388);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(609, 209);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 36;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(601, 200);
            this.tabPage1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvAdvancePayementRece);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(595, 194);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Advance/Payment/Receipt";
            // 
            // dgvAdvancePayementRece
            // 
            this.dgvAdvancePayementRece.AllowUserToAddRows = false;
            this.dgvAdvancePayementRece.AllowUserToDeleteRows = false;
            this.dgvAdvancePayementRece.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAdvancePayementRece.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvAdvancePayementRece.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdvancePayementRece.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAdvancePayementRece.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvAdvancePayementRece.Location = new System.Drawing.Point(3, 16);
            this.dgvAdvancePayementRece.MultiSelect = false;
            this.dgvAdvancePayementRece.Name = "dgvAdvancePayementRece";
            this.dgvAdvancePayementRece.ReadOnly = true;
            this.dgvAdvancePayementRece.RowHeadersVisible = false;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvAdvancePayementRece.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAdvancePayementRece.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAdvancePayementRece.ShowCellErrors = false;
            this.dgvAdvancePayementRece.ShowCellToolTips = false;
            this.dgvAdvancePayementRece.ShowEditingIcon = false;
            this.dgvAdvancePayementRece.ShowRowErrors = false;
            this.dgvAdvancePayementRece.Size = new System.Drawing.Size(589, 175);
            this.dgvAdvancePayementRece.StandardTab = true;
            this.dgvAdvancePayementRece.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Location = new System.Drawing.Point(4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(601, 200);
            this.tabPage2.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(601, 200);
            this.tabPage3.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.txtMiscAmount);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.txtMiscHrs);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.txtMiscQty);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.txtMiscRate);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.dtmMiscDate);
            this.groupBox3.Controls.Add(this.dgvMiscDetails);
            this.groupBox3.Controls.Add(this.btnMiscRemove);
            this.groupBox3.Controls.Add(this.btnMiscAddChange);
            this.groupBox3.Controls.Add(this.btnMiscAdd);
            this.groupBox3.Controls.Add(this.cmbMiscItem);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(595, 194);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Items For Rent Details";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(7, 28);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(38, 14);
            this.label33.TabIndex = 78;
            this.label33.Text = "Date";
            // 
            // txtMiscAmount
            // 
            this.txtMiscAmount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiscAmount.Location = new System.Drawing.Point(333, 50);
            this.txtMiscAmount.MaxLength = 10;
            this.txtMiscAmount.Name = "txtMiscAmount";
            this.txtMiscAmount.ReadOnly = true;
            this.txtMiscAmount.Size = new System.Drawing.Size(95, 22);
            this.txtMiscAmount.TabIndex = 79;
            this.txtMiscAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(162, 27);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(38, 14);
            this.label36.TabIndex = 80;
            this.label36.Text = "Item";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(275, 54);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(57, 14);
            this.label34.TabIndex = 80;
            this.label34.Text = "Amount";
            // 
            // txtMiscHrs
            // 
            this.txtMiscHrs.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiscHrs.Location = new System.Drawing.Point(229, 51);
            this.txtMiscHrs.MaxLength = 10;
            this.txtMiscHrs.Name = "txtMiscHrs";
            this.txtMiscHrs.Size = new System.Drawing.Size(43, 22);
            this.txtMiscHrs.TabIndex = 79;
            this.txtMiscHrs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMiscHrs.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtMiscHrs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            this.txtMiscHrs.Leave += new System.EventHandler(this.txtMiscQty_Leave);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(189, 55);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(30, 14);
            this.label38.TabIndex = 80;
            this.label38.Text = "Hrs";
            // 
            // txtMiscQty
            // 
            this.txtMiscQty.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiscQty.Location = new System.Drawing.Point(144, 51);
            this.txtMiscQty.MaxLength = 10;
            this.txtMiscQty.Name = "txtMiscQty";
            this.txtMiscQty.Size = new System.Drawing.Size(43, 22);
            this.txtMiscQty.TabIndex = 79;
            this.txtMiscQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMiscQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtMiscQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            this.txtMiscQty.Leave += new System.EventHandler(this.txtMiscQty_Leave);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(110, 55);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(31, 14);
            this.label37.TabIndex = 80;
            this.label37.Text = "Qty";
            // 
            // txtMiscRate
            // 
            this.txtMiscRate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiscRate.Location = new System.Drawing.Point(50, 52);
            this.txtMiscRate.MaxLength = 10;
            this.txtMiscRate.Name = "txtMiscRate";
            this.txtMiscRate.Size = new System.Drawing.Size(58, 22);
            this.txtMiscRate.TabIndex = 79;
            this.txtMiscRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMiscRate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            this.txtMiscRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            this.txtMiscRate.Leave += new System.EventHandler(this.txtMiscQty_Leave);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(10, 56);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(37, 14);
            this.label35.TabIndex = 80;
            this.label35.Text = "Rate";
            // 
            // dtmMiscDate
            // 
            this.dtmMiscDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmMiscDate.CustomFormat = "dd/MMM/yyyy";
            this.dtmMiscDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmMiscDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmMiscDate.Location = new System.Drawing.Point(50, 23);
            this.dtmMiscDate.Name = "dtmMiscDate";
            this.dtmMiscDate.Size = new System.Drawing.Size(106, 22);
            this.dtmMiscDate.TabIndex = 77;
            this.dtmMiscDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // dgvMiscDetails
            // 
            this.dgvMiscDetails.AllowUserToAddRows = false;
            this.dgvMiscDetails.AllowUserToDeleteRows = false;
            this.dgvMiscDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMiscDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMiscDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvMiscDetails.Location = new System.Drawing.Point(2, 78);
            this.dgvMiscDetails.MultiSelect = false;
            this.dgvMiscDetails.Name = "dgvMiscDetails";
            this.dgvMiscDetails.ReadOnly = true;
            this.dgvMiscDetails.RowHeadersVisible = false;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvMiscDetails.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvMiscDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMiscDetails.ShowCellErrors = false;
            this.dgvMiscDetails.ShowCellToolTips = false;
            this.dgvMiscDetails.ShowEditingIcon = false;
            this.dgvMiscDetails.ShowRowErrors = false;
            this.dgvMiscDetails.Size = new System.Drawing.Size(571, 98);
            this.dgvMiscDetails.TabIndex = 76;
            this.dgvMiscDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMiscDetails_CellDoubleClick);
            // 
            // btnMiscRemove
            // 
            this.btnMiscRemove.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMiscRemove.Location = new System.Drawing.Point(473, 49);
            this.btnMiscRemove.Name = "btnMiscRemove";
            this.btnMiscRemove.Size = new System.Drawing.Size(100, 23);
            this.btnMiscRemove.TabIndex = 75;
            this.btnMiscRemove.Text = "&Remove";
            this.btnMiscRemove.UseVisualStyleBackColor = true;
            this.btnMiscRemove.Click += new System.EventHandler(this.btnMiscRemove_Click);
            // 
            // btnMiscAddChange
            // 
            this.btnMiscAddChange.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMiscAddChange.Location = new System.Drawing.Point(473, 22);
            this.btnMiscAddChange.Name = "btnMiscAddChange";
            this.btnMiscAddChange.Size = new System.Drawing.Size(100, 23);
            this.btnMiscAddChange.TabIndex = 75;
            this.btnMiscAddChange.Text = "&Add/Change";
            this.btnMiscAddChange.UseVisualStyleBackColor = true;
            this.btnMiscAddChange.Click += new System.EventHandler(this.btnMiscAddChange_Click);
            // 
            // btnMiscAdd
            // 
            this.btnMiscAdd.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMiscAdd.Location = new System.Drawing.Point(398, 22);
            this.btnMiscAdd.Name = "btnMiscAdd";
            this.btnMiscAdd.Size = new System.Drawing.Size(72, 23);
            this.btnMiscAdd.TabIndex = 75;
            this.btnMiscAdd.Text = "&New";
            this.btnMiscAdd.UseVisualStyleBackColor = true;
            this.btnMiscAdd.Click += new System.EventHandler(this.btnMiscAdd_Click);
            // 
            // cmbMiscItem
            // 
            this.cmbMiscItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMiscItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbMiscItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMiscItem.FormattingEnabled = true;
            this.cmbMiscItem.Location = new System.Drawing.Point(203, 23);
            this.cmbMiscItem.Name = "cmbMiscItem";
            this.cmbMiscItem.Size = new System.Drawing.Size(187, 22);
            this.cmbMiscItem.TabIndex = 37;
            this.cmbMiscItem.SelectedIndexChanged += new System.EventHandler(this.cmbMiscItem_SelectedIndexChanged);
            this.cmbMiscItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTitle_KeyDown);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.Controls.Add(this.listView1);
            this.tabPage4.Location = new System.Drawing.Point(4, 5);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(601, 200);
            this.tabPage4.TabIndex = 3;
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(6, 12);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(567, 169);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Location = new System.Drawing.Point(4, 5);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(601, 200);
            this.tabPage5.TabIndex = 4;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgvCancellationCharge);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(601, 200);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Cancellation Charges";
            // 
            // dgvCancellationCharge
            // 
            this.dgvCancellationCharge.AllowUserToAddRows = false;
            this.dgvCancellationCharge.AllowUserToDeleteRows = false;
            this.dgvCancellationCharge.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCancellationCharge.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvCancellationCharge.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCancellationCharge.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvCancellationCharge.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCancellationCharge.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCancellationCharge.Location = new System.Drawing.Point(3, 16);
            this.dgvCancellationCharge.MultiSelect = false;
            this.dgvCancellationCharge.Name = "dgvCancellationCharge";
            this.dgvCancellationCharge.ReadOnly = true;
            this.dgvCancellationCharge.RowHeadersVisible = false;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvCancellationCharge.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCancellationCharge.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCancellationCharge.ShowCellErrors = false;
            this.dgvCancellationCharge.ShowCellToolTips = false;
            this.dgvCancellationCharge.ShowEditingIcon = false;
            this.dgvCancellationCharge.ShowRowErrors = false;
            this.dgvCancellationCharge.Size = new System.Drawing.Size(595, 181);
            this.dgvCancellationCharge.StandardTab = true;
            this.dgvCancellationCharge.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage6.Controls.Add(this.groupBox5);
            this.tabPage6.Location = new System.Drawing.Point(4, 5);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(601, 200);
            this.tabPage6.TabIndex = 5;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGridView2);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(0, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(601, 200);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Catering Cancelletion";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView2.Location = new System.Drawing.Point(3, 16);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridView2.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dataGridView2.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView2.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.ShowCellErrors = false;
            this.dataGridView2.ShowCellToolTips = false;
            this.dataGridView2.ShowEditingIcon = false;
            this.dataGridView2.ShowRowErrors = false;
            this.dataGridView2.Size = new System.Drawing.Size(595, 181);
            this.dataGridView2.StandardTab = true;
            this.dataGridView2.TabIndex = 2;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage7.Controls.Add(this.groupBox6);
            this.tabPage7.Location = new System.Drawing.Point(4, 5);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(601, 200);
            this.tabPage7.TabIndex = 6;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGridView3);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(601, 200);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Dining Details";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView3.Location = new System.Drawing.Point(3, 16);
            this.dataGridView3.MultiSelect = false;
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView3.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridView3.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dataGridView3.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView3.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.ShowCellErrors = false;
            this.dataGridView3.ShowCellToolTips = false;
            this.dataGridView3.ShowEditingIcon = false;
            this.dataGridView3.ShowRowErrors = false;
            this.dataGridView3.Size = new System.Drawing.Size(595, 181);
            this.dataGridView3.StandardTab = true;
            this.dataGridView3.TabIndex = 2;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage8.Controls.Add(this.groupBox7);
            this.tabPage8.Location = new System.Drawing.Point(4, 5);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(601, 200);
            this.tabPage8.TabIndex = 7;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dataGridView4);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(601, 200);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Misc. Details";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView4.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView4.Location = new System.Drawing.Point(3, 16);
            this.dataGridView4.MultiSelect = false;
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersVisible = false;
            this.dataGridView4.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView4.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridView4.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dataGridView4.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView4.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4.ShowCellErrors = false;
            this.dataGridView4.ShowCellToolTips = false;
            this.dataGridView4.ShowEditingIcon = false;
            this.dataGridView4.ShowRowErrors = false;
            this.dataGridView4.Size = new System.Drawing.Size(595, 181);
            this.dataGridView4.StandardTab = true;
            this.dataGridView4.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(605, 406);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(115, 14);
            this.label24.TabIndex = 40;
            this.label24.Text = " Catering Cancel";
            // 
            // txtNoPrint
            // 
            this.txtNoPrint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoPrint.Location = new System.Drawing.Point(175, 34);
            this.txtNoPrint.MaxLength = 10;
            this.txtNoPrint.Name = "txtNoPrint";
            this.txtNoPrint.Size = new System.Drawing.Size(35, 22);
            this.txtNoPrint.TabIndex = 79;
            this.txtNoPrint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNoPrint.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPax_KeyPress);
            // 
            // frmSeminarBillpol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 663);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSeminarBillpol";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seminar Bill";
            this.Load += new System.EventHandler(this.frmSeminarBill_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeminarDetails)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdvancePayementRece)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMiscDetails)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCancellationCharge)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtGstPerc;
        private System.Windows.Forms.TextBox txtTotalAmt;
        private System.Windows.Forms.ComboBox cmbSeminarType;
        private System.Windows.Forms.ComboBox cmbSeminar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtOrderFormNo;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DateTimePicker dtmUpTo;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DateTimePicker dtmFrom;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtDrawnOn;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.CheckBox chkBillTo;
        private System.Windows.Forms.Label lblGuestStatus;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.ComboBox cmbTitle;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBillTo;
        private System.Windows.Forms.DateTimePicker dtmDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRoundOff;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAmountDue;
        private System.Windows.Forms.Button btnReceipt;
        private System.Windows.Forms.TextBox txtSCharge;
        private System.Windows.Forms.Button btnOpenByReservNo;
        private System.Windows.Forms.Button btnOpenByEntryNo;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnOpnByBillNo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnSearchByBillNo;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.CheckBox chkPrintPrv;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnSRemove;
        private System.Windows.Forms.Button btnSAddChange;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtTotalMiscAmt;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtmReservTo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSemnRent;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblRoomStatus;
        private System.Windows.Forms.DataGridView dgvSeminarDetails;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNetAdvRece;
        private System.Windows.Forms.TextBox txtFinalBill;
        private System.Windows.Forms.TextBox txtEntryNo;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAddGuest;
        private System.Windows.Forms.Button btnSelectGuest;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtPax;
        private System.Windows.Forms.TextBox txtLuxuryTax;
        private System.Windows.Forms.TextBox txtExtraHrs;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox txtTotalCatCanAmt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnSNew;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtMiscAmount;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtMiscRate;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DateTimePicker dtmMiscDate;
        private System.Windows.Forms.DataGridView dgvMiscDetails;
        private System.Windows.Forms.Button btnMiscRemove;
        private System.Windows.Forms.Button btnMiscAddChange;
        private System.Windows.Forms.Button btnMiscAdd;
        private System.Windows.Forms.ComboBox cmbMiscItem;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtMiscHrs;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtMiscQty;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox txtNoPrint;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtTotalDiningAmt;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtTotalLogistiesAmt;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtTotalCancelChargeAmt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtExtraHrscharg;
        private System.Windows.Forms.CheckBox chkStExcempted;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvAdvancePayementRece;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgvCancellationCharge;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dataGridView4;
    }
}