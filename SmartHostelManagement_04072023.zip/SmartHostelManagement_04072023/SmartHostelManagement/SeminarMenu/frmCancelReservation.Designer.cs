﻿namespace SmartHostelManagement.Seminar
{
    partial class frmCancelReservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dtmReservTo = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEntryNo = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtmCancelledDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCancelRooms = new System.Windows.Forms.TextBox();
            this.cmbDetRoomType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDetRoomTypeAmt = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDetRemarks = new System.Windows.Forms.TextBox();
            this.cmbDetDorm = new System.Windows.Forms.ComboBox();
            this.txtNoOfRooms = new System.Windows.Forms.TextBox();
            this.dtmDetUptoReserv = new System.Windows.Forms.DateTimePicker();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnExist = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvReservationDet = new System.Windows.Forms.DataGridView();
            this.btnAddChange = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservationDet)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.dtmReservTo);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtEntryNo);
            this.groupBox1.Controls.Add(this.txtAddress2);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtCustName);
            this.groupBox1.Controls.Add(this.cmbTitle);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.dtmCancelledDate);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCancelRooms);
            this.groupBox1.Controls.Add(this.cmbDetRoomType);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtDetRoomTypeAmt);
            this.groupBox1.Controls.Add(this.label55);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtDetRemarks);
            this.groupBox1.Controls.Add(this.cmbDetDorm);
            this.groupBox1.Controls.Add(this.txtNoOfRooms);
            this.groupBox1.Controls.Add(this.dtmDetUptoReserv);
            this.groupBox1.Controls.Add(this.btnUndo);
            this.groupBox1.Controls.Add(this.btnExist);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.dgvReservationDet);
            this.groupBox1.Controls.Add(this.btnAddChange);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(932, 524);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Display";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(709, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 14);
            this.label4.TabIndex = 164;
            this.label4.Text = "Seminar Charges";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(178, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 14);
            this.label8.TabIndex = 163;
            this.label8.Text = "Date Of Reserv";
            // 
            // dtmReservTo
            // 
            this.dtmReservTo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.dtmReservTo.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmReservTo.Enabled = false;
            this.dtmReservTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmReservTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmReservTo.Location = new System.Drawing.Point(287, 19);
            this.dtmReservTo.Name = "dtmReservTo";
            this.dtmReservTo.Size = new System.Drawing.Size(106, 22);
            this.dtmReservTo.TabIndex = 162;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(66, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 14);
            this.label7.TabIndex = 161;
            this.label7.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 14);
            this.label5.TabIndex = 160;
            this.label5.Text = "Title";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Viner Hand ITC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(999, 12);
            this.label2.TabIndex = 159;
            this.label2.Text = "---------------------------------------------------------------------------------" +
    "--------------------------------------------------------------------------------" +
    "----";
            // 
            // txtEntryNo
            // 
            this.txtEntryNo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtEntryNo.Enabled = false;
            this.txtEntryNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryNo.Location = new System.Drawing.Point(69, 19);
            this.txtEntryNo.MaxLength = 10;
            this.txtEntryNo.Name = "txtEntryNo";
            this.txtEntryNo.Size = new System.Drawing.Size(101, 22);
            this.txtEntryNo.TabIndex = 158;
            this.txtEntryNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAddress2
            // 
            this.txtAddress2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAddress2.Enabled = false;
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(6, 112);
            this.txtAddress2.MaxLength = 40000;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(428, 22);
            this.txtAddress2.TabIndex = 157;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 92);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 14);
            this.label16.TabIndex = 156;
            this.label16.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAddress.Enabled = false;
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(69, 88);
            this.txtAddress.MaxLength = 40000;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(365, 22);
            this.txtAddress.TabIndex = 155;
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCustName.Enabled = false;
            this.txtCustName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.Location = new System.Drawing.Point(69, 63);
            this.txtCustName.MaxLength = 40000;
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(366, 22);
            this.txtCustName.TabIndex = 154;
            // 
            // cmbTitle
            // 
            this.cmbTitle.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cmbTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTitle.Enabled = false;
            this.cmbTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTitle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Location = new System.Drawing.Point(6, 63);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(59, 22);
            this.cmbTitle.TabIndex = 153;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 14);
            this.label11.TabIndex = 152;
            this.label11.Text = "Entry No.";
            // 
            // dtmCancelledDate
            // 
            this.dtmCancelledDate.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmCancelledDate.CustomFormat = "dd/MMM/yyyy HH:mm tt";
            this.dtmCancelledDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmCancelledDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmCancelledDate.Location = new System.Drawing.Point(556, 112);
            this.dtmCancelledDate.Name = "dtmCancelledDate";
            this.dtmCancelledDate.Size = new System.Drawing.Size(199, 22);
            this.dtmCancelledDate.TabIndex = 151;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(450, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 14);
            this.label1.TabIndex = 150;
            this.label1.Text = "Date Of Cancel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(281, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 14);
            this.label3.TabIndex = 147;
            this.label3.Text = "Hall Cancel";
            // 
            // txtCancelRooms
            // 
            this.txtCancelRooms.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCancelRooms.Location = new System.Drawing.Point(284, 168);
            this.txtCancelRooms.MaxLength = 10;
            this.txtCancelRooms.Name = "txtCancelRooms";
            this.txtCancelRooms.Size = new System.Drawing.Size(98, 22);
            this.txtCancelRooms.TabIndex = 146;
            this.txtCancelRooms.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cmbDetRoomType
            // 
            this.cmbDetRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDetRoomType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDetRoomType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDetRoomType.FormattingEnabled = true;
            this.cmbDetRoomType.Location = new System.Drawing.Point(504, 168);
            this.cmbDetRoomType.Name = "cmbDetRoomType";
            this.cmbDetRoomType.Size = new System.Drawing.Size(201, 22);
            this.cmbDetRoomType.TabIndex = 144;
            this.cmbDetRoomType.SelectedIndexChanged += new System.EventHandler(this.cmbDetRoomType_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(501, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 14);
            this.label6.TabIndex = 143;
            this.label6.Text = "Seminar Type";
            // 
            // txtDetRoomTypeAmt
            // 
            this.txtDetRoomTypeAmt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDetRoomTypeAmt.Location = new System.Drawing.Point(712, 168);
            this.txtDetRoomTypeAmt.MaxLength = 10;
            this.txtDetRoomTypeAmt.Name = "txtDetRoomTypeAmt";
            this.txtDetRoomTypeAmt.Size = new System.Drawing.Size(117, 22);
            this.txtDetRoomTypeAmt.TabIndex = 139;
            this.txtDetRoomTypeAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(3, 153);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(86, 14);
            this.label55.TabIndex = 140;
            this.label55.Text = "Reservation";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(2, 194);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 14);
            this.label30.TabIndex = 138;
            this.label30.Text = "Remarks";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(384, 153);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 14);
            this.label29.TabIndex = 137;
            this.label29.Text = "Hall Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(179, 153);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 14);
            this.label10.TabIndex = 135;
            this.label10.Text = "No. of Hall";
            // 
            // txtDetRemarks
            // 
            this.txtDetRemarks.BackColor = System.Drawing.Color.White;
            this.txtDetRemarks.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDetRemarks.Location = new System.Drawing.Point(6, 212);
            this.txtDetRemarks.MaxLength = 40000;
            this.txtDetRemarks.Name = "txtDetRemarks";
            this.txtDetRemarks.Size = new System.Drawing.Size(618, 22);
            this.txtDetRemarks.TabIndex = 134;
            // 
            // cmbDetDorm
            // 
            this.cmbDetDorm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDetDorm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDetDorm.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDetDorm.FormattingEnabled = true;
            this.cmbDetDorm.Location = new System.Drawing.Point(387, 168);
            this.cmbDetDorm.Name = "cmbDetDorm";
            this.cmbDetDorm.Size = new System.Drawing.Size(113, 22);
            this.cmbDetDorm.TabIndex = 133;
            // 
            // txtNoOfRooms
            // 
            this.txtNoOfRooms.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoOfRooms.Location = new System.Drawing.Point(182, 168);
            this.txtNoOfRooms.MaxLength = 10;
            this.txtNoOfRooms.Name = "txtNoOfRooms";
            this.txtNoOfRooms.Size = new System.Drawing.Size(98, 22);
            this.txtNoOfRooms.TabIndex = 131;
            this.txtNoOfRooms.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dtmDetUptoReserv
            // 
            this.dtmDetUptoReserv.CalendarFont = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetUptoReserv.CustomFormat = "dd/MMM/yyyy HH:mm";
            this.dtmDetUptoReserv.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDetUptoReserv.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmDetUptoReserv.Location = new System.Drawing.Point(6, 168);
            this.dtmDetUptoReserv.Name = "dtmDetUptoReserv";
            this.dtmDetUptoReserv.Size = new System.Drawing.Size(170, 22);
            this.dtmDetUptoReserv.TabIndex = 130;
            // 
            // btnUndo
            // 
            this.btnUndo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUndo.Location = new System.Drawing.Point(11, 486);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(96, 27);
            this.btnUndo.TabIndex = 62;
            this.btnUndo.Text = "&Undo";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnExist
            // 
            this.btnExist.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExist.Location = new System.Drawing.Point(113, 486);
            this.btnExist.Name = "btnExist";
            this.btnExist.Size = new System.Drawing.Size(96, 27);
            this.btnExist.TabIndex = 61;
            this.btnExist.Text = "&Edit";
            this.btnExist.UseVisualStyleBackColor = true;
            this.btnExist.Click += new System.EventHandler(this.btnExist_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(708, 486);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 27);
            this.button1.TabIndex = 60;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvReservationDet
            // 
            this.dgvReservationDet.AllowUserToAddRows = false;
            this.dgvReservationDet.AllowUserToDeleteRows = false;
            this.dgvReservationDet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvReservationDet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvReservationDet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReservationDet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReservationDet.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvReservationDet.Location = new System.Drawing.Point(6, 241);
            this.dgvReservationDet.MultiSelect = false;
            this.dgvReservationDet.Name = "dgvReservationDet";
            this.dgvReservationDet.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReservationDet.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvReservationDet.RowHeadersVisible = false;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvReservationDet.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvReservationDet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvReservationDet.ShowCellErrors = false;
            this.dgvReservationDet.ShowCellToolTips = false;
            this.dgvReservationDet.ShowEditingIcon = false;
            this.dgvReservationDet.ShowRowErrors = false;
            this.dgvReservationDet.Size = new System.Drawing.Size(923, 230);
            this.dgvReservationDet.TabIndex = 59;
            this.dgvReservationDet.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReservationDet_CellDoubleClick);
            // 
            // btnAddChange
            // 
            this.btnAddChange.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddChange.Location = new System.Drawing.Point(707, 206);
            this.btnAddChange.Name = "btnAddChange";
            this.btnAddChange.Size = new System.Drawing.Size(118, 27);
            this.btnAddChange.TabIndex = 58;
            this.btnAddChange.Text = "&Add/Change";
            this.btnAddChange.UseVisualStyleBackColor = true;
            this.btnAddChange.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // frmCancelReservation
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(932, 524);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCancelReservation";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Reservation Search";
            this.Load += new System.EventHandler(this.frmReservation_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservationDet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAddChange;
        private System.Windows.Forms.DataGridView dgvReservationDet;
        private System.Windows.Forms.Button btnExist;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.ComboBox cmbDetRoomType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDetRoomTypeAmt;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDetRemarks;
        private System.Windows.Forms.ComboBox cmbDetDorm;
        private System.Windows.Forms.TextBox txtNoOfRooms;
        private System.Windows.Forms.DateTimePicker dtmDetUptoReserv;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCancelRooms;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEntryNo;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.ComboBox cmbTitle;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtmCancelledDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtmReservTo;
        private System.Windows.Forms.Label label4;
    }
}