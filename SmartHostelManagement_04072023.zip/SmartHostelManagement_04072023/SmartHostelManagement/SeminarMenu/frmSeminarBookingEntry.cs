﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Seminar
{
    public partial class frmSeminarBookingEntry : Form
    {
        ReservationCaller objReservBook = new ReservationCaller();
        MasterCaller objMasterData = new MasterCaller();
        GuestCaller objGuestMaster = new GuestCaller();
        HostelCaller objHostelBook = new HostelCaller();
        ReceiptCaller objReceiptBook = new ReceiptCaller();
        AlphaPanel aplhaPanel = new AlphaPanel();

        public int reservationId { get; set; }
        bool editPage = false;
        int rowDetailIndex = -1;
        int rowMiscIndex = -1;
        readonly string reservTagChar = Convert.ToString((char)Convert.ToInt32(CommonVariables.SpecialTag.Semianr));

        public EL.RESERVATION_CHECKIN_WALKIN objReservation { get; set; }
        List<EL.RESERVATION_DETAILS_STATUS> lstReservDetails { get; set; }
        List<EL.RESERVATION_MISC_DETAILS> lstReservMiscDet { get; set; }
        List<EL.RESERVATION_CATERING_DETAILS> lstReservCatering { get; set; }

        public frmSeminarBookingEntry()
        {
            InitializeComponent();
        }

        private void frmSeminarBookingEntry_Load(object sender, EventArgs e)
        {
            BindTitle();
            BindHallName();
            BindRoomType();
            BindMiscItems();
            if (this.reservationId > 0)
            {
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.reservationId;
                resetPageData();
                this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                FillPageReservData();
            }
            else if (this.objReservation != null && this.objReservation.reservation_ID == 0 && this.objReservation.GUEST_NUM.HasValue)
            {
                GuestMasteretails(this.objReservation.GUEST_NUM.Value);
            }
            else
                btnLast_Click(sender, e);
            btnDelete.Enabled = false;

        }

        EL.FilterClass RefreshFilter()
        {
            return new EL.FilterClass
            {
                FinEnd = CommonVariables.dtmFinancialEnd.Year * 100 + CommonVariables.dtmFinancialEnd.Month,
                FinStart = CommonVariables.dtmFinancialStart.Year * 100 + CommonVariables.dtmFinancialStart.Month,
                BillNumber = 0,
                FolioNumber = 0,
                RecordCategory = 0,
                RecordNumber = 0,
                RoomCategory = 0,
                SearchByText = string.Empty,
                tagChar = reservTagChar,
                UniqueId = 0
            };
        }

        private void BindTitle()
        {
            try
            {
                List<EL.MasterTitle> lstTitle = objMasterData.GetTitleMaster().OrderBy(x => x.Titlename).ToList();
                lstTitle.Insert(0, new EL.MasterTitle { Titleid = 0, Titlename = string.Empty });
                cmbTitle.DataSource = lstTitle;
                cmbTitle.DisplayMember = "Titlename";
                cmbTitle.ValueMember = "Titleid";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindTitle");
            }
        }

        private void BindHallName()
        {
            try
            {
                List<EL.room_number> lstRoomNum = objMasterData.GetRoomNumber().Where(x => x.room_number_ConferenceRoom == 1).OrderBy(x => x.room_number_number).ToList();
                lstRoomNum.Insert(0, new EL.room_number { room_number_ID = 0, room_number_number = string.Empty });

                List<EL.room_number> lstReservRoomNum = objMasterData.GetRoomNumber().Where(x => x.room_number_ConferenceRoom == 1).OrderBy(x => x.room_number_number).ToList();
                lstReservRoomNum.Insert(0, new EL.room_number { room_number_ID = 0, room_number_number = string.Empty });

                cmbHallName.DataSource = lstRoomNum;
                cmbHallName.DisplayMember = "room_number_number";
                cmbHallName.ValueMember = "room_number_ID";

                cmbAddHallName.DataSource = lstReservRoomNum;
                cmbAddHallName.DisplayMember = "room_number_number";
                cmbAddHallName.ValueMember = "room_number_ID";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindHallName");
            }
        }
        
        private void BindRoomType()
        {
            List<EL.ROOM_TYPE> lstRoomTypeA = objMasterData.GetRoomType().Where(x => x.Room_dorm == 3).ToList();
            List<EL.ROOM_TYPE> lstRoomTypeB = objMasterData.GetRoomType().Where(x => x.Room_dorm == 3).ToList();
            lstRoomTypeA.Insert(0, new EL.ROOM_TYPE { RM_TYPE_CODE = "", RM_TYPE_DESC = "", RM_TYPE_ID = 0 });
            lstRoomTypeB.Insert(0, new EL.ROOM_TYPE { RM_TYPE_CODE = "", RM_TYPE_DESC = "", RM_TYPE_ID = 0 });

            cmbSeminarType.DataSource = lstRoomTypeA.Select(x => new { roomdesc = x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")", x.RM_TYPE_ID }).ToList();
            cmbSeminarType.DisplayMember = "roomdesc";
            cmbSeminarType.ValueMember = "RM_TYPE_ID";

            cmbAddSeminarType.DataSource = lstRoomTypeB.Select(x => new { roomdesc = x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")", x.RM_TYPE_ID }).ToList();
            cmbAddSeminarType.DisplayMember = "roomdesc";
            cmbAddSeminarType.ValueMember = "RM_TYPE_ID";
        }

        private void BindMiscItems()
        {
            List<EL.Misc_items> lstMiscItemA = objMasterData.GetMiscItems().ToList();
            lstMiscItemA.Insert(0, new EL.Misc_items { Misc_items_Name = "", Misc_items_Id = 0});
            //List<EL.Misc_items> lstMiscItemB = objMasterData.GetMiscItems().ToList();

            cmbLogItem.DataSource = lstMiscItemA.Select(x => new { roomdesc = x.Misc_items_Name, x.Misc_items_Id }).ToList();
            cmbLogItem.DisplayMember = "roomdesc";
            cmbLogItem.ValueMember = "Misc_items_Id";

            //cmbAddSeminarType.DataSource = lstRoomTypeB.Select(x => new { roomdesc = x.RM_TYPE_CODE + " (" + x.RM_TYPE_DESC + ")", x.RM_TYPE_ID }).ToList();
            //cmbAddSeminarType.DisplayMember = "roomdesc";
            //cmbAddSeminarType.ValueMember = "RM_TYPE_ID";
        }

        private void resetPageData()
        {
            this.objReservation = null;
            this.reservationId = 0;

            txtEntryNo.Text = string.Empty;
            dtmReservTo.Value = DateTime.Now;
            cmbTitle.SelectedIndex = 0;
            txtCustName.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtAddress2.Text = string.Empty;
            txtOrgans.Text = string.Empty;
            dtmFromDate.Value = DateTime.Today.AddHours(09).AddMinutes(00).AddSeconds(00);
            dtmTodate.Value = DateTime.Today.AddHours(17).AddMinutes(00).AddSeconds(00);
            cmbHallName.SelectedIndex = 0;
            txtRent.Text = string.Empty;
            cmbSeminarType.SelectedIndex = 0;
            txtRemarks.Text = string.Empty;
            txtDiscountPer.Text = string.Empty;
            chkServiceExmpt.Checked = false;
                        
            lblCustStatus.Text = string.Empty;
            lblTotalReceipt.Text = string.Empty;

            txtReceipt0.Text = string.Empty;
            txtReceipt1.Text = string.Empty;
            txtReceipt2.Text = string.Empty;
            txtReceipt3.Text = string.Empty;
            txtReceipt4.Text = string.Empty;
            txtReceipt5.Text = string.Empty;
            txtReceipt6.Text = string.Empty;
            txtReceipt7.Text = string.Empty;
            
            lblReceiptAmt0.Text = string.Empty;
            lblReceiptNo1.Text = string.Empty;
            lblReceiptNo2.Text = string.Empty;
            lblReceiptNo3.Text = string.Empty;
            lblReceiptNo4.Text = string.Empty;
            lblReceiptNo5.Text = string.Empty;
            lblReceiptNo6.Text = string.Empty;
            lblReceiptNo7.Text = string.Empty;

            lblRecepDesc0.Text = string.Empty;
            lblRecepDesc1.Text = string.Empty;
            lblRecepDesc2.Text = string.Empty;
            lblRecepDesc3.Text = string.Empty;
            lblRecepDesc4.Text = string.Empty;
            lblRecepDesc5.Text = string.Empty;
            lblRecepDesc6.Text = string.Empty;
            lblRecepDesc7.Text = string.Empty;

            this.lstReservDetails = null;
            this.lstReservMiscDet = null;
            this.lstReservCatering = null;
            
            resetMiscDetailSection();
            BindMiscItemDetails();

            resetDetailsSection();
            BindReservationStatus();

            BindReservationCatering();
        }

        #region Misc Details
        private void resetMiscDetailSection()
        {
            rowMiscIndex = -1;
            dtmLogDate.Value = DateTime.Today.Date;
            if (cmbLogItem.Items.Count > 0) cmbLogItem.SelectedIndex = 0;
            txtLogPrice.Text = string.Empty;
            txtLogQuantity.Text = string.Empty;
            txtLogHrs.Text = string.Empty;
            txtLogST.Text = string.Empty;
            txtLogHrs.Text = string.Empty;
            txtLogAmount.Text = string.Empty;
        }

        private void BindMiscItemDetails()
        {
            try
            {
                if (this.lstReservMiscDet == null) lstReservMiscDet = new List<EL.RESERVATION_MISC_DETAILS>();
                int indexs = 1;
                var dbData = (from c in lstReservMiscDet
                              join d in objMasterData.GetMiscItems() on c.Misc_items_Id equals d.Misc_items_Id
                                  into ps
                              from d in ps.DefaultIfEmpty()
                              select new
                              {
                                  c.Misc_items_Id,
                                  SlNo = indexs++,
                                  Date = c.MiscDate,
                                  Item = d.Misc_items_Name,
                                  Price = c.PRICE.HasValue ? c.PRICE.Value.ToString("0.00") : "0.00",
                                  Quantity = c.QUANTITY.HasValue ? c.QUANTITY.Value.ToString() : "0",
                                  Hrs = c.HRS.HasValue ? c.HRS.Value.ToString() : "0",
                                  ExtraHrs = c.EXTRAHRS.HasValue ? c.EXTRAHRS.Value.ToString() : "0",
                                  Amount = c.AMOUNT.HasValue ? c.AMOUNT.Value.ToString("0.00") : "0.00",
                                  ST = c.STAmt.HasValue ? c.STAmt.Value.ToString() : "0",
                                  LT = c.LTAmt.HasValue ? c.LTAmt.Value.ToString() : "0"
                              }).ToList();

                grdReservDetails.DataSource = dbData;
                grdReservDetails.Columns["Misc_items_Id"].Visible = false;
                grdReservDetails.Columns["Date"].DefaultCellStyle.Format = "dd/MMM/yyyy";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindMiscItemDetails");
            }
        }

        private void btnDetNew_Click(object sender, EventArgs e)
        {
            resetMiscDetailSection();
        }

        private void btnDetAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (objReservation != null)
                {
                    if (this.rowMiscIndex > -1 && this.lstReservMiscDet.Count > 0)
                    {
                        this.lstReservMiscDet[this.rowMiscIndex].Misc_items_Id = (cmbLogItem.SelectedIndex > 0 ? Convert.ToInt32(cmbLogItem.SelectedValue) : 0);
                        this.lstReservMiscDet[this.rowMiscIndex].PRICE = !string.IsNullOrEmpty(txtLogPrice.Text) ? Convert.ToDouble(txtLogPrice.Text) : 0;
                        this.lstReservMiscDet[this.rowMiscIndex].QUANTITY = !string.IsNullOrEmpty(txtLogQuantity.Text) ? Convert.ToDouble(txtLogQuantity.Text) : 0;
                        this.lstReservMiscDet[this.rowMiscIndex].HRS = !string.IsNullOrEmpty(txtLogHrs.Text) ? Convert.ToDouble(txtLogHrs.Text) : 0;
                        this.lstReservMiscDet[this.rowMiscIndex].STAmt = !string.IsNullOrEmpty(txtLogST.Text) ? Convert.ToDouble(txtLogST.Text) : 0;
                        this.lstReservMiscDet[this.rowMiscIndex].LTAmt = !string.IsNullOrEmpty(txtLogLT.Text) ? Convert.ToDouble(txtLogLT.Text) : 0;
                        this.lstReservMiscDet[this.rowMiscIndex].AMOUNT = !string.IsNullOrEmpty(txtLogAmount.Text) ? Convert.ToDouble(txtLogAmount.Text) : 0;
                        this.lstReservMiscDet[this.rowMiscIndex].MiscDate = dtmLogDate.Value.Date;
                    }
                    else
                    {
                        EL.RESERVATION_MISC_DETAILS objMiscItem = new EL.RESERVATION_MISC_DETAILS();
                        objMiscItem.reservation_ID = objReservation.reservation_ID;
                        objMiscItem.Misc_items_Id = (cmbLogItem.SelectedIndex > 0 ? Convert.ToInt32(cmbLogItem.SelectedValue) : 0);
                        objMiscItem.PRICE = !string.IsNullOrEmpty(txtLogPrice.Text) ? Convert.ToDouble(txtLogPrice.Text) : 0;
                        objMiscItem.QUANTITY = !string.IsNullOrEmpty(txtLogQuantity.Text) ? Convert.ToDouble(txtLogQuantity.Text) : 0;
                        objMiscItem.HRS = !string.IsNullOrEmpty(txtLogHrs.Text) ? Convert.ToDouble(txtLogHrs.Text) : 0;
                        objMiscItem.STAmt = !string.IsNullOrEmpty(txtLogST.Text) ? Convert.ToDouble(txtLogST.Text) : 0;
                        objMiscItem.LTAmt = !string.IsNullOrEmpty(txtLogLT.Text) ? Convert.ToDouble(txtLogLT.Text) : 0;
                        objMiscItem.AMOUNT = !string.IsNullOrEmpty(txtLogAmount.Text) ? Convert.ToDouble(txtLogAmount.Text) : 0;
                        objMiscItem.EXTRAHRS = 0;
                        objMiscItem.MiscDate = dtmLogDate.Value.Date;
                        this.lstReservMiscDet.Add(objMiscItem);
                    }
                    resetMiscDetailSection();
                    BindMiscItemDetails();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDetAdd_Click");
            }
        }

        private void btnDetRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.rowMiscIndex > -1 && this.lstReservMiscDet.Count > 0)
                {
                    this.lstReservMiscDet.RemoveAt(this.rowMiscIndex);
                    resetMiscDetailSection();
                    BindMiscItemDetails();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDetRemove_Click");
            }
        }

        private void grdReservDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex > -1)
                {
                    var currLst = lstReservMiscDet[e.RowIndex];
                    this.rowMiscIndex = e.RowIndex;
                    cmbLogItem.SelectedValue = currLst.Misc_items_Id;
                    txtLogPrice.Text = currLst.PRICE.HasValue ? currLst.PRICE.Value.ToString("0.00") : "0";
                    txtLogQuantity.Text = currLst.QUANTITY.HasValue ? currLst.QUANTITY.Value.ToString() : "0";
                    txtLogHrs.Text = currLst.HRS.HasValue ? currLst.HRS.Value.ToString() : "0";
                    txtLogST.Text = currLst.STAmt.HasValue ? currLst.STAmt.Value.ToString() : "0";
                    txtLogLT.Text = currLst.LTAmt.HasValue ? currLst.LTAmt.Value.ToString() : "0";
                    txtLogAmount.Text = currLst.AMOUNT.HasValue ? currLst.AMOUNT.Value.ToString("0.00") : "0.00";
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in grdReservDetails_CellDoubleClick");
            }
        }
        #endregion Misc Details

        #region Reservation Detail Status
        private void resetDetailsSection()
        {
            rowDetailIndex = -1;
            dtmAddFromDate.Value = DateTime.Today.Date.AddHours(09).AddMinutes(00).AddSeconds(00);
            dtmAddUptoDate.Value = DateTime.Today.Date.AddHours(17).AddMinutes(00).AddSeconds(00);
            if (cmbAddHallName.Items.Count > 0) cmbAddHallName.SelectedIndex = 0;
            if (cmbAddSeminarType.Items.Count > 0) cmbAddSeminarType.SelectedIndex = 0;
            txtAddRent.Text = string.Empty;
            txtaddRemarks.Text = string.Empty;
        }

        private void BindReservationStatus()
        {
            try
            {
                if (this.lstReservDetails == null) lstReservDetails = new List<EL.RESERVATION_DETAILS_STATUS>();
                int indexs = 1;
                var dbData = (from c in lstReservDetails
                              join d in objMasterData.GetRoomNumber() on c.reservation_dormid equals d.room_number_ID into ps
                              from d in ps.DefaultIfEmpty()
                              join e in objMasterData.GetRoomType() on c.RM_TYPE_ID2 equals e.RM_TYPE_ID into rt
                              from e in rt.DefaultIfEmpty()
                              select new
                              {
                                  c.reservation_status_id,
                                  SlNo = indexs++,
                                  From_Date = c.reservation_CHECKIN,
                                  Upto_Date = c.reservation_CHKOUT,
                                  //Rooms = c.reservation_Rooms,
                                  Hall = d != null ? d.room_number_number : string.Empty,
                                  //RoomAmt = c.ROOMrate1.HasValue ? c.ROOMrate1.Value.ToString("0.00") : "0.00",
                                  //Beds = c.reservation_Dorm,
                                  //Dormators = d == null ? string.Empty : d.room_number_number,
                                  SeminarType = e != null ? e.RM_TYPE_CODE+ " ("+e.RM_TYPE_DESC+")" : string.Empty,
                                  Rent = c.ROOMrate2.HasValue ? c.ROOMrate2.Value.ToString("0.00") : "0.00",
                                  Remarks = c.reservation_remark
                              }).ToList();

                dtmAddConference.DataSource = dbData;
                dtmAddConference.Columns["reservation_status_id"].Visible = false;
                dtmAddConference.Columns["From_Date"].DefaultCellStyle.Format = "dd/MMM/yyyy";
                dtmAddConference.Columns["Upto_Date"].DefaultCellStyle.Format = "dd/MMM/yyyy";
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindReservationStatus");
            }
        }

        private void btnAddCNew_Click(object sender, EventArgs e)
        {
            resetDetailsSection();
        }

        private void btnAddCAddChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (objReservation != null)
                {
                    if (this.rowDetailIndex > -1 && this.lstReservDetails.Count > 0)
                    {
                        this.lstReservDetails[this.rowDetailIndex].reservation_CHECKIN = dtmAddFromDate.Value;
                        this.lstReservDetails[this.rowDetailIndex].reservation_CHKOUT = dtmAddUptoDate.Value;
                        //this.lstReservDetails[this.rowDetailIndex].reservation_Dorm = 1;
                        //this.lstReservDetails[this.rowDetailIndex].RESERVATION_DETAILS_STATUS_SERIAL_RECORDS = 0;
                        this.lstReservDetails[this.rowDetailIndex].reservation_remark = txtaddRemarks.Text;
                        this.lstReservDetails[this.rowDetailIndex].reservation_dormid = Convert.ToInt32(cmbAddHallName.SelectedValue);
                        this.lstReservDetails[this.rowDetailIndex].RM_TYPE_ID2 = Convert.ToInt32(cmbAddSeminarType.SelectedValue);
                        this.lstReservDetails[this.rowDetailIndex].ROOMrate2 = !string.IsNullOrEmpty(txtAddRent.Text) ? Convert.ToDouble(txtAddRent.Text) : 0;
                    }
                    else
                    {
                        EL.RESERVATION_DETAILS_STATUS objDetailStatus = new EL.RESERVATION_DETAILS_STATUS();
                        objDetailStatus.reservation_ID = objReservation.reservation_ID;
                        objDetailStatus.reservation_CHECKIN = dtmAddFromDate.Value;
                        objDetailStatus.reservation_CHKOUT = dtmAddUptoDate.Value;
                        objDetailStatus.reservation_Dorm = 1;
                        objDetailStatus.RESERVATION_DETAILS_STATUS_SERIAL_RECORDS = lstReservDetails.Count + 1;
                        objDetailStatus.reservation_remark = txtaddRemarks.Text;
                        objDetailStatus.reservation_dormid = Convert.ToInt32(cmbAddHallName.SelectedValue);
                        objDetailStatus.RM_TYPE_ID2 = Convert.ToInt32(cmbAddSeminarType.SelectedValue);
                        objDetailStatus.ROOMrate2 = !string.IsNullOrEmpty(txtAddRent.Text) ? Convert.ToDouble(txtAddRent.Text) : 0;

                        this.lstReservDetails.Add(objDetailStatus);
                    }
                    resetDetailsSection();
                    BindReservationStatus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnAddCAddChange_Click");
            }
        }

        private void btnAddCRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.rowDetailIndex > -1 && this.lstReservDetails.Count > 0)
                {
                    this.lstReservDetails.RemoveAt(this.rowDetailIndex);
                    resetDetailsSection();
                    BindReservationStatus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDetRemove_Click");
            }
        }
        
        private void dtmAddConference_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex > -1)
                {
                    var currLst = lstReservDetails[e.RowIndex];
                    this.rowDetailIndex = e.RowIndex;
                    dtmAddFromDate.Value = currLst.reservation_CHECKIN.HasValue ? currLst.reservation_CHECKIN.Value : DateTime.Now;
                    dtmAddUptoDate.Value = currLst.reservation_CHKOUT.HasValue ? currLst.reservation_CHKOUT.Value : DateTime.Now;
                    cmbAddHallName.SelectedValue = currLst.reservation_dormid.HasValue ? currLst.reservation_dormid.Value : 0;
                    cmbAddSeminarType.SelectedValue = currLst.RM_TYPE_ID2.HasValue ? currLst.RM_TYPE_ID2.Value : 0;
                    txtAddRent.Text = currLst.ROOMrate2.HasValue ? currLst.ROOMrate2.Value.ToString("0.00") : "0.00";
                    txtaddRemarks.Text = currLst.reservation_remark;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in dtmAddConference_CellDoubleClick");
            }
        }
        #endregion Reservation Detail Status

        #region Catering
        private void BindReservationCatering()
        {
            try
            {
                if (this.lstReservCatering == null) lstReservCatering = new List<EL.RESERVATION_CATERING_DETAILS>();
                int indexs = 1;
                var dbData = (from c in lstReservCatering.DefaultIfEmpty()
                              select new
                              {
                                  c.reservation_CATER_id,
                                  SlNo = indexs++,
                                  Food_Name = string.Empty,
                                  Price = c.PRICE.HasValue ? c.PRICE.Value.ToString("0.00") : "0.00",
                                  Quantity = c.QUANTITY.HasValue ? c.QUANTITY.Value : 0,
                                  Person = c.PERSONS.HasValue ? c.PERSONS.Value : 0,
                                  Amount = c.AMOUNT.HasValue ? c.AMOUNT.Value.ToString("0.00") : "0.00",
                              }).ToList();

                grdReservDetails.DataSource = dbData;
                grdReservDetails.Columns["reservation_CATER_id"].Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in BindReservationCatering");
            }
        }
        #endregion Catering

        private void FillPageReservData()
        {
            try
            {
                if (this.objReservation != null)
                {
                    this.Text = "Seminar Entry : " + this.objReservation.reservation_PI_title + " " + this.objReservation.reservation_PI_frstname;

                    #region Tab 1 Entry
                    txtEntryNo.Text = this.objReservation.reservation_NUMBER.HasValue ? this.objReservation.reservation_NUMBER.Value.ToString() : string.Empty;
                    dtmReservTo.Value = this.objReservation.reservation_DATEofRESERV.HasValue ? this.objReservation.reservation_DATEofRESERV.Value : DateTime.Now;
                    cmbTitle.Text = this.objReservation.reservation_PI_title;
                    txtCustName.Text = this.objReservation.reservation_PI_frstname;
                    txtAddress.Text = this.objReservation.reservation_PI_street;
                    txtAddress2.Text = this.objReservation.reservation_PI_street1;
                    txtOrgans.Text = this.objReservation.reservation_PI_organ;
                    #endregion Tab 1 Entry

                    #region Tab 1 Add ReservDet
                    dtmFromDate.Value = this.objReservation.reservation_CHECKIN.HasValue ? this.objReservation.reservation_CHECKIN.Value : DateTime.Today.AddHours(09).AddMinutes(00).AddSeconds(0);
                    dtmTodate.Value = this.objReservation.reservation_CHKOUT.HasValue ? this.objReservation.reservation_CHKOUT.Value : DateTime.Today.AddHours(17).AddMinutes(00).AddSeconds(0);
                    cmbHallName.SelectedValue = this.objReservation.reservation_dormid.HasValue ? this.objReservation.reservation_dormid.Value : 0;
                    txtRent.Text = this.objReservation.ROOMrate2.HasValue ? this.objReservation.ROOMrate2.Value.ToString() : string.Empty;
                    cmbSeminarType.SelectedValue = this.objReservation.RM_TYPE_ID2.HasValue ? this.objReservation.RM_TYPE_ID2.Value : 0;
                    txtRemarks.Text = this.objReservation.ReservRemarks;
                    chkServiceExmpt.Checked = this.objReservation.stexempted.HasValue ? this.objReservation.stexempted.Value : false;
                    txtDiscountPer.Text = this.objReservation.Discount.HasValue ? this.objReservation.Discount.Value.ToString() : "0";
                    #endregion Tab 1 Add ReservDet

                    #region Tab 1 Receipt Entry
                    lblCustStatus.Text = objReservation.reservation_ID > 0 ? "Existing Entry" : "New Entry";

                    txtReceipt0.Text = this.objReservation.Reserv_Status_receiptNo0.HasValue ? this.objReservation.Reserv_Status_receiptNo0.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt0, null);
                    txtReceipt1.Text = this.objReservation.Reserv_Status_receiptNo1.HasValue ? this.objReservation.Reserv_Status_receiptNo1.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt1, null);
                    txtReceipt2.Text = this.objReservation.Reserv_Status_receiptNo2.HasValue ? this.objReservation.Reserv_Status_receiptNo2.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt2, null);
                    txtReceipt3.Text = this.objReservation.Reserv_Status_receiptNo3.HasValue ? this.objReservation.Reserv_Status_receiptNo3.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt3, null);
                    txtReceipt4.Text = this.objReservation.Reserv_Status_receiptNo4.HasValue ? this.objReservation.Reserv_Status_receiptNo4.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt4, null);
                    txtReceipt5.Text = this.objReservation.Reserv_Status_receiptNo5.HasValue ? this.objReservation.Reserv_Status_receiptNo5.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt5, null);
                    txtReceipt6.Text = this.objReservation.Reserv_Status_receiptNo6.HasValue ? this.objReservation.Reserv_Status_receiptNo6.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt6, null);
                    txtReceipt7.Text = this.objReservation.Reserv_Status_receiptNo7.HasValue ? this.objReservation.Reserv_Status_receiptNo7.Value.ToString() : string.Empty;
                    txtReceipt0_Leave(txtReceipt7, null);
                    #endregion Tab 1 Receipt Entry

                    decimal totalAmt = 0m;
                    if (!string.IsNullOrEmpty(lblReceiptAmt0.Text)) totalAmt += Convert.ToDecimal(lblReceiptAmt0.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo1.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo1.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo2.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo2.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo3.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo3.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo4.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo4.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo5.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo5.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo6.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo6.Text);
                    if (!string.IsNullOrEmpty(lblReceiptNo7.Text)) totalAmt += Convert.ToDecimal(lblReceiptNo7.Text);

                    lblTotalReceipt.Text = "Adv Recpt. : " + totalAmt.ToString("0.00");
                    if (totalAmt > 0) lblCustStatus.BackColor = System.Drawing.Color.Red;
                    else lblCustStatus.BackColor = System.Drawing.Color.LightSkyBlue;

                    this.lstReservDetails = this.objReservation.RESERVATION_DETAILS_STATUS.ToList();
                    this.lstReservCatering = this.objReservation.RESERVATION_CATERING_DETAILS.ToList();
                    this.lstReservMiscDet = this.objReservation.RESERVATION_MISC_DETAILS.ToList();

                    BindReservationStatus();
                    BindMiscItemDetails();
                    BindReservationCatering();

                    if (this.objReservation.reservation_ID > 0 && !editPage)
                    {
                        btnUndo.Enabled = false;
                        btnSave.Enabled = false;
                        btnAddNew.Enabled = true;
                        btnEdit.Enabled = true;
                        btnDelete.Enabled = false;

                        splitContainer1.Panel1.Controls.Add(aplhaPanel);
                        aplhaPanel.Dock = DockStyle.Fill;
                        aplhaPanel.BringToFront();
                    }
                }
                else
                {
                    splitContainer1.Panel1.Controls.Remove(aplhaPanel);
                    btnUndo.Enabled = false;
                    btnSave.Enabled = true;
                    btnAddNew.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error In FillPageReservData");
            }
        }

        private void txtReceipt0_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void txtCustName_Leave(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(TextBox))
            {
                TextBox txtCap = (TextBox)sender;
                txtCap.Text = CommonBaseFN.ConvertFirstLetterToCapital(txtCap.Text.Trim());
            }
        }

        private void txtEntryNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender.GetType() == typeof(ComboBox))
                {
                    if ((ComboBox)sender == cmbTitle) txtCustName.Focus();
                    if ((ComboBox)sender == cmbHallName) dtmTodate.Focus();
                    if ((ComboBox)sender == cmbLogItem) txtLogST.Focus();
                }
                else if (sender.GetType() == typeof(DateTimePicker))
                {
                    //if ((DateTimePicker)sender == dtmReservTo) cmbTitle.Focus();
                    //if ((DateTimePicker)sender == dtmTodate) txtUpto.Focus();
                    //if ((DateTimePicker)sender == dtmFromDate) txtRemarks.Focus();
                    //if ((DateTimePicker)sender == dtmDetUptoReserv) dtmDetFromReserv.Focus();
                    //if ((DateTimePicker)sender == dtmDetFromReserv) txtNoOfRooms.Focus();
                    //if ((DateTimePicker)sender == dateTimePicker6) dateTimePicker7.Focus();
                }
                else if (sender.GetType() == typeof(TextBox))
                {
                    if ((TextBox)sender == txtEntryNo) dtmReservTo.Focus();
                    if ((TextBox)sender == txtCustName) txtAddress.Focus();
                    if ((TextBox)sender == txtAddress) txtAddress2.Focus();
                    if ((TextBox)sender == txtAddress2) txtRent.Focus();
                    if ((TextBox)sender == txtRent) txtDiscountPer.Focus();
                    if ((TextBox)sender == txtDiscountPer) cmbHallName.Focus();
                    //if ((TextBox)sender == txtUpto)
                    //{
                    //    int dayNo = 0;
                    //    if (int.TryParse(txtUpto.Text.Trim(), out dayNo) && dayNo > 0)
                    //        dtmTodate.Value = dtmFromDate.Value.Date.AddDays(dayNo);
                    //    dtmTodate.Focus();
                    //} 
                    //if ((TextBox)sender == txtRemarks) txtRoomFolioNo.Focus();
                    //if ((TextBox)sender == txtRoomFolioNo) dtmDetUptoReserv.Focus();
                    //if ((TextBox)sender == txtNoOfRooms) txtNoOfBeds.Focus();
                    //if ((TextBox)sender == txtNoOfBeds) cmbDetDorm.Focus();
                    //if ((TextBox)sender == txtDetRemarks) txtReceipt0.Focus();
                    //if ((TextBox)sender == txtReceipt0) txtReceipt1.Focus();
                    //if ((TextBox)sender == txtReceipt1) txtReceipt2.Focus();
                    //if ((TextBox)sender == txtReceipt2) txtReceipt3.Focus();
                    //if ((TextBox)sender == txtReceipt3) txtReceipt4.Focus();
                    //if ((TextBox)sender == txtReceipt4) dateTimePicker6.Focus();
                }

            }
        }

        private void txtReceipt0_Leave(object sender, EventArgs e)
        {
            try
            {
                int receiptNo = 0;
                if (sender.GetType() == typeof(TextBox) && int.TryParse(((TextBox)sender).Text, out receiptNo))
                {
                    EL.FilterClass objFilter = RefreshFilter();
                    objFilter.tagChar = Convert.ToString((char)CommonVariables.SpecialTag.Reciept);
                    objFilter.RecordNumber = receiptNo;

                    EL.receipt_payment objReceipt = objReceiptBook.GetReceiptByID(objFilter, CommonVariables.RecordCatergory.None);
                    if (objReceipt == null) objReceipt = new EL.receipt_payment();
                    if (sender == txtReceipt0)
                    {
                        this.objReservation.Reserv_Status_receiptNo0 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id0 = objReceipt.recpt_pay_id;
                        lblReceiptAmt0.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc0.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt1)
                    {
                        this.objReservation.Reserv_Status_receiptNo1 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id1 = objReceipt.recpt_pay_id;
                        lblReceiptNo1.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc1.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt2)
                    {
                        this.objReservation.Reserv_Status_receiptNo2 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id2 = objReceipt.recpt_pay_id;
                        lblReceiptNo2.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc2.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt3)
                    {
                        this.objReservation.Reserv_Status_receiptNo3 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id3 = objReceipt.recpt_pay_id;
                        lblReceiptNo3.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc3.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt4)
                    {
                        this.objReservation.Reserv_Status_receiptNo4 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id4 = objReceipt.recpt_pay_id;
                        lblReceiptNo4.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc4.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt5)
                    {
                        this.objReservation.Reserv_Status_receiptNo5 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id5 = objReceipt.recpt_pay_id;
                        lblReceiptNo5.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc5.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt6)
                    {
                        this.objReservation.Reserv_Status_receiptNo6 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id6 = objReceipt.recpt_pay_id;
                        lblReceiptNo6.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc6.Text = objReceipt.ONACOF;
                    }
                    else if (sender == txtReceipt7)
                    {
                        this.objReservation.Reserv_Status_receiptNo7 = objReceipt.receipt_No;
                        this.objReservation.recpt_pay_id7 = objReceipt.recpt_pay_id;
                        lblReceiptNo7.Text = objReceipt.total_amt.HasValue ? objReceipt.total_amt.Value.ToString("0.00") : "0.00";
                        lblRecepDesc7.Text = objReceipt.ONACOF;
                    }

                    IList<EL.receipt_payment_Adjust_details> lstAdtype = objReceipt.receipt_payment_Adjust_details.Where(x => x.AdjType.ToUpper() == "ROOMS" ||
                        x.AdjType.ToUpper() == "DORMATORY" || x.AdjType.ToUpper() == "SEMINAR").ToList();
                    foreach (EL.receipt_payment_Adjust_details objAdjType in lstAdtype)
                    {
                        if (!string.IsNullOrEmpty(lblCustStatus.Text)) lblCustStatus.Text += " | ";
                        lblCustStatus.Text += objAdjType.Refno.ToString() + " / " + objAdjType.AdjType.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in txtReceipt0_Leave");
            }
        }

        private void btnAddGuest_Click(object sender, EventArgs e)
        {
            try
            {
                using (Master.frmGuestMaster frmGuest = new Master.frmGuestMaster())
                {
                    frmGuest.ShowDialog();
                    GuestMasteretails(frmGuest.guestnum);
                }
            }
            catch (Exception ex)
            {   
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnAddGuest_Click");
            }
        }

        private void GuestMasteretails(int guestnumber)
        {
            EL.Mast_guest objGuest = objGuestMaster.GuestDetailByID(new EL.Mast_guest { GUEST_NUM = guestnumber });
            if (objGuest != null)
            {
                if (objReservation != null)
                {
                    this.objReservation.GUEST_NUM = objGuest.GUEST_NUM;
                    this.objReservation.reservation_weekday_overriderates = objGuest.G_override_rate;
                    this.objReservation.reservation_taxINCIDENTIALS = objGuest.G_tax_incidencials;
                    this.objReservation.reservation_PI_title = objGuest.G_TITLE;
                    this.objReservation.reservation_PI_frstname = objGuest.G_FNAME;
                    this.objReservation.reservation_PI_lastname = objGuest.G_LNAME;
                    this.objReservation.reservation_PI_street = objGuest.G_Street;
                    this.objReservation.reservation_PI_city = objGuest.G_CITY;
                    this.objReservation.reservation_PI_state = objGuest.G_STATE;
                    this.objReservation.reservation_PI_country = objGuest.G_COUNTRY;
                    this.objReservation.reservation_PI_zip = objGuest.G_ZIP;
                    this.objReservation.reservation_PI_street1 = objGuest.G_PHONE1 + " " + objGuest.G_PHONE2 + " " + objGuest.G_EMAIL;
                    this.objReservation.reservation_PI_organ = objGuest.G_ContPerson;
                }
                else
                {
                    resetPageData();
                    this.objReservation = new EL.RESERVATION_CHECKIN_WALKIN
                    {
                        tag_reserv_chkin_walkin = this.reservTagChar,
                        GUEST_NUM = objGuest.GUEST_NUM,
                        reservation_weekday_overriderates = objGuest.G_override_rate,
                        reservation_taxINCIDENTIALS = objGuest.G_tax_incidencials,
                        reservation_PI_title = objGuest.G_TITLE,
                        reservation_PI_frstname = objGuest.G_FNAME,
                        reservation_PI_lastname = objGuest.G_LNAME,
                        reservation_PI_street = objGuest.G_Street,
                        reservation_PI_city = objGuest.G_CITY,
                        reservation_PI_state = objGuest.G_STATE,
                        reservation_PI_country = objGuest.G_COUNTRY,
                        reservation_PI_zip = objGuest.G_ZIP,
                        reservation_PI_street1 = objGuest.G_PHONE1 + " " + objGuest.G_PHONE2 + " " + objGuest.G_EMAIL,

                        reservation_PI_organ = objGuest.G_ContPerson,
                        reservation_discount_TYPE = false,
                        reservation_OI_sentINbatch = false,
                        activate_delete = false,
                        charge_frm_day_reserv = false,
                        change_room = false,
                        discountperamt = false,
                        LTXtraIncl = false,
                        CompanyStatus = false,
                        Amtconsolidated = false,
                        Reservation_groupmaster = false,
                        reservation_NUMBER_ROOMS = 0,
                        reservation_ISagainstReserv = 0,
                        cancelreservation = 0,

                        #region Main Columns to be filled
                        //reservation_ID;
                        //reservation_NUMBER;
                        //reservation_CHECKIN;
                        //reservation_CHKOUT;
                        //reservation_DATEofRESERV;
                        //id;
                        //date_of_add;
                        //id1;
                        //date_of_mod;
                        //hotelbillno;
                        //MachineName = maschinename;
                        reservation_UptoDays = 1,
                        //ReservRemarks;
                        //reservation_GuestRem;
                        reservation_NUMBER_BEDS = 1,
                        //Reserv_Status_receiptNo0;
                        //recpt_pay_id0;
                        //Reserv_Status_receiptNo1;
                        //recpt_pay_id1;
                        //Reserv_Status_receiptNo2;
                        //recpt_pay_id2;
                        //Reserv_Status_receiptNo3;
                        //recpt_pay_id3;
                        //Reserv_Status_receiptNo4;
                        //recpt_pay_id4;
                        //Reserv_Status_receiptNo5;
                        //recpt_pay_id5;
                        //Reserv_Status_receiptNo6;
                        //recpt_pay_id6;
                        //Reserv_Status_receiptNo7;
                        //recpt_pay_id7;
                        //Reserv_LodgingRequirement;
                        //Reserv_SemConfChargesDetails;
                        //Reserv_CateringRequirement;
                        //Reserv_OtherRequirement;
                        //Reserv_BillNumber;
                        //Reserv_advanceDet;
                        //Reserv_CaterPersons;
                        //reservation_dormid;
                        //reservation_Catering_TotalBillAmt;
                        //reservation_Catering_TotalReceiptAmt;
                        //reservation_Catering_BalanceAmt;
                        //createdby;
                        //modifiedby;
                        //reservation_DateofCancel;
                        #endregion Main Columns to be filled

                        #region Not in Used
                        //reservation_weekday
                        //reservation_weekend;
                        //this.objReservation.reservation_NUMBER_pref;
                        //this.objReservation.reservation_NIGHTS;
                        //reservation_ROOMS;
                        //this.objReservation.reservation_ADULTS;
                        //this.objReservation.reservation_CHILDS;
                        //this.objReservation.RM_TYPE_ID;
                        //this.objReservation.Rate_type_ID;
                        //this.objReservation.rate_code_id;
                        //this.objReservation.Discount_code_id;
                        //this.objReservation.reservation_discount_amt;
                        //this.objReservation.room_change_id;
                        //this.objReservation.reservation_deposits;
                        //this.objReservation.reservation_ASSIGNED;
                        //this.objReservation.group_code_id;
                        //this.objReservation.reservation_PI_phone1;
                        //this.objReservation.reservation_PI_phone2;
                        //this.objReservation.reservation_PI_reference;
                        //this.objReservation.reservation_OI_holdtype;
                        //this.objReservation.reservation_OI_number;
                        //this.objReservation.reservation_OI_expDATE;
                        //this.objReservation.reservation_OI_nameONcard;
                        //this.objReservation.reservation_OI_DIRECT_BILL;
                        //this.objReservation.reservation_OI_DIRECT_Company;
                        //this.objReservation.reservation_OI_madeBY;
                        //this.objReservation.reservation_OI_emil_addr;
                        //this.objReservation.reservation_OI_lettersent;
                        //this.objReservation.reservation_OI_language;
                        //this.objReservation.TRAVEL_AGENT_ID;
                        //this.objReservation.market_code_id;
                        //this.objReservation.airport_id;
                        //this.objReservation.reservation_CF_arrivalTIME;
                        //this.objReservation.reservation_CF_arrivalFLIGHT;
                        //this.objReservation.reservation_CF_departureTIME;
                        //this.objReservation.reservation_CF_departureFLIGHT;
                        //this.objReservation.reservation_CF_SCUBAlesson;
                        //this.objReservation.reservation_guestNOTES;
                        //this.objReservation.reservation_housekeeping;
                        //this.objReservation.Account_id;
                        //this.objReservation.reservation_deposit_AMOUNT;
                        //this.objReservation.reservation_deposit_voucher;
                        //this.objReservation.expected_time_stay;
                        //this.objReservation.room_number_ID;
                        //this.objReservation.reservation_realCHECKIN;
                        //this.objReservation.reservation_realCHECKOUT;
                        //this.objReservation.reservation_rateROOM;
                        //this.objReservation.id2;
                        //this.objReservation.date_of_add2;
                        //this.objReservation.id3;
                        //this.objReservation.date_of_add3;
                        //this.objReservation.reservation_xtrabed_amt;
                        //this.objReservation.reservation_rel_with_lodg;
                        //this.objReservation.reservation_nationality;
                        //this.objReservation.reservation_age;
                        //this.objReservation.reservation_pra;
                        //this.objReservation.reservation_dt_ap_arriv;
                        //this.objReservation.reservation_from_lodg_arrv;
                        //this.objReservation.reservation_reas_visit;
                        //this.objReservation.reservation_prob_dur_stay_in;
                        //this.objReservation.reservation_nat_accom;
                        //this.objReservation.reservation_next_proc;
                        //this.objReservation.reservation_passport;
                        //this.objReservation.reservation_addr_ind;
                        //this.objReservation.reservation_emp_ind;
                        //this.objReservation.reservation_no_dt_cert;
                        //this.objReservation.reservation_remark;
                        //this.objReservation.change_room_reser_id;
                        //this.objReservation.change_room_reser_id_PAR;
                        //this.objReservation.act_service_charges;
                        //this.objReservation.GRNo;
                        //this.objReservation.Discount; 
                        //this.objReservation.Comp_NUM;
                        //this.objReservation.CGuest_num;
                        //this.objReservation.planid;
                        //this.objReservation.ROOM_TYPE_ID;                            
                        //this.objReservation.reservation_extrabedFrom;
                        //this.objReservation.reservation_extrabedTo;
                        //this.objReservation.reservation_ExtraBedUptoDays;
                        //this.objReservation.ReserveType;
                        //this.objReservation.NoofaddlCust;
                        //this.objReservation.reservation_nationality2;
                        //this.objReservation.reservation_nationality1;
                        //this.objReservation.reservation_GuestRem2;
                        //this.objReservation.reservation_GuestRem1;
                        //this.objReservation.GRNo2;
                        //this.objReservation.GRNo1;
                        //this.objReservation.reservation_ADULTS2;
                        //this.objReservation.reservation_ADULTS1;
                        //this.objReservation.reservation_PI_title2;
                        //this.objReservation.reservation_PI_frstname2;
                        //this.objReservation.reservation_PI_title1;
                        //this.objReservation.reservation_PI_frstname1;
                        //this.objReservation.reservation_PI_reservtype;
                        //this.objReservation.reservation_Cformno;
                        //this.objReservation.hotelBillnodorm;
                        //this.objReservation.currentbookno;
                        //this.objReservation.reservation_NoRoom2;
                        //this.objReservation.reservation_NoDorm2;
                        //this.objReservation.reservation_NoRoom1;
                        //this.objReservation.reservation_NoDorm1;
                        //this.objReservation.reservation_NoRoom;
                        //this.objReservation.reservation_NoDorm;
                        //this.objReservation.reservation_shortname;
                        //this.objReservation.reservation_againstReserv;
                        //this.objReservation.reservation_roomfolio;
                        //this.objReservation.reservation_dormfolio;
                        //this.objReservation.reservation_LastPlaceStay;
                        //this.objReservation.reservation_sex;
                        //this.objReservation.reservation_DOB;
                        //this.objReservation.reservation_nationalityByBirth;
                        //this.objReservation.reservation_Parentage;
                        //this.objReservation.reservation_at_lodg_arrv;
                        //this.objReservation.reservation_PhNo;
                        //this.objReservation.reservation_Email;
                        //this.objReservation.reservation_addr_native;
                        //this.objReservation.reservation_DateRegn;
                        //this.objReservation.reservation_PlaceIssueRegn;
                        //this.objReservation.reservation_passportPlace;
                        //this.objReservation.reservation_passportDate;
                        //this.objReservation.reservation_passportExpiry;
                        //this.objReservation.reservation_VISAType;
                        //this.objReservation.reservation_VISA;
                        //this.objReservation.reservation_VISAPlace;
                        //this.objReservation.reservation_VISADate;
                        //this.objReservation.reservation_VISAExpiry;
                        //this.objReservation.reservation_OtherLodger;
                        #endregion Not in Used
                    };
                }

                //EL.CompanyGuest cguets = objGuestMaster.SearchCompanyGuest(objGuest.G_COMPANY).FirstOrDefault();
                //if (cguets != null)
                //{
                //    objReservation.RecName = cguets.CGUEST_CODE;
                //    objReservation.RecGST_NO = cguets.GST_NO;
                //    objReservation.RecUID_NO = cguets.UID_NO;
                //    objReservation.RecAddr1 = cguets.CG_Street;
                //    objReservation.RecAddr2 = cguets.CG_ADDRESS2;
                //    objReservation.RecAddr3 = cguets.CG_CITY;
                //    objReservation.GuestGSTstateID = cguets.GSTSTATE_id;
                //    objReservation.GuestGSTstateCODE = string.Empty;
                //}

                objReservation.stexempted = false;
                objReservation.ReceiptRightId = 1;
                objReservation.ReceiptRightDesc = "Conference";
                objReservation.BundledServ = false;

                FillPageReservData();
            }
        }

        private void btnSelectGuest_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmGuestSearch frmGuest = new frmGuestSearch())
                {
                    frmGuest.guestName = txtCustName.Text;
                    frmGuest.searchTypeObject = typeof(EL.Mast_guest);
                    frmGuest.ShowDialog();
                    if (frmGuest.GuestNum > 0)
                    {
                        GuestMasteretails(frmGuest.GuestNum);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnSelectGuest_Click");
            }
        }

        private void cmbSeminarType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cmbtype = (ComboBox)sender;
            if(cmbtype.SelectedIndex > 0)
            {
                TextBox textrent = (cmbtype == cmbAddSeminarType ? txtAddRent : txtRent);
                int rmid = (int)cmbtype.SelectedValue;
                if (rmid > 0)
                {
                    DBData.ISIPMEntities dbContext = new DBData.ISIPMEntities();
                    DBData.ROOM_TYPE_rates rmrate = dbContext.ROOM_TYPE_rates.Where(x => x.RM_TYPE_ID == rmid).OrderByDescending(x => x.RM_TYPE_rate_ID).FirstOrDefault();
                    if (rmrate != null)
                    {
                        textrent.Text = rmrate.Room_Type_rate.HasValue ? rmrate.Room_Type_rate.Value.ToString("0.00") : "0.00";
                    }
                }
            }
        }

        #region Bottom Action
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            resetPageData();
            splitContainer1.Panel1.Controls.Remove(this.aplhaPanel);
            btnUndo.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            editPage = true;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel1.Controls.Remove(this.aplhaPanel);
            btnUndo.Enabled = true;
            btnSave.Enabled = true;
            btnAddNew.Enabled = false;
            btnEdit.Enabled = false;
            editPage = true;
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            editPage = false;
            EL.FilterClass objFilter = RefreshFilter();
            objFilter.UniqueId = this.objReservation.reservation_ID;
            resetPageData();
            if (objFilter.UniqueId > 0)
            {
                this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                FillPageReservData();
            }
            else
                btnLast_Click(sender, e);
        }

        private bool ValidateFormData()
        {
            if (string.IsNullOrEmpty(txtCustName.Text))
            {
                CustomMessageBox.ShowInformationMessage("Please select Customer !!", this.Text);
                txtCustName.Focus();
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateFormData() && this.objReservation != null)
                {
                    bool isNew = false;
                    objReservation.reservation_NUMBER_ROOMS = 0;
                    objReservation.reservation_NUMBER_BEDS = 1;
                    //objReservation.reservation_UptoDays = (dtmTodate.Value.Date - dtmFromDate.Value.Date).Days == 0 ? 1 : (dtmTodate.Value.Date - dtmFromDate.Value.Date).Days;
                    objReservation.reservation_CHECKIN = dtmFromDate.Value;
                    objReservation.reservation_CHKOUT = dtmTodate.Value;
                    objReservation.reservation_DATEofRESERV = dtmReservTo.Value.Date;
                    objReservation.MachineName = Environment.MachineName;
                    objReservation.ReservRemarks = txtRemarks.Text;
                    objReservation.reservation_dormid = (cmbHallName.SelectedIndex > 0) ? Convert.ToInt32(cmbHallName.SelectedValue) : 0;
                    objReservation.RM_TYPE_ID2 = cmbSeminarType.SelectedIndex > 0 ? Convert.ToInt32(cmbSeminarType.SelectedValue) : 0;
                    objReservation.ROOMrate2 = !string.IsNullOrEmpty(txtRent.Text) ? Convert.ToDouble(txtRent.Text) : 0;
                    objReservation.stexempted = chkServiceExmpt.Checked;
                    objReservation.discountperamt = true;
                    objReservation.Discount = !string.IsNullOrEmpty(txtDiscountPer.Text) ? Convert.ToDouble(txtDiscountPer.Text) : 0;

                    if (this.objReservation.reservation_ID > 0)
                    {
                        #region Main Edit
                        objReservation.id1 = Frm_Login.UserLogin.log_id;
                        objReservation.date_of_mod = DateTime.Now;
                        objReservation.modifiedby = Frm_Login.UserLogin.loginID;
                        #endregion Main Edit
                    }
                    else
                    {
                        isNew = true;

                        #region Main Add
                        objReservation.id = Frm_Login.UserLogin.log_id;
                        objReservation.date_of_add = DateTime.Now;
                        objReservation.createdby = Frm_Login.UserLogin.loginID;
                        #endregion Main Add
                    }

                    objReservation.RESERVATION_MISC_DETAILS = lstReservMiscDet;
                    objReservation.RESERVATION_DETAILS_STATUS = lstReservDetails;
                    objReservation.RESERVATION_CATERING_DETAILS = lstReservCatering;

                    EL.RESERVATION_CHECKIN_WALKIN objNewReservation = isNew ? objReservBook.SaveReservation(this.objReservation) : objReservBook.UpdateReservation(this.objReservation);
                    
                    resetPageData();
                    this.objReservation = objNewReservation;
                    if (this.objReservation != null)
                        CustomMessageBox.ShowInformationMessage("Record Saved !!!", this.Text);
                    else if (this.objReservation == null && (Button)sender == btnDelete)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Saved !!!", this.Text);
                        btnAddNew_Click(sender, e);
                    }
                    else
                        CustomMessageBox.ShowInformationMessage("Record Not Saved !!!", this.Text);
                    
                    editPage = false;
                    FillPageReservData();
                    
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Unable to save data", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in Save data");
            }
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {

        }        

        private void btnMemo_Click(object sender, EventArgs e)
        {

        }

        //Button Bill Click
        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.objReservation != null && this.objReservation.reservation_ID > 0)
                {
                    using (Seminar.frmSeminarBillpol frmSembill = new Seminar.frmSeminarBillpol())
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        frmSembill.reservationID = objReservation.reservation_ID;
                        this.Hide();
                        frmSembill.ShowDialog();
                        this.Show();
                        if (frmSembill.reservationID > 0) objFilter.UniqueId = frmSembill.reservationID;
                        resetPageData();
                        this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                        FillPageReservData();
                    }
                }
                else
                    CustomMessageBox.ShowInformationMessage("Please select entry print", this.Text);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Open_Bill");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.objReservation != null && this.objReservation.reservation_ID > 0)
                {
                    using (Seminar.frmSeminarEstimate frmEstimatebill = new Seminar.frmSeminarEstimate())
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        frmEstimatebill.reservationID = objReservation.reservation_ID;
                        frmEstimatebill.StartPosition = FormStartPosition.CenterScreen;
                        this.Hide();
                        frmEstimatebill.ShowDialog();
                        this.Show();
                        if (frmEstimatebill.reservationID > 0) objFilter.UniqueId = frmEstimatebill.reservationID;
                        resetPageData();
                        this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                        FillPageReservData();
                    }
                }
                else
                    CustomMessageBox.ShowInformationMessage("Please select Seminar Entry!", this.Text);
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Open_EstimateBill");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                using (frmReservation frmSearch = new frmReservation())
                {
                    frmSearch.tagReservation = this.reservTagChar;
                    frmSearch.ShowDialog();
                    if (frmSearch.reservationid > 0)
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        objFilter.UniqueId = frmSearch.reservationid;
                        resetPageData();
                        this.objReservation = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                        FillPageReservData();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error In btnOpenByEntryNo_Click");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (CustomMessageBox.ShowDialogBoxMessage("Delete this Hostel Booking ?") == System.Windows.Forms.DialogResult.OK)
                {
                    this.objReservation.cancelreservation = 0;
                    this.objReservation.activate_delete = true;
                    btnSave_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnDelete_Click");
            }
        }

        private void btnReceipt_Click(object sender, EventArgs e)
        {
            editPage = false;
            using (Transaction.frmVoucher frmVouch = new Transaction.frmVoucher())
            {
                frmVouch.reservationID = (this.objReservation != null) ? this.objReservation.reservation_ID : 0;
                frmVouch.ShowDialog();
                int reservid = (this.objReservation != null) ? this.objReservation.reservation_ID : 0;
                resetPageData();
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = reservid;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);
                FillPageReservData();
            }
        }

        private void btnOpenByEntryNo_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                string strValue = string.Empty;
                int entryno = 0;
                if (CustomFormFunction.InputBox("Search by Entry No", "Please enter Entry No", ref strValue) == System.Windows.Forms.DialogResult.OK)
                {
                    if (int.TryParse(strValue, out entryno))
                    {
                        EL.FilterClass objFilter = RefreshFilter();
                        objFilter.RecordNumber = entryno;
                        EL.RESERVATION_CHECKIN_WALKIN objReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.None);

                        if (objReserv != null)
                        {
                            resetPageData();
                            this.objReservation = objReserv;
                            FillPageReservData();
                        }
                        else
                            CustomMessageBox.ShowHandMessage("Record not found", this.Text);
                    }
                    else
                        CustomMessageBox.ShowHandMessage("Invalid Input !!!", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error in btnOpenByEntryNo_Click");
            }
        }
        #endregion Bottom Action

        #region First Last Next Previous
        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(RefreshFilter(), CommonVariables.RecordCatergory.First);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is First record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In First Records");
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.objReservation != null ? this.objReservation.reservation_ID : 0;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.Previous);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is First record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Previous Records");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.FilterClass objFilter = RefreshFilter();
                objFilter.UniqueId = this.objReservation != null ? this.objReservation.reservation_ID : 0;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(objFilter, CommonVariables.RecordCatergory.Next);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is last record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Next Records");
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                editPage = false;
                EL.RESERVATION_CHECKIN_WALKIN objSReserv = objReservBook.GetReservationByID(RefreshFilter(), CommonVariables.RecordCatergory.Last);

                if (objSReserv != null && this.objReservation != null && objSReserv.reservation_ID == this.objReservation.reservation_ID)
                    CustomMessageBox.ShowInformationMessage("This is last record", this.Text);

                resetPageData();
                this.objReservation = objSReserv;
                FillPageReservData();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error In Last Records");
            }
        }
        #endregion First Last Next Previous

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void cmbLogItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbLogItem.SelectedIndex > 0)
            {
                int miscId = Convert.ToInt32(cmbLogItem.SelectedValue);
                EL.Misc_items objMisc = objMasterData.GetMiscItems().FirstOrDefault(x => x.Misc_items_Id == miscId);
                if (objMisc != null)
                {
                    txtLogPrice.Text = objMisc.Price.HasValue ? objMisc.Price.Value.ToString("0.00") : "0.00";
                    txtLogQuantity.Text = objMisc.Unit.HasValue ? objMisc.Unit.Value.ToString() : "0";
                    txtLogAmount.Text = txtLogPrice.Text;
                    txtLogHrs.Text = "0";
                    txtLogST.Text = ((objMisc.Price.HasValue ? objMisc.Price.Value : 0) * Convert.ToDecimal(CommonVariables.MiscGST / 100)).ToString("0.00");
                    txtLogLT.Text = "0";
                }
                else
                {
                    txtLogPrice.Text = "0";
                    txtLogQuantity.Text = "0";
                    txtLogAmount.Text = "0";
                    txtLogHrs.Text = "0";
                    txtLogST.Text = "0";
                    txtLogLT.Text = "0";
                }
            }
        }

        private void txtLogPrice_Leave(object sender, EventArgs e)
        {
            double logprice, logQuant, loghrs, logst, loglt, logAmt;
            logprice = !string.IsNullOrEmpty(txtLogPrice.Text) ? Convert.ToDouble(txtLogPrice.Text) : 0;
            logQuant = !string.IsNullOrEmpty(txtLogQuantity.Text) ? Convert.ToDouble(txtLogQuantity.Text) : 0;
            loghrs = !string.IsNullOrEmpty(txtLogHrs.Text) ? Convert.ToDouble(txtLogHrs.Text) : 0;
            logst = !string.IsNullOrEmpty(txtLogST.Text) ? Convert.ToDouble(txtLogST.Text) : 0;
            loglt = !string.IsNullOrEmpty(txtLogLT.Text) ? Convert.ToDouble(txtLogLT.Text) : 0;
                        
            logAmt = (logprice * logQuant) + loghrs;
            logst = logAmt * CommonVariables.MiscGST / 100;

            txtLogST.Text = logst.ToString("0.00");
            txtLogAmount.Text = logAmt.ToString("0.00");
        }

        private void btnCancelHostory_Click(object sender, EventArgs e)
        {
            using (frmCancelReservation frmCancelView = new frmCancelReservation())
            {
                frmCancelView.IsCancelForm = false;
                frmCancelView.reservationId = objReservation.reservation_ID;
                frmCancelView.reservationnumber = objReservation.reservation_NUMBER.HasValue ? objReservation.reservation_NUMBER.Value : 0;
                frmCancelView.title = objReservation.reservation_PI_title;
                frmCancelView.cname = objReservation.reservation_PI_frstname;
                frmCancelView.address = objReservation.reservation_PI_street;
                frmCancelView.address2 = objReservation.reservation_PI_street1;
                frmCancelView.reservdate = objReservation.reservation_DATEofRESERV.HasValue ? objReservation.reservation_DATEofRESERV.Value : DateTime.Now;
                frmCancelView.ShowDialog();
            }
        }

        private void btnCancellations_Click(object sender, EventArgs e)
        {
            using (frmCancelReservation frmCancelView = new frmCancelReservation())
            {
                frmCancelView.IsCancelForm = true;
                frmCancelView.reservationId = objReservation.reservation_ID;
                frmCancelView.reservationnumber = objReservation.reservation_NUMBER.HasValue ? objReservation.reservation_NUMBER.Value : 0;
                frmCancelView.title = objReservation.reservation_PI_title;
                frmCancelView.cname = objReservation.reservation_PI_frstname;
                frmCancelView.address = objReservation.reservation_PI_street;
                frmCancelView.address2 = objReservation.reservation_PI_street1;
                frmCancelView.reservdate = objReservation.reservation_DATEofRESERV.HasValue ? objReservation.reservation_DATEofRESERV.Value : DateTime.Now;
                frmCancelView.ShowDialog();
            }
        }
    }
}
