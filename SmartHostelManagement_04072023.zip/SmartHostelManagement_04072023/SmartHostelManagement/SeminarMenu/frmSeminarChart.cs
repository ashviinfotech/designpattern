﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using SMH.BusinessLogic.Layer;
using EL = SMH.Entities.Layer;
using SMH.CommonLogic.Layer;
using SmartHostelManagement.Search;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Seminar
{
    public partial class frmSeminarChart : Form
    {
        MasterCaller objreportData = new MasterCaller();
        HostelCaller objHostelData = new HostelCaller();
        DataTable dtChartData { get; set; }
        DataTable dtDetails { get; set; }
        Dictionary<int, System.Drawing.Color> chartColor = new Dictionary<int, System.Drawing.Color>();

        public frmSeminarChart()
        {
            InitializeComponent();
        }

        private void frmSeminarChart_Load(object sender, EventArgs e)
        {
            dtmFromDate.Value = DateTime.Now;
            chkMergeCell.Checked = true;
            dtmTodate.Value = DateTime.Now.AddDays(15);
            lblRoomDet.Text = "Room No :";
            lblDate.Text = "Dated :";
            loadPageData();
        }

        private void loadPageData()
        {
            try
            {
                DateTime dtFrm = dtmFromDate.Value;
                string filtrPeriod = string.Empty;

                while (dtFrm <= dtmTodate.Value)
                {
                    filtrPeriod += "[" + dtFrm.ToString("dd/MMM/yyyy") + "],";
                    dtFrm = dtFrm.AddDays(1);
                }
                string strQuery = @"DECLARE @start_date DATETIME = '" + dtmFromDate.Value.ToSystemDateString() + "', @end_date DATETIME = '" + dtmTodate.Value.ToSystemDateString() + "'; " +
                    @"DECLARE @DTABLE TABLE (ADATE DATE);

                    ;WITH AllDays AS 
                    ( 
	                    SELECT   cast(@start_date as date) AS [Date], 1 AS [level]
                        UNION ALL
                        SELECT   DATEADD(DAY, 1, [Date]), [level] + 1
                        FROM     AllDays
                        WHERE    [Date] < @end_date 
                    )
                    INSERT INTO @DTABLE (ADATE)
                    SELECT [Date] 
                    FROM   AllDays OPTION (MAXRECURSION 0);

                    SELECT A.room_number_number,TAB2.* FROM room_number A LEFT JOIN
                    (SELECT * FROM(
                    SELECT A.ADATE,T.reservation_ID,T.room_number_ID 
                    FROM @DTABLE A LEFT JOIN (SELECT CAST(A.reservation_CHECKIN AS DATE) reservation_CHECKIN,B.reservation_ID,C.room_number_ID
                    FROM RESERVATION_DAYWISE_STATUS A JOIN RESERVATION_CHECKIN_WALKIN B ON A.reservation_ID=B.reservation_ID
                    JOIN room_number C ON A.reservation_dormid=C.room_number_ID
                    WHERE B.tag_reserv_chkin_walkin='š' AND CAST(A.reservation_CHECKIN AS DATE) BETWEEN @start_date AND @end_date) T ON A.ADATE=T.reservation_CHECKIN) K
                    PIVOT
                    (MIN(K.reservation_ID) FOR K.ADATE IN (" + filtrPeriod.Remove(filtrPeriod.Length - 1, 1) + ")) TAB1) TAB2 " +
                    @" ON A.room_number_ID=TAB2.room_number_ID WHERE A.room_number_ConferenceRoom=1
                    ORDER BY room_number_number";

                dgvSemChart.DataSource = null;
                DataTable dtSeminar = new DataTable("SeminarChart");
                dtSeminar = objreportData.GetDataTableData(strQuery,"SeminarChart");
                dgvSemChart.DataSource = GetChartData(dtSeminar);


                dgvSemChart.Columns["room_number_number"].HeaderText = string.Empty;
                dgvSemChart.Columns["room_number_number"].Frozen = true;
                dgvSemChart.Columns["room_number_number"].DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                dgvSemChart.Columns["room_number_ID"].Visible = false;

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error on loading data in chart");
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadPageData();
        }

        private void dgvSemChart_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex > 1 && e.RowIndex > -1)
                {
                    string reserVal = Convert.ToString(dtChartData.Rows[e.RowIndex][e.ColumnIndex]);
                    if (!string.IsNullOrEmpty(reserVal))
                    {
                        DataRow[] rd = this.dtDetails.Select("reservation_ID=" + reserVal);
                        if (rd != null)
                        {
                            lblRoomDet.Text = "Room No : " + Convert.ToString(dtChartData.Rows[e.RowIndex]["room_number_number"]);
                            lblDate.Text = "Dated : " + Convert.ToString(dtChartData.Columns[e.ColumnIndex].ColumnName);
                            txtResrvStatus.Text = "Name : " + Convert.ToString(rd[0]["name"]) + Environment.NewLine +
                                "Advance : " + Convert.ToString(rd[0]["ADJ"]) + Environment.NewLine +
                                "Bill Status : Bill No. : " + Convert.ToString(rd[0]["Bill_No"]) + " - Amt : " + Convert.ToString(rd[0]["Amount"]) + Environment.NewLine +
                                "Balance : " + Convert.ToString(rd[0]["Balanced"]);
                        }
                    }
                    else
                    {
                        lblRoomDet.Text = "Room No : ";
                        lblDate.Text = "Dated : ";
                        txtResrvStatus.Text = string.Empty;
                    }
                }
                else
                {
                    lblRoomDet.Text = "Room No : ";
                    lblDate.Text = "Dated : ";
                    txtResrvStatus.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error on dgvSemChart_CellMouseEnter");
            }
        }

        private DataTable GetChartData(DataTable dtData)
        {
            Random randonGen = new Random();
            if (this.dtChartData != null) this.dtChartData = null;
            if (this.dtDetails != null) this.dtDetails = null;

            this.dtChartData = dtData;
            DataTable newData = new DataTable { TableName = dtData.TableName };
            foreach (DataColumn dtCol in dtData.Columns)
                newData.Columns.Add(new DataColumn { DataType = typeof(string), ColumnName = dtCol.ColumnName });
            foreach (DataRow drRow in dtData.Rows)
            {
                DataRow nRow = newData.NewRow();
                foreach (DataColumn dtCol in dtData.Columns)
                {
                    string strVal = Convert.ToString(drRow[dtCol.ColumnName]);

                    if (dtCol.ColumnName != "room_number_number" && dtCol.ColumnName != "room_number_ID" && !string.IsNullOrEmpty(strVal))
                    {
                        string sqlQuery = @"select *,(T.Amount - T.ADJ) Balanced from(
                            select A.reservation_ID,(A.reservation_PI_title+A.reservation_PI_frstname) name,A.reservation_NUMBER,
                            H.Bill_No,H.hotelBill_ID, cast(H.totalamt as decimal(10,2)) Amount, 
                            cast((select isnull(SUM(amount_Adj),0) 
                            from receipt_payment_Adjust_details where hotelBill_ID=A.reservation_ID AND AdjType='Seminar') as decimal(10,2)) ADJ
                            from RESERVATION_CHECKIN_WALKIN A left join HotelBILL H ON A.reservation_ID=H.reservation_ID WHERE A.reservation_ID=" + strVal + " ) T";

                        DataTable dt = objreportData.GetDataTableData(sqlQuery, "test");
                        DataRow dr = dt.Rows[0];
                        nRow[dtCol.ColumnName] = Convert.ToString(dr["Name"]) + " " + Convert.ToString(dr["reservation_NUMBER"]);
                        if (dtDetails == null)
                            dtDetails = dt;
                        else
                        {
                            dtDetails.NewRow();
                            dtDetails.Rows.Add(dr.ItemArray);
                        }

                        int reservid = Convert.ToInt32(strVal);
                        if (!chartColor.Any(x => x.Key == reservid))
                        {
                            var sColor = System.Drawing.Color.FromArgb(randonGen.Next(0, 255), randonGen.Next(0, 255), randonGen.Next(0, 255));

                            if (sColor == System.Drawing.Color.LimeGreen || sColor == System.Drawing.Color.Red)
                                sColor = System.Drawing.Color.FromArgb(randonGen.Next(0, 255), randonGen.Next(0, 255), randonGen.Next(0, 255));

                            if (objHostelData.GetHostelBillByReserveID(reservid).Any(x => x.Room_Dormatory == 5 && x.Bill_No.HasValue))
                                chartColor.Add(reservid, System.Drawing.Color.Red);
                            else
                                chartColor.Add(reservid, sColor);
                        }
                    }
                    else
                        nRow[dtCol.ColumnName] = strVal;

                }
                newData.Rows.Add(nRow);
            }

            return newData;
        }

        private void dgvSemChart_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow grdRow in dgvSemChart.Rows)
            {
                foreach (DataGridViewCell dgCell in grdRow.Cells)
                {
                    if (dgCell.ColumnIndex > 1)
                    {
                        int cellindex = dgCell.ColumnIndex - 1;
                        string reservVal = Convert.ToString(dgCell.Value);
                        string prevVal = ((cellindex == 0 && cellindex == 1) ? string.Empty : Convert.ToString(grdRow.Cells[cellindex]));
                        if (!string.IsNullOrEmpty(reservVal))
                        {
                            string reserid = Convert.ToString(this.dtChartData.Rows[grdRow.Index][dgCell.ColumnIndex]);
                            DataRow[] rd = this.dtDetails.Select("reservation_ID=" + reserid);

                            if (rd != null && !string.IsNullOrEmpty(Convert.ToString(rd[0]["ADJ"])) && Convert.ToDecimal(rd[0]["ADJ"]) > 0)
                                dgCell.Style.BackColor = chartColor.FirstOrDefault(x => x.Key == Convert.ToInt32(reserid)).Value;
                            else
                                if (chartColor.Any(x => x.Key == Convert.ToInt32(reserid) && x.Value != System.Drawing.Color.Red))
                                    dgCell.Style.BackColor = System.Drawing.Color.White;
                                else
                                    dgCell.Style.BackColor = chartColor.FirstOrDefault(x => x.Key == Convert.ToInt32(reserid)).Value;
                        }
                        else
                            dgCell.Style.BackColor = System.Drawing.Color.LimeGreen;
                    }
                }
            }
        }

        private void dgvSemChart_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex > 1 && e.RowIndex > -1)
                {
                    string reserVal = Convert.ToString(dtChartData.Rows[e.RowIndex][e.ColumnIndex]);
                    if (!string.IsNullOrEmpty(reserVal))
                    {
                        using (frmSeminarBookingEntry objSemReser = new frmSeminarBookingEntry())
                        {
                            objSemReser.reservationId = Convert.ToInt32(reserVal);
                            objSemReser.ShowDialog();
                        }
                    }
                }
                else
                {
                    lblRoomDet.Text = "Room No : ";
                    lblDate.Text = "Dated : ";
                    txtResrvStatus.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "-->Error on dgvSemChart_CellDoubleClick");
            }
        }

        private void btnEixt_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
