﻿namespace SmartHostelManagement.Order
{
    partial class frmCateringOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCateringOrder));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtmDate = new System.Windows.Forms.DateTimePicker();
            this.dtmTo = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.dtmFrom = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.txtOrder = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnReferesh = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTelephone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSelectGL = new System.Windows.Forms.Button();
            this.txtPerson = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtGuestName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvOrederMenu = new System.Windows.Forms.DataGridView();
            this.txtOrderNotes = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbBuffetType = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbMenu = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dtmOrderTime = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.chkPrintPrview = new System.Windows.Forms.CheckBox();
            this.btnOrderRemove = new System.Windows.Forms.Button();
            this.btnOrderAdd = new System.Windows.Forms.Button();
            this.btnOrderNew = new System.Windows.Forms.Button();
            this.txtOrderTotalAmt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtOrderRate = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtOrderMaxQty = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtOrderMinQty = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dgvOrderdetails = new System.Windows.Forms.DataGridView();
            this.btnOpenByOrder = new System.Windows.Forms.Button();
            this.btnSearchByOrder = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPaymentDetails = new System.Windows.Forms.TextBox();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnCancelList = new System.Windows.Forms.Button();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrederMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderdetails)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.dtmDate);
            this.groupBox1.Controls.Add(this.dtmTo);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dtmFrom);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtOrder);
            this.groupBox1.Controls.Add(this.btnExit);
            this.groupBox1.Controls.Add(this.btnPrint);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.btnReferesh);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtTelephone);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnSelectGL);
            this.groupBox1.Controls.Add(this.txtPerson);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtGuestName);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(900, 104);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(659, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 14);
            this.label9.TabIndex = 29;
            this.label9.Text = "DATE";
            // 
            // dtmDate
            // 
            this.dtmDate.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmDate.Location = new System.Drawing.Point(706, 15);
            this.dtmDate.Name = "dtmDate";
            this.dtmDate.Size = new System.Drawing.Size(185, 22);
            this.dtmDate.TabIndex = 28;
            // 
            // dtmTo
            // 
            this.dtmTo.CustomFormat = "dd/MMM/yyyy";
            this.dtmTo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmTo.Location = new System.Drawing.Point(765, 41);
            this.dtmTo.Name = "dtmTo";
            this.dtmTo.ShowCheckBox = true;
            this.dtmTo.Size = new System.Drawing.Size(126, 22);
            this.dtmTo.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(738, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 14);
            this.label7.TabIndex = 25;
            this.label7.Text = "To";
            // 
            // dtmFrom
            // 
            this.dtmFrom.CustomFormat = "dd/MMM/yyyy";
            this.dtmFrom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmFrom.Location = new System.Drawing.Point(597, 43);
            this.dtmFrom.Name = "dtmFrom";
            this.dtmFrom.ShowCheckBox = true;
            this.dtmFrom.Size = new System.Drawing.Size(126, 22);
            this.dtmFrom.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(552, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 14);
            this.label6.TabIndex = 23;
            this.label6.Text = "From";
            // 
            // txtOrder
            // 
            this.txtOrder.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtOrder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrder.Location = new System.Drawing.Point(531, 15);
            this.txtOrder.Name = "txtOrder";
            this.txtOrder.ReadOnly = true;
            this.txtOrder.Size = new System.Drawing.Size(117, 22);
            this.txtOrder.TabIndex = 22;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(813, 70);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(78, 26);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(728, 70);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(78, 26);
            this.btnPrint.TabIndex = 20;
            this.btnPrint.Text = "&Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(645, 70);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(78, 26);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(562, 69);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(77, 26);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnReferesh
            // 
            this.btnReferesh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReferesh.Location = new System.Drawing.Point(477, 69);
            this.btnReferesh.Name = "btnReferesh";
            this.btnReferesh.Size = new System.Drawing.Size(80, 26);
            this.btnReferesh.TabIndex = 17;
            this.btnReferesh.Text = "Re&feresh";
            this.btnReferesh.UseVisualStyleBackColor = true;
            this.btnReferesh.Click += new System.EventHandler(this.btnReferesh_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(474, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 14);
            this.label4.TabIndex = 16;
            this.label4.Text = "ORDER";
            // 
            // txtTelephone
            // 
            this.txtTelephone.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTelephone.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelephone.Location = new System.Drawing.Point(313, 71);
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Size = new System.Drawing.Size(148, 22);
            this.txtTelephone.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(278, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 14);
            this.label3.TabIndex = 14;
            this.label3.Text = "Tel.";
            // 
            // btnSelectGL
            // 
            this.btnSelectGL.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectGL.Location = new System.Drawing.Point(381, 13);
            this.btnSelectGL.Name = "btnSelectGL";
            this.btnSelectGL.Size = new System.Drawing.Size(89, 26);
            this.btnSelectGL.TabIndex = 13;
            this.btnSelectGL.Text = "&Select GL";
            this.btnSelectGL.UseVisualStyleBackColor = true;
            this.btnSelectGL.Click += new System.EventHandler(this.btnSelectGL_Click);
            // 
            // txtPerson
            // 
            this.txtPerson.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtPerson.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerson.Location = new System.Drawing.Point(70, 71);
            this.txtPerson.Name = "txtPerson";
            this.txtPerson.Size = new System.Drawing.Size(204, 22);
            this.txtPerson.TabIndex = 11;
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(70, 43);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(391, 22);
            this.txtAddress.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 14);
            this.label2.TabIndex = 9;
            this.label2.Text = "Person";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 14);
            this.label5.TabIndex = 8;
            this.label5.Text = "Address";
            // 
            // txtGuestName
            // 
            this.txtGuestName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtGuestName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGuestName.Location = new System.Drawing.Point(70, 15);
            this.txtGuestName.Name = "txtGuestName";
            this.txtGuestName.Size = new System.Drawing.Size(305, 22);
            this.txtGuestName.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 14);
            this.label1.TabIndex = 6;
            this.label1.Text = "Guest";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvOrederMenu);
            this.groupBox2.Controls.Add(this.txtOrderNotes);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.cmbBuffetType);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.cmbMenu);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.dtmOrderTime);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.chkPrintPrview);
            this.groupBox2.Controls.Add(this.btnOrderRemove);
            this.groupBox2.Controls.Add(this.btnOrderAdd);
            this.groupBox2.Controls.Add(this.btnOrderNew);
            this.groupBox2.Controls.Add(this.txtOrderTotalAmt);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtOrderRate);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtOrderMaxQty);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtOrderMinQty);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(6, 105);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(900, 240);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // dgvOrederMenu
            // 
            this.dgvOrederMenu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvOrederMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrederMenu.Location = new System.Drawing.Point(195, 10);
            this.dgvOrederMenu.Name = "dgvOrederMenu";
            this.dgvOrederMenu.RowHeadersVisible = false;
            this.dgvOrederMenu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvOrederMenu.ShowCellErrors = false;
            this.dgvOrederMenu.ShowCellToolTips = false;
            this.dgvOrederMenu.ShowEditingIcon = false;
            this.dgvOrederMenu.ShowRowErrors = false;
            this.dgvOrederMenu.Size = new System.Drawing.Size(460, 187);
            this.dgvOrederMenu.TabIndex = 37;
            // 
            // txtOrderNotes
            // 
            this.txtOrderNotes.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtOrderNotes.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderNotes.Location = new System.Drawing.Point(62, 201);
            this.txtOrderNotes.Name = "txtOrderNotes";
            this.txtOrderNotes.Size = new System.Drawing.Size(829, 22);
            this.txtOrderNotes.TabIndex = 36;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(5, 205);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 14);
            this.label16.TabIndex = 35;
            this.label16.Text = "Notes :";
            // 
            // cmbBuffetType
            // 
            this.cmbBuffetType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbBuffetType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBuffetType.FormattingEnabled = true;
            this.cmbBuffetType.Location = new System.Drawing.Point(6, 138);
            this.cmbBuffetType.Name = "cmbBuffetType";
            this.cmbBuffetType.Size = new System.Drawing.Size(183, 22);
            this.cmbBuffetType.TabIndex = 33;
            this.cmbBuffetType.SelectedIndexChanged += new System.EventHandler(this.cmbBuffetType_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 115);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(183, 19);
            this.label15.TabIndex = 32;
            this.label15.Text = "Buffet Type";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbMenu
            // 
            this.cmbMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbMenu.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMenu.FormattingEnabled = true;
            this.cmbMenu.Location = new System.Drawing.Point(6, 87);
            this.cmbMenu.Name = "cmbMenu";
            this.cmbMenu.Size = new System.Drawing.Size(183, 22);
            this.cmbMenu.TabIndex = 31;
            this.cmbMenu.SelectedIndexChanged += new System.EventHandler(this.cmbMenu_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 64);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(183, 19);
            this.label14.TabIndex = 30;
            this.label14.Text = "Menu";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtmOrderTime
            // 
            this.dtmOrderTime.CustomFormat = "dd/MMM/yyyy HH:mm:ss";
            this.dtmOrderTime.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmOrderTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmOrderTime.Location = new System.Drawing.Point(6, 38);
            this.dtmOrderTime.Name = "dtmOrderTime";
            this.dtmOrderTime.Size = new System.Drawing.Size(183, 22);
            this.dtmOrderTime.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(183, 21);
            this.label13.TabIndex = 28;
            this.label13.Text = "Order Serving Time";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPrintPrview
            // 
            this.chkPrintPrview.Location = new System.Drawing.Point(798, 15);
            this.chkPrintPrview.Name = "chkPrintPrview";
            this.chkPrintPrview.Size = new System.Drawing.Size(89, 41);
            this.chkPrintPrview.TabIndex = 27;
            this.chkPrintPrview.Text = "Print Preview";
            this.chkPrintPrview.UseVisualStyleBackColor = true;
            // 
            // btnOrderRemove
            // 
            this.btnOrderRemove.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderRemove.Location = new System.Drawing.Point(789, 171);
            this.btnOrderRemove.Name = "btnOrderRemove";
            this.btnOrderRemove.Size = new System.Drawing.Size(102, 26);
            this.btnOrderRemove.TabIndex = 26;
            this.btnOrderRemove.Text = "Remo&ve";
            this.btnOrderRemove.UseVisualStyleBackColor = true;
            this.btnOrderRemove.Click += new System.EventHandler(this.btnOrderRemove_Click);
            // 
            // btnOrderAdd
            // 
            this.btnOrderAdd.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderAdd.Location = new System.Drawing.Point(789, 142);
            this.btnOrderAdd.Name = "btnOrderAdd";
            this.btnOrderAdd.Size = new System.Drawing.Size(102, 26);
            this.btnOrderAdd.TabIndex = 25;
            this.btnOrderAdd.Text = "&Add/Change";
            this.btnOrderAdd.UseVisualStyleBackColor = true;
            this.btnOrderAdd.Click += new System.EventHandler(this.btnOrderAdd_Click);
            // 
            // btnOrderNew
            // 
            this.btnOrderNew.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderNew.Location = new System.Drawing.Point(789, 113);
            this.btnOrderNew.Name = "btnOrderNew";
            this.btnOrderNew.Size = new System.Drawing.Size(102, 26);
            this.btnOrderNew.TabIndex = 24;
            this.btnOrderNew.Text = "&New";
            this.btnOrderNew.UseVisualStyleBackColor = true;
            this.btnOrderNew.Click += new System.EventHandler(this.btnOrderNew_Click);
            // 
            // txtOrderTotalAmt
            // 
            this.txtOrderTotalAmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtOrderTotalAmt.Location = new System.Drawing.Point(661, 175);
            this.txtOrderTotalAmt.Name = "txtOrderTotalAmt";
            this.txtOrderTotalAmt.ReadOnly = true;
            this.txtOrderTotalAmt.Size = new System.Drawing.Size(118, 22);
            this.txtOrderTotalAmt.TabIndex = 23;
            this.txtOrderTotalAmt.TabStop = false;
            this.txtOrderTotalAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrderTotalAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(662, 155);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(117, 18);
            this.label12.TabIndex = 22;
            this.label12.Text = "Total Amount";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrderRate
            // 
            this.txtOrderRate.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtOrderRate.Location = new System.Drawing.Point(661, 128);
            this.txtOrderRate.Name = "txtOrderRate";
            this.txtOrderRate.Size = new System.Drawing.Size(118, 22);
            this.txtOrderRate.TabIndex = 21;
            this.txtOrderRate.TabStop = false;
            this.txtOrderRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrderRate.TextChanged += new System.EventHandler(this.txtOrderMinQty_TextChanged);
            this.txtOrderRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(662, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 18);
            this.label11.TabIndex = 20;
            this.label11.Text = "Rate";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrderMaxQty
            // 
            this.txtOrderMaxQty.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtOrderMaxQty.Location = new System.Drawing.Point(661, 81);
            this.txtOrderMaxQty.Name = "txtOrderMaxQty";
            this.txtOrderMaxQty.ReadOnly = true;
            this.txtOrderMaxQty.Size = new System.Drawing.Size(118, 22);
            this.txtOrderMaxQty.TabIndex = 19;
            this.txtOrderMaxQty.TabStop = false;
            this.txtOrderMaxQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrderMaxQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(662, 61);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 18);
            this.label10.TabIndex = 18;
            this.label10.Text = "Max Qty";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrderMinQty
            // 
            this.txtOrderMinQty.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtOrderMinQty.Location = new System.Drawing.Point(661, 34);
            this.txtOrderMinQty.Name = "txtOrderMinQty";
            this.txtOrderMinQty.Size = new System.Drawing.Size(118, 22);
            this.txtOrderMinQty.TabIndex = 17;
            this.txtOrderMinQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrderMinQty.TextChanged += new System.EventHandler(this.txtOrderMinQty_TextChanged);
            this.txtOrderMinQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrderMaxQty_KeyPress);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(662, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 18);
            this.label8.TabIndex = 16;
            this.label8.Text = "Min Qty";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvOrderdetails
            // 
            this.dgvOrderdetails.AllowUserToAddRows = false;
            this.dgvOrderdetails.AllowUserToDeleteRows = false;
            this.dgvOrderdetails.AllowUserToResizeColumns = false;
            this.dgvOrderdetails.AllowUserToResizeRows = false;
            this.dgvOrderdetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderdetails.Location = new System.Drawing.Point(6, 333);
            this.dgvOrderdetails.MultiSelect = false;
            this.dgvOrderdetails.Name = "dgvOrderdetails";
            this.dgvOrderdetails.ReadOnly = true;
            this.dgvOrderdetails.RowHeadersVisible = false;
            this.dgvOrderdetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrderdetails.ShowCellErrors = false;
            this.dgvOrderdetails.ShowEditingIcon = false;
            this.dgvOrderdetails.ShowRowErrors = false;
            this.dgvOrderdetails.Size = new System.Drawing.Size(900, 143);
            this.dgvOrderdetails.TabIndex = 35;
            this.dgvOrderdetails.TabStop = false;
            this.dgvOrderdetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOrderdetails_CellDoubleClick);
            // 
            // btnOpenByOrder
            // 
            this.btnOpenByOrder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenByOrder.Location = new System.Drawing.Point(778, 516);
            this.btnOpenByOrder.Name = "btnOpenByOrder";
            this.btnOpenByOrder.Size = new System.Drawing.Size(126, 26);
            this.btnOpenByOrder.TabIndex = 36;
            this.btnOpenByOrder.Text = "&Open By Order";
            this.btnOpenByOrder.UseVisualStyleBackColor = true;
            this.btnOpenByOrder.Click += new System.EventHandler(this.btnOpenByOrder_Click);
            // 
            // btnSearchByOrder
            // 
            this.btnSearchByOrder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchByOrder.Location = new System.Drawing.Point(639, 516);
            this.btnSearchByOrder.Name = "btnSearchByOrder";
            this.btnSearchByOrder.Size = new System.Drawing.Size(135, 26);
            this.btnSearchByOrder.TabIndex = 37;
            this.btnSearchByOrder.Text = "Se&arch By Order";
            this.btnSearchByOrder.UseVisualStyleBackColor = true;
            this.btnSearchByOrder.Click += new System.EventHandler(this.btnSearchByOrder_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(4, 498);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(124, 14);
            this.label17.TabIndex = 38;
            this.label17.Text = "Payment Details :";
            // 
            // txtPaymentDetails
            // 
            this.txtPaymentDetails.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtPaymentDetails.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaymentDetails.Location = new System.Drawing.Point(6, 514);
            this.txtPaymentDetails.Multiline = true;
            this.txtPaymentDetails.Name = "txtPaymentDetails";
            this.txtPaymentDetails.ReadOnly = true;
            this.txtPaymentDetails.Size = new System.Drawing.Size(298, 59);
            this.txtPaymentDetails.TabIndex = 39;
            // 
            // txtNotes
            // 
            this.txtNotes.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtNotes.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNotes.Location = new System.Drawing.Point(310, 514);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(322, 59);
            this.txtNotes.TabIndex = 40;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(308, 497);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 14);
            this.label18.TabIndex = 41;
            this.label18.Text = "Note :";
            // 
            // btnLast
            // 
            this.btnLast.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.Location = new System.Drawing.Point(584, 482);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(49, 26);
            this.btnLast.TabIndex = 30;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(526, 482);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(49, 26);
            this.btnNext.TabIndex = 42;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.Location = new System.Drawing.Point(465, 482);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(49, 26);
            this.btnPrevious.TabIndex = 43;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(404, 482);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(49, 26);
            this.btnFirst.TabIndex = 44;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOrder.Location = new System.Drawing.Point(639, 546);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(135, 26);
            this.btnCancelOrder.TabIndex = 46;
            this.btnCancelOrder.Text = "Cancel Order";
            this.btnCancelOrder.UseVisualStyleBackColor = true;
            this.btnCancelOrder.Click += new System.EventHandler(this.btnCancelOrder_Click);
            // 
            // btnCancelList
            // 
            this.btnCancelList.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelList.Location = new System.Drawing.Point(778, 546);
            this.btnCancelList.Name = "btnCancelList";
            this.btnCancelList.Size = new System.Drawing.Size(126, 26);
            this.btnCancelList.TabIndex = 45;
            this.btnCancelList.Text = "Cancel History";
            this.btnCancelList.UseVisualStyleBackColor = true;
            this.btnCancelList.Click += new System.EventHandler(this.btnCancelList_Click);
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTotalAmount.Location = new System.Drawing.Point(788, 482);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.ReadOnly = true;
            this.txtTotalAmount.Size = new System.Drawing.Size(118, 22);
            this.txtTotalAmount.TabIndex = 47;
            this.txtTotalAmount.TabStop = false;
            this.txtTotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(703, 486);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(84, 14);
            this.label19.TabIndex = 48;
            this.label19.Text = "Net Amount";
            // 
            // frmCateringOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 584);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtTotalAmount);
            this.Controls.Add(this.btnCancelOrder);
            this.Controls.Add(this.btnCancelList);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.txtPaymentDetails);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.btnSearchByOrder);
            this.Controls.Add(this.btnOpenByOrder);
            this.Controls.Add(this.dgvOrderdetails);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCateringOrder";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catering Order";
            this.Load += new System.EventHandler(this.frmCateringOrder_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrederMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderdetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtGuestName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPerson;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnSelectGL;
        private System.Windows.Forms.TextBox txtTelephone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnReferesh;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtOrder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtmFrom;
        private System.Windows.Forms.DateTimePicker dtmTo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtmDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtOrderMinQty;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtOrderMaxQty;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtOrderRate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtOrderTotalAmt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnOrderNew;
        private System.Windows.Forms.Button btnOrderAdd;
        private System.Windows.Forms.Button btnOrderRemove;
        private System.Windows.Forms.CheckBox chkPrintPrview;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtmOrderTime;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbMenu;
        private System.Windows.Forms.ComboBox cmbBuffetType;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtOrderNotes;
        private System.Windows.Forms.DataGridView dgvOrderdetails;
        private System.Windows.Forms.Button btnOpenByOrder;
        private System.Windows.Forms.Button btnSearchByOrder;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtPaymentDetails;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.DataGridView dgvOrederMenu;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Button btnCancelList;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.Label label19;

    }
}