﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using SMH.CommonLogic.Layer;
using System.Transactions;
using SMH.BusinessLogic.Layer;
using System.Collections.Generic;
using DBData = SmartHostelManagement.DBData;
using SmartHostelManagement.DBData;
using SmartHostelManagement.Windows;

namespace SmartHostelManagement.Order
{
    public partial class frmCateringOrder : Form
    {
        ISIPMEntities dbContext = new ISIPMEntities();
        MasterCaller masterCaller = new MasterCaller();
        string sqlConnectString { get; set; }

        int rowOrderIndex = -1;
        DBData.ChannelOrder objChannelOrder { get; set; }
        List<DBData.ChannelOrderDet> lstChannelOrderDet { get; set; }
        public int channelorderchartId { get; set; }

        public frmCateringOrder()
        {
            InitializeComponent();
        }

        private void frmCateringOrder_Load(object sender, EventArgs e)
        {
            sqlConnectString = dbContext.Database.Connection.ConnectionString;
            BindMenuItems();
            BindBuffetItem();
            ResetPageData();

            if (channelorderchartId > 0)
            {
                objChannelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == channelorderchartId);
                FillOrderFormPage();
            }
        }

        private void BindMenuItems()
        {
            List<DBData.Menu> lstMenu = (from x in dbContext.Menus where x.OrderBased == 1 && x.Deactivate == 0 orderby x.Food_Name select x).ToList();
            lstMenu.Insert(0, new DBData.Menu { Food_Id = 0, Food_Name = "--Select" });
            cmbMenu.DataSource = lstMenu.ToList();
            cmbMenu.DisplayMember = "Food_Name";
            cmbMenu.ValueMember = "Food_id";
        }

        private void BindBuffetItem()
        {
            List<DBData.BuffetMaster> lstBuffet = (from x in dbContext.BuffetMasters orderby x.Buffetname select x).ToList();
            lstBuffet.Insert(0, new DBData.BuffetMaster { Buffet_id = 0, Buffetname = "--Select" });
            cmbBuffetType.DataSource = lstBuffet.ToList();
            cmbBuffetType.DisplayMember = "Buffetname";
            cmbBuffetType.ValueMember = "Buffet_id";
        }

        private void ResetPageData()
        {
            objChannelOrder = null;
            txtGuestName.Text = string.Empty;
            txtOrder.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtPerson.Text = string.Empty;
            txtTelephone.Text = string.Empty;
            txtPaymentDetails.Text = "Receipt. No.:\tAmt: Rs. \tDates:\tMode:";
            txtNotes.Text = string.Empty;
            
            dtmDate.Value = DateTime.Now;
            dtmFrom.Value = DateTime.Now;            
            dtmTo.Value = DateTime.Now;
            dtmFrom.Checked = false;
            dtmTo.Checked = false;
            dtmOrderTime.Value = DateTime.Now;

            lstChannelOrderDet = null;
            ResetOrderPage();
            BindOrderDetailGrid();
        }

        private void FillOrderFormPage()
        {
            try
            {
                if (objChannelOrder != null)
                {
                    txtGuestName.Text = objChannelOrder.Name_guest;
                    txtOrder.Text = objChannelOrder.Bill_No.HasValue ? Convert.ToString(objChannelOrder.Bill_No) : string.Empty;
                    txtAddress.Text = objChannelOrder.addr1_guest;
                    txtPerson.Text = objChannelOrder.addr2_guest;
                    txtTelephone.Text = objChannelOrder.addr3_guest;
                    txtPaymentDetails.Text = "Receipt. No.:\tAmt: Rs. \tDates:\tMode:";
                    txtNotes.Text = objChannelOrder.BILLDETAILS;

                    dtmDate.Value = CommonBaseFN.MergeDatetime(objChannelOrder.Bdate,objChannelOrder.Btime);

                    if (objChannelOrder.checkintime_date.HasValue)
                    {
                        dtmFrom.Value = objChannelOrder.checkintime_date.Value;
                        dtmFrom.Checked = true;
                    }

                    if (objChannelOrder.checkouttime_date.HasValue)
                    {
                        dtmTo.Value = objChannelOrder.checkouttime_date.Value;
                        dtmTo.Checked = true;
                    }

                    this.lstChannelOrderDet = objChannelOrder.ChannelOrderDets.ToList();
                    BindOrderDetailGrid();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, this.Text);
            }
        }

        private void btnSelectGL_Click(object sender, EventArgs e)
        {
            using (Search.frmGLAccount frmGLMem = new Search.frmGLAccount())
            {
                frmGLMem.ShowDialog();
                if (frmGLMem.ORDID > 0)
                {
                    ResetPageData();
                    this.objChannelOrder = new ChannelOrder();
                    ORDER objglMem = dbContext.ORDERs.FirstOrDefault(x => x.ORDID == frmGLMem.ORDID);
                    objChannelOrder.GAccountCode = objglMem.ORDNO;
                    objChannelOrder.GAccountname = objglMem.PARNAM;
                    objChannelOrder.Name_guest = objglMem.PARNAM;
                    objChannelOrder.addr1_guest = objglMem.PARADD;
                    objChannelOrder.addr2_guest = objglMem.PARADD1;
                    objChannelOrder.addr3_guest = objglMem.PARADD2;

                    FillOrderFormPage();
                }
            }
        }

        private void btnReferesh_Click(object sender, EventArgs e)
        {
            ResetPageData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (objChannelOrder != null && !string.IsNullOrEmpty(objChannelOrder.GAccountCode))
                {
                    if (objChannelOrder != null)
                    {
                        using (TransactionScope objTrans = new TransactionScope(TransactionScopeOption.Required,
                                  new TransactionOptions { IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted, },
                                  EnterpriseServicesInteropOption.Automatic))
                        {
                            objChannelOrder.Bdate = dtmDate.Value.Date;
                            objChannelOrder.Btime = dtmDate.Value;
                            objChannelOrder.Name_guest = txtGuestName.Text;
                            objChannelOrder.addr1_guest = txtAddress.Text;
                            objChannelOrder.addr2_guest = txtPerson.Text;
                            objChannelOrder.addr3_guest = txtTelephone.Text;
                            objChannelOrder.Name_billto = string.Empty;
                            objChannelOrder.addr1_billto = string.Empty;
                            objChannelOrder.addr2_billto = string.Empty;
                            objChannelOrder.addr3_billto = string.Empty;
                            if (dtmFrom.Checked) objChannelOrder.checkintime_date = dtmFrom.Value;
                            if (dtmTo.Checked) objChannelOrder.checkouttime_date = dtmTo.Value;
                            objChannelOrder.description_b = txtPaymentDetails.Text;
                            objChannelOrder.activate_delete = objChannelOrder.activate_delete.HasValue ? objChannelOrder.activate_delete.Value : false;
                            objChannelOrder.MachineName = Environment.MachineName;
                            objChannelOrder.BILLDETAILS = txtNotes.Text;
                            //objChannelOrder.description_b = "Receipt No. :     Amt : Rs.    Dated :     Mode :";

                            if (objChannelOrder.ChannelOrder_Id > 0)
                            {
                                objChannelOrder.id1 = Frm_Login.UserLogin.log_id;
                                objChannelOrder.date_of_mod = DateTime.Now;
                                objChannelOrder.modifiedby = Frm_Login.UserLogin.loginID;
                            }
                            else
                            {
                                int? channelId = dbContext.ChannelOrders.Max(x => x.Bill_No) + 1;
                                int? billNo = dbContext.ChannelOrders.Max(x => x.Bill_No) + 1;

                                objChannelOrder.ChannelOrder_Id = channelId.HasValue ? channelId.Value : 0;
                                objChannelOrder.Bill_No = billNo;
                                objChannelOrder.id = Frm_Login.UserLogin.log_id;
                                objChannelOrder.date_of_add = DateTime.Now;
                                objChannelOrder.createdby = Frm_Login.UserLogin.loginID;
                                objChannelOrder.billtochk = false;
                                objChannelOrder.billroomtype = 0;
                                objChannelOrder.BillcreationType = 0;
                                objChannelOrder.orderformno = billNo.HasValue ? Convert.ToString(billNo.Value) : string.Empty;
                                objChannelOrder.stexempted = false;
                                objChannelOrder.BundledServ = false;
                                objChannelOrder.PrefixInv = "CATO\\19-20\\";
                                objChannelOrder.netpayable = !string.IsNullOrEmpty(txtTotalAmount.Text) ? Convert.ToDouble(txtTotalAmount.Text) : 0;
                                dbContext.ChannelOrders.Add(objChannelOrder);
                            }

                            if (dbContext.SaveChanges() > 0)
                            {
                                IList<DBData.ChannelOrderDet> lstChannlDel = dbContext.ChannelOrderDets.Where(x => x.ChannelOrder_Id == objChannelOrder.ChannelOrder_Id).ToList();
                                foreach (DBData.ChannelOrderDet objdelMis in lstChannlDel)
                                    if (!lstChannelOrderDet.Any(x => x.ChannelOrderdet_id == objdelMis.ChannelOrderdet_id))
                                        dbContext.ChannelOrderDets.Remove(objdelMis);

                                int channelDetId = dbContext.ChannelOrderDets.Max(x => x.ChannelOrderdet_id);

                                foreach (DBData.ChannelOrderDet objChalDet in lstChannelOrderDet)
                                {
                                    if (!objChalDet.ChannelOrder_Id.HasValue)
                                    {
                                        channelDetId = channelDetId + 1;
                                        objChalDet.ChannelOrderdet_id = channelDetId;
                                        objChalDet.ChannelOrder_Id = objChannelOrder.ChannelOrder_Id;
                                        dbContext.ChannelOrderDets.Add(objChalDet);
                                    }
                                }

                                dbContext.SaveChanges();
                            }

                            objTrans.Complete();
                            objTrans.Dispose();
                            CustomMessageBox.ShowInformationMessage("Record Save", this.Text);
                        }

                        this.dbContext = new ISIPMEntities();
                        int Cid = this.objChannelOrder.ChannelOrder_Id;
                        ResetPageData();
                        objChannelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == Cid);
                        FillOrderFormPage();
                    }
                    else
                    {
                        CustomMessageBox.ShowInformationMessage("Please create order form.", this.Text);
                    }
                }
                else
                {
                    CustomMessageBox.ShowInformationMessage("Please Select GL Account member", this.Text);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (objChannelOrder != null)
                {
                    if (CustomMessageBox.ShowDialogBoxMessage("Delete this order form.") == System.Windows.Forms.DialogResult.Yes)
                    {
                        objChannelOrder.activate_delete = true;
                        btnSave_Click(sender, e);
                        btnLast_Click(sender, e);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.objChannelOrder != null && this.objChannelOrder.ChannelOrder_Id > 0)
                {
                    string strQuery = @"DECLARE @ChannelOrder_Id int=" + objChannelOrder.ChannelOrder_Id + @";

                        DELETE FROM tempc;
                        DELETE FROM tempc1;

                        INSERT INTO tempc(sno,tempC_1,tempC_2,tempC_3,tempC_4,tempC_5,tempC_6,tempC_12,tempC_14,tempC_15,tempF_2,tempF_4,tempF_5,tempF_6,tempF_9)
                        SELECT ROW_NUMBER() OVER(ORDER BY ChannelOrder_Id),Bill_No,replace(CONVERT(varchar(20),Bdate,106),' ','-'),Name_guest,addr1_guest,addr2_guest,addr3_guest,description_b,BILLDETAILS,'',0,0,0,0,0 
                        from ChannelOrder where ChannelOrder_Id=@ChannelOrder_Id;

                        ;WITH ABC (ChannelOrderdet_id,DataItem,Data) AS
                        (
	                        SELECT ChannelOrderdet_id,CAST(LEFT(listmenuid, CHARINDEX(',',listmenuid+',')-1) as varchar),STUFF(listmenuid, 1, CHARINDEX(',',listmenuid+','), '')
	                        FROM ChannelOrderDet where ChannelOrder_Id=@ChannelOrder_Id
	                        UNION ALL
	                        SELECT ChannelOrderdet_id,cast(LEFT(Data, CHARINDEX(',',Data+',')-1)  as varchar),STUFF(Data, 1, CHARINDEX(',',Data+','), '')
	                        FROM ABC
	                        WHERE Data > ''
                        )
                        INSERT INTO tempc1 (sno1,sno,tempC_1,tempC_2,tempLC_1,tempC_4,tempF_1,tempF_2,tempF_3,tempF_4,tempI_1)
                        SELECT ROW_NUMBER() OVER(ORDER BY ChannelOrderdet_id),1,Food_Name,date_ofdet,ISNULL(STUFF((SELECT ', ' + Food_Name FROM ABC JOIN Menu ON ABC.DataItem=Menu.Food_Id 
                        AND  ABC.ChannelOrderdet_id= a.ChannelOrderdet_id FOR XML PATH('')),1,1,''),''),ISNULL(A.notes,''),qty,rate,netamt,ServiceTax,ROW_NUMBER() OVER(ORDER BY ChannelOrderdet_id)
                        FROM ChannelOrderDet A where ChannelOrder_Id=@ChannelOrder_Id;

                        update tempc set tempc.tempF_10=(b.gst/2), tempc.tempF_11=(b.gst/2), tempc.tempF_12=(b.gst) 
                        from tempc join (select sno, sum(tempF_4) gst from tempc1 group by sno) b on tempc.sno = b.sno;
                      ";

                    if (dbContext.Database.ExecuteSqlCommand(strQuery) > 0)
                    {
                        Report.frmbillreportview freport = new Report.frmbillreportview();
                        freport.reportName = "rpt_ravi_channelOrder.rpt";
                        freport.amttowaords = "Rupees " + CommonBaseFN.NumberToWords(Convert.ToInt32(objChannelOrder.netpayable.Value)) + " Only ";
                        freport.Createdby = objChannelOrder.createdby + " / " +
                            (objChannelOrder.date_of_add.HasValue ? objChannelOrder.date_of_add.Value.ToString("dd-MMM-yyyy / HH:mm") : string.Empty) +
                            "   P/ON : " + DateTime.Now.ToString("dd-MMM-yyyy / HH:mm");
                        freport.Show();
                    }
                }
                else
                    CustomMessageBox.ShowHandMessage("Please select Order form", "");
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }
        
        private void btnExit_Click(object sender, EventArgs e)
        {
            if (CustomMessageBox.ShowDialogBoxMessage("Would you like to close this form.") == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnOpenByOrder_Click(object sender, EventArgs e)
        {
            try
            {
                string strVal = string.Empty;
                if (CustomFormFunction.InputBox("Search by Order Form No.", "Please Enter Order Form Number", ref strVal) ==
                    System.Windows.Forms.DialogResult.OK)
                {
                    int billNo = 0;
                    int.TryParse(strVal, out billNo);
                    
                    var searchR = dbContext.ChannelOrders.FirstOrDefault(x => x.Bill_No == billNo);
                    if (searchR != null)
                    {   
                        ResetPageData();
                        this.objChannelOrder = searchR;
                        FillOrderFormPage();
                    }
                    else
                        CustomMessageBox.ShowHandMessage("Record not found", "");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void btnSearchByOrder_Click(object sender, EventArgs e)
        {
            using (Search.frmSearchOrderForm frmOrderSearch = new Search.frmSearchOrderForm())
            {
                frmOrderSearch.ShowDialog();
                if (frmOrderSearch.orderFormID > 0)
                {
                    ResetPageData();
                    objChannelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == frmOrderSearch.orderFormID);
                    FillOrderFormPage();
                }
            }
        }

        #region First, Second, Last, Previous
        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelOrder_Id from ChannelOrder WHERE ISNULL(activate_delete,0) = 0 order by ChannelOrder_Id asc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);

                if (this.objChannelOrder != null && this.objChannelOrder.ChannelOrder_Id == hotelID)
                    CustomMessageBox.ShowHandMessage("This is Last record", "");
                else
                {
                    ResetPageData();
                    this.objChannelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == hotelID);
                    FillOrderFormPage();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Pervious Selection Data");
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelOrder_Id from ChannelOrder WHERE ISNULL(activate_delete,0) = 0" +
                    (this.objChannelOrder != null && this.objChannelOrder.ChannelOrder_Id > 0 ? " and ChannelOrder_Id < " + this.objChannelOrder.ChannelOrder_Id : string.Empty) +
                    " order by ChannelOrder_Id desc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);

                if (this.objChannelOrder != null && this.objChannelOrder.ChannelOrder_Id == hotelID)
                    CustomMessageBox.ShowHandMessage("This is Last record", "");
                else
                {
                    ResetPageData();
                    this.objChannelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == hotelID);
                    FillOrderFormPage();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Pervious Selection Data");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelOrder_Id from ChannelOrder WHERE ISNULL(activate_delete,0) = 0" +
                    (this.objChannelOrder != null && this.objChannelOrder.ChannelOrder_Id > 0 ? " and ChannelOrder_Id > " + this.objChannelOrder.ChannelOrder_Id : string.Empty) +
                    " order by ChannelOrder_Id asc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);

                if (this.objChannelOrder != null && this.objChannelOrder.ChannelOrder_Id == hotelID)
                    CustomMessageBox.ShowHandMessage("This is Last record", "");
                else
                {
                    ResetPageData();
                    this.objChannelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == hotelID);
                    FillOrderFormPage();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in Pervious Selection Data");
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = @"select top 1 ChannelOrder_Id from ChannelOrder WHERE ISNULL(activate_delete,0) = 0 order by ChannelOrder_Id desc";
                int hotelID = masterCaller.GetIdentityID(sqlQuery);
                if (this.objChannelOrder != null && this.objChannelOrder.ChannelOrder_Id == hotelID)
                    CustomMessageBox.ShowHandMessage("This is Last record", "");
                else
                {
                    ResetPageData();
                    this.objChannelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == hotelID);
                    FillOrderFormPage();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Error in First Selection Data");
            }
        }
        #endregion First, Second, Last, Previous

        #region OrderDetails
        private void ResetOrderPage()
        {
            rowOrderIndex = -1;
            //dtmOrderTime.Value = DateTime.Now;
            cmbMenu.SelectedIndex = 0;
            cmbBuffetType.SelectedIndex = 0;
            txtOrderMinQty.Text = string.Empty;
            txtOrderMaxQty.Text = string.Empty;
            txtOrderRate.Text = string.Empty;
            txtOrderTotalAmt.Text = string.Empty;
            txtOrderNotes.Text = string.Empty;
            //cmbBuffetType_SelectedIndexChanged(null, null);
        }

        private void BindOrderDetailGrid()
        {
            try 
	        {
                if (this.lstChannelOrderDet == null) lstChannelOrderDet = new List<DBData.ChannelOrderDet>();
                int index = 1;
                var dbData = (from c in lstChannelOrderDet
                              select new
                              {
                                  Slno = index++,
                                  c.ChannelOrderdet_id,
                                  Menu = c.Food_Name,
                                  ServTime = c.date_ofdet,
                                  BuffetGroup = c.buffetCode,
                                  MenuDetails = c.ItemList,
                                  Qty = c.qty.HasValue ? c.qty.Value : 0,
                                  Rate = c.rate.HasValue ? c.rate.Value : 0,
                                  Amount = c.total_amt.HasValue ? c.total_amt.Value : 0,
                                  GST = c.ServiceTax.HasValue ? c.ServiceTax.Value : 0,
                                  NetAmount = c.netamt.HasValue ? c.netamt.Value : 0,
                              }).ToList();

                dgvOrderdetails.DataSource = dbData;
                dgvOrderdetails.Columns["ChannelOrderdet_id"].Visible = false;
                dgvOrderdetails.Columns["Rate"].DefaultCellStyle.Format = "0.00";
                dgvOrderdetails.Columns["Amount"].DefaultCellStyle.Format = "0.00";
                dgvOrderdetails.Columns["Rate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvOrderdetails.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvOrderdetails.Columns["GST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvOrderdetails.Columns["NetAmount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                double? netamount = lstChannelOrderDet.Sum(x => x.netamt);
                txtTotalAmount.Text = netamount.HasValue ? netamount.Value.ToString("0.00") : "0.00";
            }
	        catch (Exception ex)
	        {
                ExceptionLogging.SendErrorToText(ex, "");
	        }
        }

        private void cmbMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtOrderMinQty.Text = string.Empty;
            txtOrderMaxQty.Text = string.Empty;
            txtOrderRate.Text = string.Empty;
            txtOrderTotalAmt.Text = string.Empty;

            if (cmbMenu.SelectedIndex > 0)
            {
                int menuId = Convert.ToInt32(cmbMenu.SelectedValue);
                var menuDB = dbContext.Menus.FirstOrDefault(x => x.Food_Id == menuId);
                if (menuDB != null)
                {
                    txtOrderMinQty.Text = menuDB.Unit.HasValue ? menuDB.Unit.Value.ToString("0") : "0";
                    txtOrderMaxQty.Text = "0";
                    txtOrderRate.Text = menuDB.Price.HasValue ? menuDB.Price.Value.ToString("0.00") : "0.00";
                    txtOrderTotalAmt.Text = menuDB.Price.HasValue ? menuDB.Price.Value.ToString("0.00") : "0.00";
                }
            }
        }

        private void cmbBuffetType_SelectedIndexChanged(object sender, EventArgs e)
        {
            int menuId = cmbBuffetType.SelectedIndex > 0 ? Convert.ToInt32(cmbBuffetType.SelectedValue) : 0;
            int foodid = cmbMenu.SelectedIndex > 0 ? Convert.ToInt32(cmbMenu.SelectedValue) : 0;

            if (dgvOrederMenu.Columns.Count > 0) dgvOrederMenu.Columns.Clear();
            if (dgvOrederMenu.Rows.Count > 0) dgvOrederMenu.Rows.Clear();

            string sqlQuery = @"select row_number() over (order by c.MENUGROUPname) Slno,A.MENUGROUPDET_ID,A.Food_Id,c.MENUGROUP_id,c.MENUGROUPname Menu,b.Food_Name 
                from MENUGROUPMASTER C join MENUGROUPMASTERDETAIL A on c.MENUGROUP_id=a.MENUGROUP_id join Menu B on A.Food_Id=b.Food_Id 
                where c.MENUGROUP_id in (select MENUGROUP_id from BuffetMasterDetail where Buffet_id=" + menuId + ") order by c.MENUGROUPname";
            DataTable dt = masterCaller.GetDataTableData(sqlQuery, "Menu");


            if (dt.Rows.Count > 0) dgvOrederMenu.Columns.Add(new DataGridViewCheckBoxColumn { ReadOnly = false });            
            dgvOrederMenu.DataSource = dt;
            string columnColor = string.Empty;
            System.Drawing.Color objColr = System.Drawing.Color.Blue;
            foreach (DataGridViewRow grdRow in dgvOrederMenu.Rows)
            {
                if (string.IsNullOrEmpty(columnColor)) columnColor = Convert.ToString(grdRow.Cells["Menu"].Value);
                if (columnColor != Convert.ToString(grdRow.Cells["Menu"].Value))
                {
                    objColr = objColr == System.Drawing.Color.Black ? System.Drawing.Color.Blue : System.Drawing.Color.Black;
                    columnColor = Convert.ToString(grdRow.Cells["Menu"].Value);
                }

                foreach (DataGridViewCell grdCell in grdRow.Cells)
                {
                    grdCell.Style.ForeColor = objColr;
                }
            }

            dgvOrederMenu.Columns[0].ReadOnly = false;
            dgvOrederMenu.Columns["MENUGROUPDET_ID"].Visible = false;
            dgvOrederMenu.Columns["Food_Id"].Visible = false;
            dgvOrederMenu.Columns["MENUGROUP_id"].Visible = false;
        }

        private void txtOrderMinQty_TextChanged(object sender, EventArgs e)
        {
            decimal qty = !string.IsNullOrEmpty(txtOrderMinQty.Text) ? Convert.ToDecimal(txtOrderMinQty.Text) : 0;
            decimal rate = !string.IsNullOrEmpty(txtOrderRate.Text) ? Convert.ToDecimal(txtOrderRate.Text) : 0;
            txtOrderTotalAmt.Text = (rate * qty).ToString("0.00");
        }

        private void btnOrderNew_Click(object sender, EventArgs e)
        {
            ResetOrderPage();
            BindOrderDetailGrid();
        }

        private void btnOrderAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbMenu.SelectedIndex > 0)
                {
                    string itmlistStr = string.Empty;
                    string itemIdStr = string.Empty;

                    foreach (DataGridViewRow grdRow in dgvOrederMenu.Rows)
                    {
                        DataGridViewCell grdCell = (DataGridViewCell)grdRow.Cells[0];
                        if (Convert.ToBoolean(grdCell.Value) == true)
                        {
                            itmlistStr = itmlistStr + Convert.ToString(grdRow.Cells["Menu"].Value) + " " + Convert.ToString(grdRow.Cells["Food_Name"].Value) + "\n";
                            itemIdStr = itemIdStr + Convert.ToString(grdRow.Cells["Food_Id"].Value) + ",";
                        }
                    }

                    itmlistStr = !string.IsNullOrEmpty(itmlistStr) ? itmlistStr.Remove(itmlistStr.Length - 1, 1) : itmlistStr;
                    itemIdStr = !string.IsNullOrEmpty(itemIdStr) ? itemIdStr.Remove(itemIdStr.Length - 1, 1) : itemIdStr;

                    if (rowOrderIndex > -1)
                    {
                        lstChannelOrderDet[rowOrderIndex].date_ofdet = dtmOrderTime.Value;
                        lstChannelOrderDet[rowOrderIndex].buffetCode = cmbBuffetType.SelectedIndex > 0 ? cmbBuffetType.Text : string.Empty;
                        lstChannelOrderDet[rowOrderIndex].ItemList = itmlistStr;
                        lstChannelOrderDet[rowOrderIndex].qty = !string.IsNullOrEmpty(txtOrderMinQty.Text) ? Convert.ToDouble(txtOrderMinQty.Text) : 0;
                        lstChannelOrderDet[rowOrderIndex].rate = !string.IsNullOrEmpty(txtOrderRate.Text) ? Convert.ToDouble(txtOrderRate.Text) : 0;
                        lstChannelOrderDet[rowOrderIndex].total_amt = !string.IsNullOrEmpty(txtOrderTotalAmt.Text) ? Convert.ToDouble(txtOrderTotalAmt.Text) : 0;
                        lstChannelOrderDet[rowOrderIndex].notes = txtOrderNotes.Text;
                        lstChannelOrderDet[rowOrderIndex].listmenuid = itemIdStr;
                        lstChannelOrderDet[rowOrderIndex].Buffet_id = cmbBuffetType.SelectedIndex > 0 ? Convert.ToInt32(cmbBuffetType.SelectedValue) : -1;
                        lstChannelOrderDet[rowOrderIndex].Food_Id = cmbMenu.SelectedIndex > 0 ? Convert.ToInt32(cmbMenu.SelectedValue) : -1;
                        lstChannelOrderDet[rowOrderIndex].Food_Name = cmbMenu.SelectedIndex > 0 ? cmbMenu.Text : string.Empty;
                        lstChannelOrderDet[rowOrderIndex].Qtymax = !string.IsNullOrEmpty(txtOrderMaxQty.Text) ? Convert.ToDouble(txtOrderMaxQty.Text) : 0;
                        lstChannelOrderDet[rowOrderIndex].date_ofdetDate = DateTime.Now.Date;
                        lstChannelOrderDet[rowOrderIndex].ServiceTax = (CommonVariables.FoodGST * lstChannelOrderDet[rowOrderIndex].total_amt.Value) / 100;
                        lstChannelOrderDet[rowOrderIndex].netamt = lstChannelOrderDet[rowOrderIndex].ServiceTax + lstChannelOrderDet[rowOrderIndex].total_amt;
                        lstChannelOrderDet[rowOrderIndex].VAT = 0;
                    }
                    else
                    {
                        var newOrder = new DBData.ChannelOrderDet
                        {
                            buffetname = string.Empty,
                            date_ofdet = dtmOrderTime.Value,
                            buffetCode = cmbBuffetType.SelectedIndex > 0 ? cmbBuffetType.Text : string.Empty,
                            ItemList = itmlistStr,
                            qty = !string.IsNullOrEmpty(txtOrderMinQty.Text) ? Convert.ToDouble(txtOrderMinQty.Text) : 0,
                            rate = !string.IsNullOrEmpty(txtOrderRate.Text) ? Convert.ToDouble(txtOrderRate.Text) : 0,
                            total_amt = !string.IsNullOrEmpty(txtOrderTotalAmt.Text) ? Convert.ToDouble(txtOrderTotalAmt.Text) : 0,
                            notes = txtOrderNotes.Text,
                            listmenuid = itemIdStr,
                            Buffet_id = cmbBuffetType.SelectedIndex > 0 ? Convert.ToInt32(cmbBuffetType.SelectedValue) : -1,
                            Food_Id = cmbMenu.SelectedIndex > 0 ? Convert.ToInt32(cmbMenu.SelectedValue) : -1,
                            Food_Name = cmbMenu.Text,
                            Qtymax = !string.IsNullOrEmpty(txtOrderMaxQty.Text) ? Convert.ToDouble(txtOrderMaxQty.Text) : 0,
                            date_ofdetDate = DateTime.Now.Date
                        };

                        newOrder.ServiceTax = (CommonVariables.FoodGST * newOrder.total_amt.Value) / 100;
                        newOrder.netamt = newOrder.ServiceTax + newOrder.total_amt;
                        newOrder.VAT = 0;
                        lstChannelOrderDet.Add(newOrder);
                    }
                    
                    ResetOrderPage();
                    BindOrderDetailGrid();
                }
                else
                {
                    CustomMessageBox.ShowExclamationMessage("Please select Menu", "");
                    cmbMenu.Focus();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }           
        }

        private void btnOrderRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (rowOrderIndex > -1)
                {
                    lstChannelOrderDet.RemoveAt(rowOrderIndex);
                    ResetOrderPage();
                    BindOrderDetailGrid();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }

        private void dgvOrderdetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvOrderdetails.SelectedRows.Count > 0)
                {
                    rowOrderIndex = dgvOrderdetails.SelectedRows[0].Index;
                    dtmOrderTime.Value = lstChannelOrderDet[rowOrderIndex].date_ofdet.HasValue ? lstChannelOrderDet[rowOrderIndex].date_ofdet.Value : DateTime.Now;
                    cmbMenu.SelectedValue = lstChannelOrderDet[rowOrderIndex].Food_Id.HasValue ? lstChannelOrderDet[rowOrderIndex].Food_Id.Value : 0;
                    cmbBuffetType.SelectedValue = lstChannelOrderDet[rowOrderIndex].Buffet_id.HasValue ? lstChannelOrderDet[rowOrderIndex].Buffet_id.Value : 0;
                    cmbBuffetType_SelectedIndexChanged(cmbBuffetType, null);
                    txtOrderMaxQty.Text = lstChannelOrderDet[rowOrderIndex].Qtymax.HasValue ? lstChannelOrderDet[rowOrderIndex].Qtymax.Value.ToString("0.00") : "0.00";
                    txtOrderMinQty.Text = lstChannelOrderDet[rowOrderIndex].qty.HasValue ? lstChannelOrderDet[rowOrderIndex].qty.Value.ToString("0.00") : "0.00";
                    txtOrderRate.Text = lstChannelOrderDet[rowOrderIndex].rate.HasValue ? lstChannelOrderDet[rowOrderIndex].rate.Value.ToString("0.00") : "0.00";
                    txtOrderTotalAmt.Text = lstChannelOrderDet[rowOrderIndex].total_amt.HasValue ? lstChannelOrderDet[rowOrderIndex].total_amt.Value.ToString() : "0.00";
                    txtOrderNotes.Text = lstChannelOrderDet[rowOrderIndex].notes;

                    if (lstChannelOrderDet[rowOrderIndex].listmenuid.Length > 0)
                    {
                        string[] menuid = lstChannelOrderDet[rowOrderIndex].listmenuid.Split(',');
                        for (int i = 0; i < menuid.Length; i++)
                        {
                            foreach (DataGridViewRow grd in dgvOrederMenu.Rows)
                            {
                                if (Convert.ToString(grd.Cells["Food_Id"].Value) == menuid[i])
                                {
                                    DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)grd.Cells[0];
                                    chkCell.Value = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "");
            }
        }
        #endregion OrderDetails

        private void txtOrderMaxQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            CommonBaseFN.CheckDigitOnly(e, 1);
        }

        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            if (objChannelOrder == null || (objChannelOrder != null && objChannelOrder.ChannelOrder_Id == 0)) return;
            using (Order.frmCancelCatOrder frmcanOrder = new frmCancelCatOrder())
            {
                frmcanOrder.IsCancelForm = true;
                frmcanOrder.reservationId = objChannelOrder.ChannelOrder_Id;
                frmcanOrder.reservationnumber = objChannelOrder.Bill_No.HasValue ? objChannelOrder.Bill_No.Value : 0;
                frmcanOrder.cname = objChannelOrder.Name_guest;
                frmcanOrder.address = objChannelOrder.addr1_guest;
                frmcanOrder.address2 = objChannelOrder.addr2_guest;
                frmcanOrder.reservdate = objChannelOrder.Bdate.HasValue ? objChannelOrder.Bdate.Value : DateTime.Now;
                frmcanOrder.ShowDialog();
                lstChannelOrderDet = dbContext.ChannelOrderDets.Where(x => x.ChannelOrder_Id == objChannelOrder.ChannelOrder_Id).ToList();
            }
        }

        private void btnCancelList_Click(object sender, EventArgs e)
        {
            if (objChannelOrder == null || (objChannelOrder != null && objChannelOrder.ChannelOrder_Id == 0)) return;
            using (Order.frmCancelCatOrder frmcanOrder = new frmCancelCatOrder())
            {
                frmcanOrder.IsCancelForm = false;
                frmcanOrder.reservationId = objChannelOrder.ChannelOrder_Id;
                frmcanOrder.reservationnumber = objChannelOrder.Bill_No.HasValue ? objChannelOrder.Bill_No.Value : 0;
                frmcanOrder.cname = objChannelOrder.Name_guest;
                frmcanOrder.address = objChannelOrder.addr1_guest;
                frmcanOrder.address2 = objChannelOrder.addr2_guest;
                frmcanOrder.reservdate = objChannelOrder.Bdate.HasValue ? objChannelOrder.Bdate.Value : DateTime.Now;
                frmcanOrder.ShowDialog();
            }
        }
    }
}
