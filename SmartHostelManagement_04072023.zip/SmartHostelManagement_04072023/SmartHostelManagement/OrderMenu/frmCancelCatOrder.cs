﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EL = SMH.Entities.Layer;
using SMH.BusinessLogic.Layer;
using SMH.CommonLogic.Layer;

namespace SmartHostelManagement.Order
{
    public partial class frmCancelCatOrder : Form
    {
        DBData.ISIPMEntities dbContext = null;
        public bool IsCancelForm { get; set; }
        private List<DBData.ChannelOrderDet> lstdayWise = null;
        private List<DBData.ChannelOrder_cancelDetail> lstCanceldayWise = null;
        int rowDayIndex = -1;

        public int reservationId { get; set; }
        public int reservationnumber { get; set; }
        public string title { get; set; }
        public string cname { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
        public DateTime reservdate { get; set; }

        public frmCancelCatOrder()
        {
            InitializeComponent();
        }

        private void frmReservation_Load(object sender, EventArgs e)
        {
            using (dbContext = new DBData.ISIPMEntities())
            {
                if (IsCancelForm)
                    lstdayWise = dbContext.ChannelOrderDets.Where(x => x.ChannelOrder_Id == reservationId).ToList();
                else
                    lstCanceldayWise = dbContext.ChannelOrder_cancelDetail.Where(x => x.ChannelOrder_Id == reservationId).ToList();
            }

            txtEntryNo.Text = reservationnumber.ToString();
            txtCustName.Text = cname;
            txtAddress.Text = address;
            txtAddress2.Text = address2;
            dtmReservTo.Value = reservdate;
            pageRefereshControl();
            frmReservation_Load();
        }
        
        void pageRefereshControl()
        {
            dtmCancelledDate.Value = DateTime.Now;
            dtmDetUptoReserv.Value = DateTime.Now;
            txtOrderQty.Text = string.Empty;
            txtCancelQty.Text = string.Empty;
            txtRate.Text = string.Empty;
            txtItemList.Text = string.Empty;
            txtMenuName.Text = string.Empty;
            txtBuffetTYpe.Text = string.Empty;
            txtTotalamt.Text = string.Empty;
            txtDetRemarks.Text = string.Empty;

            if (!IsCancelForm)
            {
                dtmCancelledDate.Enabled = false;
                dtmDetUptoReserv.Enabled = false;
                txtOrderQty.Enabled = false;
                txtCancelQty.Enabled = false;
                txtRate.Enabled = false;
                txtItemList.Enabled = false;
                txtMenuName.Enabled = false;
                txtBuffetTYpe.Enabled = false;
                txtDetRemarks.Enabled = false;
                txtTotalamt.Enabled = false;
                btnAddChange.Enabled = false;
                btnUndo.Enabled = false;
                btnExist.Enabled = false;
                button1.Enabled = false;
            }
        }
        
        private void frmReservation_Load()
        {
            try
            {
                if (IsCancelForm)
                {
                    if (lstdayWise == null) new List<DBData.RESERVATION_DAYWISE_STATUS>();

                    var dbData = lstdayWise.Select((c, index) => new
                    {
                        SrNo = index + 1,
                        c.ChannelOrderdet_id,
                        ServeDate = c.date_ofdet.HasValue ? c.date_ofdet.Value.ToString("dd-MMM-yyyy") : string.Empty,
                        Qty = c.qty.HasValue ? c.qty.Value : 0,
                        Cancel_Qty = string.Empty,
                        Rate = c.rate.HasValue ? c.rate.Value : 0,
                        Menu = c.Food_Name,
                        Buffet = string.Empty,
                        Item_List = c.listmenuid,
                        TotalAmt = c.total_amt.HasValue ? c.total_amt.Value.ToString("0.00") : "0.00",
                        Remarks = c.notes
                    }).ToList();

                    dgvReservationDet.DataSource = dbData;
                    dgvReservationDet.Columns["ChannelOrderdet_id"].Visible = false;
                    dgvReservationDet.Columns["SlNo"].Frozen = true;
                }
                else
                {
                    if (lstCanceldayWise == null) new List<DBData.RESERVATION_DAYWISE_STATUS>();

                    var dbData = lstCanceldayWise.Select((c, index) =>
                    new
                    {
                        SrNo = index + 1,
                        c.Catering_daywiseCANCEL_status_id,
                        ForDate = c.date_ofdet.HasValue ? c.date_ofdet.Value.ToString("dd-MMM-yyyy") : string.Empty,
                        Qty = c.Qty.HasValue ? c.Qty.Value : 0,
                        Cancel_Qty = c.QtyCancel.HasValue ? c.QtyCancel.Value : 0,
                        Rate = c.rate.HasValue ? c.rate.Value : 0,
                        Menu = c.Food_Name,
                        Buffet = string.Empty,
                        Item_List = c.listmenuid,
                        TotalAmt = c.total_amt.HasValue ? c.total_amt.Value.ToString("0.00") : "0.00",
                        Remarks = c.notes
                    }).ToList();

                    dgvReservationDet.DataSource = dbData.ToList();
                    dgvReservationDet.Columns["Catering_daywiseCANCEL_status_id"].Visible = false;
                    dgvReservationDet.Columns["SlNo"].Frozen = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex,"-->Error on page load.");
            }
        } 
        
        //Edit
        private void btnExist_Click(object sender, EventArgs e)
        {
            if (dgvReservationDet.SelectedRows.Count > 0)
            {
                rowDayIndex = dgvReservationDet.SelectedRows[0].Index;
                var currLst = lstdayWise[rowDayIndex];
                dtmDetUptoReserv.Value = currLst.date_ofdet.HasValue ? currLst.date_ofdet.Value : DateTime.Now;
                txtOrderQty.Text = currLst.qty.HasValue ? currLst.qty.Value.ToString() : "1";
                txtCancelQty.Text = string.Empty;
                txtRate.Text = currLst.rate.HasValue ? currLst.rate.Value.ToString("0.00") : "0.00";
                txtMenuName.Text = currLst.Food_Name;
                txtBuffetTYpe.Text = string.Empty;
                txtItemList.Text = string.Empty;
                txtTotalamt.Text = currLst.total_amt.HasValue ? currLst.total_amt.Value.ToString("0.00") : "0.00";
                txtDetRemarks.Text = currLst.notes;
            }
        }

        //Add/Change
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                if (rowDayIndex > -1)
                {
                    if (lstCanceldayWise == null) lstCanceldayWise = new List<DBData.ChannelOrder_cancelDetail>();
                    using (dbContext = new DBData.ISIPMEntities())
                    {
                        int noHrs = (int)(dtmDetUptoReserv.Value - dtmCancelledDate.Value).TotalHours;
                        DBData.Reservation_cancel_policy objCancelPolicy = dbContext.Reservation_cancel_policy
                            .FirstOrDefault(x => x.Type == "5" && x.from_hrs <= noHrs && x.to_hrs >= noHrs);
                        if (objCancelPolicy != null)
                        {                            
                            double qtyItem = !string.IsNullOrEmpty(txtOrderQty.Text) ? Convert.ToDouble(txtOrderQty.Text) : 0;
                            double qtyCanItem = !string.IsNullOrEmpty(txtCancelQty.Text) ? Convert.ToDouble(txtCancelQty.Text) : 0;
                            double rateItem = !string.IsNullOrEmpty(txtRate.Text) ? Convert.ToDouble(txtRate.Text) : 0;
                            double totalCharge = qtyCanItem * (objCancelPolicy.AmtPERC.HasValue ? (objCancelPolicy.AmtPERC.Value * rateItem) / 100 : 0);
                            long maxId = dbContext.ChannelOrder_cancelDetail.Max(x => x.Catering_daywiseCANCEL_status_id) + 1;
                            if (lstCanceldayWise.Count > 0 && lstCanceldayWise.Any(x => x.Catering_daywiseCANCEL_status_id == maxId))
                            {
                                maxId = lstCanceldayWise.Max(x => x.Catering_daywiseCANCEL_status_id) + 1;
                            }

                            DBData.ChannelOrder_cancelDetail objCancelDay = new DBData.ChannelOrder_cancelDetail
                            {
                                Catering_daywiseCANCEL_status_id = maxId,
                                ChannelOrderdet_id = lstdayWise[rowDayIndex].ChannelOrderdet_id,
                                ChannelOrder_Id = reservationId,
                                date_ofdet = dtmDetUptoReserv.Value,
                                date_ofdetDate = dtmCancelledDate.Value,
                                Qty = (int)qtyItem,
                                QtyCancel = qtyCanItem,
                                Food_Name = txtMenuName.Text,
                                buffetname = txtBuffetTYpe.Text,
                                ItemList = txtItemList.Text,
                                rate = rateItem,
                                total_amt = qtyItem * rateItem,
                                notes = txtDetRemarks.Text,
                                listmenuid = lstdayWise[rowDayIndex].listmenuid,
                                Buffet_id = lstdayWise[rowDayIndex].Buffet_id,
                                Food_Id = lstdayWise[rowDayIndex].Food_Id,
                                cancel_hrs = noHrs,
                                Cancel_perc = objCancelPolicy.AmtPERC.HasValue ? objCancelPolicy.AmtPERC.Value : 0,
                                Cancel_charges = (objCancelPolicy.AmtPERC.HasValue ? (objCancelPolicy.AmtPERC.Value * rateItem) / 100 : 0),
                                Cancel_charges_ttl = totalCharge
                            };
                            lstCanceldayWise.Add(objCancelDay);
        
                            lstdayWise[rowDayIndex].qty = (int)(qtyItem - qtyCanItem);
                            lstdayWise[rowDayIndex].total_amt = rateItem * (qtyItem - qtyCanItem);
                            lstdayWise[rowDayIndex].ServiceTax = (CommonVariables.FoodGST * lstdayWise[rowDayIndex].total_amt) / 100;
                            lstdayWise[rowDayIndex].netamt = lstdayWise[rowDayIndex].total_amt + lstdayWise[rowDayIndex].ServiceTax;

                            pageRefereshControl();
                            frmReservation_Load();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Btn Add Change");
            }
        }

        //Save
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (dbContext = new DBData.ISIPMEntities())
                {
                    dbContext.Configuration.LazyLoadingEnabled = false;

                    var resultData = dbContext.ChannelOrderDets.Where(x => x.ChannelOrder_Id == reservationId);
                    double netAmount = 0; 
                    foreach (var items in resultData)
                    {
                        var objDay = lstdayWise.FirstOrDefault(x => x.ChannelOrderdet_id == items.ChannelOrderdet_id);
                        if (objDay != null)
                        {
                            items.qty = objDay.qty;
                            items.total_amt = objDay.total_amt;
                            items.ServiceTax = objDay.ServiceTax;
                            items.netamt = objDay.netamt;
                            netAmount = netAmount + (objDay.netamt.HasValue ? objDay.netamt.Value : 0);
                        }
                    }

                    var channelOrder = dbContext.ChannelOrders.FirstOrDefault(x => x.ChannelOrder_Id == reservationId);
                    if (channelOrder != null)
                        channelOrder.netpayable = netAmount;

                    dbContext.ChannelOrder_cancelDetail.AddRange(lstCanceldayWise);
                    
                    if (dbContext.SaveChanges() > 0)
                    {
                        CustomMessageBox.ShowInformationMessage("Record Save !", "DayWise Cancellation");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "Save Cancel Daywise");
            }
        }

        //Undo
        private void btnUndo_Click(object sender, EventArgs e)
        {
            pageRefereshControl();
            rowDayIndex = -1;
        }

        private void dgvReservationDet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex > -1)
                {
                    //var currLst = lstdayWise[e.RowIndex];
                    //rowDayIndex = e.RowIndex;
                    //dtmDetUptoReserv.Value = currLst.reservation_realCHECKIN.HasValue ? currLst.reservation_realCHECKIN.Value : DateTime.Now;
                    //txtOrderQty.Text = currLst.reservation_Rooms.HasValue ? currLst.reservation_Rooms.HasValue.ToString() : "1";
                    //txtCancelQty.Text = string.Empty;
                    //cmbDetDorm.SelectedValue = currLst.reservation_dormid.HasValue ? currLst.reservation_dormid.Value : 0;
                    //cmbDetRoomType.SelectedValue = currLst.RM_TYPE_ID1.HasValue ? currLst.RM_TYPE_ID1.Value : 0;
                    //txtMenuName.Text = currLst.ROOMrate2.HasValue ? currLst.ROOMrate1.Value.ToString("0.00") : "0.00";
                    //txtDetRemarks.Text = currLst.reservation_remark;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex, "dgvReservationDet_CellDoubleClick");
            }
        }

        private void txtOrderMaxQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            CommonBaseFN.CheckDigitOnly(e, 1);
        }
    }
}
